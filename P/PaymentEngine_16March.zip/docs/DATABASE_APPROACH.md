# Frontend Database Options for React — Sports Pay Pro

## Implementation status (current)

- **sql.js + IndexedDB is implemented** and used as the app database.
- **Entry:** `src/database/dbService.js` re-exports the sqlite layer; `main.jsx` calls `initDatabase()` before rendering.
- **Schema:** `src/database/sqliteSchema.js` — all tables for Sport Business, Talent, and Partner.
- **Persistence:** `src/database/indexedDBPersistence.js` — save/load DB binary to IndexedDB key `sports_pay_pro_sqlite`.
- **SQLite layer:** `src/database/sqliteDb.js` — same API as the old dbService (`getAll`, `getById`, `getAllByOrganization`, `create`, `update`, `remove`, `getDbRaw`, `resetDb`). Seeds from `seedData.js` when no saved DB exists.
- **WASM:** `public/sqljs/sql-wasm.wasm` (copied from `node_modules/sql.js/dist/`). If you reinstall sql.js, copy the file again or add a postinstall script.

---

## Requirement
- **No backend**: all data in the browser
- **Same structure** for Sport Business, Talent, and Partner portals
- **Sync across portals**: one source of truth (shared tables)
- **Seed from CSV/Excel**: e.g. `sample/ins_*.csv` for initial data

---

## Option Comparison

| Option | Pros | Cons | Best for |
|--------|------|------|----------|
| **sql.js** (SQLite WASM) | Full SQL, joins, indexes, transactions; same schema as SQLite; persist to IndexedDB; CSV import via INSERT | ~600KB WASM; save/load is async; need to persist after writes | **Recommended** — complex queries, three portals, CSV load |
| **Dexie.js** (IndexedDB) | Nice API, indexes, large storage, no WASM | No SQL; different mental model | Simple key-value or document store |
| **IndexedDB raw** | Native, large storage | Verbose API, no query language | When you need only get/put by key |
| **localStorage + JSON** | Simple, no deps, sync | ~5–10MB limit, no queries, manual filtering | Current approach; good for small data |

---

## Recommended: **sql.js + IndexedDB**

### Why sql.js fits Sports Pay Pro
1. **One schema, three portals** — Same tables (users, talents, contracts, salaryPayments, paymentLedger, etc.) used by Sport Business, Talent, and Partner; SQL `WHERE organizationId = ?` or `WHERE role = ?` gives per-portal views.
2. **React-friendly** — Init once (e.g. in `main.jsx` or a `DatabaseProvider`), then expose a `db` or service; components use the same `getAll(collection)`, `getAllByOrganization(collection, orgId)` API you have today.
3. **Persistence** — Export `db.export()` to `Uint8Array`, save to IndexedDB; on load, `new SQL.Database(savedArray)`. Data survives refresh and reopens.
4. **CSV / Excel import** — Parse `ins_*.csv` (e.g. with Papa Parse or XLSX), then run `INSERT INTO table (...) VALUES (...)` in a transaction. Same data can sync across portals because it’s one DB.
5. **Queries** — Aggregations, filters, and reporting (e.g. totals by talent, by month) are simple SQL instead of hand-written loops.

### Best practices
- **Init on app load** — Create/open DB in a root component or `main.jsx`; show a loading state until `initSqlJs` + schema + load from IndexedDB (or seed) is done.
- **Persist after writes** — After `CREATE`, `UPDATE`, `DELETE`, call `db.export()` and save to IndexedDB. Debounce (e.g. 300ms) if many rapid writes.
- **Keep API compatible** — Implement the same `getAll`, `getById`, `getAllByOrganization`, `create`, `update`, `remove` interface as your current `dbService.js` so the rest of the app does not need to change.
- **Seed from CSV** — Place files like `ins_users.csv`, `ins_talents.csv` in `public/sample/`; on first run or “Reset data”, fetch each file, parse, and run INSERTs (with conflict handling if needed).
- **WASM location** — In Vite, copy `node_modules/sql.js/dist/sql-wasm.wasm` to `public/` and set `locateFile: (file) => '/' + file` so the worker loads correctly.

---

## Schema (shared across portals)

Tables map to your current collections:

- `users` — id, email, password, role, name, talentId, organizationId
- `organizations` — id, name, createdAt
- `talents` — id, name, signingDate, signingBonus, releaseDate, signingBonusStatus, organizationId
- `sportsBusinesses` — id, businessName, revenueRecognized, revenueSharePercent, minimumGuarantee, talentsAssociated (JSON or separate table), organizationId
- `sponsorshipCompanies` — id, companyName, country, contractValue, royaltyRate, minimumGuarantee, organizationId
- `contracts` — id, contractID, talentId, talentName, licenseeId, licensee, sponsorId, annualSalary, basicSalary2026_27, basicSalary2027_28, royaltyPercent, signingBonus, startDate, endDate, status, organizationId, …
- `salaryPayments` — id, talentId, talentName, month, salaryAmount, paymentStatus, organizationId
- `signingBonuses` — id, talentId, talentName, amount, signingDate, releaseDate, status, organizationId
- `sales` — id, sku, licensee, productDescription, talentNames, talentIds (JSON), country, unitsSold, netSales, date, organizationId, …
- `invoices` — id, invoiceID, talentId, talentName, royaltyAmount, netSales, date, status, paidAmount, organizationId
- `paymentLedger` — id, date, transactionId, talentId, talentName, paymentType, amount, paymentMethod, status, details, organizationId

Store JSON columns (e.g. `talentsAssociated`, `talentIds`) as TEXT and parse in the app, or use a separate link table.

---

## File layout (sample data)

```
public/sample/
  ins_organizations.csv
  ins_users.csv
  ins_talents.csv
  ins_contracts.csv
  ins_salary_payments.csv
  ins_signing_bonuses.csv
  ins_sales.csv
  ins_invoices.csv
  ins_payment_ledger.csv
```

Naming: `ins_` = insert; load order can follow foreign keys (organizations first, then users/talents, then contracts, then payments).

---

## Summary

- **Choose: sql.js + IndexedDB** for a React-only app with one shared database, SQL, and CSV/Excel-based seed.
- **Approach:** Define schema once, persist to IndexedDB after changes, keep your existing `dbService`-style API, and load initial data from `sample/ins_*.csv` (and optionally Excel) so data stays in sync across all three portals.
