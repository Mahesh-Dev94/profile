import React from 'react'
import { Link, NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useAppStore } from '../../context/AppStore'
import { OrganizationSwitcher } from '../../components/OrganizationSwitcher'
import { Button } from '../../components/ui/button'
import {
  LayoutDashboard,
  FileText,
  Building2,
  Receipt,
  Upload,
  BarChart3,
  LogOut,
  Menu,
  ChevronLeft,
  Gift,
  CreditCard,
  FileSpreadsheet,
  TrendingUp,
  BookOpen,
  User,
  ChevronDown,
  PlusCircle,
} from 'lucide-react'
import { cn } from '../../utils/cn'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../../components/ui/dropdown-menu'

const adminNav = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/admin/organizations', label: 'Organizations', icon: Building2 },
  { to: '/admin/contracts', label: 'Contracts', icon: FileText },
  { to: '/admin/reconciliation', label: 'Reconciliation', icon: FileSpreadsheet },
  { to: '/admin/forecast', label: 'Forecast', icon: TrendingUp },
  { to: '/sponsorship/dashboard', label: 'Sponsorship portal', icon: CreditCard },
]

// Sport Business: 1-Dashboard, 2-Talents (one sub: Talent Contracts), 3-Payments (Salary, Signing Bonus, Royalties, Release, Ledger), 4-Journal
const sponsorshipNav = [
  { to: '/sponsorship/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sponsorship/talents', label: 'Talents', icon: User, children: [
    { to: '/sponsorship/talents/contracts', label: 'Talent Contracts', icon: FileText },
  ]},
  { to: '/sponsorship/payments', label: 'Payments', icon: CreditCard, children: [
    { to: '/sponsorship/payments/salary', label: 'Salary', icon: Receipt },
    { to: '/sponsorship/signing-bonus', label: 'Signing Bonus', icon: Gift },
    { to: '/sponsorship/royalties', label: 'Royalties', icon: TrendingUp },
    { to: '/sponsorship/payments/release-payment', label: 'Release Payment', icon: CreditCard },
    { to: '/sponsorship/payments/ledger', label: 'Payment Ledger', icon: BookOpen },
  ]},
  { to: '/sponsorship/journal-entry', label: 'Journal Entry', icon: PlusCircle },
]

const talentNav = [
  { to: '/talent/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/talent/salary', label: 'Salary', icon: Receipt },
  { to: '/talent/signing-bonus', label: 'Signing Bonus', icon: Gift },
  { to: '/talent/royalties', label: 'Royalties', icon: TrendingUp },
]

const partnerNav = [
  { to: '/partner/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/partner/upload-sales', label: 'Upload Sales', icon: Upload },
  { to: '/partner/sales', label: 'Sales', icon: BarChart3 },
  { to: '/partner/contracts', label: 'Contracts', icon: FileText },
]

export function MainLayout() {
  const { user, logout } = useAuth()
  const { sidebarOpen, toggleSidebar } = useAppStore()
  const navigate = useNavigate()
  const location = useLocation()
  const isAdminPath = location.pathname.startsWith('/admin')
  const isSponsorshipPath = location.pathname.startsWith('/sponsorship')
  const isTalentPath = location.pathname.startsWith('/talent')
  const isPartnerPath = location.pathname.startsWith('/partner')

  const nav =
    isAdminPath
      ? adminNav
      : isSponsorshipPath
      ? sponsorshipNav
      : isTalentPath
      ? talentNav
      : isPartnerPath
      ? partnerNav
      : adminNav

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <aside
        className={cn(
          'flex flex-col border-r border-gray-200 bg-white transition-all duration-200',
          sidebarOpen ? 'w-56' : 'w-16'
        )}
      >
        <div className="flex h-14 items-center justify-between border-b border-gray-200 px-4">
          <Link to="/" className="flex items-center justify-center text-primary hover:opacity-90" aria-label="Sports Pay Pro - Back to Home">
            <CreditCard className="h-8 w-8 shrink-0" />
          </Link>
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            {sidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-1 p-2 overflow-y-auto [&_a]:outline-none [&_a]:select-none [&_a]:transition-[color,background-color] [&_a]:duration-150 [&_a]:ease-out [&_a]:[-webkit-tap-highlight-color:transparent]">
          {isSponsorshipPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Sport Business</p>}
              {sponsorshipNav.map((item) => {
                const Icon = item.icon
                const showChildren = item.children && (location.pathname.startsWith(item.to) || (item.to === '/sponsorship/payments' && ['/sponsorship/signing-bonus', '/sponsorship/royalties'].includes(location.pathname)))
                const isPaymentParentActive = item.to === '/sponsorship/payments' && ['/sponsorship/signing-bonus', '/sponsorship/royalties'].includes(location.pathname)
                const isParentActive = location.pathname === item.to || isPaymentParentActive || (item.children && location.pathname.startsWith(item.to + '/'))
                return (
                  <div key={item.to} className="min-w-0">
                    <NavLink
                      to={item.to}
                      end={!item.children}
                      className={({ isActive }) => cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium w-full',
                        (isActive || isParentActive) ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100'
                      )}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                      {sidebarOpen && <span>{item.label}</span>}
                    </NavLink>
                    {sidebarOpen && item.children && showChildren && (
                      <div className="ml-4 mt-1 space-y-0.5 border-l border-gray-200 pl-3">
                        {item.children.map((child) => {
                          const ChildIcon = child.icon
                          return (
                            <NavLink
                              key={child.to}
                              to={child.to}
                              end
                              className={({ isActive }) => cn(
                                'flex items-center gap-2 rounded-lg px-2 py-1.5 text-xs font-medium',
                                isActive ? 'bg-primary text-white' : 'text-gray-600 hover:bg-gray-100'
                              )}
                            >
                              <ChildIcon className="h-4 w-4 shrink-0" />
                              <span>{child.label}</span>
                            </NavLink>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })}
            </>
          ) : isTalentPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Talent</p>}
              {talentNav.map((item) => {
                const Icon = item.icon
                return (
                  <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium', isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </NavLink>
                )
              })}
            </>
          ) : isPartnerPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Sponsorship Partner Vendor</p>}
              {partnerNav.map((item) => {
                const Icon = item.icon
                return (
                  <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium', isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </NavLink>
                )
              })}
            </>
          ) : (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Admin</p>}
              {adminNav.map((item) => {
                const Icon = item.icon
                return (
                  <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium', isActive ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </NavLink>
                )
              })}
            </>
          )}
        </nav>
        <div className="border-t border-gray-200 p-2 space-y-1">
          <Link to="/" className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 w-full', !sidebarOpen && 'justify-center')}>
            <CreditCard className="h-5 w-5 shrink-0" />
            {sidebarOpen && <span>Back to Home</span>}
          </Link>
          <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
            {sidebarOpen && <span>Logout</span>}
          </Button>
        </div>
      </aside>
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 items-center justify-between border-b border-gray-200 bg-white px-6">
          <h1 className="text-lg font-semibold text-gray-900">
            {(() => {
              const exact = nav.find((n) => n.to === location.pathname)?.label
              if (exact) return exact
              if (location.pathname === '/sponsorship/payments/salary') return 'Salary'
              if (location.pathname === '/sponsorship/signing-bonus') return 'Signing Bonus'
              if (location.pathname === '/sponsorship/royalties') return 'Royalties'
              if (location.pathname === '/sponsorship/payments/release-payment') return 'Release Payment'
              if (location.pathname === '/sponsorship/payments/ledger') return 'Payment Ledger'
              if (location.pathname === '/sponsorship/talents/contracts') return 'Talent Contracts'
              if (location.pathname.startsWith('/sponsorship/talents/') && location.pathname !== '/sponsorship/talents') return 'Talent detail'
              return isAdminPath ? 'Admin' : 'Dashboard'
            })()}
          </h1>
          <div className="flex items-center gap-3">
            {/* <OrganizationSwitcher /> */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 rounded-full pl-2 pr-3 py-1.5 hover:bg-gray-100" aria-label="User profile">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <User className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium text-gray-700 max-w-[140px] truncate">{user?.name || user?.email}</span>
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="left" className="w-72 rounded-lg shadow-lg">
                <div className="px-4 py-3 border-b border-gray-100">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">User information</p>
                  <p className="text-sm font-semibold text-gray-900">{user?.name || 'User'}</p>
                  <p className="text-xs text-gray-500 mt-0.5 truncate">{user?.email || '—'}</p>
                  <p className="text-xs text-primary font-medium mt-2">Login type: {user?.role?.replace(/_/g, ' ') || '—'}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer py-2.5" onSelect={() => { handleLogout(); }}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
