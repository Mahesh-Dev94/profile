import React from 'react'
import { Link, Outlet } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

export function AuthLayout() {
  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gray-200 p-4">
      <div className="w-full max-w-md space-y-4">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
          <ChevronLeft className="h-4 w-4" /> Back to Home
        </Link>
        <Outlet />
      </div>
    </div>
  )
}
