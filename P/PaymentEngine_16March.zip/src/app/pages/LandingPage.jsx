import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { CreditCard, User, Building2, ArrowRight } from 'lucide-react'
import { Button } from '../../components/ui/button'

// Sport Business theme — used for all cards (primary + accent)
const CARD_PRIMARY = '#0B3C5D'
const CARD_ACCENT = '#F97316'

const portals = [
  {
    id: 'sports_business',
    role: 'sponsorship_admin',
    title: 'Sport Business Payment',
    description: 'Manage salary, performance bonus, royalty & payments for your club. Release payments, view ledger and contracts.',
    icon: CreditCard,
    path: '/sponsorship/dashboard',
  },
  {
    id: 'talent',
    role: 'talent',
    title: 'Talent Portal',
    description: 'View your salary, signing bonus, royalties and payment history. Access payslips and tax details.',
    icon: User,
    path: '/talent/dashboard',
  },
  {
    id: 'partner',
    role: 'vendor_partner',
    title: 'Partner Vendor / Sponsorship',
    description: 'Manage sponsor partnerships, contracts and sales. Upload sales and track royalty contributions.',
    icon: Building2,
    path: '/partner/dashboard',
  },
]

function getSampleUserForRole(users, role) {
  if (!Array.isArray(users)) return null
  if (role === 'sponsorship_admin') return users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role)) || null
  if (role === 'talent') return users.find((u) => u.role === 'talent') || null
  if (role === 'vendor_partner') return users.find((u) => u.role === 'vendor_partner' || u.role === 'partner') || null
  return null
}

export function LandingPage() {
  const navigate = useNavigate()
  const { user, loginAsFirstUserForRole } = useAuth()
  const users = useMemo(() => getAll('users'), [])

  const handleEnter = (portal) => {
    const samePortal = user && (
      (portal.role === 'sponsorship_admin' && ['sponsorship_admin', 'sponsor_manager', 'platform_admin', 'finance_manager'].includes(user.role)) ||
      (portal.role === 'talent' && user.role === 'talent') ||
      (portal.role === 'vendor_partner' && ['vendor_partner', 'partner'].includes(user.role))
    )
    if (samePortal) {
      navigate(portal.path)
      return
    }
    const ok = loginAsFirstUserForRole(portal.role)
    if (ok.success) navigate(portal.path)
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <div className="relative max-w-6xl mx-auto px-6 py-12">
        <header className="text-center mb-16">
          <div
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6"
            style={{ backgroundColor: `${CARD_ACCENT}18`, color: CARD_ACCENT }}
          >
            <CreditCard className="w-9 h-9" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-3" style={{ color: CARD_PRIMARY }}>
            Sports Pay Pro
          </h1>
          <p className="text-lg text-gray-600 max-w-xl mx-auto">
            Royalty & Payment Management for Clubs, Talents and Partners
          </p>
          {user && (
            <p className="mt-4 text-sm text-gray-500">
              Signed in as {user.name} ·{' '}
              <button
                type="button"
                onClick={() => navigate(user.role === 'talent' ? '/talent/dashboard' : user.role === 'vendor_partner' || user.role === 'partner' ? '/partner/dashboard' : '/sponsorship/dashboard')}
                className="text-[#0B3C5D] font-medium hover:underline"
              >
                Go to my dashboard
              </button>
            </p>
          )}
        </header>

        <section className="grid md:grid-cols-3 gap-8">
          {portals.map((portal) => {
            const Icon = portal.icon
            return (
              <div
                key={portal.id}
                className="group relative rounded-2xl bg-white border border-gray-200 p-8 shadow-sm transition-all duration-300 hover:shadow-md hover:border-[#F97316]/50"
              >
                <div className="flex items-center gap-4 mb-5">
                  <div
                    className="flex items-center justify-center w-14 h-14 rounded-xl transition-opacity group-hover:opacity-90"
                    style={{ backgroundColor: `${CARD_ACCENT}20`, color: CARD_ACCENT }}
                  >
                    <Icon className="w-7 h-7" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900">{portal.title}</h2>
                </div>
                <p className="text-sm text-gray-600 mb-4 leading-relaxed">{portal.description}</p>
                {(() => {
                  const sample = getSampleUserForRole(users, portal.role)
                  return sample ? (
                    <p className="text-xs text-gray-500 mb-4 border border-gray-200 rounded-lg px-3 py-2 bg-gray-50">
                      Direct login: <span className="font-medium text-gray-800">{sample.name}</span>
                      {sample.email && <span className="block text-gray-400 truncate mt-0.5">{sample.email}</span>}
                    </p>
                  ) : null
                })()}
                <Button
                  onClick={() => handleEnter(portal)}
                  className="w-full text-white font-medium border-0 hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: CARD_ACCENT }}
                >
                  Enter <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )
          })}
        </section>

        <footer className="mt-20 text-center text-gray-400 text-xs">
          Sports Pay Pro — Secure payment and royalty management
        </footer>
      </div>
    </div>
  )
}
