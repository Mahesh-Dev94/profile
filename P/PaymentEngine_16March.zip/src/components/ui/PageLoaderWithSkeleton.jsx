import React from 'react'
import { cn } from '../../utils/cn'

/**
 * Full-page skeleton layout (cards + chart areas) with overlay spinner and message.
 * Use when loading; once loaded show real content and toast.
 */
export function PageLoaderWithSkeleton({ message = 'Loading...', className }) {
  return (
    <div className={cn('relative min-h-[400px]', className)}>
      {/* Background skeleton view */}
      <div className="space-y-6 animate-pulse">
        <div className="flex justify-end">
          <div className="h-9 w-28 rounded-md bg-gray-200" />
        </div>
        <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="rounded-lg border border-gray-200 bg-gray-50 p-4">
              <div className="h-4 w-20 rounded bg-gray-200 mb-3" />
              <div className="h-7 w-24 rounded bg-gray-200" />
            </div>
          ))}
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-6 min-h-[320px]">
            <div className="h-5 w-40 rounded bg-gray-200 mb-4" />
            <div className="h-[240px] rounded bg-gray-200" />
          </div>
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-6 min-h-[320px]">
            <div className="h-5 w-40 rounded bg-gray-200 mb-4" />
            <div className="h-[240px] rounded bg-gray-200" />
          </div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-6 min-h-[200px]">
          <div className="h-5 w-48 rounded bg-gray-200 mb-4" />
          <div className="h-4 rounded bg-gray-200 w-full mb-2" />
          <div className="h-4 rounded bg-gray-200 w-full mb-2" />
          <div className="h-4 rounded bg-gray-200 w-3/4" />
        </div>
      </div>

      {/* Overlay with spinner and text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 rounded-lg bg-white/80 backdrop-blur-[2px]">
        <div className="h-12 w-12 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        <p className="text-sm font-medium text-gray-700">{message}</p>
      </div>
    </div>
  )
}
