import React from 'react'
import { cn } from '../../utils/cn'

export function PageLoader({ message = 'Loading...', className }) {
  return (
    <div className={cn('flex min-h-[280px] flex-col items-center justify-center gap-4 p-8', className)}>
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      <p className="text-sm font-medium text-gray-600">{message}</p>
    </div>
  )
}
