import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ChartCard } from '../cards/ChartCard'

const COLORS = ['#0B3C5D', '#F97316', '#6B7280']

const monthTickFormatter = (v) => {
  if (!v || typeof v !== 'string') return v
  if (v.length >= 7) return `${v.slice(5, 7)}/${v.slice(0, 4)}`
  return v
}
const monthLabelFormatter = (l) => {
  if (!l || typeof l !== 'string') return l
  if (l.length >= 7) {
    const m = l.slice(5, 7)
    const y = l.slice(0, 4)
    const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    const idx = parseInt(m, 10) - 1
    const monthName = idx >= 0 && idx < 12 ? names[idx] : m
    return `${monthName} ${y}`
  }
  return l
}

export function MonthlyRevenueChart({ data = [], title, description, currency = 'USD', valueLabel = 'Revenue' }) {
  const yFormatter = (v) => (v >= 1000000 ? `$${(v / 1000000).toFixed(1)}M` : v >= 1000 ? `$${(v / 1000).toFixed(0)}k` : `$${v}`)
  const tooltipFormatter = (v) => [`$${Number(v).toLocaleString()}`, valueLabel]
  return (
    <ChartCard title={title || 'Monthly Trend'} description={description || 'By month'}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 11 }} tickFormatter={monthTickFormatter} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={yFormatter} />
          <Tooltip formatter={tooltipFormatter} labelFormatter={monthLabelFormatter} />
          <Bar dataKey="revenue" fill={COLORS[0]} radius={[4, 4, 0, 0]} name={valueLabel} />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
