import React, { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import toast from 'react-hot-toast'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'

// Portal labels per spec: Sport Business Payment Engine, Sponsorship / Partner Vendor, Talent Portal
const roles = [
  { value: 'sponsorship_admin', label: 'Sport Business Payment Engine' },
  { value: 'vendor_partner', label: 'Sponsorship / Partner Vendor' },
  { value: 'talent', label: 'Talent Portal' },
]

function getFirstUserForPortal(selectedRole, users) {
  if (!selectedRole || !Array.isArray(users)) return null
  if (selectedRole === 'talent') return users.find((u) => u.role === 'talent') || null
  if (selectedRole === 'vendor_partner') return users.find((u) => u.role === 'vendor_partner' || u.role === 'partner') || null
  return users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role)) || null
}

const schema = z.object({
  role: z.enum(['sponsorship_admin', 'vendor_partner', 'talent']),
  email: z.string().email('Invalid email'),
  password: z.string().min(1, 'Password required'),
})

function getDefaultPath(role) {
  if (role === 'sponsorship_admin') return '/sponsorship/dashboard'
  if (role === 'talent') return '/talent/dashboard'
  if (role === 'vendor_partner') return '/partner/dashboard'
  return '/'
}

const portalToRole = { sponsorship: 'sponsorship_admin', talent: 'talent', partner: 'vendor_partner' }

export function LoginPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const portalFromUrl = searchParams.get('portal')
  const { login } = useAuth()
  const {
    register,
    setValue,
    watch,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: { role: portalToRole[portalFromUrl] || '', email: '', password: '' },
    resolver: zodResolver(schema),
  })

  const selectedRole = watch('role')

  // Preselect portal from URL (?portal=sponsorship|talent|partner)
  useEffect(() => {
    const role = portalToRole[portalFromUrl]
    if (role) setValue('role', role)
  }, [portalFromUrl, setValue])

  // Auto-fill credentials using the first record in the database for selected portal
  useEffect(() => {
    if (!selectedRole) return
    const users = getAll('users')
    const first = getFirstUserForPortal(selectedRole, users)
    if (first) {
      setValue('email', first.email)
      setValue('password', first.password)
    }
  }, [selectedRole, setValue])

  const onSubmit = (data) => {
    const result = login(data.email, data.password, data.role)
    if (result.success) {
      toast.success('Signed in successfully')
      navigate(getDefaultPath(data.role))
    } else {
      toast.error(result.error || 'Login failed')
    }
  }

  return (
    <Card className="border border-gray-200 bg-white shadow-lg">
      <CardHeader className="space-y-1 text-center p-5">
        <CardTitle className="text-lg font-bold text-primary">Sports Pay Pro</CardTitle>
        <p className="text-xs text-neutral">Sign in to your account — credentials auto-fill by portal</p>
        <p className="text-2xs text-gray-400 mt-0.5">Royalty &amp; Payment Management</p>
      </CardHeader>
      <CardContent className="p-5 pt-0">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs">Portal</Label>
            <Select
              value={watch('role') || undefined}
              onValueChange={(v) => setValue('role', v)}
            >
              <SelectTrigger className="text-sm h-8">
                <SelectValue placeholder="Select portal" />
              </SelectTrigger>
              <SelectContent>
                {roles.map((r) => (
                  <SelectItem key={r.value} value={r.value} className="text-sm">
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-2xs text-neutral">Select portal to auto-fill credentials (first user in database).</p>
          </div>
          <div className="space-y-1">
            <Label htmlFor="email" className="text-xs">Email</Label>
            <Input
              id="email"
              type="email"
              className="text-sm h-8"
              placeholder="you@example.com"
              {...register('email')}
            />
            {errors.email && (
              <p className="text-2xs text-red-600">{errors.email.message}</p>
            )}
          </div>
          <div className="space-y-1">
            <Label htmlFor="password" className="text-xs">Password</Label>
            <Input
              id="password"
              type="password"
              className="text-sm h-8"
              placeholder="••••••••"
              {...register('password')}
            />
            {errors.password && (
              <p className="text-2xs text-red-600">{errors.password.message}</p>
            )}
          </div>
          <Button type="submit" className="w-full text-sm h-9 bg-accent text-white hover:bg-accent/90">
            Sign in
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
