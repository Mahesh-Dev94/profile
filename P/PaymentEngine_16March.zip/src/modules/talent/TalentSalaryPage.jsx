import React, { useMemo, useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { Button } from '../../components/ui/button'
import { SalarySlipPDFViewer } from '../../components/forms/SalarySlipPDFViewer'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { downloadSalarySlipPDF } from '../../utils/pdfGenerator'
import { FileText, Download } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function TalentSalaryPage() {
  const { user } = useAuth()
  const { loading, loadMessage } = usePageLoadAuto('Loading your salary records...', 'Salary data loaded')
  const talentId = user?.talentId
  const salaryPayments = useMemo(() => (getAll('salaryPayments') || []).filter((s) => s.talentId === talentId), [talentId])
  const [viewingSlip, setViewingSlip] = useState(null)

  const columns = [
    { id: 'month', header: 'Month', accessorKey: 'month', cell: (info) => String(info.getValue() || '').replace(/(\d{4})-(\d{2})/, '$2/$1') },
    { id: 'salaryAmount', header: 'Salary Amount ($)', accessorKey: 'salaryAmount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'paymentStatus', header: 'Payment Status', accessorKey: 'paymentStatus', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
    { id: 'actions', header: 'Actions', cell: ({ row }) => (
      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="bg-primary text-white hover:bg-primary/90 border-primary" onClick={() => setViewingSlip(row.original)}>
          <FileText className="h-4 w-4 mr-1" /> View Salary PDF
        </Button>
        <Button variant="outline" size="sm" onClick={() => downloadSalarySlipPDF(row.original, 'Sports Business')}>
          <Download className="h-4 w-4 mr-1" /> Download PDF
        </Button>
      </div>
    )},
  ]

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Salary</h2>
      <p className="text-sm text-neutral">Your monthly salary records. View or download salary slip PDF.</p>
      <DataTable columns={columns} data={salaryPayments} searchKey="month" searchPlaceholder="Search by month..." />
      <SalarySlipPDFViewer open={!!viewingSlip} onOpenChange={(v) => !v && setViewingSlip(null)} salaryRecord={viewingSlip} businessName="Sports Business" />
    </div>
  )
}
