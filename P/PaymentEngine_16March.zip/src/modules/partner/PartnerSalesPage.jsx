import React, { useState, useMemo } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { getAll } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { DataTable } from '../../components/tables/DataTable'
import { FilterPanel } from '../../components/filters/FilterPanel'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import Papa from 'papaparse'

const ALL_VALUE = '__all__'

export function PartnerSalesPage() {
  const { loading: pageLoading, loadMessage } = usePageLoadAuto('Loading sales data...', 'Sales data loaded')
  const { data } = useDatabase('sales')
  const sales = Array.isArray(data) ? data : []
  const [licenseeFilter, setLicenseeFilter] = useState([])
  const [countryFilter, setCountryFilter] = useState(ALL_VALUE)
  const [productFilter, setProductFilter] = useState('')

  const licensees = useMemo(() => [...new Set(sales.map((s) => s.licensee).filter(Boolean))], [sales])
  const countries = useMemo(() => [...new Set(sales.map((s) => s.country).filter(Boolean))], [sales])

  const filtered = useMemo(() => {
    return sales.filter((s) => {
      if (licenseeFilter.length > 0 && !licenseeFilter.includes(s.licensee)) return false
      if (countryFilter && countryFilter !== ALL_VALUE && s.country !== countryFilter) return false
      if (productFilter && !(s.productDescription || s.sku || '').toLowerCase().includes(productFilter.toLowerCase())) return false
      return true
    })
  }, [sales, licenseeFilter, countryFilter, productFilter])

  const contracts = getAll('contracts')
  const talents = getAll('talents')
  const sportsBusinesses = getAll('sportsBusinesses')
  const invoices = getAll('invoices')
  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const royaltyTotal = ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyEarned = (invoices || []).reduce((a, i) => a + (Number(i.paidAmount) || 0), 0)
  const royaltyPending = Math.max(0, royaltyTotal - royaltyEarned)

  const monthlyData = useMemo(() => {
    const byMonth = {}
    sales.forEach((s) => {
      const d = s.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [sales])
  const countryData = useMemo(() => {
    const byCountry = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      byCountry[c] = (byCountry[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byCountry).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])
  const salesByClub = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const club = s.licensee || 'Other'
      map[club] = (map[club] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6)
  }, [sales])

  const filters = [
    {
      key: 'licensee',
      label: 'Licensee',
      type: 'multicheckbox',
      value: licenseeFilter,
      onChange: setLicenseeFilter,
      options: licensees.map((l) => ({ value: l, label: l })),
    },
    {
      key: 'country',
      label: 'Country',
      type: 'select',
      value: countryFilter || ALL_VALUE,
      onChange: setCountryFilter,
      options: [{ value: ALL_VALUE, label: 'All' }, ...countries.map((c) => ({ value: c, label: c }))],
      placeholder: 'All',
    },
  ]

  const columns = [
    { id: 'sku', header: 'SKU', accessorKey: 'sku' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'productDescription', header: 'Product', accessorKey: 'productDescription' },
    { id: 'country', header: 'Country', accessorKey: 'country' },
    { id: 'currency', header: 'Currency', accessorKey: 'currency' },
    { id: 'unitsSold', header: 'Units', accessorKey: 'unitsSold' },
    { id: 'effectiveUnitSalesPrice', header: 'Unit Price', accessorKey: 'effectiveUnitSalesPrice', cell: (info) => `$${Number(info.getValue()).toFixed(2)}` },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'typeOfSales', header: 'Type', accessorKey: 'typeOfSales' },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const exportCSV = () => {
    const keys = columns.map((c) => c.accessorKey || c.id).filter(Boolean)
    const rows = filtered.map((row) => keys.map((k) => row[k] ?? ''))
    const csv = Papa.unparse({ fields: keys, data: rows })
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `sales-export-${new Date().toISOString().slice(0, 10)}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  if (pageLoading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-xl font-semibold">Sales</h2>
        <Button variant="outline" onClick={exportCSV}>Export CSV</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Royalty Total" value={`$${royaltyTotal.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Royalty Paid" value={`$${royaltyEarned.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryData} />
      </div>
      {salesByClub.length > 0 && (
        <div className="lg:max-w-lg rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <h3 className="mb-4 text-base font-medium">Sales by Sports Business (Club)</h3>
          <RoyaltyDistributionChart data={salesByClub} />
        </div>
      )}
      <div className="flex gap-6">
        <FilterPanel
          filters={filters}
          onApply={() => {}}
          onReset={() => { setLicenseeFilter([]); setCountryFilter(ALL_VALUE); setProductFilter(''); }}
        />
        <div className="flex-1 space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Search product..."
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
            />
          </div>
          <DataTable
            columns={columns}
            data={filtered}
            searchKey="sku"
            searchPlaceholder="Search by SKU, licensee..."
            pageSize={15}
          />
        </div>
      </div>
    </div>
  )
}
