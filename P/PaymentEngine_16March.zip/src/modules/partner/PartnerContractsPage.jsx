import React, { useState } from 'react'
import { getAll } from '../../database/dbService'
import { downloadVendorAgreementPDF } from '../../utils/pdfGenerator'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { Button } from '../../components/ui/button'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { FileDown } from 'lucide-react'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

/**
 * Contracts between Sponsorship / Partner Vendor (company) and Sports Business (club).
 * Includes SKU minimum guarantee (Annual). PDF = vendor agreement with signature block.
 */
export function PartnerContractsPage() {
  const { loading, loadMessage } = usePageLoadAuto('Loading contracts...', 'Contracts loaded')
  const contracts = getAll('contracts')
  const sponsors = getAll('sponsorshipCompanies')

  const sponsorName = (sponsorId) => {
    const s = sponsors.find((x) => x.id === sponsorId)
    return s?.companyName || sponsorId || '—'
  }

  const columns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'sponsorName', header: 'Sponsor / Partner (Company)', cell: ({ row }) => sponsorName(row.original.sponsorId) },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'contractPeriod', header: 'Contract Period', cell: ({ row }) => `${formatDisplayDate(row.original.startDate)} – ${formatDisplayDate(row.original.endDate)}` },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => info.getValue() != null ? `${((info.getValue()) * 100).toFixed(2)}%` : '—' },
    { id: 'skuMinimumGuaranteeAnnual', header: 'SKU Min. Guarantee (Annual)', accessorKey: 'skuMinimumGuaranteeAnnual', cell: ({ row }) => { const val = row.original.skuMinimumGuaranteeAnnual ?? row.original.minimumGuarantee; return val != null && val !== '' ? formatINRDisplay(val) : '—'; } },
    { id: 'productLicensing', header: 'Product / Licensing', cell: () => 'Licensed products' },
    { id: 'revenueShare', header: 'Revenue Share', cell: ({ row }) => row.original.royaltyPercent != null ? `${((row.original.royaltyPercent) * 100).toFixed(2)}% royalty` : '—' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewPdfContract(row.original)}>
          <FileDown className="mr-1 h-4 w-4" /> View PDF
        </Button>
      ),
    },
  ]

  const [viewPdfContract, setViewPdfContract] = useState(null)

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Contracts</h2>
      <p className="text-sm text-neutral">Agreements between Sponsorship / Partner Vendor (company) and Sports Business (club). Product licensing and revenue share.</p>
      <DataTable columns={columns} data={contracts} searchKey="contractID" searchPlaceholder="Search contracts..." />
      <ContractPDFViewer
        open={!!viewPdfContract}
        onOpenChange={(v) => !v && setViewPdfContract(null)}
        contract={viewPdfContract}
        vendorAgreement
        sponsorCompanyName={viewPdfContract ? sponsorName(viewPdfContract.sponsorId) : undefined}
        onDownloadPDF={(c) => downloadVendorAgreementPDF(c, sponsorName(c?.sponsorId), c?.licensee)}
      />
    </div>
  )
}
