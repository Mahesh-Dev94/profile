import React, { useState } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { UploadZone } from '../../components/forms/UploadZone'
import { parseSalesFile } from '../../utils/parseSalesFile'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { getAll } from '../../database/dbService'
import { Download } from 'lucide-react'

export function PartnerUploadSalesPage() {
  const { loading: pageLoad, loadMessage } = usePageLoadAuto('Loading upload...', 'Upload page loaded')
  const { create, refresh } = useDatabase('sales')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState({ success: 0, failed: 0, errors: [] })

  const talents = getAll('talents')

  const mapTalentIds = (talentNamesStr) => {
    if (!talentNamesStr) return []
    const names = String(talentNamesStr).split(',').map((n) => n.trim()).filter(Boolean)
    return names.map((name) => talents.find((t) => t.name === name)?.id).filter(Boolean)
  }

  const handleFile = async (file) => {
    setLoading(true)
    setResult({ success: 0, failed: 0, errors: [] })
    try {
      const rows = await parseSalesFile(file)
      let success = 0
      const errors = []
      for (const row of rows) {
        try {
          const talentIds = mapTalentIds(row.talentNames)
          create({
            ...row,
            talentIds,
          })
          success++
        } catch (e) {
          errors.push(e.message || String(e))
        }
      }
      setResult({ success, failed: rows.length - success, errors })
      refresh()
    } catch (err) {
      setResult({ success: 0, failed: 0, errors: [err.message || String(err)] })
    } finally {
      setLoading(false)
    }
  }

  if (pageLoad) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Upload Sales</h2>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">CSV / Excel Upload</CardTitle>
          <p className="text-sm text-neutral">
            Columns: ID, SKU, Licensee, ProductDescription, TalentNames, Country, Currency, UnitsSold, EffectiveUnitSalesPrice, NetSales, TypeOfSales, Date
          </p>
          <a href="/sample/sales.csv" download="sales-sample.csv" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
            <Download className="h-4 w-4" /> Download sample sales.csv
          </a>
        </CardHeader>
        <CardContent>
          <UploadZone onFile={handleFile} disabled={loading} />
          {loading && <p className="mt-2 text-sm text-neutral">Processing...</p>}
          {result.success > 0 && (
            <p className="mt-2 text-sm text-green-600">{result.success} row(s) imported.</p>
          )}
          {result.failed > 0 && (
            <p className="mt-1 text-sm text-amber-600">{result.failed} row(s) failed.</p>
          )}
          {result.errors?.length > 0 && (
            <ul className="mt-1 list-inside list-disc text-xs text-red-600">
              {result.errors.slice(-5).map((e, i) => (
                <li key={i}>{e}</li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
