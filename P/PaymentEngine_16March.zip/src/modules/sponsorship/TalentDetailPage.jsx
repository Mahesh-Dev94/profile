import React, { useMemo, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { useOrganizationData } from '../../hooks/useOrganizationData'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getAnnualSalaryTotal, getPaidSalaryTotal, getPendingSalaryTotal } from '../../utils/salaryCalculator'
import { processSalaryPayment, processSigningBonusPayment, processRoyaltyPayment, recordPaymentLedgerEntry } from '../../utils/paymentProcessor'
import { downloadContractPDF } from '../../utils/pdfGenerator'
import { ContractViewer } from '../../components/forms/ContractViewer'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { ContractDetailsViewer } from '../../components/forms/ContractDetailsViewer'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { PaymentModal } from '../../components/PaymentModal'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { User, FileText, DollarSign, Gift, TrendingUp, ArrowLeft, Plus, Pencil, Trash2, FileSpreadsheet } from 'lucide-react'
import { format } from 'date-fns'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { formatDisplayDate } from '../../utils/dateFormat'
import toast from 'react-hot-toast'
import { Badge } from '../../components/ui/badge'

function aggregateSalaryByMonth(salaryPayments) {
  const byMonth = {}
  ;(salaryPayments || []).forEach((s) => {
    const key = s.month || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.salaryAmount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function TalentDetailPage() {
  const { talentId } = useParams()
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading talent details...', 'Loaded')

  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])

  const { data: contractsData, create: createContract, update: updateContract, remove: removeContract } = useOrganizationData('contracts')
  const talent = useMemo(() => (talents || []).find((t) => t.id === talentId), [talents, talentId])
  const contract = useMemo(() => (contractsData || []).find((c) => c.talentId === talentId), [contractsData, talentId])
  const sponsorshipCompanies = useMemo(() => getAllByOrganization('sponsorshipCompanies', currentOrganizationId), [currentOrganizationId])

  const mySalaryPayments = useMemo(() => (salaryPayments || []).filter((s) => s.talentId === talentId), [salaryPayments, talentId])
  const mySigningBonuses = useMemo(() => (signingBonuses || []).filter((b) => b.talentId === talentId), [signingBonuses, talentId])
  const ledger = useMemo(() => buildRoyaltyLedger(sales, contractsData || [], talents, sportsBusinesses), [sales, contractsData, talents, sportsBusinesses])
  const myLedger = useMemo(() => ledger.filter((r) => r.talentId === talentId), [ledger, talentId])
  const myInvoices = useMemo(() => (invoices || []).filter((inv) => inv.talentId === talentId), [invoices, talentId])

  const annualSalary = useMemo(() => getAnnualSalaryTotal(mySalaryPayments), [mySalaryPayments])
  const paidSalary = useMemo(() => getPaidSalaryTotal(mySalaryPayments), [mySalaryPayments])
  const pendingSalary = useMemo(() => getPendingSalaryTotal(mySalaryPayments), [mySalaryPayments])
  const signingBonusTotal = useMemo(() => (mySigningBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [mySigningBonuses])
  const signingBonusPaid = useMemo(() => (mySigningBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [mySigningBonuses])
  const royaltyTotal = useMemo(() => myInvoices.reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0), [myInvoices])
  const royaltyPaid = useMemo(() => myInvoices.reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [myInvoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const salaryMonthlyData = useMemo(() => aggregateSalaryByMonth(mySalaryPayments), [mySalaryPayments])
  const royaltyMonthlyData = useMemo(() => {
    const byMonth = {}
    myLedger.forEach((r) => {
      const d = r.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [myLedger])

  const pendingSalaryList = useMemo(() => mySalaryPayments.filter((s) => s.paymentStatus === 'pending'), [mySalaryPayments])
  const pendingBonusList = useMemo(() => mySigningBonuses.filter((b) => b.status === 'pending'), [mySigningBonuses])
  const pendingRoyaltyList = useMemo(() => myInvoices.filter((inv) => (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0) > 0), [myInvoices])

  const totalPendingAmount = useMemo(() => {
    let sum = pendingSalaryList.reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)
    sum += pendingBonusList.reduce((a, b) => a + (Number(b.amount) || 0), 0)
    pendingRoyaltyList.forEach((inv) => {
      sum += (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
    })
    return sum
  }, [pendingSalaryList, pendingBonusList, pendingRoyaltyList])

  const [paymentModal, setPaymentModal] = useState(null)
  const [viewContract, setViewContract] = useState(null)
  const [viewPdfContract, setViewPdfContract] = useState(null)
  const [viewDetailsContract, setViewDetailsContract] = useState(null)
  const [contractDialogOpen, setContractDialogOpen] = useState(false)
  const [editingContract, setEditingContract] = useState(null)
  const [contractForm, setContractForm] = useState({
    contractID: '',
    talentId: '',
    licenseeId: '',
    sponsorId: '',
    basicSalary2026_27: '',
    basicSalary2027_28: '',
    signingBonus: '',
    royaltyPercent: '',
    startDate: '',
    endDate: '',
    status: 'active',
  })

  const resetContractForm = () => {
    setContractForm({
      contractID: '',
      talentId: talentId || '',
      licenseeId: '',
      sponsorId: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
    })
    setEditingContract(null)
    setContractDialogOpen(false)
  }

  const openEditContract = (row) => {
    setEditingContract(row)
    setContractForm({
      contractID: row.contractID || '',
      talentId: row.talentId || '',
      licenseeId: row.licenseeId || '',
      sponsorId: row.sponsorId || '',
      basicSalary2026_27: String(row.basicSalary2026_27 ?? row.annualSalary ?? ''),
      basicSalary2027_28: String(row.basicSalary2027_28 ?? row.annualSalary ?? ''),
      signingBonus: String(row.signingBonus ?? ''),
      royaltyPercent: String((row.royaltyPercent ?? 0) * 100),
      startDate: row.startDate || '',
      endDate: row.endDate || '',
      status: row.status || 'active',
    })
    setContractDialogOpen(true)
  }

  const openAddContract = () => {
    setEditingContract(null)
    setContractForm({
      contractID: '',
      talentId: talentId || '',
      licenseeId: '',
      sponsorId: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
    })
    setContractDialogOpen(true)
  }

  const handleContractSubmit = (e) => {
    e.preventDefault()
    const talentObj = talents.find((t) => t.id === contractForm.talentId)
    const licenseeBiz = sportsBusinesses.find((b) => b.id === contractForm.licenseeId)
    const annualSalary = Number(contractForm.basicSalary2026_27) || 0
    const payload = {
      contractID: contractForm.contractID || `CNT-${Date.now()}`,
      talentId: contractForm.talentId,
      talentName: talentObj?.name || '',
      licenseeId: contractForm.licenseeId,
      licensee: licenseeBiz?.businessName || '',
      sponsorId: contractForm.sponsorId,
      organizationId: currentOrganizationId,
      annualSalary,
      basicSalary2026_27: Number(contractForm.basicSalary2026_27) || 0,
      basicSalary2027_28: Number(contractForm.basicSalary2027_28) || 0,
      signingBonus: Number(contractForm.signingBonus) || 0,
      royaltyPercent: Number(contractForm.royaltyPercent) / 100 || 0,
      startDate: contractForm.startDate,
      endDate: contractForm.endDate,
      status: contractForm.status,
    }
    if (editingContract) {
      updateContract(editingContract.id, payload)
      toast.success('Contract updated')
    } else {
      createContract(payload)
      toast.success('Contract created')
    }
    resetContractForm()
  }

  const handleRemoveContract = (id) => {
    removeContract(id)
    toast.success('Contract removed')
    resetContractForm()
  }

  const handleReleasePayment = () => {
    if (totalPendingAmount <= 0) {
      toast.error('No pending amount to pay')
      return
    }
    setPaymentModal({
      amount: totalPendingAmount,
      title: `Release payment — ${talent?.name || 'Talent'}`,
    })
  }

  const handlePaymentSuccess = ({ amount, paymentMethod }) => {
    if (!talent) return
    try {
      pendingSalaryList.forEach((s) => processSalaryPayment(s, paymentMethod, currentOrganizationId))
      pendingBonusList.forEach((b) => processSigningBonusPayment(b, paymentMethod, currentOrganizationId))
      pendingRoyaltyList.forEach((inv) => {
        const due = (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
        if (due > 0) processRoyaltyPayment(inv, due, paymentMethod, currentOrganizationId)
      })
      recordPaymentLedgerEntry({
        organizationId: currentOrganizationId,
        talentId: talent.id,
        talentName: talent.name,
        paymentType: 'Release Payment',
        amount,
        paymentMethod,
        details: 'Single payment done',
      })
      toast.success('Release payment recorded')
      setPaymentModal(null)
      setTimeout(() => window.location.reload(), 600)
    } catch (e) {
      toast.error('Failed to record payment')
      setPaymentModal(null)
    }
  }

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />
  if (!talent) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/sponsorship/talents')}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Talents</Button>
        <p className="text-neutral">Talent not found.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/sponsorship/talents')}><ArrowLeft className="h-4 w-4 mr-1" /> Back to Talents</Button>
      </div>

      {/* Talent info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <User className="h-5 w-5" />
            </div>
            {talent.name}
          </CardTitle>
          <p className="text-sm text-neutral">Signing date: {talent.signingDate || '—'} · Release date: {talent.releaseDate || '—'} · Signing bonus status: {talent.signingBonusStatus || '—'}</p>
        </CardHeader>
      </Card>

      {/* Talent Contract – full info and actions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Talent Contract
          </CardTitle>
          <div className="flex gap-2">
            {contract ? (
              <>
                <Button variant="outline" size="sm" onClick={() => setViewContract(contract)} title="View details"><FileText className="h-4 w-4 mr-1" /> View details</Button>
                <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewPdfContract(contract)}>View PDF</Button>
                <Button variant="outline" size="sm" onClick={() => setViewDetailsContract(contract)}><FileSpreadsheet className="h-4 w-4 mr-1" /> View contract detailed info</Button>
                <Button variant="outline" size="sm" onClick={() => openEditContract(contract)}><Pencil className="h-4 w-4 mr-1" /> Edit</Button>
                <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" onClick={() => handleRemoveContract(contract.id)}><Trash2 className="h-4 w-4 mr-1" /> Delete</Button>
              </>
            ) : (
              <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={openAddContract}><Plus className="h-4 w-4 mr-1" /> Add contract</Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {contract ? (
            <div className="grid gap-2 text-sm border rounded-lg p-4 bg-gray-50">
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <p><span className="text-neutral">Contract ID:</span> <span className="font-medium">{contract.contractID}</span></p>
                <p><span className="text-neutral">Status:</span> <Badge variant={contract.status === 'active' ? 'success' : 'secondary'}>{contract.status}</Badge></p>
                <p><span className="text-neutral">Talent:</span> {contract.talentName}</p>
                <p><span className="text-neutral">Licensee (Club):</span> {contract.licensee}</p>
                <p><span className="text-neutral">Start date:</span> {formatDisplayDate(contract.startDate)}</p>
                <p><span className="text-neutral">End date:</span> {formatDisplayDate(contract.endDate)}</p>
                <p><span className="text-neutral">Basic Salary 2026-27:</span> {formatINRDisplay(contract.basicSalary2026_27 ?? contract.annualSalary)}</p>
                <p><span className="text-neutral">Basic Salary 2027-28:</span> {formatINRDisplay(contract.basicSalary2027_28)}</p>
                <p><span className="text-neutral">Signing bonus:</span> {formatINRDisplay(contract.signingBonus)}</p>
                <p><span className="text-neutral">Royalty %:</span> {contract.royaltyPercent != null ? (Number(contract.royaltyPercent) * 100).toFixed(2) : '—'}%</p>
              </div>
              <Button variant="ghost" size="sm" className="mt-2 justify-start" onClick={() => navigate('/sponsorship/talents/contracts')}>View all contracts</Button>
            </div>
          ) : (
            <p className="text-sm text-neutral">No contract for this talent. Click &quot;Add contract&quot; to create one.</p>
          )}
        </CardContent>
      </Card>

      {/* Create / Edit contract dialog */}
      <Dialog open={contractDialogOpen} onOpenChange={(v) => !v && resetContractForm()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingContract ? 'Edit Contract' : 'Add Contract'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleContractSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Contract ID</Label>
              <Input value={contractForm.contractID} onChange={(e) => setContractForm((f) => ({ ...f, contractID: e.target.value }))} placeholder="CNT-2024-001" />
            </div>
            <div className="space-y-2">
              <Label>Talent</Label>
              <Select value={contractForm.talentId} onValueChange={(v) => setContractForm((f) => ({ ...f, talentId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select talent" /></SelectTrigger>
                <SelectContent>
                  {(talents || []).map((t) => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sports Business (Club)</Label>
              <Select value={contractForm.licenseeId} onValueChange={(v) => setContractForm((f) => ({ ...f, licenseeId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select club" /></SelectTrigger>
                <SelectContent>
                  {(sportsBusinesses || []).map((b) => (<SelectItem key={b.id} value={b.id}>{b.businessName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sponsor</Label>
              <Select value={contractForm.sponsorId} onValueChange={(v) => setContractForm((f) => ({ ...f, sponsorId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select sponsor" /></SelectTrigger>
                <SelectContent>
                  {(sponsorshipCompanies || []).map((c) => (<SelectItem key={c.id} value={c.id}>{c.companyName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Basic Salary 2026-27 ($)</Label>
                <Input type="number" value={contractForm.basicSalary2026_27} onChange={(e) => setContractForm((f) => ({ ...f, basicSalary2026_27: e.target.value }))} placeholder="e.g. 18000000" />
              </div>
              <div className="space-y-2">
                <Label>Basic Salary 2027-28 ($)</Label>
                <Input type="number" value={contractForm.basicSalary2027_28} onChange={(e) => setContractForm((f) => ({ ...f, basicSalary2027_28: e.target.value }))} placeholder="e.g. 20000000" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Signing Bonus ($)</Label>
              <Input type="number" value={contractForm.signingBonus} onChange={(e) => setContractForm((f) => ({ ...f, signingBonus: e.target.value }))} placeholder="e.g. 3000000" />
            </div>
            <div className="space-y-2">
              <Label>Royalty %</Label>
              <Input type="number" step="0.01" value={contractForm.royaltyPercent} onChange={(e) => setContractForm((f) => ({ ...f, royaltyPercent: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input type="date" value={contractForm.startDate} onChange={(e) => setContractForm((f) => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input type="date" value={contractForm.endDate} onChange={(e) => setContractForm((f) => ({ ...f, endDate: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={contractForm.status} onValueChange={(v) => setContractForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetContractForm}>Cancel</Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ContractViewer open={!!viewContract} onOpenChange={(v) => !v && setViewContract(null)} contract={viewContract} onGeneratePDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)} />
      <ContractPDFViewer open={!!viewPdfContract} onOpenChange={(v) => !v && setViewPdfContract(null)} contract={viewPdfContract} onDownloadPDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)} />
      <ContractDetailsViewer open={!!viewDetailsContract} onOpenChange={(v) => !v && setViewDetailsContract(null)} contract={viewDetailsContract} />

      {/* Calculation cards (like dashboard for single talent) */}
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="Salary (total)" value={formatINRDisplay(annualSalary)} icon={DollarSign} />
        <StatCard title="Salary paid" value={formatINRDisplay(paidSalary)} icon={DollarSign} />
        <StatCard title="Salary pending" value={formatINRDisplay(pendingSalary)} icon={DollarSign} />
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="Signing bonus" value={formatINRDisplay(signingBonusTotal)} icon={Gift} />
        <StatCard title="Royalty total" value={formatINRDisplay(royaltyTotal)} icon={TrendingUp} />
        <StatCard title="Royalty paid" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[300px]">
          <MonthlyRevenueChart data={salaryMonthlyData} title="Salary by month" valueLabel="Salary" />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[300px]">
          <MonthlyRevenueChart data={royaltyMonthlyData} title="Royalty by month" valueLabel="Royalty" />
        </div>
      </div>

      {/* Release payment for this talent */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader>
          <CardTitle>Release Payment</CardTitle>
          <p className="text-sm text-neutral">Pay all pending salary, signing bonus, and royalty for this talent. One payment syncs to ledger with remark &quot;Single payment done&quot;.</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            {pendingSalaryList.length > 0 && (
              <p>Pending salary: {pendingSalaryList.length} item(s) — {formatINRDisplay(pendingSalaryList.reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0))}</p>
            )}
            {pendingBonusList.length > 0 && (
              <p>Pending signing bonus: {formatINRDisplay(pendingBonusList.reduce((a, b) => a + (Number(b.amount) || 0), 0))}</p>
            )}
            {pendingRoyaltyList.length > 0 && (
              <p>Pending royalty: {formatINRDisplay(pendingRoyaltyList.reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0), 0))}</p>
            )}
          </div>
          <Button
            className="mt-4"
            disabled={totalPendingAmount <= 0}
            onClick={handleReleasePayment}
          >
            Pay now — {formatINRDisplay(totalPendingAmount)}
          </Button>
        </CardContent>
      </Card>

      {paymentModal && (
        <PaymentModal
          open
          onOpenChange={(v) => !v && setPaymentModal(null)}
          amount={paymentModal.amount}
          title={paymentModal.title}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
