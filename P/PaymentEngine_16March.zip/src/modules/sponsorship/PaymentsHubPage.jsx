import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { getAnnualSalaryTotal, getPaidSalaryTotal, getPendingSalaryTotal } from '../../utils/salaryCalculator'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Receipt, CreditCard, BookOpen, ArrowRight } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function PaymentsHubPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const ledger = useMemo(() => {
    const sales = getAllByOrganization('sales', currentOrganizationId)
    const contracts = getAllByOrganization('contracts', currentOrganizationId)
    const talents = getAllByOrganization('talents', currentOrganizationId)
    const sportsBusinesses = getAllByOrganization('sportsBusinesses', currentOrganizationId)
    return buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
  }, [currentOrganizationId])
  const paymentLedger = useMemo(() => getAllByOrganization('paymentLedger', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])

  const totalSalary = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  const paidSalary = useMemo(() => getPaidSalaryTotal(salaryPayments), [salaryPayments])
  const pendingSalary = useMemo(() => getPendingSalaryTotal(salaryPayments), [salaryPayments])
  const signingBonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])

  const cards = [
    {
      title: 'Salary',
      description: 'Salary compensation: monthly salary, performance bonus, royalty, tax/TDS in payslips.',
      to: '/sponsorship/payments/salary',
      icon: Receipt,
      stats: [
        { label: 'Total', value: formatINRDisplay(totalSalary) },
        { label: 'Paid', value: formatINRDisplay(paidSalary) },
        { label: 'Pending', value: formatINRDisplay(pendingSalary) },
      ],
    },
    {
      title: 'Release Payment',
      description: 'Pay multiple talents: salary, bonus, royalties. One Pay now, monthly-wise release.',
      to: '/sponsorship/payments/release-payment',
      icon: CreditCard,
      stats: [
        { label: 'Signing bonus total', value: formatINRDisplay(signingBonusTotal) },
        { label: 'Royalty total', value: formatINRDisplay(royaltyTotal) },
        { label: 'Royalty paid', value: formatINRDisplay(royaltyPaid) },
      ],
    },
    {
      title: 'Payment Ledger',
      description: 'Track every payment. Filter by talent and payment type.',
      to: '/sponsorship/payments/ledger',
      icon: BookOpen,
      stats: [
        { label: 'Entries', value: String((paymentLedger || []).length) },
      ],
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Payments</h2>
        <p className="text-sm text-neutral mt-1">Choose a section to manage salary, release payments, or view the ledger.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {cards.map((item) => {
          const Icon = item.icon
          return (
            <Card
              key={item.to}
              className="cursor-pointer border-gray-200 hover:border-primary/40 hover:shadow-md transition-all"
              onClick={() => navigate(item.to)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Icon className="h-5 w-5 text-primary" />
                    {item.title}
                  </CardTitle>
                  <ArrowRight className="h-4 w-4 text-gray-400" />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-neutral">{item.description}</p>
                <div className="flex flex-wrap gap-3 pt-2">
                  {item.stats.map((s) => (
                    <span key={s.label} className="text-xs rounded bg-gray-100 px-2 py-1">
                      <span className="text-gray-500">{s.label}:</span> <span className="font-medium">{s.value}</span>
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
