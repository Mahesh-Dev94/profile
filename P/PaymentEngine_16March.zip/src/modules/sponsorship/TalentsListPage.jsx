import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { getAnnualSalaryByTalentFromContracts } from '../../utils/salaryCalculator'
import { getRoyaltyByTalent } from '../../utils/revenueEngine'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { Card, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Checkbox } from '../../components/ui/checkbox'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { User, Filter, Search } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'

const PAGE_SIZE = 6

export function TalentsListPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading talents...', 'Talents loaded')
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(() => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses), [sales, contracts, talents, sportsBusinesses])
  const salaryByTalent = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])
  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger), [ledger])

  const [search, setSearch] = useState('')
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const [page, setPage] = useState(0)

  const filteredTalents = useMemo(() => {
    let list = [...(talents || [])]
    const q = (search || '').toLowerCase().trim()
    if (q) list = list.filter((t) => (t.name || '').toLowerCase().includes(q))
    if (selectedTalentIds.length > 0) list = list.filter((t) => selectedTalentIds.includes(t.id))
    return list.sort((a, b) => (a.name || '').localeCompare(b.name || ''))
  }, [talents, search, selectedTalentIds])

  const paginatedTalents = useMemo(() => {
    const start = page * PAGE_SIZE
    return filteredTalents.slice(start, start + PAGE_SIZE)
  }, [filteredTalents, page])

  const totalPages = Math.ceil(filteredTalents.length / PAGE_SIZE) || 1

  const getTalentStats = (talentId) => {
    const talent = (talents || []).find((t) => t.id === talentId)
    const talentName = talent?.name || ''
    const salaryRec = salaryByTalent.find((s) => s.name === talentName)
    const salary = salaryRec?.value ?? 0
    const royaltyRec = royaltyByTalent.find((r) => r.name === talentName)
    const royalty = royaltyRec?.value ?? 0
    return { salary, royalty, total: salary + royalty }
  }

  const talentOptions = useMemo(() => (talents || []).map((t) => ({ id: t.id, name: t.name })), [talents])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filter by talent</span>
        </div>
        <p className="text-2xs text-neutral mb-2">Search and filter (none = all)</p>
        <div className="relative mb-3">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search talent..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 text-sm"
          />
        </div>
        <div className="space-y-2 max-h-[50vh] overflow-y-auto">
          {talentOptions.length === 0 ? (
            <p className="text-2xs text-neutral">No talent data</p>
          ) : (
            talentOptions.map((t) => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
                <Checkbox
                  checked={selectedTalentIds.includes(t.id)}
                  onCheckedChange={() => setSelectedTalentIds((prev) => prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id])}
                />
                <span className="text-xs truncate">{t.name}</span>
              </label>
            ))
          )}
        </div>
        {(search || selectedTalentIds.length > 0) && (
          <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={() => { setSearch(''); setSelectedTalentIds([]); setPage(0); }}>
            Clear
          </Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <div>
          <h2 className="text-xl font-semibold">Talents</h2>
          <p className="text-sm text-neutral mt-1">Talent profile cards. Click a card to view details, contract, and release payment.</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {paginatedTalents.map((talent) => {
            const stats = getTalentStats(talent.id)
            return (
              <Card
                key={talent.id}
                className="cursor-pointer border-gray-200 hover:border-primary/40 hover:shadow-md transition-all"
                onClick={() => navigate(`/sponsorship/talents/${talent.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <User className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-gray-900 truncate">{talent.name}</p>
                      <p className="text-xs text-neutral mt-0.5">Signing: {talent.signingDate || '—'}</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs">
                        <span className="rounded bg-gray-100 px-1.5 py-0.5">Salary: {formatINRDisplay(stats.salary)}</span>
                        <span className="rounded bg-gray-100 px-1.5 py-0.5">Royalty: {formatINRDisplay(stats.royalty)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {filteredTalents.length === 0 && (
          <p className="text-sm text-neutral">No talents match the filter.</p>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 pt-4">
            <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
              Previous
            </Button>
            <span className="text-sm text-neutral">
              Page {page + 1} of {totalPages}
            </span>
            <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)}>
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
