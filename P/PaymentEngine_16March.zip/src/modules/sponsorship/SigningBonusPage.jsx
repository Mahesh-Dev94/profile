import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function SigningBonusPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading signing bonuses...', 'Signing bonus data loaded')
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const columns = [
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName' },
    { id: 'amount', header: 'Signing Bonus ($)', accessorKey: 'amount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'signingDate', header: 'Signing Date', accessorKey: 'signingDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'releaseDate', header: 'Release Date', accessorKey: 'releaseDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
  ]

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-accent">Signing Bonus</h2>
      <p className="text-sm text-neutral">$3,000,000 payable within 10 business days of execution. Release payment via Release Payment page.</p>
      <DataTable columns={columns} data={signingBonuses} searchKey="talentName" searchPlaceholder="Search by talent..." />
    </div>
  )
}
