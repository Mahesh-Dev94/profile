import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { MainLayout } from './app/layouts/MainLayout'
import { ProtectedRoute } from './app/routes/ProtectedRoute'
import { SponsorshipDashboard } from './modules/sponsorship/SponsorshipDashboard'
import { SportsBusinessesPage } from './modules/sponsorship/SportsBusinessesPage'
import { SponsorshipCompaniesPage } from './modules/sponsorship/SponsorshipCompaniesPage'
import { ContractsPage } from './modules/contracts/ContractsPage'
import { InvoicesPage } from './modules/invoices/InvoicesPage'
import { SigningBonusPage } from './modules/sponsorship/SigningBonusPage'
import { PaymentsHubPage } from './modules/sponsorship/PaymentsHubPage'
import { PaymentLedgerPage } from './modules/sponsorship/PaymentLedgerPage'
import { SponsorshipRoyaltiesPage } from './modules/sponsorship/SponsorshipRoyaltiesPage'
import { SalaryPage } from './modules/sponsorship/SalaryPage'
import { ReleasePaymentPage } from './modules/sponsorship/ReleasePaymentPage'
import { GeneralEntryPage } from './modules/sponsorship/GeneralEntryPage'
import { TalentsListPage } from './modules/sponsorship/TalentsListPage'
import { TalentDetailPage } from './modules/sponsorship/TalentDetailPage'
import { TalentDashboard } from './modules/talent/TalentDashboard'
import { TalentSalaryPage } from './modules/talent/TalentSalaryPage'
import { TalentRoyaltiesPage } from './modules/talent/TalentRoyaltiesPage'
import { TalentSigningBonusPage } from './modules/talent/TalentSigningBonusPage'
import { PartnerDashboard } from './modules/partner/PartnerDashboard'
import { PartnerUploadSalesPage } from './modules/partner/PartnerUploadSalesPage'
import { PartnerSalesPage } from './modules/partner/PartnerSalesPage'
import { PartnerContractsPage } from './modules/partner/PartnerContractsPage'
import { AdminDashboard } from './modules/admin/AdminDashboard'
import { OrganizationsPage } from './modules/admin/OrganizationsPage'
import { AdminContractsPage } from './modules/admin/AdminContractsPage'
import { ReconciliationPage } from './modules/admin/ReconciliationPage'
import { ForecastPage } from './modules/admin/ForecastPage'
import { LandingPage } from './app/pages/LandingPage'

export default function App() {

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" replace />} />

      <Route path="/admin" element={
        <ProtectedRoute allowedRoles={['platform_admin', 'finance_manager']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="organizations" element={<OrganizationsPage />} />
        <Route path="contracts" element={<AdminContractsPage />} />
        <Route path="reconciliation" element={<ReconciliationPage />} />
        <Route path="forecast" element={<ForecastPage />} />
      </Route>

      <Route path="/sponsorship" element={
        <ProtectedRoute allowedRoles={['sponsor_manager', 'platform_admin', 'finance_manager', 'sponsorship_admin']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<SponsorshipDashboard />} />
        <Route path="talents" element={<TalentsListPage />} />
        <Route path="talents/contracts" element={<ContractsPage />} />
        <Route path="talents/:talentId" element={<TalentDetailPage />} />
        <Route path="contracts" element={<Navigate to="/sponsorship/talents/contracts" replace />} />
        <Route path="payments" element={<PaymentsHubPage />} />
        <Route path="payments/salary" element={<SalaryPage />} />
        <Route path="payments/release-payment" element={<ReleasePaymentPage />} />
        <Route path="payments/ledger" element={<PaymentLedgerPage />} />
        <Route path="salary" element={<Navigate to="/sponsorship/payments/salary" replace />} />
        <Route path="release-payment" element={<Navigate to="/sponsorship/payments/release-payment" replace />} />
        <Route path="ledger" element={<Navigate to="/sponsorship/payments/ledger" replace />} />
        <Route path="signing-bonus" element={<SigningBonusPage />} />
        <Route path="journal-entry" element={<GeneralEntryPage />} />
        <Route path="businesses" element={<SportsBusinessesPage />} />
        <Route path="companies" element={<SponsorshipCompaniesPage />} />
        <Route path="invoices" element={<InvoicesPage />} />
        <Route path="royalties" element={<SponsorshipRoyaltiesPage />} />
      </Route>

      <Route path="/talent" element={
        <ProtectedRoute allowedRoles={['talent']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<TalentDashboard />} />
        <Route path="salary" element={<TalentSalaryPage />} />
        <Route path="signing-bonus" element={<TalentSigningBonusPage />} />
        <Route path="royalties" element={<TalentRoyaltiesPage />} />
      </Route>

      <Route path="/partner" element={
        <ProtectedRoute allowedRoles={['vendor_partner', 'partner']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<PartnerDashboard />} />
        <Route path="upload-sales" element={<PartnerUploadSalesPage />} />
        <Route path="sales" element={<PartnerSalesPage />} />
        <Route path="contracts" element={<PartnerContractsPage />} />
      </Route>

      <Route path="/" element={<LandingPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
