import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { OrganizationProvider } from './context/OrganizationContext'
import { AppStoreProvider } from './context/AppStore'
import { Toaster } from 'react-hot-toast'
import { initDatabase } from './database/dbService'
import App from './App'
import './index.css'

const root = ReactDOM.createRoot(document.getElementById('root'))

function renderApp() {
  root.render(
    <React.StrictMode>
      <BrowserRouter>
        <AuthProvider>
          <OrganizationProvider>
            <AppStoreProvider>
              <App />
              <Toaster position="top-right" toastOptions={{ duration: 4000 }} />
            </AppStoreProvider>
          </OrganizationProvider>
        </AuthProvider>
      </BrowserRouter>
    </React.StrictMode>,
  )
}

// Initialize db (sql.js + IndexedDB, or fallback to localStorage), then render
initDatabase().then(renderApp)
