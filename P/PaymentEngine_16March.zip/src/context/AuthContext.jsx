import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { getAll } from '../database/dbService'

const AUTH_STORAGE_KEY = 'sports_platform_auth'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTH_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (parsed?.id && parsed?.email) setUser(parsed)
      }
    } catch (_) {}
    setLoading(false)
  }, [])

  // Map selected role to allowed DB roles. Three login types: sponsorship_admin (Admin+Finance), vendor_partner, talent.
  const roleAllowed = (selectedRole, dbRole) => {
    if (selectedRole === dbRole) return true
    if (selectedRole === 'sponsorship_admin' && (dbRole === 'platform_admin' || dbRole === 'finance_manager')) return true
    if (selectedRole === 'vendor_partner' && dbRole === 'partner') return true
    return false
  }

  const login = useCallback((email, password, role) => {
    const users = getAll('users')
    const match = users.find(
      (u) =>
        u.email === email &&
        u.password === password &&
        roleAllowed(role, u.role)
    )
    if (!match) return { success: false, error: 'Invalid credentials or role' }
    const session = {
      id: match.id,
      email: match.email,
      role: role,
      name: match.name,
      talentId: match.talentId,
      organizationId: match.organizationId,
    }
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_STORAGE_KEY)
    setUser(null)
  }, [])

  /** Direct login: use first sample user for the given portal role and set session. */
  const loginAsFirstUserForRole = useCallback((role) => {
    const users = getAll('users')
    let match = null
    if (role === 'sponsorship_admin') {
      match = users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role))
    } else if (role === 'talent') {
      match = users.find((u) => u.role === 'talent')
    } else if (role === 'vendor_partner') {
      match = users.find((u) => u.role === 'vendor_partner' || u.role === 'partner')
    }
    if (!match) return { success: false }
    const session = {
      id: match.id,
      email: match.email,
      role: match.role,
      name: match.name,
      talentId: match.talentId,
      organizationId: match.organizationId,
    }
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }, [])

  const value = { user, loading, login, loginAsFirstUserForRole, logout, isAuthenticated: !!user }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
