import { useState, useCallback, useEffect } from 'react'
import toast from 'react-hot-toast'

/**
 * Page load hook: shows loading state until setLoaded() is called, then shows bottom-center toast.
 * @param {string} loadMessage - Text shown with spinner (e.g. "Calculating talents salaries")
 * @param {string} loadedMessage - Toast text when done (e.g. "Salary data loaded")
 * @param {number} minLoadMs - Minimum time to show loader (ms) so it's visible
 */
export function usePageLoad(loadMessage = 'Loading...', loadedMessage = 'Loaded', minLoadMs = 600) {
  const [loading, setLoading] = useState(true)
  const [startedAt] = useState(() => Date.now())

  const setLoaded = useCallback(() => {
    const elapsed = Date.now() - startedAt
    const remaining = Math.max(0, minLoadMs - elapsed)
    setTimeout(() => {
      setLoading(false)
      toast.success(loadedMessage, { position: 'bottom-center', duration: 3000 })
    }, remaining)
  }, [loadedMessage, minLoadMs, startedAt])

  return { loading, setLoaded, loadMessage }
}

/**
 * Simpler hook: auto setLoaded after minLoadMs (for pages with sync data).
 */
export function usePageLoadAuto(loadMessage, loadedMessage = 'Loaded', minLoadMs = 600) {
  const { loading, setLoaded, loadMessage: msg } = usePageLoad(loadMessage, loadedMessage, minLoadMs)
  useEffect(() => {
    const t = setTimeout(setLoaded, minLoadMs)
    return () => clearTimeout(t)
  }, [setLoaded, minLoadMs])
  return { loading, loadMessage: msg }
}
