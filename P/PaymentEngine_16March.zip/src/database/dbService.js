/**
 * Database service — uses sql.js + IndexedDB when available, falls back to localStorage.
 * Call initDatabase() before first render (see main.jsx).
 */

import {
  initSqliteDb,
  getAll as sqlGetAll,
  getById as sqlGetById,
  getAllByOrganization as sqlGetAllByOrganization,
  create as sqlCreate,
  update as sqlUpdate,
  remove as sqlRemove,
  getDbRaw as sqlGetDbRaw,
  resetDb as sqlResetDb,
  isSqliteReady,
} from './sqliteDb'
import { seedDatabase, resetDatabase, STORAGE_KEY } from './seedData'

// Legacy localStorage backend (used when sql.js fails or isn't ready)
function getDb() {
  let db = null
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) db = JSON.parse(raw)
  } catch (_) {}
  if (!db || typeof db !== 'object') {
    db = seedDatabase()
  }
  if (!Array.isArray(db.organizations)) db.organizations = []
  if (!Array.isArray(db.salaryPayments)) db.salaryPayments = []
  if (!Array.isArray(db.signingBonuses)) db.signingBonuses = []
  if (!Array.isArray(db.royaltyPayments)) db.royaltyPayments = []
  if (!Array.isArray(db.paymentLedger)) db.paymentLedger = []
  if (!Array.isArray(db.invoices)) db.invoices = []
  return db
}

function saveDb(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db))
  return db
}

const ORG_COLLECTIONS = ['talents', 'sponsorshipCompanies', 'sportsBusinesses', 'contracts', 'sales', 'invoices', 'salaryPayments', 'signingBonuses', 'royaltyPayments', 'paymentLedger']

export function getAll(collection) {
  if (isSqliteReady()) return sqlGetAll(collection)
  const db = getDb()
  const list = db[collection]
  return Array.isArray(list) ? [...list] : []
}

export function getById(collection, id) {
  if (isSqliteReady()) return sqlGetById(collection, id)
  const list = getAll(collection)
  return list.find((item) => item.id === id) ?? null
}

export function getAllByOrganization(collection, organizationId) {
  if (isSqliteReady()) return sqlGetAllByOrganization(collection, organizationId)
  const list = getAll(collection)
  if (!organizationId || !ORG_COLLECTIONS.includes(collection)) return list
  return list.filter((item) => item.organizationId === organizationId)
}

export function create(collection, data) {
  if (isSqliteReady()) return sqlCreate(collection, data)
  const db = getDb()
  if (!Array.isArray(db[collection])) db[collection] = []
  const id = data.id || `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
  const record = { ...data, id }
  db[collection].push(record)
  saveDb(db)
  return record
}

export function update(collection, id, data) {
  if (isSqliteReady()) return sqlUpdate(collection, id, data)
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return null
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return null
  const updated = { ...list[index], ...data, id }
  list[index] = updated
  saveDb(db)
  return updated
}

export function remove(collection, id) {
  if (isSqliteReady()) return sqlRemove(collection, id)
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return false
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return false
  list.splice(index, 1)
  saveDb(db)
  return true
}

export function getDbRaw() {
  if (isSqliteReady()) return sqlGetDbRaw()
  return getDb()
}

export function resetDb() {
  if (isSqliteReady()) return sqlResetDb()
  return resetDatabase()
}

/** Always resolves; on sql.js failure we use localStorage so the app still runs. */
export function initDatabase() {
  return initSqliteDb()
    .catch((err) => {
      console.warn('SQLite init failed, using localStorage:', err)
    })
    .then(() => undefined)
}

export { isSqliteReady }
