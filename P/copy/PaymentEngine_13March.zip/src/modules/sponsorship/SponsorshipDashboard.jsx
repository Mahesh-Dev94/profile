import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { getAnnualSalaryTotal, getPaidSalaryTotal, getPendingSalaryTotal, getAnnualSalaryByTalentFromContracts } from '../../utils/salaryCalculator'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { Button } from '../../components/ui/button'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp, Download, Gift } from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'

function aggregateRoyaltyByMonth(ledger) {
  const byMonth = {}
  ;(ledger || []).forEach((r) => {
    const d = r.date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function aggregateSalaryByMonth(salaryPayments) {
  const byMonth = {}
  ;(salaryPayments || []).forEach((s) => {
    const key = s.month || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.salaryAmount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function aggregateSigningBonusByMonth(signingBonuses) {
  const byMonth = {}
  ;(signingBonuses || []).forEach((b) => {
    const d = b.signingDate
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(b.amount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function getSigningBonusByTalent(signingBonuses) {
  return (signingBonuses || [])
    .map((b) => ({ name: b.talentName || 'Unknown', value: Number(b.amount) || 0 }))
    .filter((x) => x.value > 0)
    .sort((a, b) => b.value - a.value)
}

export function SponsorshipDashboard() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Calculating dashboard analytics...', 'Dashboard loaded')
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const totalSalary = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  const paidSalary = useMemo(() => getPaidSalaryTotal(salaryPayments), [salaryPayments])
  const outstandingSalary = useMemo(() => getPendingSalaryTotal(salaryPayments), [salaryPayments])

  const signingBonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const paidSigningBonus = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const outstandingSigningBonus = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const salaryMonthlyData = useMemo(() => aggregateSalaryByMonth(salaryPayments), [salaryPayments])
  const signingBonusMonthlyData = useMemo(() => aggregateSigningBonusByMonth(signingBonuses), [signingBonuses])
  const signingBonusByTalent = useMemo(() => getSigningBonusByTalent(signingBonuses), [signingBonuses])
  const royaltyMonthlyData = useMemo(() => aggregateRoyaltyByMonth(ledger), [ledger])
  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger).slice(0, 8), [ledger])
  const salaryDistribution = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])

  // Talent Payment Summary: salary = annual from contract; royalty = from ledger (same as Total Royalty)
  const talentPaymentSummary = useMemo(() => {
    const salaryByTalent = getAnnualSalaryByTalentFromContracts(contracts)
    const royaltyByTalentMap = {}
    ledger.forEach((r) => {
      const name = r.talentName || 'Unknown'
      royaltyByTalentMap[name] = (royaltyByTalentMap[name] || 0) + Number(r.royaltyEarned || 0)
    })
    const nameToSalary = Object.fromEntries(salaryByTalent.map(({ name, value }) => [name, value]))
    const allNames = new Set([...salaryByTalent.map((s) => s.name), ...Object.keys(royaltyByTalentMap)])
    return Array.from(allNames)
      .map((name) => {
        const salary = nameToSalary[name] || 0
        const royalty = royaltyByTalentMap[name] || 0
        return { name, salary, royalty, total: salary + royalty }
      })
      .sort((a, b) => b.total - a.total)
  }, [ledger, contracts])

  const exportReport = () => {
    const salaryRows = (salaryPayments || []).map((s) => ({
      Type: 'Salary',
      Talent: s.talentName,
      Period: s.month,
      Amount: s.salaryAmount,
      Status: s.paymentStatus,
    }))
    const bonusRows = (signingBonuses || []).map((b) => ({
      Type: 'Signing Bonus',
      Talent: b.talentName,
      Amount: b.amount,
      SigningDate: b.signingDate,
      ReleaseDate: b.releaseDate,
      Status: b.status,
    }))
    const royaltyRows = ledger.map((r) => ({
      Type: 'Royalty',
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      RoyaltyEarned: r.royaltyEarned,
      Date: r.date,
    }))
    const all = [...salaryRows, ...bonusRows, ...royaltyRows]
    const csv = Papa.unparse(all)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `report-salary-bonus-royalty-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  const clubName = (sportsBusinesses && sportsBusinesses[0]?.businessName) || 'this club'

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={exportReport}><Download className="mr-2 h-4 w-4" /> Export Report (Salary, signing bonus, royalty details)</Button>
      </div>
      {/* Cards: three rows – Salary, Signing Bonus, Royalty */}
      <div className="space-y-4">
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
          <StatCard title="Total Payable Salary" value={formatINRDisplay(totalSalary)} icon={DollarSign} />
          <StatCard title="Paid Salary" value={formatINRDisplay(paidSalary)} icon={DollarSign} />
          <StatCard title="Outstanding Salary" value={formatINRDisplay(outstandingSalary)} icon={DollarSign} />
        </div>
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
          <StatCard title="Total Payable Signing Bonus" value={formatINRDisplay(signingBonusTotal)} icon={Gift} />
          <StatCard title="Paid Signing Bonus" value={formatINRDisplay(paidSigningBonus)} icon={Gift} />
          <StatCard title="Outstanding Signing Bonus" value={formatINRDisplay(outstandingSigningBonus)} icon={Gift} />
        </div>
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
          <StatCard title="Total Payable Royalty" value={formatINRDisplay(royaltyTotal)} icon={TrendingUp} />
          <StatCard title="Paid Royalty" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
          <StatCard title="Outstanding Royalty" value={formatINRDisplay(royaltyPending)} icon={TrendingUp} />
        </div>
        <p className="text-right text-xs text-gray-500 pt-1">
          Summary reflects total payable salary, signing bonus, and royalty for <span className="font-medium text-gray-600">{clubName}</span> across all contracted talent.
        </p>
      </div>
      {/* Row 1: Salary monthly trend | Salary distribution by talent */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <MonthlyRevenueChart
            data={salaryMonthlyData}
            title="Salary Monthly Trend"
            description="Salary by month (matches Total / Paid / Outstanding above)"
            currency="USD"
            valueLabel="Salary"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          {salaryDistribution.length > 0 ? (
            <RoyaltyDistributionChart data={salaryDistribution} title="Salary Distribution" description="By talent" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Salary Distribution</h3>
              <p className="text-sm text-neutral">No salary data</p>
            </>
          )}
        </div>
      </div>
      {/* Row 2: Signing Bonus monthly trend | Signing Bonus distribution by talent */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <MonthlyRevenueChart
            data={signingBonusMonthlyData}
            title="Signing Bonus Monthly Trend"
            description="Signing bonus by month (signing date)"
            currency="USD"
            valueLabel="Signing Bonus"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          {signingBonusByTalent.length > 0 ? (
            <RoyaltyDistributionChart data={signingBonusByTalent} title="Signing Bonus Distribution" description="By talent" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Signing Bonus Distribution</h3>
              <p className="text-sm text-neutral">No signing bonus data</p>
            </>
          )}
        </div>
      </div>
      {/* Row 3: Royalty monthly trend | Royalty distribution by talent */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <MonthlyRevenueChart
            data={royaltyMonthlyData}
            title="Royalty Monthly Trend"
            description="Royalty by month (matches Total / Paid / Outstanding above)"
            currency="USD"
            valueLabel="Royalty"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          {royaltyByTalent.length > 0 ? (
            <RoyaltyDistributionChart data={royaltyByTalent} title="Royalty Distribution" description="By talent" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Royalty Distribution</h3>
              <p className="text-sm text-neutral">No royalty data</p>
            </>
          )}
        </div>
      </div>
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Talent Payment Summary</h3>
        <p className="text-xs text-neutral mb-3">Salary and royalty per talent (matches Salary total and Total Royalty above).</p>
        {talentPaymentSummary.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-2 px-3 font-semibold">Talent</th>
                  <th className="text-right py-2 px-3 font-semibold">Salary</th>
                  <th className="text-right py-2 px-3 font-semibold">Royalty</th>
                  <th className="text-right py-2 px-3 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody>
                {talentPaymentSummary.map(({ name, salary, royalty, total }) => (
                  <tr key={name} className="border-b border-gray-100">
                    <td className="py-2.5 px-3 font-medium">{name}</td>
                    <td className="py-2.5 px-3 text-right">{formatINRDisplay(salary)}</td>
                    <td className="py-2.5 px-3 text-right">{formatINRDisplay(royalty)}</td>
                    <td className="py-2.5 px-3 text-right font-medium">{formatINRDisplay(total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-neutral">No payment data</p>
        )}
      </div>
    </div>
  )
}
