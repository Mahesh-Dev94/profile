/**
 * Repository layer — Sport Business (club) reads from local DB.
 * Keeps data access out of UI components.
 */
import { getAllByOrganization } from '../database/dbService'
import {
  computeTalentMonthWiseBreakdown,
  enumerateMonthsInclusive,
  toYearMonth,
} from './talentMonthPaymentSnapshotEngine'
import {
  snapshotRowsToMonthWiseApiShape,
  rebuildTalentMonthPaymentSnapshotsForOrganization,
  getTalentMonthPaymentSnapshotRows,
} from './talentMonthPaymentSnapshots'
import { buildRoyaltyLedger } from '../utils/revenueEngine'
import {
  getAnnualSalaryTotal,
  getPaidSalaryTotal,
  getPendingSalaryTotal,
  getPayrollPerformanceBonusTotalsFromSalaryRows,
} from '../utils/salaryCalculator'

/** Calendar years where this talent has any salary / bonus / invoice / ledger activity (for rolling up month-wise royalty). */
function yearsWithTalentPaymentActivity(talentId, organizationId) {
  const ys = new Set()
  const add = (s) => {
    if (s && typeof s === 'string' && s.length >= 4) ys.add(s.slice(0, 4))
  }
  const salaryPayments = getAllByOrganization('salaryPayments', organizationId)
  const signingBonuses = getAllByOrganization('signingBonuses', organizationId)
  const invoices = getAllByOrganization('invoices', organizationId)
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)

  ;(salaryPayments || [])
    .filter((s) => s.talentId === talentId)
    .forEach((s) => add(s.month))
  ;(signingBonuses || [])
    .filter((b) => b.talentId === talentId)
    .forEach((b) => {
      add(b.signingDate)
      add(b.releaseDate)
      const start = toYearMonth(b.signingDate)
      const end = toYearMonth(b.releaseDate || b.signingDate) || start
      if (start) {
        for (const ym of enumerateMonthsInclusive(start, end)) add(ym)
      }
    })
  ;(invoices || [])
    .filter((inv) => inv.talentId === talentId)
    .forEach((inv) => add(inv.date || inv.issueDate || inv.invoiceDate))
  ledger
    .filter((r) => r.talentId === talentId)
    .forEach((r) => add(r.date))
  add(String(new Date().getFullYear()))
  return [...ys].filter((y) => /^\d{4}$/.test(y)).sort()
}

export function fetchSportsBusinessBundle(organizationId) {
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const invoices = getAllByOrganization('invoices', organizationId)
  const salaryPayments = getAllByOrganization('salaryPayments', organizationId)
  const signingBonuses = getAllByOrganization('signingBonuses', organizationId)
  const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
  return {
    sales,
    contracts,
    talents,
    sportsBusinesses,
    invoices,
    salaryPayments,
    signingBonuses,
    ledger,
  }
}

export function getDashboardPaymentMetrics(organizationId) {
  const { salaryPayments, signingBonuses, invoices, talents } = fetchSportsBusinessBundle(organizationId)

  const salary = {
    payable: getAnnualSalaryTotal(salaryPayments),
    paid: getPaidSalaryTotal(salaryPayments),
    outstanding: getPendingSalaryTotal(salaryPayments),
  }

  const bonusFromPayroll = getPayrollPerformanceBonusTotalsFromSalaryRows(salaryPayments)
  const bonusPayable = bonusFromPayroll.payable
  const bonusPaid = bonusFromPayroll.paid
  const bonusOutstanding = bonusFromPayroll.outstanding

  let royaltyPayable = 0
  let royaltyPaid = 0
  let royaltyOutstanding = 0
  for (const t of talents || []) {
    const tr = getTalentPaymentTotalsAllTime(t.id, organizationId)
    royaltyPayable += tr.royalty.payable
    royaltyPaid += tr.royalty.paid
    royaltyOutstanding += tr.royalty.outstanding
  }

  const grandPayable = salary.payable + bonusPayable + royaltyPayable
  const grandPaid = salary.paid + bonusPaid + royaltyPaid
  const grandOutstanding = salary.outstanding + bonusOutstanding + royaltyOutstanding

  return {
    talentCount: (talents || []).length,
    salary,
    bonus: { payable: bonusPayable, paid: bonusPaid, outstanding: bonusOutstanding },
    royalty: { payable: royaltyPayable, paid: royaltyPaid, outstanding: royaltyOutstanding },
    grand: { payable: grandPayable, paid: grandPaid, outstanding: grandOutstanding },
  }
}

export function getPaymentsSummaryForYear(organizationId, year) {
  const y = String(year)
  const talents = getAllByOrganization('talents', organizationId)
  const salary = { payable: 0, paid: 0, outstanding: 0 }
  const bonus = { payable: 0, paid: 0, outstanding: 0 }
  const royalty = { payable: 0, paid: 0, outstanding: 0 }
  for (const t of talents || []) {
    const row = getTalentYearPaymentBreakdown(t.id, organizationId, y)
    salary.payable += row.salary.payable
    salary.paid += row.salary.paid
    salary.outstanding += row.salary.outstanding
    bonus.payable += row.bonus.payable
    bonus.paid += row.bonus.paid
    bonus.outstanding += row.bonus.outstanding
    royalty.payable += row.royalty.payable
    royalty.paid += row.royalty.paid
    royalty.outstanding += row.royalty.outstanding
  }
  return { year: y, salary, bonus, royalty }
}

/**
 * Calendar month breakdown (yyyy-MM) for one talent — read from `talentMonthPayments` table.
 * Rebuilds org snapshots if rows are missing (e.g. first run after migration).
 */
export function getTalentMonthWisePaymentBreakdown(talentId, organizationId, year) {
  const y = String(year)
  let rows = getTalentMonthPaymentSnapshotRows(talentId, organizationId, y)
  if (rows.length < 12) {
    rebuildTalentMonthPaymentSnapshotsForOrganization(organizationId)
    rows = getTalentMonthPaymentSnapshotRows(talentId, organizationId, y)
  }
  if (rows.length >= 12) return snapshotRowsToMonthWiseApiShape(rows)

  const salaryPayments = getAllByOrganization('salaryPayments', organizationId)
  const signingBonuses = getAllByOrganization('signingBonuses', organizationId)
  const invoices = getAllByOrganization('invoices', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const talent = (talents || []).find((t) => t.id === talentId)
  const ledgerRows = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses).filter(
    (row) => row.talentId === talentId
  )
  const computed = computeTalentMonthWiseBreakdown(
    talentId,
    talent?.name || '',
    organizationId,
    y,
    salaryPayments,
    signingBonuses,
    invoices,
    ledgerRows
  )
  return computed.map(({ month, salary, bonus, royalty }) => ({ month, salary, bonus, royalty }))
}

/** Year-wise totals for one talent = sum of month-wise snapshot rows (same source as payment details UI). */
export function getTalentYearPaymentBreakdown(talentId, organizationId, year) {
  const y = String(year)
  const monthWise = getTalentMonthWisePaymentBreakdown(talentId, organizationId, y)
  const salary = { payable: 0, paid: 0, outstanding: 0 }
  const bonus = { payable: 0, paid: 0, outstanding: 0 }
  const royalty = { payable: 0, paid: 0, outstanding: 0 }
  for (const m of monthWise) {
    salary.payable += m.salary.payable
    salary.paid += m.salary.paid
    salary.outstanding += m.salary.outstanding
    bonus.payable += m.bonus.payable
    bonus.paid += m.bonus.paid
    bonus.outstanding += m.bonus.outstanding
    royalty.payable += m.royalty.payable
    royalty.paid += m.royalty.paid
    royalty.outstanding += m.royalty.outstanding
  }
  return { year: y, salary, bonus, royalty }
}

/** All-time salary / bonus / royalty payable–paid–outstanding for one talent (for lists & dashboard cards). */
export function getTalentPaymentTotalsAllTime(talentId, organizationId) {
  const salaryPayments = getAllByOrganization('salaryPayments', organizationId)
  const signingBonuses = getAllByOrganization('signingBonuses', organizationId)
  const invoices = getAllByOrganization('invoices', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const talent = (talents || []).find((t) => t.id === talentId)

  const salRows = (salaryPayments || []).filter((s) => s.talentId === talentId)
  const salaryPayable = salRows.reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)
  const salaryPaid = salRows.filter((s) => s.paymentStatus === 'paid').reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)
  const salaryOutstanding = salRows.filter((s) => s.paymentStatus === 'pending').reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)

  const bonusFromPayroll = getPayrollPerformanceBonusTotalsFromSalaryRows(salRows)
  const bonusPayable = bonusFromPayroll.payable
  const bonusPaid = bonusFromPayroll.paid
  const bonusOutstanding = bonusFromPayroll.outstanding

  const ledgerRows = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses).filter((row) => row.talentId === talentId)
  let royaltyPayable = 0
  let royaltyPaid = 0
  let royaltyOutstanding = 0
  for (const y of yearsWithTalentPaymentActivity(talentId, organizationId)) {
    const mw = computeTalentMonthWiseBreakdown(
      talentId,
      talent?.name || '',
      organizationId,
      y,
      salaryPayments,
      signingBonuses,
      invoices,
      ledgerRows
    )
    for (const row of mw) {
      royaltyPayable += row.royalty.payable
      royaltyPaid += row.royalty.paid
      royaltyOutstanding += row.royalty.outstanding
    }
  }

  const grand = {
    payable: salaryPayable + bonusPayable + royaltyPayable,
    paid: salaryPaid + bonusPaid + royaltyPaid,
    outstanding: salaryOutstanding + bonusOutstanding + royaltyOutstanding,
  }

  return {
    salary: { payable: salaryPayable, paid: salaryPaid, outstanding: salaryOutstanding },
    bonus: { payable: bonusPayable, paid: bonusPaid, outstanding: bonusOutstanding },
    royalty: { payable: royaltyPayable, paid: royaltyPaid, outstanding: royaltyOutstanding },
    grand,
  }
}
