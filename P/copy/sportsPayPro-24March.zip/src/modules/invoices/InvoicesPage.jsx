import React, { useState, useMemo } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization, create as dbCreate } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { downloadInvoicePDF } from '../../utils/pdfGenerator'
import { InvoiceViewer } from '../../components/forms/InvoiceViewer'
import { PaymentModal } from '../../components/PaymentModal'
import { Button } from '../../components/ui/button'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { FileDown, Plus, CreditCard } from 'lucide-react'
import { format, subMonths } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import toast from 'react-hot-toast'

export function InvoicesPage() {
  const { currentOrganizationId } = useOrganization()
  const { data: allInvoices, create, update: updateInvoice, refresh } = useDatabase('invoices')
  const invoices = useMemo(() => (allInvoices || []).filter((i) => i.organizationId === currentOrganizationId), [allInvoices, currentOrganizationId])
  const [selected, setSelected] = useState(null)
  const [payInvoice, setPayInvoice] = useState(null)
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])

  const handlePaymentSuccess = ({ invoice, amount, paymentMethod, transactionId }) => {
    const totalDue = (Number(invoice.royaltyAmount) || 0) + (Number(invoice.minimumGuarantee) || 0)
    const newPaidAmount = (Number(invoice.paidAmount) || 0) + amount
    const newStatus = newPaidAmount >= totalDue ? 'paid' : 'partially_paid'
    updateInvoice(invoice.id, { paidAmount: newPaidAmount, status: newStatus })
    dbCreate('paymentLedger', {
      date: format(new Date(), 'yyyy-MM-dd'),
      transactionId,
      source: 'Sport Platform',
      destination: invoice.sportsBusiness || invoice.talentName,
      amount,
      paymentMethod,
      status: 'completed',
      organizationId: currentOrganizationId,
      invoiceId: invoice.id,
    })
    refresh()
    setPayInvoice(null)
    toast.success('Payment completed successfully')
  }

  const monthlySummary = useMemo(() => {
    const byMonth = {}
    invoices.forEach((inv) => {
      const d = inv.date
      const monthKey = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      if (!byMonth[monthKey]) {
        byMonth[monthKey] = { month: monthKey, netSales: 0, royaltyTotal: 0, royaltyPaid: 0, royaltyPending: 0 }
      }
      const totalDue = (Number(inv.royaltyAmount) || 0) + (Number(inv.minimumGuarantee) || 0)
      const paid = Number(inv.paidAmount) || 0
      byMonth[monthKey].netSales += Number(inv.netSales) || 0
      byMonth[monthKey].royaltyTotal += totalDue
      byMonth[monthKey].royaltyPaid += paid
      byMonth[monthKey].royaltyPending += Math.max(0, totalDue - paid)
    })
    const salesByMonth = {}
    sales.forEach((s) => {
      const d = s.date
      const monthKey = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      if (!salesByMonth[monthKey]) salesByMonth[monthKey] = { units: 0, netSales: 0 }
      salesByMonth[monthKey].units += Number(s.unitsSold) || 0
      salesByMonth[monthKey].netSales += Number(s.netSales) || 0
    })
    return Object.values(byMonth)
      .map((row) => {
        const sm = salesByMonth[row.month]
        const pricePerUnit = sm && sm.units > 0 ? sm.netSales / sm.units : null
        return {
          ...row,
          monthLabel: row.month ? format(new Date(row.month + '-01'), 'MMMM yyyy') : row.month,
          pricePerUnit,
        }
      })
      .sort((a, b) => (b.month || '').localeCompare(a.month || ''))
      .slice(0, 12)
  }, [invoices, sales])

  const generateMonthlyInvoices = () => {
    const contracts = getAllByOrganization('contracts', currentOrganizationId)
    const talents = getAllByOrganization('talents', currentOrganizationId)
    const sportsBusinesses = getAllByOrganization('sportsBusinesses', currentOrganizationId)
    const sponsors = getAllByOrganization('sponsorshipCompanies', currentOrganizationId)
    const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
    const thisMonth = format(new Date(), 'yyyy-MM')
    const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM')
    const byTalentContract = {}
    ledger.forEach((r) => {
      const d = r.date && (typeof r.date === 'string' ? r.date.slice(0, 7) : format(new Date(r.date), 'yyyy-MM'))
      if (d !== lastMonth && d !== thisMonth) return
      const key = `${r.talentId}-${r.licensee}`
      if (!byTalentContract[key]) {
        const contract = contracts.find((c) => c.talentId === r.talentId && c.licensee === r.licensee)
        const sponsor = contract && sponsors.find((s) => s.id === contract.sponsorId)
        byTalentContract[key] = {
          talentId: r.talentId,
          talentName: r.talentName,
          licensee: r.licensee,
          sponsorCompany: sponsor?.companyName || 'N/A',
          royaltyAmount: 0,
          netSales: 0,
          minimumGuarantee: contract?.minimumGuarantee ? (contract.minimumGuarantee / 12) : 0,
        }
      }
      byTalentContract[key].royaltyAmount += r.royaltyEarned || 0
      byTalentContract[key].netSales += r.netSales || 0
    })
    Object.values(byTalentContract).forEach((inv, i) => {
      create({
        invoiceID: `INV-${format(new Date(), 'yyyy')}-${String(invoices.length + i + 1).padStart(3, '0')}`,
        sponsorCompany: inv.sponsorCompany,
        sportsBusiness: inv.licensee,
        talentName: inv.talentName,
        talentId: inv.talentId,
        royaltyAmount: inv.royaltyAmount,
        minimumGuarantee: inv.minimumGuarantee,
        netSales: inv.netSales,
        date: format(new Date(), 'yyyy-MM-dd'),
        period: 'monthly',
        status: 'pending',
        paidAmount: 0,
        organizationId: currentOrganizationId,
      })
    })
    refresh()
    toast.success('Monthly invoices generated')
  }

  const columns = [
    { id: 'invoiceID', header: 'Invoice ID', accessorKey: 'invoiceID' },
    { id: 'sponsorCompany', header: 'Sponsor', accessorKey: 'sponsorCompany' },
    { id: 'sportsBusiness', header: 'Sports Business', accessorKey: 'sportsBusiness' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'royaltyAmount', header: 'Royalty', accessorKey: 'royaltyAmount', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'minimumGuarantee', header: 'Min. Guarantee', accessorKey: 'minimumGuarantee', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'period', header: 'Period', accessorKey: 'period' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => {
      const v = info.getValue()
      const variant = v === 'paid' ? 'success' : v === 'partially_paid' ? 'secondary' : 'warning'
      return <Badge variant={variant}>{v}</Badge>
    }},
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => {
        const inv = row.original
        const totalDue = (Number(inv.royaltyAmount) || 0) + (Number(inv.minimumGuarantee) || 0)
        const paid = Number(inv.paidAmount) || 0
        const canPay = paid < totalDue
        return (
          <div className="flex gap-2 flex-wrap">
            {canPay && (
              <Button size="sm" className="bg-accent text-white hover:bg-accent/90" onClick={() => setPayInvoice(inv)}>
                <CreditCard className="h-3.5 w-3.5 mr-1" /> PAY NOW
              </Button>
            )}
            <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setSelected(inv)}>View PDF</Button>
            <Button variant="outline" size="sm" onClick={() => downloadInvoicePDF(inv)}><FileDown className="h-4 w-4" /></Button>
          </div>
        )
      },
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <h2 className="text-xl font-semibold">Invoices</h2>
        <Button onClick={generateMonthlyInvoices}><Plus className="mr-2 h-4 w-4" /> Generate monthly invoices</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Monthly summary (Net Sales, Price per unit, Royalty Total / Paid / Pending)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="px-4 py-2 text-left font-medium text-gray-700">Month</th>
                  <th className="px-4 py-2 text-right font-medium text-gray-700">Net Sales</th>
                  <th className="px-4 py-2 text-right font-medium text-gray-700">Price per unit</th>
                  <th className="px-4 py-2 text-right font-medium text-gray-700">Royalty Total</th>
                  <th className="px-4 py-2 text-right font-medium text-gray-700">Royalty Paid</th>
                  <th className="px-4 py-2 text-right font-medium text-gray-700">Royalty Pending</th>
                </tr>
              </thead>
              <tbody>
                {monthlySummary.map((row) => (
                  <tr key={row.month} className="border-b border-gray-100">
                    <td className="px-4 py-2 font-medium">{row.monthLabel || row.month}</td>
                    <td className="px-4 py-2 text-right">${Number(row.netSales).toLocaleString()}</td>
                    <td className="px-4 py-2 text-right">{row.pricePerUnit != null ? `$${row.pricePerUnit.toFixed(2)}` : '—'}</td>
                    <td className="px-4 py-2 text-right">${Number(row.royaltyTotal).toLocaleString()}</td>
                    <td className="px-4 py-2 text-right">${Number(row.royaltyPaid).toLocaleString()}</td>
                    <td className="px-4 py-2 text-right">${Number(row.royaltyPending).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <DataTable columns={columns} data={invoices} searchKey="invoiceID" searchPlaceholder="Search invoices..." />
      <InvoiceViewer open={!!selected} onOpenChange={(v) => !v && setSelected(null)} invoice={selected} onDownloadPDF={downloadInvoicePDF} />
      <PaymentModal open={!!payInvoice} onOpenChange={(v) => !v && setPayInvoice(null)} invoice={payInvoice} onSuccess={handlePaymentSuccess} />
    </div>
  )
}
