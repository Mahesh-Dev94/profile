import React, { useMemo } from 'react'
import { cn } from '../../utils/cn'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT, PERFORMANCE_BONUS_PAYROLL_LABEL } from '../../utils/salaryCalculator'
import { DollarSign, Gift } from 'lucide-react'

function signingMonthKey(b) {
  const d = b?.signingDate
  if (!d) return null
  return typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')
}

function monthLabel(ym) {
  if (!ym || typeof ym !== 'string') return '—'
  const [y, m] = ym.split('-')
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : ym
}

function aggregatePerformanceBonusByMonth(signingBonuses) {
  const byMonth = {}
  ;(signingBonuses || []).forEach((b) => {
    const key = signingMonthKey(b) || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(b.amount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function aggregatePerformanceBonusByMonthForYear(signingBonuses, year) {
  const y = String(year)
  const keys = []
  for (let m = 1; m <= 12; m++) keys.push(`${y}-${String(m).padStart(2, '0')}`)
  const byMonth = Object.fromEntries(keys.map((k) => [k, 0]))
  ;(signingBonuses || []).forEach((b) => {
    const key = signingMonthKey(b)
    if (!key || !key.startsWith(`${y}-`)) return
    byMonth[key] = (byMonth[key] || 0) + Number(b.amount || 0)
  })
  return keys.map((month) => ({ month, revenue: byMonth[month] || 0 }))
}

function getPerformanceBonusByTalent(signingBonuses) {
  return (signingBonuses || [])
    .map((b) => ({ name: b.talentName || 'Unknown', value: Number(b.amount) || 0 }))
    .filter((x) => x.value > 0)
    .sort((a, b) => b.value - a.value)
}

/**
 * Club performance bonus page (Sport Business / Club) – same structure as royalties page.
 * One-time bonus (signing/release record) + monthly performance bonus ($180k/mo in payroll window, from salaryCalculator).
 */
/**
 * @param {{ embedded?: boolean, filterYear?: string | number | null }} props
 * When `filterYear` is set, totals, charts, and tables follow that calendar year (signing-date month for trend chart).
 */
export function ClubPerformanceBonusPage({ embedded = false, filterYear = null } = {}) {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto(
    'Loading performance bonuses...',
    'Performance bonus data loaded',
    600,
    embedded
  )
  const signingBonusesAll = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const yearKey = filterYear != null && filterYear !== '' ? String(filterYear) : null

  /** Scope to calendar year by signing month so stats, table, and monthly chart stay aligned. */
  const signingBonuses = useMemo(() => {
    if (!yearKey) return signingBonusesAll || []
    return (signingBonusesAll || []).filter((b) => {
      const key = signingMonthKey(b)
      return key && key.startsWith(`${yearKey}-`)
    })
  }, [signingBonusesAll, yearKey])

  const bonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const bonusPaid = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const bonusPending = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])

  const bonusMonthlyData = useMemo(() => {
    if (yearKey) return aggregatePerformanceBonusByMonthForYear(signingBonuses, yearKey)
    return aggregatePerformanceBonusByMonth(signingBonusesAll)
  }, [signingBonuses, signingBonusesAll, yearKey])

  const bonusByTalent = useMemo(() => getPerformanceBonusByTalent(signingBonuses), [signingBonuses])

  const bonusByTalentRows = useMemo(() => {
    const totalByTalent = {}
    const paidByTalent = {}
    ;(signingBonuses || []).forEach((b) => {
      const name = b.talentName || 'Unknown'
      totalByTalent[name] = (totalByTalent[name] || 0) + (Number(b.amount) || 0)
      if (b.status === 'paid') paidByTalent[name] = (paidByTalent[name] || 0) + (Number(b.amount) || 0)
    })
    const allNames = new Set([...Object.keys(totalByTalent)])
    return Array.from(allNames)
      .map((name) => {
        const total = totalByTalent[name] || 0
        const paid = paidByTalent[name] || 0
        const pending = Math.max(0, total - paid)
        return { talentName: name, bonusTotal: total, bonusPaid: paid, bonusPending: pending }
      })
      .filter((row) => row.bonusTotal > 0)
      .sort((a, b) => b.bonusTotal - a.bonusTotal)
  }, [signingBonuses])

  /** Same column shape as Salary payments: one-time bonus in perf. bonus column; period total = bonus. */
  const bonusPeriodRowsEmbedded = useMemo(() => {
    return (signingBonuses || [])
      .map((b) => {
        const ym = signingMonthKey(b) || '—'
        const amt = Number(b.amount) || 0
        return {
          id: b.id,
          talentName: b.talentName || '—',
          month: ym,
          monthlyPerformanceBonus: amt,
          totalEarnings: amt,
          paymentStatus: b.status === 'paid' ? 'paid' : 'pending',
        }
      })
      .sort((a, b) => {
        const cm = String(a.month).localeCompare(String(b.month))
        if (cm !== 0) return cm
        return String(a.talentName || '').localeCompare(String(b.talentName || ''))
      })
  }, [signingBonuses])

  const bonusEmbeddedPaymentColumns = [
    {
      id: 'talentName',
      header: 'Talent',
      accessorKey: 'talentName',
      cell: (info) => <span className="font-medium">{info.getValue()}</span>,
    },
    {
      id: 'month',
      header: 'Period',
      accessorKey: 'month',
      cell: (info) => monthLabel(info.getValue()),
    },
    { id: 'salaryAmount', header: 'Monthly salary', cell: () => <span className="text-neutral">—</span> },
    {
      id: 'monthlyPerformanceBonus',
      header: 'Perf. bonus',
      accessorKey: 'monthlyPerformanceBonus',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    { id: 'monthlyRoyalty', header: 'Royalty', cell: () => <span className="text-neutral">—</span> },
    {
      id: 'totalEarnings',
      header: 'Period total',
      accessorKey: 'totalEarnings',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'paymentStatus',
      header: 'Status',
      accessorKey: 'paymentStatus',
      cell: (info) => (
        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-2xs font-medium',
            info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
          )}
        >
          {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
        </span>
      ),
    },
  ]

  const ledgerColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'amount', header: 'Performance Bonus ($)', accessorKey: 'amount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'signingDate', header: 'Signing Date', accessorKey: 'signingDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'releaseDate', header: 'Release Date', accessorKey: 'releaseDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
  ]

  const talentSummaryColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'bonusTotal', header: 'Bonus Total', accessorKey: 'bonusTotal', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'bonusPaid', header: 'Bonus Paid', accessorKey: 'bonusPaid', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'bonusPending', header: 'Bonus Pending', accessorKey: 'bonusPending', cell: (info) => formatINRDisplay(info.getValue()) },
  ]

  if (loading && !embedded) return <PageLoaderWithSkeleton message={loadMessage} />
  if (loading && embedded) {
    return <div className="py-10 text-center text-sm text-neutral">{loadMessage}</div>
  }

  return (
    <div className={cn('space-y-6', embedded && 'space-y-4')}>
      {!embedded && (
        <>
          <h2 className="text-xl font-semibold">Performance Bonus</h2>
          <p className="text-sm text-neutral">
            One-time performance bonus (signing/release) below. Monthly performance bonus:{' '}
            <strong>{formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}</strong> per talent per month on salary slips ({PERFORMANCE_BONUS_PAYROLL_LABEL}).
          </p>
        </>
      )}
      {embedded && (
        <p className="text-xs text-neutral">
          {yearKey ? (
            <>
              One-time bonus records whose <span className="font-semibold text-primary-800">signing month</span> falls in{' '}
              <span className="font-semibold text-primary-800">{yearKey}</span> (matches the monthly chart). Payroll line:{' '}
              <strong>{formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}</strong>/mo ({PERFORMANCE_BONUS_PAYROLL_LABEL}) on salary slips.
            </>
          ) : (
            <>
              One-time bonus (signing/release) and monthly performance bonus:{' '}
              <strong>{formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}</strong> per talent per month ({PERFORMANCE_BONUS_PAYROLL_LABEL}; also on salary slips).
            </>
          )}
        </p>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Performance Bonus Total" value={formatINRDisplay(bonusTotal)} icon={DollarSign} />
        <StatCard title="Performance Bonus Paid" value={formatINRDisplay(bonusPaid)} icon={Gift} />
        <StatCard title="Performance Bonus Pending" value={formatINRDisplay(bonusPending)} icon={DollarSign} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          <MonthlyRevenueChart
            data={bonusMonthlyData}
            title={yearKey ? `Performance bonus by month (${yearKey})` : 'Performance Bonus Monthly Trend'}
            description={
              yearKey ? 'One-time bonus by signing month in selected year' : 'One-time bonus by month (signing date)'
            }
            currency="USD"
            valueLabel="Bonus"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          {bonusByTalent.length > 0 ? (
            <RoyaltyDistributionChart data={bonusByTalent} title="Performance Bonus Distribution" description="By talent" />
          ) : (
            <div>
              <h3 className="mb-4 text-base font-medium">Performance Bonus Distribution</h3>
              <p className="text-sm text-neutral">No performance bonus data</p>
            </div>
          )}
        </div>
      </div>

      {embedded && (
        <div className="theme-card overflow-hidden p-3">
          <h3 className="mb-2 text-sm font-semibold text-primary-900">Performance bonus payments</h3>
          <p className="mb-3 text-2xs text-neutral">
            Rows match Salary payments layout: one-time signing/release bonus is shown in Perf. bonus; monthly payroll bonus ({PERFORMANCE_BONUS_PAYROLL_LABEL}) appears on Salary payments with salary and royalty.
          </p>
          {bonusPeriodRowsEmbedded.length > 0 ? (
            <DataTable
              columns={bonusEmbeddedPaymentColumns}
              data={bonusPeriodRowsEmbedded}
              searchKey="talentName"
              searchPlaceholder="Search talent or period…"
            />
          ) : (
            <p className="text-sm text-neutral">No performance bonus records for this scope.</p>
          )}
        </div>
      )}
      {!embedded && bonusByTalentRows.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-3 text-base font-medium">Performance bonus by talent (Total, Paid, Pending)</h3>
          <DataTable columns={talentSummaryColumns} data={bonusByTalentRows} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}

      {!embedded && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-2 text-base font-medium">Performance bonus ledger</h3>
          <DataTable columns={ledgerColumns} data={signingBonusesAll || []} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}
      {embedded && (
        <p className="text-2xs text-neutral">
          Full line-item ledger (all years) is on the club <strong>Performance Bonus</strong> page.
        </p>
      )}
    </div>
  )
}
