/**
 * Sports Business Club — SAP-style chart of accounts & journal builders.
 * Pure functions for UI integration or backend port (JSON / CSV / SQL).
 */

export const CHART_OF_ACCOUNTS = [
  {
    paymentComponent: 'Salary',
    glAccount: '61000',
    accountName: 'Player Salary Expense',
    type: 'Debit',
  },
  {
    paymentComponent: 'Joining Bonus',
    glAccount: '61010',
    accountName: 'Player Bonus Expense',
    type: 'Debit',
  },
  {
    paymentComponent: 'Royalty',
    glAccount: '61020',
    accountName: 'Player Royalty Expense',
    type: 'Debit',
  },
  {
    paymentComponent: 'Player Payable',
    glAccount: '210000',
    accountName: 'Player Payable',
    type: 'Credit',
  },
  {
    paymentComponent: 'Bank',
    glAccount: '110000',
    accountName: 'Bank Account',
    type: 'Credit',
  },
]

const GL = {
  salary: { code: '61000', name: 'Player Salary Expense' },
  bonus: { code: '61010', name: 'Player Bonus Expense' },
  royalty: { code: '61020', name: 'Player Royalty Expense' },
  payable: { code: '210000', name: 'Player Payable' },
  bank: { code: '110000', name: 'Bank Account' },
}

export function parseMoney(value) {
  if (value === '' || value == null) return 0
  const n = Number(String(value).replace(/,/g, ''))
  return Number.isFinite(n) ? n : NaN
}

export function roundMoney(n) {
  return Math.round(Number(n) * 100) / 100
}

export function playerRowTotal(row) {
  return roundMoney(
    (parseMoney(row.salary) || 0) + (parseMoney(row.joiningBonus) || 0) + (parseMoney(row.royalty) || 0)
  )
}

/**
 * @param {Array<{ name: string, salary: *, joiningBonus: *, royalty: * }>} rows
 * @returns {{ ok: boolean, errors: string[] }}
 */
export function validatePlayerRows(rows) {
  const errors = []
  const active = rows.filter((r) => playerRowTotal(r) > 0)
  if (active.length === 0) {
    errors.push('Enter at least one player with a positive salary and/or bonus and/or royalty.')
  }
  active.forEach((r, i) => {
    const name = String(r.name || '').trim()
    if (!name) errors.push(`Row ${i + 1}: player name is required when amounts are entered.`)
    ;['salary', 'joiningBonus', 'royalty'].forEach((k) => {
      const v = parseMoney(r[k])
      if (Number.isNaN(v)) errors.push(`Row ${i + 1}: ${k} must be a valid number.`)
      else if (v < 0) errors.push(`Row ${i + 1}: ${k} cannot be negative.`)
    })
  })
  return { ok: errors.length === 0, errors }
}

/**
 * Expense recognition: debit expense GLs, credit Player Payable for total.
 * @param {Array<{ name: string, salary: number, joiningBonus: number, royalty: number }>} players — normalized
 */
export function buildExpenseRecognitionJournal(players) {
  const lines = []
  let line = 1
  let totalDebit = 0

  const pushDebit = (glCode, glName, amount, playerName) => {
    const a = roundMoney(amount)
    if (a <= 0) return
    lines.push({
      line: line++,
      glAccount: glCode,
      accountName: glName,
      debit: a,
      credit: 0,
      description: `Expense recognition for ${playerName}`,
    })
    totalDebit += a
  }

  for (const p of players) {
    const name = String(p.name || '').trim()
    const salary = roundMoney(Number(p.salary) || 0)
    const joiningBonus = roundMoney(Number(p.joiningBonus) || 0)
    const royalty = roundMoney(Number(p.royalty) || 0)
    if (!name || salary + joiningBonus + royalty <= 0) continue
    pushDebit(GL.salary.code, GL.salary.name, salary, name)
    pushDebit(GL.bonus.code, GL.bonus.name, joiningBonus, name)
    pushDebit(GL.royalty.code, GL.royalty.name, royalty, name)
  }

  totalDebit = roundMoney(totalDebit)
  if (totalDebit <= 0) {
    return { lines: [], totalDebit: 0, totalCredit: 0, balanced: true }
  }

  lines.push({
    line: line,
    glAccount: GL.payable.code,
    accountName: GL.payable.name,
    debit: 0,
    credit: totalDebit,
    description: `Expense recognition — Player Payable (${lines.filter((l) => l.debit > 0).length} expense line(s))`,
  })

  return {
    lines,
    totalDebit,
    totalCredit: totalDebit,
    balanced: true,
  }
}

/**
 * Payment: debit Player Payable, credit Bank.
 * @param {number} amount
 * @param {string[]} playerNames — for description
 */
export function buildPaymentJournal(amount, playerNames = []) {
  const a = roundMoney(amount)
  if (a <= 0) {
    return { lines: [], totalDebit: 0, totalCredit: 0, balanced: true, error: 'Payment amount must be positive.' }
  }
  const names = [...new Set(playerNames.map((n) => String(n || '').trim()).filter(Boolean))]
  const desc =
    names.length === 0
      ? 'Payment to player'
      : names.length === 1
        ? `Payment to ${names[0]}`
        : `Payment to ${names.length} players (${names.slice(0, 5).join(', ')}${names.length > 5 ? '…' : ''})`

  const lines = [
    {
      line: 1,
      glAccount: GL.payable.code,
      accountName: GL.payable.name,
      debit: a,
      credit: 0,
      description: desc,
    },
    {
      line: 2,
      glAccount: GL.bank.code,
      accountName: GL.bank.name,
      debit: 0,
      credit: a,
      description: desc,
    },
  ]
  return { lines, totalDebit: a, totalCredit: a, balanced: true }
}

/** SAP-style document number: JE-YYYYMMDD-NNNNN (sequence resets per calendar day). */
export function nextDocumentNumber(date, daySequence) {
  const d = date instanceof Date ? date : new Date(date)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `JE-${y}${m}${day}-${String(daySequence).padStart(5, '0')}`
}

export function loadDocSequenceState() {
  try {
    const raw = localStorage.getItem('club-accounting-doc-seq-v1')
    if (!raw) return { dateKey: '', seq: 0 }
    return JSON.parse(raw)
  } catch {
    return { dateKey: '', seq: 0 }
  }
}

export function bumpDocSequence() {
  const now = new Date()
  const dateKey = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`
  const prev = loadDocSequenceState()
  const seq = prev.dateKey === dateKey ? prev.seq + 1 : 1
  const next = { dateKey, seq }
  localStorage.setItem('club-accounting-doc-seq-v1', JSON.stringify(next))
  return nextDocumentNumber(now, seq)
}

export function journalLinesToCsvRows(lines, extra = {}) {
  return lines.map((l) => ({
    ...extra,
    Line: l.line,
    'GL Account': l.glAccount,
    'Account Name': l.accountName,
    Debit: l.debit > 0 ? l.debit.toFixed(2) : '',
    Credit: l.credit > 0 ? l.credit.toFixed(2) : '',
    Description: l.description,
  }))
}

/** Generic INSERT template for integration testing / DBA handoff. */
export function journalDocumentToSql(doc, tableName = 'journal_entry_lines') {
  const cols = '(document_number, document_type, line_no, gl_account, account_name, debit, credit, description, posted_at)'
  const esc = (s) => String(s ?? '').replace(/'/g, "''")
  const rows = doc.lines
    .map(
      (l) =>
        `('${esc(doc.documentNumber)}','${esc(doc.kind)}',${l.line},'${esc(l.glAccount)}','${esc(l.accountName)}',${l.debit},${l.credit},'${esc(l.description)}','${esc(doc.postedAt)}')`
    )
    .join(',\n')
  return rows.length
    ? `INSERT INTO ${tableName} ${cols} VALUES\n${rows};`
    : `-- no lines for ${esc(doc.documentNumber)}`
}

export function exportHistoryAsJson(chartOfAccounts, documents) {
  return JSON.stringify(
    {
      generatedAt: new Date().toISOString(),
      chartOfAccounts,
      documents,
    },
    null,
    2
  )
}
