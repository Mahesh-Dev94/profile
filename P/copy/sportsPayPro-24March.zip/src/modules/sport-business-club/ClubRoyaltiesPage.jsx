import React, { useMemo } from 'react'
import { cn } from '../../utils/cn'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

function rowBookingMonth(row) {
  const d = row?.date
  if (!d) return null
  return typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')
}

function monthLabel(ym) {
  if (!ym || typeof ym !== 'string') return '—'
  const [y, m] = ym.split('-')
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : ym
}

function invoiceBookingMonth(inv) {
  const d = inv?.date || inv?.issueDate || inv?.invoiceDate
  return d ? String(d).slice(0, 7) : null
}

function aggregateRoyaltyByMonth(ledger) {
  const byMonth = {}
  ;(ledger || []).forEach((r) => {
    const key = rowBookingMonth(r) || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function aggregateRoyaltyByMonthForYear(ledger, year) {
  const y = String(year)
  const keys = []
  for (let m = 1; m <= 12; m++) keys.push(`${y}-${String(m).padStart(2, '0')}`)
  const byMonth = Object.fromEntries(keys.map((k) => [k, 0]))
  ;(ledger || []).forEach((r) => {
    const key = rowBookingMonth(r)
    if (!key || !key.startsWith(`${y}-`)) return
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return keys.map((month) => ({ month, revenue: byMonth[month] || 0 }))
}

/**
 * Club royalties page (Sport Business / Club) – based on sales (ledger).
 * Shows Royalty Total, Royalty Paid, Royalty Pending.
 */
/**
 * @param {{ embedded?: boolean, filterYear?: string | number | null }} props
 * When `filterYear` is set, stats, charts, and tables (except full standalone ledger) are scoped to that calendar year.
 */
export function ClubRoyaltiesPage({ embedded = false, filterYear = null } = {}) {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Calculating royalties...', 'Royalty data loaded', 600, embedded)
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])

  const ledgerAll = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const yearKey = filterYear != null && filterYear !== '' ? String(filterYear) : null

  const ledger = useMemo(() => {
    if (!yearKey) return ledgerAll
    return (ledgerAll || []).filter((r) => {
      const ym = rowBookingMonth(r)
      return ym && ym.startsWith(`${yearKey}-`)
    })
  }, [ledgerAll, yearKey])

  const invoicesScoped = useMemo(() => {
    if (!yearKey) return invoices || []
    return (invoices || []).filter((inv) => {
      const ym = invoiceBookingMonth(inv)
      return ym && ym.startsWith(`${yearKey}-`)
    })
  }, [invoices, yearKey])

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(
    () => invoicesScoped.reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0),
    [invoicesScoped]
  )
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger), [ledger])
  const royaltyMonthlyData = useMemo(() => {
    if (yearKey) return aggregateRoyaltyByMonthForYear(ledger, yearKey)
    return aggregateRoyaltyByMonth(ledger)
  }, [ledger, yearKey])

  // Per-talent Royalty Total, Paid, Pending for the listing table
  const royaltyByTalentRows = useMemo(() => {
    const totalByTalent = {}
    ledger.forEach((r) => {
      const name = r.talentName || 'Unknown'
      totalByTalent[name] = (totalByTalent[name] || 0) + Number(r.royaltyEarned || 0)
    })
    const paidByTalent = {}
    invoicesScoped.forEach((inv) => {
      const name = inv.talentName || 'Unknown'
      paidByTalent[name] = (paidByTalent[name] || 0) + Number(inv.paidAmount || 0)
    })
    const allNames = new Set([...Object.keys(totalByTalent), ...Object.keys(paidByTalent)])
    return Array.from(allNames)
      .map((name) => {
        const royaltyTotal = totalByTalent[name] || 0
        const royaltyPaid = paidByTalent[name] || 0
        const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)
        return { talentName: name, royaltyTotal, royaltyPaid, royaltyPending }
      })
      .filter((row) => row.royaltyTotal > 0 || row.royaltyPaid > 0)
      .sort((a, b) => b.royaltyTotal - a.royaltyTotal)
  }, [ledger, invoicesScoped])

  /** Same column shape as Salary payments (Payment summary): period rows with royalty as period total. */
  const royaltyPeriodRowsEmbedded = useMemo(() => {
    return (ledger || [])
      .map((r) => {
        const ym = rowBookingMonth(r)
        const roy = Number(r.royaltyEarned) || 0
        return {
          id: r.id || `${r.talentName}-${r.date}-${r.product}`,
          talentName: r.talentName || '—',
          month: ym || '—',
          monthlyRoyalty: roy,
          totalEarnings: roy,
        }
      })
      .sort((a, b) => {
        const cm = String(a.month).localeCompare(String(b.month))
        if (cm !== 0) return cm
        return String(a.talentName || '').localeCompare(String(b.talentName || ''))
      })
  }, [ledger])

  const royaltyEmbeddedPaymentColumns = [
    {
      id: 'talentName',
      header: 'Talent',
      accessorKey: 'talentName',
      cell: (info) => <span className="font-medium">{info.getValue()}</span>,
    },
    {
      id: 'month',
      header: 'Period',
      accessorKey: 'month',
      cell: (info) => monthLabel(info.getValue()),
    },
    { id: 'salaryAmount', header: 'Monthly salary', cell: () => <span className="text-neutral">—</span> },
    { id: 'perfBonus', header: 'Perf. bonus', cell: () => <span className="text-neutral">—</span> },
    {
      id: 'monthlyRoyalty',
      header: 'Royalty',
      accessorKey: 'monthlyRoyalty',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'totalEarnings',
      header: 'Period total',
      accessorKey: 'totalEarnings',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'status',
      header: 'Status',
      cell: () => (
        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-2xs font-medium text-slate-700">Earned</span>
      ),
    },
  ]

  const ledgerColumns = [
    { id: 'product', header: 'Product', accessorKey: 'product' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue() || 0) * 100).toFixed(2)}%` },
    { id: 'royaltyEarned', header: 'Royalty Paid', accessorKey: 'royaltyEarned', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const talentSummaryColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'royaltyTotal', header: 'Royalty Total', accessorKey: 'royaltyTotal', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPaid', header: 'Royalty Paid', accessorKey: 'royaltyPaid', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPending', header: 'Royalty Pending', accessorKey: 'royaltyPending', cell: (info) => formatINRDisplay(info.getValue()) },
  ]

  if (loading && !embedded) return <PageLoaderWithSkeleton message={loadMessage} />
  if (loading && embedded) {
    return <div className="py-10 text-center text-sm text-neutral">{loadMessage}</div>
  }

  return (
    <div className={cn('space-y-6', embedded && 'space-y-4')}>
      {!embedded && <h2 className="text-xl font-semibold">Royalties (based on sales)</h2>}
      {embedded && (
        <p className="text-xs text-neutral">
          {yearKey ? (
            <>
              Royalty for <span className="font-semibold text-primary-800">{yearKey}</span> (ledger + invoices booked in that year).
            </>
          ) : (
            'Royalty from sales ledger and invoice payments.'
          )}
        </p>
      )}
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Royalty Total" value={formatINRDisplay(royaltyTotal)} icon={DollarSign} />
        <StatCard title="Royalty Paid" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          <MonthlyRevenueChart
            data={royaltyMonthlyData}
            title={yearKey ? `Royalty by month (${yearKey})` : 'Royalty Monthly Trend'}
            description={
              yearKey
                ? 'Earned royalty per month in selected year (cards = same scope)'
                : 'Royalty by month (matches Total / Paid / Pending above)'
            }
            currency="USD"
            valueLabel="Royalty"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          {royaltyByTalent.length > 0 ? (
            <RoyaltyDistributionChart data={royaltyByTalent} title="Royalty Distribution" description="By talent" />
          ) : (
            <div>
              <h3 className="mb-4 text-base font-medium">Royalty Distribution</h3>
              <p className="text-sm text-neutral">No royalty data</p>
            </div>
          )}
        </div>
      </div>
      {embedded && (
        <div className="theme-card overflow-hidden p-3">
          <h3 className="mb-2 text-sm font-semibold text-primary-900">Royalty payments</h3>
          <p className="mb-3 text-2xs text-neutral">
            Rows follow the same layout as Salary payments: monthly salary and perf. bonus are not in this ledger; royalty is the amount for each sales period (period total = royalty).
          </p>
          {royaltyPeriodRowsEmbedded.length > 0 ? (
            <DataTable
              columns={royaltyEmbeddedPaymentColumns}
              data={royaltyPeriodRowsEmbedded}
              searchKey="talentName"
              searchPlaceholder="Search talent or period…"
            />
          ) : (
            <p className="text-sm text-neutral">No royalty ledger rows for this scope.</p>
          )}
        </div>
      )}
      {!embedded && royaltyByTalentRows.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-3 text-base font-medium">Royalty by talent (Total, Paid, Pending)</h3>
          <DataTable columns={talentSummaryColumns} data={royaltyByTalentRows} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}
      {!embedded && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-2 text-base font-medium">Royalty ledger</h3>
          <div className="mb-3 flex flex-wrap gap-4 rounded-md bg-gray-50 px-3 py-2 text-sm">
            <span><strong>Royalty Total:</strong> {formatINRDisplay(royaltyTotal)}</span>
            <span><strong>Royalty Paid:</strong> {formatINRDisplay(royaltyPaid)}</span>
            <span><strong>Royalty Pending:</strong> {formatINRDisplay(royaltyPending)}</span>
          </div>
          <DataTable columns={ledgerColumns} data={ledgerAll} searchKey="product" searchPlaceholder="Search by product or talent..." />
        </div>
      )}
      {embedded && (
        <p className="text-2xs text-neutral">
          Full line-item royalty ledger (all periods) is on the standalone <strong>Royalties</strong> page from the club menu.
        </p>
      )}
    </div>
  )
}
