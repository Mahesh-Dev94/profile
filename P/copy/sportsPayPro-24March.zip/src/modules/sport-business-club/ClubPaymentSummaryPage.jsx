import React, { useEffect, useMemo, useState } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentYearPaymentBreakdown } from '../../repositories/sportsBusinessRepository'
import { Card, CardContent } from '../../components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import { BarChart3, CalendarRange, ChevronDown, ChevronUp, Gift, Receipt, TrendingUp } from 'lucide-react'
import { ClubPerformanceBonusPage } from './ClubPerformanceBonusPage'
import { ClubRoyaltiesPage } from './ClubRoyaltiesPage'
import { ClubSalaryPage } from './ClubSalaryPage'

const FALLBACK_YEARS = ['2028', '2027', '2026', '2025', '2024', '2023']

function inferYearOptions(organizationId) {
  const ys = new Set(FALLBACK_YEARS)
  const add = (d) => {
    if (d == null) return
    const s = String(d)
    if (s.length >= 4 && /^\d{4}/.test(s)) ys.add(s.slice(0, 4))
  }
  ;(getAllByOrganization('salaryPayments', organizationId) || []).forEach((s) => add(s.month))
  ;(getAllByOrganization('invoices', organizationId) || []).forEach((inv) => {
    add(inv.date)
    add(inv.issueDate)
    add(inv.invoiceDate)
  })
  ;(getAllByOrganization('signingBonuses', organizationId) || []).forEach((b) => {
    add(b.signingDate)
    add(b.releaseDate)
  })
  ;(getAllByOrganization('sales', organizationId) || []).forEach((sale) => add(sale.date))
  ys.add(String(new Date().getFullYear()))
  return [...ys].sort((a, b) => Number(b) - Number(a))
}

function SectionShell({ open, onToggle, title, subtitle, icon: Icon, children }) {
  return (
    <Card className="overflow-hidden rounded-lg border border-slate-200/90 bg-white shadow-sm">
      <button type="button" className={cn('expand-trigger', open && 'expand-trigger--open')} onClick={onToggle}>
        <div className="flex min-w-0 flex-1 items-start gap-3">
          <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0 text-left">
            <p className="text-sm font-semibold text-primary-900">{title}</p>
            {subtitle ? <p className="mt-1 text-xs leading-relaxed text-slate-600">{subtitle}</p> : null}
          </div>
        </div>
        <span className="expand-chevron-wrap">
          {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </span>
      </button>
      {open ? <CardContent className="border-t border-slate-200/90 bg-slate-50/30 pt-4">{children}</CardContent> : null}
    </Card>
  )
}

export function ClubPaymentSummaryPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading payment summary...', 'Payment summary loaded')

  const yearOptions = useMemo(() => inferYearOptions(currentOrganizationId), [currentOrganizationId])

  const defaultYear = useMemo(() => {
    const cur = String(new Date().getFullYear())
    if (yearOptions.includes(cur)) return cur
    return yearOptions[0] || cur
  }, [yearOptions])

  const [summaryYear, setSummaryYear] = useState(() => String(new Date().getFullYear()))
  const [openByTalentYear, setOpenByTalentYear] = useState(true)
  const [openSalarySection, setOpenSalarySection] = useState(true)
  const [openBonusSection, setOpenBonusSection] = useState(false)
  const [openRoyaltySection, setOpenRoyaltySection] = useState(false)

  useEffect(() => {
    setSummaryYear((prev) => (yearOptions.includes(prev) ? prev : defaultYear))
  }, [currentOrganizationId, yearOptions, defaultYear])

  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])

  const talentsSorted = useMemo(
    () => [...(talents || [])].sort((a, b) => (a.name || '').localeCompare(b.name || '')),
    [talents]
  )

  const breakdownByTalent = useMemo(() => {
    return talentsSorted.map((t) => ({
      talent: t,
      b: getTalentYearPaymentBreakdown(t.id, currentOrganizationId, summaryYear),
    }))
  }, [talentsSorted, currentOrganizationId, summaryYear])

  const breakdownTotals = useMemo(() => {
    const z = () => ({ payable: 0, paid: 0, outstanding: 0 })
    const acc = { salary: z(), bonus: z(), royalty: z() }
    for (const { b } of breakdownByTalent) {
      acc.salary.payable += b.salary.payable
      acc.salary.paid += b.salary.paid
      acc.salary.outstanding += b.salary.outstanding
      acc.bonus.payable += b.bonus.payable
      acc.bonus.paid += b.bonus.paid
      acc.bonus.outstanding += b.bonus.outstanding
      acc.royalty.payable += b.royalty.payable
      acc.royalty.paid += b.royalty.paid
      acc.royalty.outstanding += b.royalty.outstanding
    }
    const grandOut = acc.salary.outstanding + acc.bonus.outstanding + acc.royalty.outstanding
    return { ...acc, grandOut }
  }, [breakdownByTalent])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  const currentCalendarYear = String(new Date().getFullYear())
  const yearHint =
    summaryYear === currentCalendarYear
      ? `All sections use ${summaryYear} (current calendar year).`
      : `All sections use calendar year ${summaryYear}.`

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <h2 className="theme-page-title">Payment summary</h2>
          <p className="theme-section-summary mt-1 max-w-3xl">
            Choose a year (top right). Tables, stat cards, and charts in every section below follow that year. Release payments and payment ledger are in the sidebar.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2 self-end rounded-lg border border-slate-200/90 bg-slate-50/80 px-3 py-2 shadow-sm sm:self-start">
          <CalendarRange className="h-4 w-4 text-primary" aria-hidden />
          <span className="text-sm font-semibold text-primary-900">Year</span>
          <Select value={summaryYear} onValueChange={setSummaryYear}>
            <SelectTrigger className="h-9 w-[108px] border-primary/25 bg-white font-mono text-sm font-semibold text-primary">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              {yearOptions.map((y) => (
                <SelectItem key={y} value={y}>
                  {y}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* 1 — Payment details by talent & year */}
      <SectionShell
        open={openByTalentYear}
        onToggle={() => setOpenByTalentYear((o) => !o)}
        title="Payment details by talent & year"
        subtitle={`Payable, paid, and outstanding for salary, bonus, and royalty. ${yearHint}`}
        icon={BarChart3}
      >
        <p className="mb-3 text-xs text-neutral">
          Year is controlled above (page header). This table matches the same year as Salary, Performance bonus, and Royalty sections.
        </p>
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b bg-slate-50 text-left">
                <th className="px-3 py-2 font-semibold text-gray-900">Talent</th>
                <th className="px-3 py-2 text-right font-semibold">Salary</th>
                <th className="px-3 py-2 text-right font-semibold">Bonus</th>
                <th className="px-3 py-2 text-right font-semibold">Royalty</th>
                <th className="px-3 py-2 text-right font-semibold">Grand (outst.)</th>
              </tr>
            </thead>
            <tbody>
              {breakdownByTalent.map(({ talent, b }) => {
                const gOut =
                  (b.salary?.outstanding || 0) + (b.bonus?.outstanding || 0) + (b.royalty?.outstanding || 0)
                return (
                  <tr key={talent.id} className="border-b border-gray-100 last:border-0">
                    <td className="px-3 py-2 font-medium text-primary-900">{talent.name || '—'}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-xs">
                      <span className="block text-neutral">P {formatINRDisplay(b.salary.payable)}</span>
                      <span className="text-green-700">Pd {formatINRDisplay(b.salary.paid)}</span>
                      <span className="block text-amber-700">O {formatINRDisplay(b.salary.outstanding)}</span>
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-xs">
                      <span className="block text-neutral">P {formatINRDisplay(b.bonus.payable)}</span>
                      <span className="text-green-700">Pd {formatINRDisplay(b.bonus.paid)}</span>
                      <span className="block text-amber-700">O {formatINRDisplay(b.bonus.outstanding)}</span>
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-xs">
                      <span className="block text-neutral">P {formatINRDisplay(b.royalty.payable)}</span>
                      <span className="text-green-700">Pd {formatINRDisplay(b.royalty.paid)}</span>
                      <span className="block text-amber-700">O {formatINRDisplay(b.royalty.outstanding)}</span>
                    </td>
                    <td className="px-3 py-2 text-right font-medium tabular-nums text-amber-800">{formatINRDisplay(gOut)}</td>
                  </tr>
                )
              })}
            </tbody>
            {breakdownByTalent.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-primary/20 bg-primary/[0.06] text-sm font-semibold text-primary-950">
                  <td className="px-3 py-2">All talents ({summaryYear})</td>
                  <td className="px-3 py-2 text-right tabular-nums text-xs">
                    <span className="block text-neutral">P {formatINRDisplay(breakdownTotals.salary.payable)}</span>
                    <span className="text-green-800">Pd {formatINRDisplay(breakdownTotals.salary.paid)}</span>
                    <span className="block text-amber-800">O {formatINRDisplay(breakdownTotals.salary.outstanding)}</span>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-xs">
                    <span className="block text-neutral">P {formatINRDisplay(breakdownTotals.bonus.payable)}</span>
                    <span className="text-green-800">Pd {formatINRDisplay(breakdownTotals.bonus.paid)}</span>
                    <span className="block text-amber-800">O {formatINRDisplay(breakdownTotals.bonus.outstanding)}</span>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-xs">
                    <span className="block text-neutral">P {formatINRDisplay(breakdownTotals.royalty.payable)}</span>
                    <span className="text-green-800">Pd {formatINRDisplay(breakdownTotals.royalty.paid)}</span>
                    <span className="block text-amber-800">O {formatINRDisplay(breakdownTotals.royalty.outstanding)}</span>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-amber-900">{formatINRDisplay(breakdownTotals.grandOut)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
        {breakdownByTalent.length === 0 && <p className="text-sm text-neutral">No talents in this organization.</p>}
        <p className="mt-2 text-2xs text-neutral">P = payable, Pd = paid, O = outstanding (for {summaryYear}).</p>
      </SectionShell>

      {/* 2 — Salary details: full salary page (register, charts, PDF) */}
      <SectionShell
        open={openSalarySection}
        onToggle={() => setOpenSalarySection((o) => !o)}
        title="Salary details"
        subtitle={`Salary workspace for ${summaryYear}: totals, monthly trend (Jan–Dec), by-talent from contracts, and payment rows for that year.`}
        icon={Receipt}
      >
        <div className="max-h-[80vh] overflow-y-auto overflow-x-hidden pr-1">
          <ClubSalaryPage key={`salary-${summaryYear}`} embedded filterYear={summaryYear} />
        </div>
      </SectionShell>

      {/* 3 — Performance bonus (embedded; line-item ledger hidden here) */}
      <SectionShell
        open={openBonusSection}
        onToggle={() => setOpenBonusSection((o) => !o)}
        title="Performance bonus details"
        subtitle={`One-time bonus (signing month in ${summaryYear}), charts, and embedded table — aligned. Line-item ledger is on the Performance Bonus page.`}
        icon={Gift}
      >
        <div className="max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1">
          <ClubPerformanceBonusPage key={`bonus-${summaryYear}`} embedded filterYear={summaryYear} />
        </div>
      </SectionShell>

      {/* 4 — Royalties (embedded; royalty line-item ledger hidden here) */}
      <SectionShell
        open={openRoyaltySection}
        onToggle={() => setOpenRoyaltySection((o) => !o)}
        title="Royalty details"
        subtitle={`Royalty earned and invoices booked in ${summaryYear}. Full sales ledger is on the Royalties page.`}
        icon={TrendingUp}
      >
        <div className="max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1">
          <ClubRoyaltiesPage key={`royalty-${summaryYear}`} embedded filterYear={summaryYear} />
        </div>
      </SectionShell>
    </div>
  )
}
