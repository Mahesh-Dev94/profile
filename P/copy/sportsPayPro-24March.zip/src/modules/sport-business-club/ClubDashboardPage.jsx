import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentPaymentTotalsAllTime } from '../../repositories/sportsBusinessRepository'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import {
  getAnnualSalaryTotal,
  getPaidSalaryTotal,
  getPendingSalaryTotal,
  getAnnualSalaryByTalentFromContracts,
  getPayrollPerformanceBonusTotalsFromSalaryRows,
  getPayrollPerformanceBonusByTalentName,
} from '../../utils/salaryCalculator'
import { StatCard } from '../../components/cards/StatCard'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Card, CardContent } from '../../components/ui/card'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  DollarSign,
  TrendingUp,
  Download,
  Gift,
  Search,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Users,
} from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'
import {
  MONTHLY_PERFORMANCE_BONUS_AMOUNT,
  STANDARD_ANNUAL_SALARY,
  PERFORMANCE_BONUS_PERCENT_OF_ANNUAL,
} from '../../utils/salaryCalculator'
import { cn } from '../../utils/cn'
import { getTalentEmployeeIdDisplay, talentMatchesSearch } from '../../utils/talentEmployeeId'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'

const TALENT_CARDS_PAGE_SIZE = 6

function talentInitials(name) {
  if (!name || typeof name !== 'string') return '?'
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function ClubDashboardPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Calculating dashboard analytics...', 'Dashboard loaded')
  const [talentSearch, setTalentSearch] = useState('')
  const [talentPage, setTalentPage] = useState(0)
  const [paymentSummaryExpandedId, setPaymentSummaryExpandedId] = useState(null)
  const [talentsInformationOpen, setTalentsInformationOpen] = useState(true)
  const [paymentSummaryDistributionOpen, setPaymentSummaryDistributionOpen] = useState(true)

  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const totalSalary = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  const paidSalary = useMemo(() => getPaidSalaryTotal(salaryPayments), [salaryPayments])
  const outstandingSalary = useMemo(() => getPendingSalaryTotal(salaryPayments), [salaryPayments])

  const payrollBonusTotals = useMemo(
    () => getPayrollPerformanceBonusTotalsFromSalaryRows(salaryPayments),
    [salaryPayments]
  )
  const performanceBonusTotal = payrollBonusTotals.payable
  const paidPerformanceBonus = payrollBonusTotals.paid
  const outstandingPerformanceBonus = payrollBonusTotals.outstanding

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const performanceBonusByTalent = useMemo(
    () => getPayrollPerformanceBonusByTalentName(salaryPayments),
    [salaryPayments]
  )
  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger).slice(0, 8), [ledger])
  const salaryDistribution = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])

  const filteredTalentsForCards = useMemo(() => {
    const list = [...(talents || [])]
    const q = (talentSearch || '').toLowerCase().trim()
    if (q) return list.filter((t) => talentMatchesSearch(t, q))
    return list
  }, [talents, talentSearch])

  const paginatedTalents = useMemo(() => {
    const start = talentPage * TALENT_CARDS_PAGE_SIZE
    return filteredTalentsForCards.slice(start, start + TALENT_CARDS_PAGE_SIZE)
  }, [filteredTalentsForCards, talentPage])

  const talentCardsTotalPages = Math.ceil(filteredTalentsForCards.length / TALENT_CARDS_PAGE_SIZE) || 1

  const exportReport = () => {
    const salaryRows = (salaryPayments || []).map((s) => ({
      Type: 'Salary',
      Talent: s.talentName,
      Period: s.month,
      Amount: s.salaryAmount,
      Status: s.paymentStatus,
    }))
    const bonusRows = (signingBonuses || []).map((b) => ({
      Type: 'Performance Bonus',
      Talent: b.talentName,
      Amount: b.amount,
      SigningDate: b.signingDate,
      ReleaseDate: b.releaseDate,
      Status: b.status,
    }))
    const royaltyRows = ledger.map((r) => ({
      Type: 'Royalty',
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      RoyaltyEarned: r.royaltyEarned,
      Date: r.date,
    }))
    const all = [...salaryRows, ...bonusRows, ...royaltyRows]
    const csv = Papa.unparse(all)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `report-salary-bonus-royalty-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  const clubName = (sportsBusinesses && sportsBusinesses[0]?.businessName) || 'this club'

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <Tabs defaultValue="talents" className="w-full space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
          <TabsList className="grid h-auto min-h-11 w-full grid-cols-2 gap-1.5 p-1.5 sm:max-w-md">
            <TabsTrigger value="talents" className="gap-2 py-2.5">
              <Users className="h-4 w-4 shrink-0 opacity-90" aria-hidden />
              Talents
            </TabsTrigger>
            <TabsTrigger value="summary" className="gap-2 py-2.5">
              <TrendingUp className="h-4 w-4 shrink-0 opacity-90" aria-hidden />
              Club summary
            </TabsTrigger>
          </TabsList>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 border-primary/25 text-primary hover:bg-primary/10 hover:border-primary/40 hover:text-primary-700"
            onClick={exportReport}
          >
            <Download className="mr-2 h-4 w-4" /> Export CSV
          </Button>
        </div>

        <TabsContent value="talents" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
      {/* All Talent Information — roster with expandable payment summary per talent */}
      <Card className="overflow-hidden rounded-lg border border-slate-200/90 border-l-[3px] border-l-primary bg-white shadow-sm">
        <button
          type="button"
          className={cn('expand-trigger', talentsInformationOpen && 'expand-trigger--open')}
          onClick={() => setTalentsInformationOpen((v) => !v)}
          aria-expanded={talentsInformationOpen}
          aria-controls="dashboard-talents-information-panel"
          id="dashboard-talents-information-trigger"
        >
          <div className="flex min-w-0 flex-1 items-start gap-3 sm:gap-4">
            <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 sm:h-12 sm:w-12">
              <Users className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-bold tracking-tight text-primary-900">Talents Information</p>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-2xs font-semibold tabular-nums text-primary-800 ring-1 ring-primary/12">
                  {filteredTalentsForCards.length} {filteredTalentsForCards.length === 1 ? 'talent' : 'talents'}
                </span>
              </div>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600">
                Tap a row below for payment summary · salary, bonus &amp; royalty
              </p>
            </div>
          </div>
          <span className="expand-chevron-wrap" aria-hidden>
            {talentsInformationOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </span>
        </button>
        {talentsInformationOpen ? (
          <CardContent id="dashboard-talents-information-panel" className="space-y-0 border-t border-slate-200/90 p-0" role="region" aria-labelledby="dashboard-talents-information-trigger">
           
            <div className="divide-y divide-slate-200/80 bg-slate-50/40">
              {paginatedTalents.map((talent, rowIdx) => {
                const totals = getTalentPaymentTotalsAllTime(talent.id, currentOrganizationId)
                const psOpen = paymentSummaryExpandedId === talent.id
                return (
                  <div
                    key={talent.id}
                    className={cn(
                      'w-full transition-colors duration-200',
                      psOpen
                        ? 'bg-primary/[0.04]'
                        : rowIdx % 2 === 1
                          ? 'bg-white hover:bg-slate-50/90'
                          : 'bg-slate-50/30 hover:bg-slate-100/50'
                    )}
                  >
                    <div
                      className={cn(
                        'flex min-w-0 flex-col border-l-[3px]',
                        psOpen ? 'border-l-primary' : 'border-l-transparent hover:border-l-slate-300'
                      )}
                    >
                      <button
                        type="button"
                        className={cn(
                          'flex w-full min-w-0 items-center gap-3 px-4 py-3 text-left outline-none transition-colors sm:gap-4 sm:py-3.5',
                          'focus-visible:bg-primary/[0.06] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/25'
                        )}
                        onClick={() =>
                          setPaymentSummaryExpandedId((id) => (id === talent.id ? null : talent.id))
                        }
                        aria-expanded={psOpen}
                        aria-label={`${psOpen ? 'Collapse' : 'Expand'} payment summary for ${talent.name}`}
                      >
                        <div
                          className={cn(
                            'flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold shadow-inner sm:h-12 sm:w-12 sm:text-base',
                            psOpen
                              ? 'bg-primary text-white ring-2 ring-primary/30'
                              : 'border border-primary/15 bg-primary/[0.08] text-primary-900'
                          )}
                          aria-hidden
                        >
                          {talentInitials(talent.name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold text-primary-900">{talent.name}</p>
                          <p className="mt-0.5 text-2xs text-slate-600">
                            <span className="font-mono font-semibold text-primary-800">
                              {getTalentEmployeeIdDisplay(talent)}
                            </span>
                            <span className="mx-1.5 text-slate-300">·</span>
                            <span className="text-slate-600">Signed</span>{' '}
                            <span className="font-medium text-primary-800">{talent.signingDate || '—'}</span>
                          </p>
                          {!psOpen && (
                            <>
                              <div className="mt-2 flex flex-wrap gap-2">
                                <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                  Outstanding {formatINRDisplay(totals.grand.outstanding)}
                                </span>
                                <span className="inline-flex items-center rounded-full border border-slate-200 bg-white px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                  Paid {formatINRDisplay(totals.grand.paid)}
                                </span>
                              </div>
                              <p className="mt-1.5 text-[10px] font-medium uppercase tracking-wide text-primary/50">
                                Tap for payment summary
                              </p>
                            </>
                          )}
                        </div>
                        <span
                          className={cn(
                            'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-primary',
                            psOpen ? 'border-primary/25 bg-primary/10' : 'border-slate-200 bg-white shadow-sm'
                          )}
                          aria-hidden
                        >
                          <ChevronRight
                            className={cn(
                              'h-4 w-4 transition-transform duration-200 ease-out sm:h-[18px] sm:w-[18px]',
                              psOpen ? 'rotate-90' : 'rotate-0'
                            )}
                          />
                        </span>
                      </button>
                    {psOpen && (
                      <div className="border-t border-primary/12 bg-primary/[0.04] px-4 pb-4 pt-3 sm:px-5">
                        <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">
                          Payment summary
                        </p>
                        <div className="overflow-x-auto rounded-lg border-2 border-primary/18 bg-white/95 shadow-inner shadow-primary/[0.08] ring-1 ring-primary/[0.05]">
                          <table className="w-full min-w-[520px] text-2xs">
                            <thead>
                              <tr className="border-b border-primary/15 bg-primary/12 text-left text-primary-900">
                                <th className="px-3 py-2 text-2xs font-bold">Type</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Payable</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Paid</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Outstanding</th>
                              </tr>
                            </thead>
                            <tbody>
                              {[
                                { label: 'Salary', ...totals.salary },
                                { label: 'Bonus', ...totals.bonus },
                                { label: 'Royalty', ...totals.royalty },
                              ].map((row) => (
                                <tr
                                  key={row.label}
                                  className="border-b border-primary/[0.08] last:border-0 odd:bg-primary/[0.02]"
                                >
                                  <td className="px-3 py-2 text-2xs font-semibold text-primary-900">{row.label}</td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-gray-800">
                                    {formatINRDisplay(row.payable)}
                                  </td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-green-700">
                                    {formatINRDisplay(row.paid)}
                                  </td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-amber-700">
                                    {formatINRDisplay(row.outstanding)}
                                  </td>
                                </tr>
                              ))}
                              <tr className="bg-primary/15 text-xs font-bold text-primary-950">
                                <td className="px-3 py-2">Total</td>
                                <td className="px-3 py-2 text-right tabular-nums">
                                  {formatINRDisplay(totals.grand.payable)}
                                </td>
                                <td className="px-3 py-2 text-right tabular-nums text-green-900">
                                  {formatINRDisplay(totals.grand.paid)}
                                </td>
                                <td className="px-3 py-2 text-right tabular-nums text-amber-900">
                                  {formatINRDisplay(totals.grand.outstanding)}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        <div className="flex justify-end border-t border-slate-200/90 bg-slate-50/60 px-1 py-3">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-7 border-primary/30 px-2.5 text-2xs font-semibold text-primary hover:bg-primary/10"
                            onClick={() => navigate(`/sponsorship/talents/${talent.id}`)}
                          >
                            View more
                          </Button>
                        </div>
                      </div>
                    )}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="space-y-3 border-t border-slate-200/90 bg-slate-50/50 px-4 py-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-2xs text-neutral">
                  Showing {paginatedTalents.length} of {filteredTalentsForCards.length} talent
                  {filteredTalentsForCards.length !== 1 ? 's' : ''} · page {talentPage + 1} of {talentCardsTotalPages}
                </p>
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-primary/50" />
                  <Input
                    placeholder="Search talent..."
                    value={talentSearch}
                    onChange={(e) => {
                      setTalentSearch(e.target.value)
                      setTalentPage(0)
                    }}
                    className="h-8 border-primary/15 pl-8 text-2xs focus-visible:border-primary/30 focus-visible:ring-primary/20"
                  />
                </div>
              </div>
              {filteredTalentsForCards.length === 0 && (
                <p className="text-2xs text-neutral">No talents match search.</p>
              )}
              {talentCardsTotalPages > 1 && (
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                    disabled={talentPage === 0}
                    onClick={() => setTalentPage((p) => p - 1)}
                  >
                    Previous
                  </Button>
                  <span className="text-2xs font-medium text-primary-800">
                    Page {talentPage + 1} of {talentCardsTotalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                    disabled={talentPage >= talentCardsTotalPages - 1}
                    onClick={() => setTalentPage((p) => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        ) : null}
      </Card>
        </TabsContent>

        <TabsContent value="summary" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
      {/* Club-wide aggregates & charts */}
      <Card className="overflow-hidden rounded-lg border border-slate-200/90 border-l-[3px] border-l-primary bg-white shadow-sm">
        <button
          type="button"
          className={cn('expand-trigger', paymentSummaryDistributionOpen && 'expand-trigger--open')}
          onClick={() => setPaymentSummaryDistributionOpen((v) => !v)}
          aria-expanded={paymentSummaryDistributionOpen}
          aria-controls="dashboard-payment-summary-distribution-panel"
          id="dashboard-payment-summary-distribution-trigger"
        >
          <div className="flex min-w-0 flex-1 items-start gap-3 sm:gap-4">
            <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <TrendingUp className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1 text-left">
              <p className="text-sm font-bold tracking-tight text-primary-900">Talents payment summary &amp; distribution</p>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600 sm:text-xs">
                Combined figures across <span className="font-medium text-primary-800">all talents</span>: salary, performance
                bonus, and royalty — plus distribution charts.
              </p>
            </div>
          </div>
          <span className="expand-chevron-wrap" aria-hidden>
            {paymentSummaryDistributionOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </span>
        </button>
        {paymentSummaryDistributionOpen ? (
          <CardContent
            id="dashboard-payment-summary-distribution-panel"
            className="space-y-4 border-t border-slate-200/90 bg-slate-50/40 px-4 pb-4 pt-4 sm:px-5"
            role="region"
            aria-labelledby="dashboard-payment-summary-distribution-trigger"
          >
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Total Payable Salary"
                value={formatINRDisplay(totalSalary)}
                icon={DollarSign}
                onClick={() => navigate('/sponsorship/payments')}
              />
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Paid Salary"
                value={formatINRDisplay(paidSalary)}
                icon={DollarSign}
                onClick={() => navigate('/sponsorship/payments')}
              />
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Outstanding Salary"
                value={formatINRDisplay(outstandingSalary)}
                icon={DollarSign}
                onClick={() => navigate('/sponsorship/payments')}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <StatCard
                className="border border-accent/25 bg-accent/[0.06] shadow-sm"
                title="Total Payable Bonus"
                value={formatINRDisplay(performanceBonusTotal)}
                icon={Gift}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
                subtitle={`${formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/mo · ${PERFORMANCE_BONUS_PERCENT_OF_ANNUAL * 100}% of ${formatINRDisplay(STANDARD_ANNUAL_SALARY)} annual`}
              />
              <StatCard
                className="border border-accent/25 bg-accent/[0.06] shadow-sm"
                title="Paid Bonus"
                value={formatINRDisplay(paidPerformanceBonus)}
                icon={Gift}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
              />
              <StatCard
                className="border border-accent/25 bg-accent/[0.06] shadow-sm"
                title="Outstanding Bonus"
                value={formatINRDisplay(outstandingPerformanceBonus)}
                icon={Gift}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Total Payable Royalty"
                value={formatINRDisplay(royaltyTotal)}
                icon={TrendingUp}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
              />
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Paid Royalty"
                value={formatINRDisplay(royaltyPaid)}
                icon={TrendingUp}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
              />
              <StatCard
                className="border border-primary/10 bg-white/95 shadow-sm shadow-primary/5"
                title="Outstanding Royalty"
                value={formatINRDisplay(royaltyPending)}
                icon={TrendingUp}
                onClick={() => navigate('/sponsorship/payments/release-payment')}
              />
            </div>
            <p className="border-t border-primary/10 pt-2 text-right text-xs text-primary-700/70">
              Reflects salary, bonus ({formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/talent/mo ={' '}
              {PERFORMANCE_BONUS_PERCENT_OF_ANNUAL * 100}% of annual {formatINRDisplay(STANDARD_ANNUAL_SALARY)}), and royalty for{' '}
              <span className="font-medium text-accent-600">{clubName}</span>.
            </p>

            <div className="grid gap-6 lg:grid-cols-3">
              <div className="min-h-[300px] rounded-lg border border-primary/15 bg-white p-6 shadow-md shadow-primary/[0.07] ring-1 ring-primary/[0.04]">
                {salaryDistribution.length > 0 ? (
                  <RoyaltyDistributionChart data={salaryDistribution} title="Salary distribution" description="By talent" />
                ) : (
                  <>
                    <h3 className="mb-4 text-base font-medium">Salary distribution</h3>
                    <p className="text-sm text-neutral">No salary data</p>
                  </>
                )}
              </div>
              <div className="min-h-[300px] rounded-lg border border-accent/25 bg-accent/[0.04] p-6 shadow-sm">
                {performanceBonusByTalent.length > 0 ? (
                  <RoyaltyDistributionChart data={performanceBonusByTalent} title="Performance bonus distribution" description="By talent" />
                ) : (
                  <>
                    <h3 className="mb-4 text-base font-medium">Performance bonus distribution</h3>
                    <p className="text-sm text-neutral">No performance bonus data</p>
                  </>
                )}
              </div>
              <div className="min-h-[300px] rounded-lg border border-primary/15 bg-white p-6 shadow-md shadow-primary/[0.07] ring-1 ring-primary/[0.04]">
                {royaltyByTalent.length > 0 ? (
                  <RoyaltyDistributionChart data={royaltyByTalent} title="Royalty distribution" description="By talent" />
                ) : (
                  <>
                    <h3 className="mb-4 text-base font-medium">Royalty distribution</h3>
                    <p className="text-sm text-neutral">No royalty data</p>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        ) : null}
      </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
