import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentPaymentTotalsAllTime } from '../../repositories/sportsBusinessRepository'
import { Card, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Checkbox } from '../../components/ui/checkbox'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { User, Filter, Search, ChevronDown, ChevronUp, Users, LayoutList } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import { getTalentEmployeeIdDisplay, talentMatchesSearch } from '../../utils/talentEmployeeId'

const PAGE_SIZE = 6

export function ClubTalentsListPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading talents...', 'Talents loaded')
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])

  const [search, setSearch] = useState('')
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const [page, setPage] = useState(0)
  const [paymentSummaryExpandedId, setPaymentSummaryExpandedId] = useState(null)
  const [rosterPanelOpen, setRosterPanelOpen] = useState(true)

  const filteredTalents = useMemo(() => {
    let list = [...(talents || [])]
    const q = (search || '').toLowerCase().trim()
    if (q) list = list.filter((t) => talentMatchesSearch(t, q))
    if (selectedTalentIds.length > 0) list = list.filter((t) => selectedTalentIds.includes(t.id))
    return list.sort((a, b) => (a.name || '').localeCompare(b.name || ''))
  }, [talents, search, selectedTalentIds])

  const paginatedTalents = useMemo(() => {
    const start = page * PAGE_SIZE
    return filteredTalents.slice(start, start + PAGE_SIZE)
  }, [filteredTalents, page])

  const totalPages = Math.ceil(filteredTalents.length / PAGE_SIZE) || 1
  const talentOptions = useMemo(
    () => (talents || []).map((t) => ({ id: t.id, name: t.name, employeeId: t.employeeId })),
    [talents]
  )

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
      {/* Left: tab first, then full-width listing */}
      <div className="min-w-0 flex-1">
        <div className="w-full">
          <button
            type="button"
            onClick={() => setRosterPanelOpen((v) => !v)}
            className="mb-4 flex w-full items-center gap-3 rounded-lg border border-primary/12 bg-primary/[0.05] p-1.5 pl-4 pr-3 text-left shadow-sm transition-colors hover:bg-primary/[0.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
            aria-expanded={rosterPanelOpen}
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <LayoutList className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold tracking-tight text-primary-900">All Talents Information</p>
              <p className="mt-0.5 text-2xs leading-snug text-slate-600">
                Full-width roster · expand a row for salary, bonus &amp; royalty totals
              </p>
            </div>
            <Users className="hidden h-4 w-4 shrink-0 text-primary/40 sm:block" aria-hidden />
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <ChevronDown className={cn('h-5 w-5 transition-transform duration-200', rosterPanelOpen && 'rotate-180')} />
            </span>
          </button>

          {rosterPanelOpen && (
            <Card className="overflow-hidden rounded-lg border border-slate-200/90 bg-white shadow-sm">
              <div className="flex items-center justify-between gap-3 border-b border-primary/12 bg-primary/[0.05] px-4 py-2.5 shadow-sm">
                <p className="text-xs font-bold uppercase tracking-wider text-primary-900">All Talents Information</p>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-2xs font-semibold text-primary-800 ring-1 ring-primary/12">
                  {filteredTalents.length} total
                </span>
              </div>
              <CardContent className="space-y-0 p-0">
                <div className="divide-y divide-slate-200/80 bg-slate-50/40">
                  {paginatedTalents.map((talent, rowIdx) => {
                    const totals = getTalentPaymentTotalsAllTime(talent.id, currentOrganizationId)
                    const psOpen = paymentSummaryExpandedId === talent.id
                    return (
                      <div
                        key={talent.id}
                        className={cn(
                          'w-full transition-colors duration-200',
                          psOpen
                            ? 'bg-primary/[0.04]'
                            : rowIdx % 2 === 1
                              ? 'bg-white hover:bg-slate-50/90'
                              : 'bg-slate-50/30 hover:bg-slate-100/50'
                        )}
                      >
                        <div
                          className={cn(
                            'flex w-full min-w-0 flex-col border-l-[3px]',
                            psOpen ? 'border-l-primary' : 'border-l-transparent hover:border-l-slate-300'
                          )}
                        >
                          <div className="flex min-w-0 flex-1 items-center gap-3 px-4 py-3 sm:gap-4">
                            <div
                              className={cn(
                                'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border-2 shadow-sm sm:h-12 sm:w-12',
                                psOpen
                                  ? 'border-primary/35 bg-primary text-white'
                                  : 'border-primary/20 bg-primary/10 text-primary'
                              )}
                            >
                              <User className="h-5 w-5 sm:h-6 sm:w-6" />
                            </div>
                            <button
                              type="button"
                              className="min-w-0 flex-1 rounded-lg py-1 text-left transition-colors hover:bg-primary/[0.06] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                              onClick={() =>
                                setPaymentSummaryExpandedId((id) => (id === talent.id ? null : talent.id))
                              }
                              aria-expanded={psOpen}
                              aria-label={`${psOpen ? 'Collapse' : 'Expand'} payment summary for ${talent.name}`}
                            >
                              <p className="truncate text-sm font-bold text-primary-900">{talent.name}</p>
                              <p className="mt-0.5 text-2xs text-neutral">
                                Employee ID:{' '}
                                <span className="font-mono font-semibold text-primary-800">
                                  {getTalentEmployeeIdDisplay(talent)}
                                </span>
                              </p>
                              <p className="mt-0.5 text-2xs text-neutral">
                                Signing date: <span className="font-medium text-primary-800">{talent.signingDate || '—'}</span>
                              </p>
                              {!psOpen && (
                                <div className="mt-2 flex flex-wrap gap-2">
                                  <span className="inline-flex items-center rounded-md border border-primary/15 bg-primary/[0.08] px-2 py-0.5 text-2xs font-medium text-primary-900">
                                    Outst. {formatINRDisplay(totals.grand.outstanding)}
                                  </span>
                                  <span className="inline-flex items-center rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-2xs font-medium text-slate-700">
                                    Paid {formatINRDisplay(totals.grand.paid)}
                                  </span>
                                </div>
                              )}
                            </button>
                            <button
                              type="button"
                              className={cn(
                                'flex h-10 w-10 shrink-0 items-center justify-center self-center rounded-xl border-2 transition-colors sm:h-11 sm:w-11',
                                psOpen
                                  ? 'border-primary/30 bg-white text-primary shadow-sm'
                                  : 'border-primary/15 bg-white text-primary hover:border-primary/30 hover:bg-primary/[0.06]'
                              )}
                              onClick={() =>
                                setPaymentSummaryExpandedId((id) => (id === talent.id ? null : talent.id))
                              }
                              aria-expanded={psOpen}
                              aria-label={psOpen ? 'Collapse payment row' : 'Expand payment row'}
                            >
                              {psOpen ? (
                                <ChevronUp className="h-4 w-4 sm:h-5 sm:w-5" />
                              ) : (
                                <ChevronDown className="h-4 w-4 text-primary/70 sm:h-5 sm:w-5" />
                              )}
                            </button>
                          </div>
                          
                        </div>
                        {psOpen && (
                          <div className="border-t border-slate-200/90 bg-slate-50/50 px-4 pb-4 pt-3">
                            <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">
                              Payment summary
                            </p>
                            <div className="overflow-x-auto rounded-lg border-2 border-primary/18 bg-white/95 shadow-inner shadow-primary/[0.08] ring-1 ring-primary/[0.05]">
                              <table className="w-full min-w-[520px] text-2xs">
                                <thead>
                                  <tr className="border-b border-primary/15 bg-primary/12 text-left text-primary-900">
                                    <th className="px-3 py-2 text-2xs font-bold">Type</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Payable</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Paid</th>
                                    <th className="px-3 py-2 text-right text-2xs font-bold">Outstanding</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {[
                                    { label: 'Salary', ...totals.salary },
                                    { label: 'Bonus', ...totals.bonus },
                                    { label: 'Royalty', ...totals.royalty },
                                  ].map((row) => (
                                    <tr
                                      key={row.label}
                                      className="border-b border-primary/[0.08] last:border-0 odd:bg-primary/[0.02]"
                                    >
                                      <td className="px-3 py-2 text-2xs font-semibold text-primary-900">{row.label}</td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-gray-800">
                                        {formatINRDisplay(row.payable)}
                                      </td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-green-700">
                                        {formatINRDisplay(row.paid)}
                                      </td>
                                      <td className="px-3 py-2 text-right text-2xs tabular-nums text-amber-700">
                                        {formatINRDisplay(row.outstanding)}
                                      </td>
                                    </tr>
                                  ))}
                                  <tr className="bg-primary/15 text-xs font-bold text-primary-950">
                                    <td className="px-3 py-2">Total</td>
                                    <td className="px-3 py-2 text-right tabular-nums">
                                      {formatINRDisplay(totals.grand.payable)}
                                    </td>
                                    <td className="px-3 py-2 text-right tabular-nums text-green-900">
                                      {formatINRDisplay(totals.grand.paid)}
                                    </td>
                                    <td className="px-3 py-2 text-right tabular-nums text-amber-900">
                                      {formatINRDisplay(totals.grand.outstanding)}
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                            <div className="flex justify-end px-4 pb-3 pt-3 pb-5">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="h-7 border-primary/30 px-2.5 text-2xs font-semibold text-primary hover:bg-primary/10"
                              onClick={() => navigate(`/sponsorship/talents/${talent.id}`)}
                            >
                              View more
                            </Button>
                          </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>

                <div className="space-y-3 border-t border-slate-200/90 bg-slate-50/50 px-4 py-4">
                  <p className="text-2xs text-neutral">
                    Showing {paginatedTalents.length} of {filteredTalents.length} talent
                    {filteredTalents.length !== 1 ? 's' : ''} · page {page + 1} of {totalPages}
                  </p>

                  {filteredTalents.length === 0 && (
                    <p className="text-2xs text-neutral">No talents match the current filters.</p>
                  )}

                  {totalPages > 1 && (
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                        disabled={page === 0}
                        onClick={() => setPage((p) => p - 1)}
                      >
                        Previous
                      </Button>
                      <span className="text-2xs font-medium text-primary-800">
                        Page {page + 1} of {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                        disabled={page >= totalPages - 1}
                        onClick={() => setPage((p) => p + 1)}
                      >
                        Next
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Right: filters */}
      <aside className="w-full shrink-0 overflow-hidden rounded-xl border-2 border-accent/35 bg-accent/[0.07] shadow-md shadow-primary/5 lg:w-80">
        <div className="border-b-2 border-accent/30 bg-primary px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15 text-accent-200">
              <Filter className="h-4 w-4" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-white">Filters</p>
              <p className="text-2xs font-medium text-primary-100/90">Search & narrow the list</p>
            </div>
          </div>
        </div>

        <div className="space-y-4 bg-white/90 p-4">
          <div>
            <label className="mb-1.5 block text-2xs font-semibold uppercase tracking-wide text-primary-800">
              Search
            </label>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-accent-600" />
              <Input
                placeholder="Name…"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(0)
                }}
                className="h-8 border-accent/25 bg-white pl-8 text-2xs text-gray-800 placeholder:text-neutral focus-visible:border-accent/50 focus-visible:ring-accent/20"
              />
            </div>
          </div>

          <div>
            <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">Include only</p>
            <p className="mb-2 text-2xs leading-relaxed text-neutral">Check talents to restrict the list (none = all).</p>
            <div className="max-h-[46vh] space-y-1 overflow-y-auto rounded-lg border border-slate-200/90 bg-slate-50/80 p-2 scrollbar-thin">
              {talentOptions.length === 0 ? (
                <p className="px-2 py-2 text-2xs text-neutral">No talent data</p>
              ) : (
                talentOptions.map((t) => {
                  const checked = selectedTalentIds.includes(t.id)
                  return (
                    <label
                      key={t.id}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-2xs transition-colors',
                        checked
                          ? 'bg-primary/15 font-medium text-primary-900 ring-1 ring-primary/25'
                          : 'text-gray-800 hover:bg-white/90 hover:ring-1 hover:ring-accent/20'
                      )}
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={() =>
                          setSelectedTalentIds((prev) =>
                            prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id]
                          )
                        }
                        className="border-primary/40 data-[state=checked]:border-primary data-[state=checked]:bg-primary"
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate">{t.name}</span>
                        {t.employeeId ? (
                          <span className="mt-0.5 block truncate font-mono text-3xs text-primary-700">{t.employeeId}</span>
                        ) : null}
                      </span>
                    </label>
                  )
                })
              )}
            </div>
          </div>

          {(search || selectedTalentIds.length > 0) && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 w-full border-accent/40 text-2xs font-semibold text-accent-700 hover:bg-accent/10 hover:text-accent-800"
              onClick={() => {
                setSearch('')
                setSelectedTalentIds([])
                setPage(0)
              }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </aside>
    </div>
  )
}
