/**
 * sql.js + IndexedDB database layer — same API as dbService for Sports Pay Pro.
 * Call initSqliteDb() once from app entry (e.g. main.jsx) before using getAll/create/etc.
 */

import initSqlJs from 'sql.js'
import wasmUrl from 'sql.js/dist/sql-wasm.wasm?url'
import { SCHEMA_SQL, TABLE_COLUMNS } from './sqliteSchema'
import { saveToIndexedDB, loadFromIndexedDB } from './indexedDBPersistence'
import { getSeedData } from './seedData'

let db = null

const JSON_COLUMNS = { talentIds: true, talentsAssociated: true }

function locateFile(file) {
  return wasmUrl
}

function valueToDb(val) {
  if (val === undefined || val === null) return null
  if (Array.isArray(val)) return JSON.stringify(val)
  return val
}

function persist() {
  if (!db) return Promise.resolve()
  const binary = db.export()
  return saveToIndexedDB(binary)
}

function runSqliteMigrations(database) {
  try {
    database.run('ALTER TABLE contracts ADD COLUMN productType TEXT')
  } catch (_) {
    /* column already exists */
  }
  try {
    database.run('ALTER TABLE talents ADD COLUMN employeeId TEXT')
  } catch (_) {
    /* column already exists */
  }
  try {
    database.run(`
      CREATE TABLE IF NOT EXISTS talentMonthPayments (
        id TEXT PRIMARY KEY,
        organizationId TEXT,
        talentId TEXT,
        talentName TEXT,
        month TEXT,
        salaryPayable REAL,
        salaryPaid REAL,
        salaryOutstanding REAL,
        bonusPayable REAL,
        bonusPaid REAL,
        bonusOutstanding REAL,
        royaltyPayable REAL,
        royaltyPaid REAL,
        royaltyOutstanding REAL
      )
    `)
  } catch (_) {
    /* ignore */
  }
}

export function initSqliteDb() {
  if (db) return Promise.resolve(db)
  return initSqlJs({ locateFile }).then((SQL) => {
    return loadFromIndexedDB().then((saved) => {
      db = new SQL.Database(saved || null)
      if (!saved) {
        db.run(SCHEMA_SQL)
        seedFromData(db, getSeedData())
        return persist().then(() => db)
      }
      runSqliteMigrations(db)
      return persist().then(() => db)
    })
  })
}

function seedFromData(database, data) {
  for (const [collection, rows] of Object.entries(data)) {
    const cols = TABLE_COLUMNS[collection]
    if (!cols || !Array.isArray(rows)) continue
    const table = collection
    for (const row of rows) {
      if (table === 'royaltyPayments') {
        const { id: rowId, ...rest } = row
        try {
          database.run('INSERT OR REPLACE INTO royaltyPayments (id, data) VALUES (?, ?)', [rowId ?? row.id, JSON.stringify(rest)])
        } catch (e) {
          console.warn('Seed insert failed for', table, row?.id, e)
        }
        continue
      }
      const placeholders = cols.map(() => '?').join(', ')
      const names = cols.join(', ')
      const values = cols.map((c) => valueToDb(row[c]))
      try {
        database.run(`INSERT OR REPLACE INTO ${table} (${names}) VALUES (${placeholders})`, values)
      } catch (e) {
        console.warn('Seed insert failed for', table, row?.id, e)
      }
    }
  }
}

const ORG_COLLECTIONS = [
  'talents',
  'sponsorshipCompanies',
  'sportsBusinesses',
  'contracts',
  'sales',
  'invoices',
  'salaryPayments',
  'signingBonuses',
  'royaltyPayments',
  'paymentLedger',
  'talentMonthPayments',
]

function getTable(collection) {
  return collection
}

export function getAll(collection) {
  if (!db) return []
  const table = getTable(collection)
  const cols = TABLE_COLUMNS[table]
  if (!cols) return []
  try {
    const r = db.exec(`SELECT * FROM ${table}`)
    if (!r.length || !r[0].values.length) return []
    const { columns } = r[0]
    return r[0].values.map((row) => {
      const obj = {}
      columns.forEach((col, i) => {
        let v = row[i]
        if (JSON_COLUMNS[col] && typeof v === 'string') {
          try {
            v = JSON.parse(v)
          } catch (_) {}
        }
        obj[col] = v
      })
      if (table === 'royaltyPayments' && obj.data != null) {
        try {
          const parsed = typeof obj.data === 'string' ? JSON.parse(obj.data) : obj.data
          return { id: obj.id, ...parsed }
        } catch (_) {}
      }
      return obj
    })
  } catch {
    return []
  }
}

export function getById(collection, id) {
  const list = getAll(collection)
  return list.find((item) => item.id === id) ?? null
}

export function getAllByOrganization(collection, organizationId) {
  const list = getAll(collection)
  if (!organizationId || !ORG_COLLECTIONS.includes(collection)) return list
  return list.filter((item) => item.organizationId === organizationId)
}

export function create(collection, data) {
  if (!db) return data
  const id = data.id || `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
  const record = { ...data, id }
  const table = getTable(collection)
  const cols = TABLE_COLUMNS[table]
  if (!cols) return record
  if (table === 'royaltyPayments') {
    const { id: _id, ...rest } = record
    try {
      db.run('INSERT OR REPLACE INTO royaltyPayments (id, data) VALUES (?, ?)', [id, JSON.stringify(rest)])
      persist()
    } catch (e) {
      console.warn('Create failed', collection, e)
    }
    return record
  }
  const placeholders = cols.map(() => '?').join(', ')
  const names = cols.join(', ')
  const values = cols.map((c) => valueToDb(record[c]))
  try {
    db.run(`INSERT OR REPLACE INTO ${table} (${names}) VALUES (${placeholders})`, values)
    persist()
  } catch (e) {
    console.warn('Create failed', collection, e)
  }
  return record
}

export function update(collection, id, data) {
  const existing = getById(collection, id)
  if (!existing) return null
  const updated = { ...existing, ...data, id }
  const table = getTable(collection)
  const cols = TABLE_COLUMNS[table]
  if (!cols) return null
  if (table === 'royaltyPayments') {
    const { id: _id, ...rest } = updated
    try {
      db.run('UPDATE royaltyPayments SET data = ? WHERE id = ?', [JSON.stringify(rest), id])
      persist()
    } catch (e) {
      console.warn('Update failed', collection, id, e)
      return null
    }
    return updated
  }
  const setClause = cols.filter((c) => c !== 'id').map((c) => `${c} = ?`).join(', ')
  const values = cols.filter((c) => c !== 'id').map((c) => valueToDb(updated[c]))
  values.push(id)
  try {
    db.run(`UPDATE ${table} SET ${setClause} WHERE id = ?`, values)
    persist()
  } catch (e) {
    console.warn('Update failed', collection, id, e)
    return null
  }
  return updated
}

export function remove(collection, id) {
  if (!db) return false
  const table = getTable(collection)
  try {
    db.run(`DELETE FROM ${table} WHERE id = ?`, [id])
    persist()
    return true
  } catch {
    return false
  }
}

export function getDbRaw() {
  return {
    organizations: getAll('organizations'),
    users: getAll('users'),
    talents: getAll('talents'),
    sportsBusinesses: getAll('sportsBusinesses'),
    sponsorshipCompanies: getAll('sponsorshipCompanies'),
    contracts: getAll('contracts'),
    salaryPayments: getAll('salaryPayments'),
    signingBonuses: getAll('signingBonuses'),
    sales: getAll('sales'),
    invoices: getAll('invoices'),
    royaltyPayments: getAll('royaltyPayments'),
    paymentLedger: getAll('paymentLedger'),
    talentMonthPayments: getAll('talentMonthPayments'),
  }
}

export function resetDb() {
  if (!db) return getDbRaw()
  const tables = [
    'organizations', 'users', 'talents', 'sportsBusinesses', 'sponsorshipCompanies',
    'contracts', 'salaryPayments', 'signingBonuses', 'sales', 'invoices',
    'paymentLedger', 'royaltyPayments', 'talentMonthPayments',
  ]
  for (const t of tables) {
    try {
      db.run(`DELETE FROM ${t}`)
    } catch (_) {}
  }
  seedFromData(db, getSeedData())
  persist()
  return getDbRaw()
}

export function isSqliteReady() {
  return !!db
}
