import React from 'react'
import { Card, CardContent } from '../ui/card'
import { cn } from '../../utils/cn'

export function StatCard({ title, value, subtitle, icon: Icon, trend, className, valueClassName, onClick }) {
  return (
    <Card className={cn('overflow-hidden', onClick && 'cursor-pointer hover:border-primary/40 hover:shadow-md transition-all', className)} onClick={onClick}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs font-medium uppercase tracking-wide text-neutral">{title}</p>
            <p className={cn('mt-1.5 text-lg font-bold tabular-nums text-primary-900', valueClassName)}>{value}</p>
            {subtitle && <p className="mt-1 text-2xs text-neutral">{subtitle}</p>}
            {trend && (
              <p className={cn('mt-1 text-xs font-medium', trend > 0 ? 'text-green-600' : 'text-red-600')}>
                {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}% vs last period
              </p>
            )}
          </div>
          {Icon && (
            <div className="shrink-0 rounded-lg border border-primary/15 bg-primary/10 p-2.5">
              <Icon className="h-5 w-5 text-primary" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
