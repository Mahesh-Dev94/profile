import React from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { chartCategoricalFills } from '../../theme/chartTheme'

export function RoyaltyDistributionChart({ data = [], title, description }) {
  return (
    <ChartCard title={title ?? 'Royalty Distribution'} description={description ?? 'By talent or category'}>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={2}
            dataKey="value"
            nameKey="name"
            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          >
            {data.map((_, i) => (
              <Cell key={i} fill={chartCategoricalFills[i % chartCategoricalFills.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Amount']} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
