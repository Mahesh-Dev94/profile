import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { CreditCard, User, Building2, ArrowRight } from 'lucide-react'
import { Button } from '../../components/ui/button'

// Sport Business theme — used for all cards (primary + accent)
const CARD_PRIMARY = '#0B3C5D'
const CARD_ACCENT = '#EAB308'

const portals = [
  {
    id: 'sports_business',
    role: 'sponsorship_admin',
    title: 'Sport Business Payment',
    description: 'Manage salary, performance bonus, royalty & payments for your club. Release payments, view ledger and contracts.',
    icon: CreditCard,
    path: '/sponsorship/dashboard',
  },
  {
    id: 'talent',
    role: 'talent',
    title: 'Talent Portal',
    description: 'View your salary, performance bonus, royalties and payment history. Access payslips and tax details.',
    icon: User,
    path: '/talent/dashboard',
  },
  {
    id: 'partner',
    role: 'vendor_partner',
    title: 'Partner / Sport vendor',
    description: 'Manage sport / partner relationships, contracts and sales. Upload sales and track royalty contributions.',
    icon: Building2,
    path: '/partner/dashboard',
  },
]

function getSampleUserForRole(users, role) {
  if (!Array.isArray(users)) return null
  if (role === 'sponsorship_admin') return users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role)) || null
  if (role === 'talent') return users.find((u) => u.role === 'talent') || null
  if (role === 'vendor_partner') return users.find((u) => u.role === 'vendor_partner' || u.role === 'partner') || null
  return null
}

export function LandingPage() {
  const navigate = useNavigate()
  const { user, loginAsFirstUserForRole } = useAuth()
  const users = useMemo(() => getAll('users'), [])

  const handleEnter = (portal) => {
    const samePortal = user && (
      (portal.role === 'sponsorship_admin' && ['sponsorship_admin', 'sponsor_manager', 'platform_admin', 'finance_manager'].includes(user.role)) ||
      (portal.role === 'talent' && user.role === 'talent') ||
      (portal.role === 'vendor_partner' && ['vendor_partner', 'partner'].includes(user.role))
    )
    if (samePortal) {
      navigate(portal.path)
      return
    }
    const ok = loginAsFirstUserForRole(portal.role)
    if (ok.success) navigate(portal.path)
  }

  return (
    <div className="min-h-screen bg-white text-gray-900">
      <div className="relative mx-auto max-w-6xl px-6 py-10">
        <header className="mb-12 text-center">
          <div
            className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl border-2 border-primary/15 bg-white shadow-sm"
            style={{ color: CARD_ACCENT, boxShadow: `0 0 0 1px ${CARD_PRIMARY}14` }}
          >
            <CreditCard className="h-7 w-7" />
          </div>
          <h1 className="mb-2 text-xs font-bold uppercase tracking-wide text-primary">
            Sports Pay Pro
          </h1>
          <p className="mx-auto max-w-xl text-2xs leading-relaxed text-primary-600">
            Royalty & payment management for clubs, talents and partners.
          </p>
          {user && (
            <p className="mt-3 text-2xs text-neutral">
              Signed in as {user.name} ·{' '}
              <button
                type="button"
                onClick={() => navigate(user.role === 'talent' ? '/talent/dashboard' : user.role === 'vendor_partner' || user.role === 'partner' ? '/partner/dashboard' : '/sponsorship/dashboard')}
                className="font-semibold text-primary hover:underline"
              >
                Go to my dashboard
              </button>
            </p>
          )}
        </header>

        <section className="grid md:grid-cols-3 gap-8">
          {portals.map((portal) => {
            const Icon = portal.icon
            return (
              <div
                key={portal.id}
                className="group relative rounded-2xl border-2 border-primary/12 bg-white p-6 shadow-sm transition-all duration-300 hover:border-accent/40 hover:shadow-md"
              >
                <div className="mb-4 flex items-center gap-3">
                  <div
                    className="flex h-12 w-12 items-center justify-center rounded-xl border border-accent/25 bg-accent/10 transition-opacity group-hover:opacity-90"
                    style={{ color: CARD_ACCENT }}
                  >
                    <Icon className="h-6 w-6" />
                  </div>
                  <h2 className="text-xs font-semibold text-primary-900">{portal.title}</h2>
                </div>
                <p className="mb-3 text-2xs leading-relaxed text-neutral">{portal.description}</p>
                {(() => {
                  const sample = getSampleUserForRole(users, portal.role)
                  return sample ? (
                    <p className="mb-3 rounded-lg border border-primary/10 bg-primary/[0.04] px-3 py-2 text-2xs text-neutral">
                      Direct login: <span className="font-medium text-gray-800">{sample.name}</span>
                      {sample.email && <span className="block text-gray-400 truncate mt-0.5">{sample.email}</span>}
                    </p>
                  ) : null
                })()}
                <Button
                  onClick={() => handleEnter(portal)}
                  className="w-full text-white font-medium border-0 hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: CARD_ACCENT }}
                >
                  Enter <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )
          })}
        </section>

        <footer className="mt-14 text-center text-3xs text-primary-400">
          Sports Pay Pro — Secure payment and royalty management
        </footer>
      </div>
    </div>
  )
}
