import React, { useMemo } from 'react'
import { getAll } from '../../database/dbService'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { DollarSign, Building2, FileText, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'

function aggregateByMonth(sales) {
  const byMonth = {}
  sales.forEach((s) => {
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function PartnerDashboard() {
  const sales = getAll('sales')
  const contracts = getAll('contracts')
  const sponsorshipCompanies = getAll('sponsorshipCompanies')
  const sportsBusinesses = getAll('sportsBusinesses')
  const invoices = getAll('invoices')

  const activeContracts = useMemo(() => contracts.filter((c) => c.status === 'active'), [contracts])
  const partnerCompaniesCount = sponsorshipCompanies.length
  const totalSales = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const royaltyContributions = useMemo(() => {
    return (invoices || []).reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0)
  }, [invoices])

  const countryRevenue = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])

  const monthlyData = aggregateByMonth(sales)

  const clubPartners = useMemo(() => {
    const set = new Set()
    contracts.forEach((c) => {
      if (c.licensee) set.add(c.licensee)
    })
    return Array.from(set)
  }, [contracts])

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Partner Companies" value={partnerCompaniesCount} icon={Building2} subtitle="Sponsorship / vendor companies" />
        <StatCard title="Active Contracts" value={activeContracts.length} icon={FileText} subtitle="With sports businesses (clubs)" />
        <StatCard title="Royalty Contributions" value={`$${royaltyContributions.toLocaleString()}`} icon={TrendingUp} subtitle="Total royalty from sales" />
        <StatCard title="Total Sales" value={`$${totalSales.toLocaleString()}`} icon={DollarSign} subtitle="Net sales volume" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryRevenue} />
      </div>
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Sports Businesses (Clubs) under contract</h3>
        <ul className="space-y-2">
          {clubPartners.length === 0 ? (
            <p className="text-sm text-neutral">No clubs linked yet</p>
          ) : (
            clubPartners.map((name) => (
              <li key={name} className="flex justify-between text-sm">
                <span>{name}</span>
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  )
}
