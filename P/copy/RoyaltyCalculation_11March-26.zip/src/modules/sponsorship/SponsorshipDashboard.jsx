import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getAnnualSalaryTotal, getPaidSalaryTotal } from '../../utils/salaryCalculator'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { Button } from '../../components/ui/button'
import { DollarSign, Users, TrendingUp, Download, Gift } from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'

function aggregateRoyaltyByMonth(ledger) {
  const byMonth = {}
  ;(ledger || []).forEach((r) => {
    const d = r.date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function SponsorshipDashboard() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const annualSalaryTotal = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  const signingBonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const signingBonusReleased = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const signingBonusPending = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const royaltyMonthlyData = useMemo(() => aggregateRoyaltyByMonth(ledger), [ledger])

  const royaltyByTalent = useMemo(() => {
    const map = {}
    ledger.forEach((r) => {
      map[r.talentName] = (map[r.talentName] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(map).map(([name, value]) => ({ name, value })).slice(0, 8)
  }, [ledger])

  const salaryDistribution = useMemo(() => {
    const byTalent = {}
    ;(salaryPayments || []).forEach((s) => {
      byTalent[s.talentName] = (byTalent[s.talentName] || 0) + (Number(s.salaryAmount) || 0)
    })
    return Object.entries(byTalent).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value)
  }, [salaryPayments])

  const talentPaymentSummary = useMemo(() => {
    const byTalent = {}
    ledger.forEach((r) => {
      if (!byTalent[r.talentName]) byTalent[r.talentName] = { royalty: 0, salary: 0 }
      byTalent[r.talentName].royalty += r.royaltyEarned || 0
    })
    ;(salaryPayments || []).forEach((s) => {
      if (!byTalent[s.talentName]) byTalent[s.talentName] = { royalty: 0, salary: 0 }
      byTalent[s.talentName].salary += Number(s.salaryAmount) || 0
    })
    return Object.entries(byTalent).map(([name, data]) => ({ name, ...data, total: data.royalty + data.salary })).sort((a, b) => b.total - a.total).slice(0, 6)
  }, [ledger, salaryPayments])

  const exportRoyaltyReport = () => {
    const csv = Papa.unparse(ledger.map((r) => ({
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      UnitsSold: r.unitsSold,
      NetSales: r.netSales,
      RoyaltyEarned: r.royaltyEarned,
      Date: r.date,
    })))
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `royalty-report-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={exportRoyaltyReport}><Download className="mr-2 h-4 w-4" /> Export royalty report CSV</Button>
      </div>
      <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <StatCard title="Annual Salary Total" value={formatINRDisplay(annualSalaryTotal)} icon={DollarSign} />
        <StatCard title="Signing Bonus Total" value={formatINRDisplay(signingBonusTotal)} icon={Gift} />
        <StatCard title="Signing Bonus Released" value={formatINRDisplay(signingBonusReleased)} icon={Gift} />
        <StatCard title="Signing Bonus Pending" value={formatINRDisplay(signingBonusPending)} icon={Gift} />
        <StatCard title="Total Royalty" value={formatINRDisplay(royaltyTotal)} icon={TrendingUp} />
        <StatCard title="Pending Royalty" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
        <StatCard title="Paid Royalty" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <MonthlyRevenueChart
            data={royaltyMonthlyData}
            title="Royalty Monthly Trend"
            description="Royalty by month (INR)"
            currency="INR"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <h3 className="mb-4 text-base font-medium">Salary Distribution</h3>
          {salaryDistribution.length > 0 ? (
            <RoyaltyDistributionChart data={salaryDistribution} />
          ) : (
            <p className="text-sm text-neutral">No salary data</p>
          )}
        </div>
      </div>
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Talent Payment Summary</h3>
        {talentPaymentSummary.length > 0 ? (
          <ul className="space-y-2">
            {talentPaymentSummary.map(({ name, salary, royalty, total }) => (
              <li key={name} className="flex justify-between items-center text-sm">
                <span className="font-medium">{name}</span>
                <span className="text-neutral">Salary: {formatINRDisplay(salary)} · Royalty: {formatINRDisplay(royalty)} · Total: {formatINRDisplay(total)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-neutral">No payment data</p>
        )}
      </div>
    </div>
  )
}
