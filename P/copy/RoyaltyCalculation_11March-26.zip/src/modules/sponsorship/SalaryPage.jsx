import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { SalarySlipPDFViewer } from '../../components/forms/SalarySlipPDFViewer'
import { downloadSalarySlipPDF } from '../../utils/pdfGenerator'
import { FileText, Download, Filter, User, Calendar, DollarSign } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { Checkbox } from '../../components/ui/checkbox'

function monthLabel(month) {
  if (!month || typeof month !== 'string') return '—'
  const [y, m] = month.split('-')
  const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : month
}

export function SalaryPage() {
  const { currentOrganizationId } = useOrganization()
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const [viewingSlip, setViewingSlip] = useState(null)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])

  const businessName = sportsBusinesses[0]?.businessName || 'Sports Business'

  const talentOptions = useMemo(() => {
    const map = new Map()
    ;(salaryPayments || []).forEach((s) => {
      if (s.talentId && s.talentName) map.set(s.talentId, s.talentName)
    })
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }))
  }, [salaryPayments])

  const filterByTalent = (talentId) => {
    setSelectedTalentIds((prev) =>
      prev.includes(talentId) ? prev.filter((id) => id !== talentId) : [...prev, talentId]
    )
  }

  const filteredSalaries = useMemo(() => {
    if (selectedTalentIds.length === 0) return salaryPayments || []
    return (salaryPayments || []).filter((s) => selectedTalentIds.includes(s.talentId))
  }, [salaryPayments, selectedTalentIds])

  const summary = useMemo(() => {
    const list = filteredSalaries
    const totalAmount = list.reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)
    const paidCount = list.filter((s) => s.paymentStatus === 'paid').length
    const pendingCount = list.filter((s) => s.paymentStatus === 'pending').length
    const paidAmount = list.filter((s) => s.paymentStatus === 'paid').reduce((a, s) => a + (Number(s.salaryAmount) || 0), 0)
    return { totalAmount, paidCount, pendingCount, paidAmount, recordCount: list.length }
  }, [filteredSalaries])

  const columns = [
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'month', header: 'Period', accessorKey: 'month', cell: (info) => <span title={info.getValue()}>{monthLabel(info.getValue())}</span> },
    { id: 'salaryAmount', header: 'Salary Amount (INR)', accessorKey: 'salaryAmount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'paymentStatus', header: 'Payment Status', accessorKey: 'paymentStatus', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
    { id: 'actions', header: 'Actions', cell: ({ row }) => (
      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="bg-primary text-white hover:bg-primary/90 border-primary text-xs" onClick={() => setViewingSlip(row.original)}>
          <FileText className="h-4 w-4 mr-1" /> View Salary Slip PDF
        </Button>
        <Button variant="outline" size="sm" className="text-xs" onClick={() => downloadSalarySlipPDF(row.original, businessName)}>
          <Download className="h-4 w-4 mr-1" /> Download PDF
        </Button>
      </div>
    )},
  ]

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filter by talent</span>
        </div>
        <p className="text-2xs text-neutral mb-2">Check talent to show only their salaries (none = all)</p>
        <div className="space-y-2 max-h-[70vh] overflow-y-auto">
          {talentOptions.length === 0 ? (
            <p className="text-2xs text-neutral">No talent data</p>
          ) : (
            talentOptions.map((t) => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
                <Checkbox
                  checked={selectedTalentIds.includes(t.id)}
                  onCheckedChange={() => filterByTalent(t.id)}
                />
                <span className="text-xs truncate">{t.name}</span>
              </label>
            ))
          )}
        </div>
        {selectedTalentIds.length > 0 && (
          <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={() => setSelectedTalentIds([])}>
            Show all talents
          </Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <h2 className="text-xl font-semibold">Salary</h2>
        <p className="text-sm text-neutral">Monthly salary records. Use the left panel to filter by talent. View or download salary slip PDF.</p>

        <div className="grid gap-4 grid-cols-2 lg:grid-cols-5">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><User className="h-3.5 w-3.5" /> Records</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold">{summary.recordCount}</p>
              <p className="text-2xs text-neutral">salary entries</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><DollarSign className="h-3.5 w-3.5" /> Total Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold">{formatINRDisplay(summary.totalAmount)}</p>
              <p className="text-2xs text-neutral">in selected range</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral">Paid</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-green-700">{summary.paidCount}</p>
              <p className="text-2xs text-neutral">{formatINRDisplay(summary.paidAmount)} paid</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-amber-700">{summary.pendingCount}</p>
              <p className="text-2xs text-neutral">awaiting payment</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Period</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs font-medium">Monthly</p>
              <p className="text-2xs text-neutral">per talent</p>
            </CardContent>
          </Card>
        </div>

        <DataTable columns={columns} data={filteredSalaries} searchKey="talentName" searchPlaceholder="Search by talent..." />
      </div>

      <SalarySlipPDFViewer open={!!viewingSlip} onOpenChange={(v) => !v && setViewingSlip(null)} salaryRecord={viewingSlip} businessName={businessName} />
    </div>
  )
}
