import React, { useState, useMemo } from 'react'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { StatCard } from '../../components/cards/StatCard'
import { FilterPanel } from '../../components/filters/FilterPanel'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { TrendingUp } from 'lucide-react'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'

const ALL_VALUE = '__all__'

export function TalentSalesPage() {
  const { user } = useAuth()
  const talentId = user?.talentId
  const allSales = getAll('sales')
  const sales = useMemo(
    () => (Array.isArray(allSales) ? allSales : []).filter((s) => (s.talentIds || []).includes(talentId)),
    [allSales, talentId]
  )

  const [licenseeFilter, setLicenseeFilter] = useState(ALL_VALUE)
  const [countryFilter, setCountryFilter] = useState(ALL_VALUE)

  const filtered = useMemo(() => {
    return sales.filter((s) => {
      if (licenseeFilter && licenseeFilter !== ALL_VALUE && s.licensee !== licenseeFilter) return false
      if (countryFilter && countryFilter !== ALL_VALUE && s.country !== countryFilter) return false
      return true
    })
  }, [sales, licenseeFilter, countryFilter])

  const licensees = useMemo(() => [...new Set(sales.map((s) => s.licensee).filter(Boolean))], [sales])
  const countries = useMemo(() => [...new Set(sales.map((s) => s.country).filter(Boolean))], [sales])

  const totalUnits = filtered.reduce((a, s) => a + (Number(s.unitsSold) || 0), 0)

  const monthlyData = useMemo(() => {
    const byMonth = {}
    sales.forEach((s) => {
      const d = s.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (Number(s.unitsSold) || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [sales])
  const countryData = useMemo(() => {
    const byCountry = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      byCountry[c] = (byCountry[c] || 0) + (Number(s.unitsSold) || 0)
    })
    return Object.entries(byCountry).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])

  const filters = [
    {
      key: 'licensee',
      label: 'Licensee',
      type: 'select',
      value: licenseeFilter || ALL_VALUE,
      onChange: setLicenseeFilter,
      options: [{ value: ALL_VALUE, label: 'All' }, ...licensees.map((l) => ({ value: l, label: l }))],
      placeholder: 'All',
    },
    {
      key: 'country',
      label: 'Country',
      type: 'select',
      value: countryFilter || ALL_VALUE,
      onChange: setCountryFilter,
      options: [{ value: ALL_VALUE, label: 'All' }, ...countries.map((c) => ({ value: c, label: c }))],
      placeholder: 'All',
    },
  ]

  const columns = [
    { id: 'sku', header: 'SKU', accessorKey: 'sku' },
    { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
    { id: 'productDescription', header: 'Product', accessorKey: 'productDescription' },
    { id: 'country', header: 'Country', accessorKey: 'country' },
    { id: 'unitsSold', header: 'Units Sold', accessorKey: 'unitsSold' },
    { id: 'typeOfSales', header: 'Type', accessorKey: 'typeOfSales' },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Sales</h2>
      <p className="text-sm text-neutral">Sales where you are associated (units by product and region).</p>
      <div className="grid gap-4 md:grid-cols-2">
        <StatCard title="Total Units" value={totalUnits.toLocaleString()} icon={TrendingUp} />
      </div>
      {(monthlyData.length > 0 || countryData.length > 0) && (
        <div className="grid gap-6 lg:grid-cols-2">
          {monthlyData.length > 0 && <MonthlyRevenueChart data={monthlyData} />}
          {countryData.length > 0 && <CountrySalesChart data={countryData} />}
        </div>
      )}
      <div className="flex gap-6">
        <FilterPanel
          filters={filters}
          onApply={() => {}}
          onReset={() => { setLicenseeFilter(ALL_VALUE); setCountryFilter(ALL_VALUE); }}
        />
        <div className="flex-1">
          <DataTable
            columns={columns}
            data={filtered}
            searchKey="productDescription"
            searchPlaceholder="Search by product..."
            pageSize={10}
          />
        </div>
      </div>
    </div>
  )
}
