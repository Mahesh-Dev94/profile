/**
 * Indian Rupee (INR) formatting with Indian number system (lakhs, crores).
 * e.g. 18000000 → "1,80,00,000" (last 3 digits, then groups of 2)
 */
export function formatINR(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Math.round(Number(num))
  if (n === 0) return '0'
  const s = String(Math.abs(n))
  const len = s.length
  let out = ''
  for (let i = 0; i < len; i++) {
    out += s[i]
    const remaining = len - (i + 1)
    if (i < len - 1 && remaining > 3 && (remaining - 3) % 2 === 0) out += ','
  }
  return (n < 0 ? '−' : '') + out
}

/** Display as "INR 1,80,00,000" */
export function formatINRDisplay(num) {
  return `INR ${formatINR(num)}`
}

/** Default basic salary (INR) and signing bonus text for contracts */
export const DEFAULT_SALARY_2026_27 = 18000000   // INR 1,80,00,000
export const DEFAULT_SALARY_2027_28 = 20000000   // INR 2,00,00,000
export const DEFAULT_SIGNING_BONUS_INR = 3000000 // INR 30,00,000
export const SIGNING_BONUS_DESCRIPTION = 'INR 30,00,000 payable within 10 business days of execution.'
