/**
 * Salary calculations for talent payments.
 * Monthly salary = Annual Salary / 12 (or from contract).
 */

export function getMonthlySalary(annualSalary) {
  return (Number(annualSalary) || 0) / 12
}

export function getAnnualSalaryTotal(salaryPayments) {
  return (salaryPayments || []).reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPaidSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'paid')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPendingSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'pending')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}
