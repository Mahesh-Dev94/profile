/**
 * Payment processing simulation: create ledger entry, update status.
 * No backend – updates via dbService.
 */

import { create, update, getById } from '../database/dbService'
import { formatINR } from './currencyFormat'

export function generateTransactionId() {
  return `TXN-${String(Date.now()).slice(-8)}`
}

export function recordPaymentLedgerEntry({ organizationId, talentId, talentName, paymentType, amount, paymentMethod, details }) {
  const id = `ledger-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
  const entry = {
    id,
    date: new Date().toISOString().slice(0, 10),
    transactionId: generateTransactionId(),
    talentId: talentId || null,
    talentName: talentName || '—',
    paymentType: paymentType || 'Royalty', // 'Salary' | 'Signing Bonus' | 'Royalty'
    amount: Number(amount) || 0,
    paymentMethod: paymentMethod || 'card',
    status: 'completed',
    details: details || '',
    organizationId: organizationId || null,
  }
  create('paymentLedger', entry)
  return entry
}

export function processSalaryPayment(salaryRecord, paymentMethod, organizationId) {
  update('salaryPayments', salaryRecord.id, { paymentStatus: 'paid' })
  const entry = recordPaymentLedgerEntry({
    organizationId,
    talentId: salaryRecord.talentId,
    talentName: salaryRecord.talentName,
    paymentType: 'Salary',
    amount: salaryRecord.salaryAmount,
    paymentMethod,
    details: `Salary slip ${salaryRecord.month}`,
  })
  return entry
}

export function processSigningBonusPayment(signingBonusRecord, paymentMethod, organizationId) {
  update('signingBonuses', signingBonusRecord.id, { status: 'paid' })
  const amt = Number(signingBonusRecord.amount) || 0
  const entry = recordPaymentLedgerEntry({
    organizationId,
    talentId: signingBonusRecord.talentId,
    talentName: signingBonusRecord.talentName,
    paymentType: 'Signing Bonus',
    amount: amt,
    paymentMethod,
    details: `Signing bonus – INR ${formatINR(amt)} payable within 10 business days of execution. Release date: ${signingBonusRecord.releaseDate || 'N/A'}.`,
  })
  return entry
}

export function processRoyaltyPayment(invoice, amount, paymentMethod, organizationId) {
  const inv = typeof invoice === 'string' ? getById('invoices', invoice) : invoice
  if (!inv) return null
  const paidSoFar = Number(inv.paidAmount) || 0
  const newPaid = paidSoFar + (Number(amount) || 0)
  const totalDue = Number(inv.royaltyAmount) || 0
  const status = newPaid >= totalDue ? 'paid' : 'partially_paid'
  update('invoices', inv.id, { paidAmount: newPaid, status })
  const entry = recordPaymentLedgerEntry({
    organizationId,
    talentId: inv.talentId,
    talentName: inv.talentName,
    paymentType: 'Royalty',
    amount,
    paymentMethod,
    details: `Royalty ${inv.date || inv.invoiceID}`,
  })
  return entry
}
