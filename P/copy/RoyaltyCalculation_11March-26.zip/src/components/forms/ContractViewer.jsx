import React from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog'
import { Button } from '../ui/button'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function ContractViewer({ open, onOpenChange, contract, onGeneratePDF }) {
  if (!contract) return null
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Contract {contract.contractID || contract.id}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-2 text-sm">
          <p><span className="font-medium text-neutral">Talent:</span> {contract.talentName}</p>
          <p><span className="font-medium text-neutral">Licensee:</span> {contract.licensee}</p>
          <p><span className="font-medium text-neutral">Basic Salary 2026-27:</span> {formatINRDisplay(contract.basicSalary2026_27 ?? contract.annualSalary)}</p>
          <p><span className="font-medium text-neutral">Basic Salary 2027-28:</span> {formatINRDisplay(contract.basicSalary2027_28 ?? contract.annualSalary)}</p>
          <p><span className="font-medium text-neutral">Signing Bonus:</span> {formatINRDisplay(contract.signingBonus)} — payable within 10 business days of execution</p>
          <p><span className="font-medium text-neutral">Royalty %:</span> {((contract.royaltyPercent || 0) * 100).toFixed(2)}%</p>
          <p><span className="font-medium text-neutral">SKU Min. Guarantee (Annual):</span> {formatINRDisplay(contract.skuMinimumGuaranteeAnnual)}</p>
          <p><span className="font-medium text-neutral">Start:</span> {formatDisplayDate(contract.startDate)}</p>
          <p><span className="font-medium text-neutral">End:</span> {formatDisplayDate(contract.endDate)}</p>
          <p><span className="font-medium text-neutral">Status:</span> {contract.status || 'Active'}</p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          <Button onClick={() => { onGeneratePDF?.(contract); onOpenChange(false); }}>Generate PDF</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
