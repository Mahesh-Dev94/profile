import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { formatINR } from '../../utils/currencyFormat'

const COLORS = ['#0B3C5D', '#F97316', '#6B7280']

function formatShort(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Number(num)
  if (n >= 10000000) return `${(n / 10000000).toFixed(1)}Cr`
  if (n >= 100000) return `${(n / 100000).toFixed(1)}L`
  if (n >= 1000) return `${(n / 1000).toFixed(0)}k`
  return String(Math.round(n))
}

export function MonthlyRevenueChart({ data = [], title, description, currency = 'USD' }) {
  const isINR = currency === 'INR'
  const yFormatter = (v) => (isINR ? `₹${formatShort(v)}` : `$${(v / 1000).toFixed(0)}k`)
  const tooltipFormatter = (v) => (isINR ? [`INR ${formatINR(v)}`, 'Revenue'] : [`$${Number(v).toLocaleString()}`, 'Revenue'])
  return (
    <ChartCard title={title || 'Monthly Revenue'} description={description || 'Revenue by month'}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 11 }} tickFormatter={(v) => (v && v.length >= 7 ? `${v.slice(5, 7)}/${v.slice(0, 4)}` : v)} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={yFormatter} />
          <Tooltip formatter={tooltipFormatter} labelFormatter={(l) => (l && l.length >= 7 ? `${l.slice(5, 7)}/${l.slice(0, 4)}` : l)} />
          <Bar dataKey="revenue" fill={COLORS[0]} radius={[4, 4, 0, 0]} name="Revenue" />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
