import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import { AuthLayout } from './app/layouts/AuthLayout'
import { MainLayout } from './app/layouts/MainLayout'
import { ProtectedRoute } from './app/routes/ProtectedRoute'
import { LoginPage } from './modules/auth/LoginPage'
import { SponsorshipDashboard } from './modules/sponsorship/SponsorshipDashboard'
import { SportsBusinessesPage } from './modules/sponsorship/SportsBusinessesPage'
import { SponsorshipCompaniesPage } from './modules/sponsorship/SponsorshipCompaniesPage'
import { ContractsPage } from './modules/contracts/ContractsPage'
import { InvoicesPage } from './modules/invoices/InvoicesPage'
import { SigningBonusPage } from './modules/sponsorship/SigningBonusPage'
import { PaymentsPage } from './modules/sponsorship/PaymentsPage'
import { TalentDashboard } from './modules/talent/TalentDashboard'
import { TalentRoyaltiesPage } from './modules/talent/TalentRoyaltiesPage'
import { TalentInvoicesPage } from './modules/talent/TalentInvoicesPage'
import { TalentSalesPage } from './modules/talent/TalentSalesPage'
import { TalentSigningBonusPage } from './modules/talent/TalentSigningBonusPage'
import { PartnerDashboard } from './modules/partner/PartnerDashboard'
import { PartnerUploadSalesPage } from './modules/partner/PartnerUploadSalesPage'
import { PartnerSalesPage } from './modules/partner/PartnerSalesPage'
import { PartnerContractsPage } from './modules/partner/PartnerContractsPage'
import { AdminDashboard } from './modules/admin/AdminDashboard'
import { OrganizationsPage } from './modules/admin/OrganizationsPage'
import { AdminContractsPage } from './modules/admin/AdminContractsPage'
import { ReconciliationPage } from './modules/admin/ReconciliationPage'
import { AuditLogsPage } from './modules/admin/AuditLogsPage'
import { ForecastPage } from './modules/admin/ForecastPage'

function getDefaultPath(user) {
  if (!user) return '/login'
  if (user.role === 'platform_admin' || user.role === 'finance_manager') return '/admin/dashboard'
  if (user.role === 'sponsor_manager') return '/sponsorship/dashboard'
  if (user.role === 'talent') return '/talent/dashboard'
  if (user.role === 'vendor_partner') return '/partner/dashboard'
  if (user.role === 'sponsorship_admin' || user.role === 'partner') return user.role === 'partner' ? '/partner/dashboard' : '/sponsorship/dashboard'
  return '/admin/dashboard'
}

export default function App() {
  const { user } = useAuth()

  return (
    <Routes>
      <Route path="/login" element={
        user ? <Navigate to={getDefaultPath(user)} replace /> : <AuthLayout />
      }>
        <Route index element={<LoginPage />} />
      </Route>

      <Route path="/admin" element={
        <ProtectedRoute allowedRoles={['platform_admin', 'finance_manager']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="organizations" element={<OrganizationsPage />} />
        <Route path="contracts" element={<AdminContractsPage />} />
        <Route path="reconciliation" element={<ReconciliationPage />} />
        <Route path="audit-logs" element={<AuditLogsPage />} />
        <Route path="forecast" element={<ForecastPage />} />
      </Route>

      <Route path="/sponsorship" element={
        <ProtectedRoute allowedRoles={['sponsor_manager', 'platform_admin', 'finance_manager', 'sponsorship_admin']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<SponsorshipDashboard />} />
        <Route path="businesses" element={<SportsBusinessesPage />} />
        <Route path="companies" element={<SponsorshipCompaniesPage />} />
        <Route path="contracts" element={<ContractsPage />} />
        <Route path="invoices" element={<InvoicesPage />} />
        <Route path="payments" element={<PaymentsPage />} />
        <Route path="signing-bonus" element={<SigningBonusPage />} />
      </Route>

      <Route path="/talent" element={
        <ProtectedRoute allowedRoles={['talent']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<TalentDashboard />} />
        <Route path="sales" element={<TalentSalesPage />} />
        <Route path="royalties" element={<TalentRoyaltiesPage />} />
        <Route path="invoices" element={<TalentInvoicesPage />} />
        <Route path="signing-bonus" element={<TalentSigningBonusPage />} />
      </Route>

      <Route path="/partner" element={
        <ProtectedRoute allowedRoles={['vendor_partner', 'partner']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<PartnerDashboard />} />
        <Route path="upload-sales" element={<PartnerUploadSalesPage />} />
        <Route path="sales" element={<PartnerSalesPage />} />
        <Route path="contracts" element={<PartnerContractsPage />} />
      </Route>

      <Route path="/" element={<Navigate to={user ? getDefaultPath(user) : '/login'} replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
