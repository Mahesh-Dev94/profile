import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { getAll } from '../database/dbService'

const AUTH_STORAGE_KEY = 'sports_platform_auth'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTH_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (parsed?.id && parsed?.email) setUser(parsed)
      }
    } catch (_) {}
    setLoading(false)
  }, [])

  // Map selected role to allowed DB roles (supports legacy seed: sponsorship_admin, partner)
  const roleAllowed = (selectedRole, dbRole) => {
    if (selectedRole === dbRole) return true
    if (selectedRole === 'platform_admin' && dbRole === 'sponsorship_admin') return true
    if (selectedRole === 'finance_manager' && dbRole === 'sponsorship_admin') return true
    if (selectedRole === 'sponsor_manager' && dbRole === 'sponsorship_admin') return true
    if (selectedRole === 'vendor_partner' && dbRole === 'partner') return true
    return false
  }

  const login = useCallback((email, password, role) => {
    const users = getAll('users')
    const match = users.find(
      (u) =>
        u.email === email &&
        u.password === password &&
        roleAllowed(role, u.role)
    )
    if (!match) return { success: false, error: 'Invalid credentials or role' }
    const session = {
      id: match.id,
      email: match.email,
      role: role,
      name: match.name,
      talentId: match.talentId,
      organizationId: match.organizationId,
    }
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_STORAGE_KEY)
    setUser(null)
  }, [])

  const value = { user, loading, login, logout, isAuthenticated: !!user }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
