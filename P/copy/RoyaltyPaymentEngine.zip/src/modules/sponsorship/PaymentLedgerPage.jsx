import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { DataTable } from '../../components/tables/DataTable'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Badge } from '../../components/ui/badge'
import { formatDisplayDate } from '../../utils/dateFormat'

export function PaymentLedgerPage() {
  const { currentOrganizationId } = useOrganization()
  const ledger = useMemo(() => getAllByOrganization('paymentLedger', currentOrganizationId), [currentOrganizationId])
  const sortedLedger = useMemo(() => [...(ledger || [])].sort((a, b) => (b.date || '').localeCompare(a.date || '')), [ledger])

  const columns = [
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'transactionId', header: 'Transaction ID', accessorKey: 'transactionId' },
    { id: 'source', header: 'Source', accessorKey: 'source' },
    { id: 'destination', header: 'Destination', accessorKey: 'destination' },
    { id: 'amount', header: 'Amount', accessorKey: 'amount', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'paymentMethod', header: 'Payment Method', accessorKey: 'paymentMethod', cell: (info) => String(info.getValue() || '').toUpperCase() },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant="success">{info.getValue()}</Badge> },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Payment Ledger</h2>
      <p className="text-sm text-neutral">Sponsor → Sports Business → Talent payment flow and transaction history.</p>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable columns={columns} data={sortedLedger} searchKey="transactionId" searchPlaceholder="Search by transaction ID..." />
        </CardContent>
      </Card>
    </div>
  )
}
