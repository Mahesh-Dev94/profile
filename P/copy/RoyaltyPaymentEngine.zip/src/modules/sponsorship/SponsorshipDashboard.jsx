import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { Button } from '../../components/ui/button'
import { DollarSign, Users, FileCheck, TrendingUp, Download } from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'

function aggregateByMonth(sales) {
  const byMonth = {}
  sales.forEach((s) => {
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function SponsorshipDashboard() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const sponsors = useMemo(() => getAllByOrganization('sponsorshipCompanies', currentOrganizationId), [currentOrganizationId])

  const sponsorRevenue = useMemo(() => {
    const bySponsor = {}
    contracts.forEach((c) => {
      const sponsor = sponsors.find((s) => s.id === c.sponsorId)
      const name = sponsor?.companyName || c.sponsorId || 'Unknown'
      if (!bySponsor[name]) bySponsor[name] = 0
      sales.filter((s) => s.licensee === c.licensee).forEach((s) => { bySponsor[name] += Number(s.netSales) || 0 })
    })
    return Object.entries(bySponsor).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8)
  }, [sales, contracts, sponsors])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const totalNetSales = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const royaltyTotal = ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyPaid = (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0)
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)
  const activeContracts = contracts.filter((c) => c.status === 'active').length
  const monthlyData = aggregateByMonth(sales)

  const royaltyByTalent = useMemo(() => {
    const map = {}
    ledger.forEach((r) => {
      map[r.talentName] = (map[r.talentName] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(map).map(([name, value]) => ({ name, value }))
  }, [ledger])

  const countrySales = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])

  const topTalents = useMemo(() => {
    const map = {}
    ledger.forEach((r) => {
      map[r.talentName] = (map[r.talentName] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5)
  }, [ledger])

  const exportRoyaltyReport = () => {
    const csv = Papa.unparse(ledger.map((r) => ({
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      UnitsSold: r.unitsSold,
      NetSales: r.netSales,
      RoyaltyPercent: `${((r.royaltyPercent || 0) * 100).toFixed(2)}%`,
      RoyaltyEarned: r.royaltyEarned,
      Date: r.date,
    })))
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `royalty-report-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button variant="outline" onClick={exportRoyaltyReport}><Download className="mr-2 h-4 w-4" /> Export royalty report CSV</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
        <StatCard title="Total Net Sales" value={`$${totalNetSales.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Royalty Total" value={`$${royaltyTotal.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Paid" value={`$${royaltyPaid.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Minimum Guarantees Active" value={activeContracts} icon={FileCheck} />
        <StatCard title="Top Talents" value={topTalents.length} subtitle={topTalents[0]?.name} icon={Users} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <RoyaltyDistributionChart data={royaltyByTalent} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <CountrySalesChart data={countrySales} />
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <h3 className="mb-4 text-base font-medium">Sponsor Revenue</h3>
          {sponsorRevenue.length > 0 ? (
            <ul className="space-y-2">
              {sponsorRevenue.map(({ name, value }) => (
                <li key={name} className="flex justify-between text-sm">
                  <span>{name}</span>
                  <span className="font-medium">${Number(value).toLocaleString()}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-neutral">No sponsor revenue data</p>
          )}
        </div>
      </div>
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Top Licensees by Sales</h3>
        <ul className="space-y-2">
            {Object.entries(
              sales.reduce((acc, s) => {
                const n = s.licensee || 'Other'
                acc[n] = (acc[n] || 0) + (Number(s.netSales) || 0)
                return acc
              }, {})
            )
              .sort((a, b) => b[1] - a[1])
              .slice(0, 6)
              .map(([name, val]) => (
                <li key={name} className="flex justify-between text-sm">
                  <span>{name}</span>
                  <span className="font-medium">${Number(val).toLocaleString()}</span>
                </li>
              ))}
          </ul>
      </div>
    </div>
  )
}
