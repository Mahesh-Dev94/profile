import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { DollarSign, TrendingUp } from 'lucide-react'
import { formatDisplayDate } from '../../utils/dateFormat'

/**
 * Royalties page for Sponsorship portal – based on sales (ledger).
 * Shows Royalty Total, Royalty Paid, Royalty Pending.
 */
export function SponsorshipRoyaltiesPage() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const royaltyByTalent = useMemo(() => {
    const map = {}
    ledger.forEach((r) => {
      map[r.talentName] = (map[r.talentName] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8)
  }, [ledger])

  const columns = [
    { id: 'product', header: 'Product', accessorKey: 'product' },
    { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue() || 0) * 100).toFixed(2)}%` },
    { id: 'royaltyEarned', header: 'Royalty Earned', accessorKey: 'royaltyEarned', cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Royalties (based on sales)</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Royalty Total" value={`$${royaltyTotal.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Royalty Paid" value={`$${royaltyPaid.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
      </div>
      {royaltyByTalent.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <h3 className="mb-4 text-base font-medium">Royalty by Talent</h3>
          <RoyaltyDistributionChart data={royaltyByTalent} />
        </div>
      )}
      <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <h3 className="mb-4 text-base font-medium">Royalty ledger</h3>
        <DataTable columns={columns} data={ledger} searchKey="product" searchPlaceholder="Search by product or talent..." />
      </div>
    </div>
  )
}
