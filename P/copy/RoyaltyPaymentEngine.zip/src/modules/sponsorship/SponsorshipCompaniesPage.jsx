import React, { useState } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { Card, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import { DataTable } from '../../components/tables/DataTable'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export function SponsorshipCompaniesPage() {
  const { data, create, update, remove } = useDatabase('sponsorshipCompanies')
  const [editing, setEditing] = useState(null)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({
    companyName: '',
    country: '',
    contractValue: '',
    royaltyRate: '',
    minimumGuarantee: '',
  })

  const resetForm = () => {
    setForm({ companyName: '', country: '', contractValue: '', royaltyRate: '', minimumGuarantee: '' })
    setEditing(null)
    setOpen(false)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const payload = {
      companyName: form.companyName,
      country: form.country,
      contractValue: Number(form.contractValue) || 0,
      royaltyRate: Number(form.royaltyRate) / 100 || 0,
      minimumGuarantee: Number(form.minimumGuarantee) || 0,
    }
    if (editing) update(editing.id, payload)
    else create(payload)
    resetForm()
  }

  const openEdit = (row) => {
    setEditing(row)
    setForm({
      companyName: row.companyName || '',
      country: row.country || '',
      contractValue: String(row.contractValue ?? ''),
      royaltyRate: String((row.royaltyRate ?? 0) * 100),
      minimumGuarantee: String(row.minimumGuarantee ?? ''),
    })
    setOpen(true)
  }

  const columns = [
    { id: 'companyName', header: 'Company', accessorKey: 'companyName' },
    { id: 'country', header: 'Country', accessorKey: 'country' },
    { id: 'contractValue', header: 'Contract Value', accessorKey: 'contractValue', cell: (v) => `$${Number(v.getValue()).toLocaleString()}` },
    { id: 'royaltyRate', header: 'Royalty %', accessorKey: 'royaltyRate', cell: (v) => `${((v.getValue()) * 100).toFixed(1)}%` },
    { id: 'minimumGuarantee', header: 'Min. Guarantee', accessorKey: 'minimumGuarantee', cell: (v) => `$${Number(v.getValue()).toLocaleString()}` },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}><Pencil className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={() => remove(row.original.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <h2 className="text-xl font-semibold">Sponsorship Companies</h2>
        <Button onClick={() => { setEditing(null); setForm({ companyName: '', country: '', contractValue: '', royaltyRate: '', minimumGuarantee: '' }); setOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" /> Add Company
        </Button>
      </div>
      <DataTable columns={columns} data={data} searchKey="companyName" searchPlaceholder="Search companies..." />

      <Dialog open={open} onOpenChange={(v) => !v && resetForm()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Company' : 'Add Company'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Company Name</Label>
              <Input value={form.companyName} onChange={(e) => setForm((f) => ({ ...f, companyName: e.target.value }))} required />
            </div>
            <div className="space-y-2">
              <Label>Country</Label>
              <Input value={form.country} onChange={(e) => setForm((f) => ({ ...f, country: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Contract Value</Label>
              <Input type="number" value={form.contractValue} onChange={(e) => setForm((f) => ({ ...f, contractValue: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Royalty Rate %</Label>
              <Input type="number" step="0.1" value={form.royaltyRate} onChange={(e) => setForm((f) => ({ ...f, royaltyRate: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Minimum Guarantee</Label>
              <Input type="number" value={form.minimumGuarantee} onChange={(e) => setForm((f) => ({ ...f, minimumGuarantee: e.target.value }))} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetForm}>Cancel</Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
