import React from 'react'
import { getAll } from '../../database/dbService'
import { useDatabase } from '../../hooks/useDatabase'
import { getReleaseDateFormatted } from '../../utils/signingBonus'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { isAfter, startOfDay } from 'date-fns'

export function SigningBonusPage() {
  const talents = getAll('talents')
  const { update } = useDatabase('talents')
  const signingTalents = talents.filter((t) => t.signingBonus != null && t.signingBonus > 0)

  const canRelease = (talent) => {
    const releaseDate = talent.signingDate && getReleaseDateFormatted(talent.signingDate)
    if (!releaseDate) return false
    const release = new Date(releaseDate)
    const today = startOfDay(new Date())
    return !isAfter(release, today) && (talent.signingBonusStatus !== 'released')
  }

  const handleRelease = (talent) => {
    update(talent.id, { signingBonusStatus: 'released' })
  }

  const columns = [
    { id: 'name', header: 'Talent', accessorKey: 'name' },
    { id: 'signingDate', header: 'Signing Date', accessorKey: 'signingDate' },
    {
      id: 'releaseDate',
      header: 'Release Date (10 working days)',
      cell: ({ row }) => getReleaseDateFormatted(row.original.signingDate),
    },
    {
      id: 'signingBonus',
      header: 'Signing Bonus',
      accessorKey: 'signingBonus',
      cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}`,
    },
    {
      id: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const status = row.original.signingBonusStatus || 'pending'
        return <Badge variant={status === 'released' ? 'success' : 'warning'}>{status}</Badge>
      },
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => {
        const t = row.original
        const released = t.signingBonusStatus === 'released'
        if (released) return <span className="text-xs text-neutral">Released</span>
        return (
          <Button
            size="sm"
            disabled={!canRelease(t)}
            onClick={() => handleRelease(t)}
            title={!canRelease(t) ? 'Available on or after release date' : 'Generate & release signing bonus'}
          >
            Generate & Release
          </Button>
        )
      },
    },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-accent">Signing Bonus</h2>
      <p className="text-sm text-neutral">
        Generate and release signing bonus within 10 working days of signing. Once released, the talent can view and download their certificate.
      </p>
      <Card className="border-accent/40 bg-accent/5">
        <CardHeader>
          <CardTitle className="text-base">Talents with signing bonus</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={columns}
            data={signingTalents}
            searchKey="name"
            searchPlaceholder="Search talent..."
          />
        </CardContent>
      </Card>
    </div>
  )
}
