import React, { useMemo, useState } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { getAll, getAllByOrganization, create as dbCreate } from '../../database/dbService'
import { useOrganization } from '../../context/OrganizationContext'
import toast from 'react-hot-toast'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import { Label } from '../../components/ui/label'
import { Input } from '../../components/ui/input'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import { User, DollarSign, CheckCircle2, Loader2 } from 'lucide-react'

/**
 * Payment process: (1) Sponsorship Company pays Sports Business, (2) Sports Business pays Talent.
 * Flow: Sponsorship Company → Sports Business → Talent User.
 */
export function PaymentsPage() {
  const { currentOrganizationId } = useOrganization()
  const { data: invoices, update: updateInvoice, refresh: refreshInvoices } = useDatabase('invoices')
  const { data: payments, create: createPayment, refresh: refreshPayments } = useDatabase('payments')
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', currentOrganizationId)
  const talents = getAllByOrganization('talents', currentOrganizationId)

  const [confirmPayment, setConfirmPayment] = useState(null)
  const [paymentRef, setPaymentRef] = useState('')
  const [paymentDialogStep, setPaymentDialogStep] = useState('confirm') // 'confirm' | 'processing' | 'complete'

  const orgInvoices = useMemo(() => (invoices || []).filter((inv) => inv.organizationId === currentOrganizationId), [invoices, currentOrganizationId])
  const pendingInvoices = useMemo(() => orgInvoices.filter((inv) => inv.status === 'pending'), [orgInvoices])

  // Step 1: Pending amount per Sports Business (Sponsorship → Business)
  const pendingByBusiness = useMemo(() => {
    const map = {}
    pendingInvoices.forEach((inv) => {
      const key = inv.sportsBusiness || 'Other'
      if (!map[key]) {
        const biz = sportsBusinesses.find((b) => b.businessName === key)
        map[key] = { businessName: key, businessId: biz?.id, amount: 0, invoiceIds: [], invoices: [] }
      }
      const amt = (Number(inv.royaltyAmount) || 0) + (Number(inv.minimumGuarantee) || 0)
      map[key].amount += amt
      map[key].invoiceIds.push(inv.id)
      map[key].invoices.push(inv)
    })
    return Object.values(map).filter((r) => r.amount > 0)
  }, [pendingInvoices, sportsBusinesses])

  // Step 2: Pending amount per (Sports Business, Talent) (Business → Talent)
  const pendingByBusinessTalent = useMemo(() => {
    const map = {}
    pendingInvoices.forEach((inv) => {
      const key = `${inv.sportsBusiness || 'Other'}|||${inv.talentId || ''}`
      if (!map[key]) {
        const biz = sportsBusinesses.find((b) => b.businessName === inv.sportsBusiness)
        const talent = talents.find((t) => t.id === inv.talentId)
        map[key] = {
          businessName: inv.sportsBusiness,
          businessId: biz?.id,
          talentId: inv.talentId,
          talentName: inv.talentName || talent?.name,
          amount: 0,
          invoiceIds: [],
          invoices: [],
        }
      }
      const amt = (Number(inv.royaltyAmount) || 0) + (Number(inv.minimumGuarantee) || 0)
      map[key].amount += amt
      map[key].invoiceIds.push(inv.id)
      map[key].invoices.push(inv)
    })
    return Object.values(map).filter((r) => r.amount > 0)
  }, [pendingInvoices, sportsBusinesses, talents])

  const handleRecordPaymentToBusiness = (row) => {
    setConfirmPayment({
      type: 'sponsorship_to_business',
      toId: row.businessId,
      toName: row.businessName,
      fromId: 'platform',
      fromName: 'Sponsorship Platform',
      amount: row.amount,
      invoiceIds: row.invoiceIds,
      invoices: row.invoices,
    })
    setPaymentRef('')
    setPaymentDialogStep('confirm')
  }

  const handleRecordPaymentToTalent = (row) => {
    setConfirmPayment({
      type: 'business_to_talent',
      fromId: row.businessId,
      fromName: row.businessName,
      toId: row.talentId,
      toName: row.talentName,
      amount: row.amount,
      invoiceIds: row.invoiceIds,
      invoices: row.invoices,
    })
    setPaymentRef('')
    setPaymentDialogStep('confirm')
  }

  const executePayment = () => {
    if (!confirmPayment) return
    const { type, fromId, fromName, toId, toName, amount, invoiceIds, invoices } = confirmPayment
    const ref = paymentRef.trim() || `Payment ${format(new Date(), 'yyyy-MM-dd')}`
    const dateStr = format(new Date(), 'yyyy-MM-dd')
    const txnId = `TXN-${format(new Date(), 'yyyyMMdd')}-${Date.now().toString(36).slice(-6)}`
    createPayment({
      type,
      fromId,
      fromName,
      toId,
      toName,
      amount: Number(amount),
      currency: 'USD',
      invoiceIds: invoiceIds || [],
      date: dateStr,
      status: 'completed',
      reference: ref,
      organizationId: currentOrganizationId,
    })
    // Add to payment ledger for full flow visibility
    dbCreate('paymentLedger', {
      date: dateStr,
      transactionId: txnId,
      source: fromName,
      destination: toName,
      amount: Number(amount),
      paymentMethod: 'transfer',
      status: 'completed',
      organizationId: currentOrganizationId,
      invoiceIds: invoiceIds || [],
    })
    ;(invoices || []).forEach((inv) => updateInvoice(inv.id, { status: 'paid', paidAmount: (Number(inv.royaltyAmount) || 0) + (Number(inv.minimumGuarantee) || 0) }))
    refreshInvoices()
    refreshPayments()
    toast.success('Payment recorded')
  }

  const handleConfirmPaymentClick = async () => {
    if (!confirmPayment) return
    setPaymentDialogStep('processing')
    await new Promise((r) => setTimeout(r, 1500))
    executePayment()
    setPaymentDialogStep('complete')
  }

  const handleClosePaymentDialog = () => {
    setConfirmPayment(null)
    setPaymentDialogStep('confirm')
  }

  const orgPayments = useMemo(() => (payments || []).filter((p) => p.organizationId === currentOrganizationId), [payments, currentOrganizationId])
  const paymentHistoryByType = (type) =>
    orgPayments.filter((p) => p.type === type).sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 10)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Payment Process</h2>
        <p className="text-sm text-neutral mt-1">
          <strong>Sponsorship Company</strong> pays <strong>Sports Business</strong>, then <strong>Sports Business</strong> pays <strong>Talent User</strong>.
        </p>
      </div>

      {/* Step 1: Sponsorship → Sports Business */}
      <Card>
        <CardHeader className="flex flex-row items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" />
          <CardTitle className="text-base">Step 1: Sponsorship Company pays Sports Business</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-neutral">
            Record payment from Sponsorship Company (platform) to each Sports Business for their pending invoice amounts.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="px-4 py-2 text-left font-medium">Sports Business</th>
                  <th className="px-4 py-2 text-right font-medium">Pending amount (USD)</th>
                  <th className="px-4 py-2 text-left font-medium">Invoices</th>
                  <th className="px-4 py-2 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {pendingByBusiness.length === 0 ? (
                  <tr><td colSpan={4} className="px-4 py-3 text-neutral">No pending amounts for Sports Businesses.</td></tr>
                ) : (
                  pendingByBusiness.map((row) => (
                    <tr key={row.businessName} className="border-b border-gray-100">
                      <td className="px-4 py-2 font-medium">{row.businessName}</td>
                      <td className="px-4 py-2 text-right">${Number(row.amount).toLocaleString()}</td>
                      <td className="px-4 py-2">{row.invoices?.map((i) => i.invoiceID).join(', ') || '—'}</td>
                      <td className="px-4 py-2 text-right">
                        <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => handleRecordPaymentToBusiness(row)}>
                          Record payment
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {paymentHistoryByType('sponsorship_to_business').length > 0 && (
            <div className="pt-2">
              <p className="text-xs font-medium text-neutral mb-1">Recent payments (Sponsorship Company → Sports Business)</p>
              <ul className="text-xs space-y-1">
                {paymentHistoryByType('sponsorship_to_business').map((p) => (
                  <li key={p.id} className="flex justify-between">
                    <span>{p.toName} — ${Number(p.amount).toLocaleString()}</span>
                    <span className="text-neutral">{formatDisplayDate(p.date)} {p.reference && `(${p.reference})`}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Step 2: Sports Business → Talent */}
      <Card>
        <CardHeader className="flex flex-row items-center gap-2">
          <User className="h-5 w-5 text-primary" />
          <CardTitle className="text-base">Step 2: Sports Business pays Talent User</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-neutral">
            Record payment from Sports Business to each Talent User for royalty and minimum guarantee (per invoice).
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="px-4 py-2 text-left font-medium">Sports Business</th>
                  <th className="px-4 py-2 text-left font-medium">Talent</th>
                  <th className="px-4 py-2 text-right font-medium">Amount (USD)</th>
                  <th className="px-4 py-2 text-left font-medium">Invoices</th>
                  <th className="px-4 py-2 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {pendingByBusinessTalent.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-3 text-neutral">No pending amounts for Talents.</td></tr>
                ) : (
                  pendingByBusinessTalent.map((row) => (
                    <tr key={`${row.businessName}-${row.talentId}`} className="border-b border-gray-100">
                      <td className="px-4 py-2">{row.businessName}</td>
                      <td className="px-4 py-2 font-medium">{row.talentName}</td>
                      <td className="px-4 py-2 text-right">${Number(row.amount).toLocaleString()}</td>
                      <td className="px-4 py-2">{row.invoices?.map((i) => i.invoiceID).join(', ') || '—'}</td>
                      <td className="px-4 py-2 text-right">
                        <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => handleRecordPaymentToTalent(row)}>
                          Record payment
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          {paymentHistoryByType('business_to_talent').length > 0 && (
            <div className="pt-2">
              <p className="text-xs font-medium text-neutral mb-1">Recent payments (Business → Talent)</p>
              <ul className="text-xs space-y-1">
                {paymentHistoryByType('business_to_talent').map((p) => (
                  <li key={p.id} className="flex justify-between">
                    <span>{p.fromName} → {p.toName} — ${Number(p.amount).toLocaleString()}</span>
                    <span className="text-neutral">{formatDisplayDate(p.date)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Record payment dialog: confirm → processing → complete */}
      <Dialog open={!!confirmPayment} onOpenChange={(v) => !v && handleClosePaymentDialog()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {confirmPayment?.type === 'sponsorship_to_business' ? 'Sponsorship Company → Sports Business' : 'Sports Business → Talent'}
            </DialogTitle>
          </DialogHeader>
          {confirmPayment && paymentDialogStep === 'confirm' && (
            <div className="space-y-3 text-sm">
              <p>
                {confirmPayment.type === 'sponsorship_to_business' ? (
                  <>Sponsorship Company pays <strong>{confirmPayment.toName}</strong> (Sports Business)</>
                ) : (
                  <>Record: <strong>{confirmPayment.fromName}</strong> pays <strong>{confirmPayment.toName}</strong> (Talent)</>
                )}
              </p>
              <p className="font-medium">Amount: ${Number(confirmPayment.amount).toLocaleString()} USD</p>
              <p className="text-neutral">Invoices: {confirmPayment.invoices?.map((i) => i.invoiceID).join(', ')}</p>
              <div>
                <Label className="text-xs">Reference (optional)</Label>
                <Input
                  className="mt-1"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  placeholder="e.g. Batch Nov 2024"
                />
              </div>
            </div>
          )}
          {confirmPayment && paymentDialogStep === 'processing' && (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
              <p className="text-sm font-medium text-neutral">Payment in process...</p>
            </div>
          )}
          {confirmPayment && paymentDialogStep === 'complete' && (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <CheckCircle2 className="h-14 w-14 text-green-600" />
              <p className="text-sm font-semibold text-gray-900">Payment complete</p>
              <p className="text-xs text-neutral">
                {confirmPayment.type === 'sponsorship_to_business' ? (
                  <>${Number(confirmPayment.amount).toLocaleString()} paid to <strong>{confirmPayment.toName}</strong></>
                ) : (
                  <><strong>{confirmPayment.fromName}</strong> paid ${Number(confirmPayment.amount).toLocaleString()} to <strong>{confirmPayment.toName}</strong></>
                )}
              </p>
            </div>
          )}
          <DialogFooter>
            {paymentDialogStep === 'confirm' && (
              <>
                <Button variant="outline" onClick={handleClosePaymentDialog}>Cancel</Button>
                <Button className="bg-primary text-white hover:bg-primary/90" onClick={handleConfirmPaymentClick}>Confirm payment</Button>
              </>
            )}
            {paymentDialogStep === 'complete' && (
              <Button className="bg-primary text-white hover:bg-primary/90" onClick={handleClosePaymentDialog}>
                Done
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
