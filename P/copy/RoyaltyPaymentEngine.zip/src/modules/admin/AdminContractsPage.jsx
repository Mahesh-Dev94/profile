import React from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { ContractAIValidatorList } from '../../components/ContractAIValidator'
import { formatDisplayDate } from '../../utils/dateFormat'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'

export function AdminContractsPage() {
  const { currentOrganizationId } = useOrganization()
  const contracts = getAllByOrganization('contracts', currentOrganizationId)

  const columns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue() || 0) * 100).toFixed(2)}%` },
    { id: 'minimumGuarantee', header: 'Min. guarantee', accessorKey: 'minimumGuarantee', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'startDate', header: 'Start', accessorKey: 'startDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'endDate', header: 'End', accessorKey: 'endDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Contracts (AI validation)</h2>
      <ContractAIValidatorList contracts={contracts} />
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Contracts</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable columns={columns} data={contracts} searchKey="contractID" searchPlaceholder="Search contracts..." />
        </CardContent>
      </Card>
    </div>
  )
}
