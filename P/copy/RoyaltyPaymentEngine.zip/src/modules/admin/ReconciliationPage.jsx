import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { useDatabase } from '../../hooks/useDatabase'
import { getAllByOrganization } from '../../database/dbService'
import { RoyaltyReconciliationTool } from '../../components/RoyaltyReconciliationTool'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { StatCard } from '../../components/cards/StatCard'
import { format } from 'date-fns'
import { DollarSign, AlertCircle, FileCheck } from 'lucide-react'

export function ReconciliationPage() {
  const { currentOrganizationId } = useOrganization()
  const { data: reports, refresh } = useDatabase('reconciliationReports')
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])

  const orgReports = useMemo(() => (reports || []).filter((r) => r.organizationId === currentOrganizationId).sort((a, b) => (b.runAt || '').localeCompare(a.runAt || '')), [reports, currentOrganizationId])
  const totalDiffs = orgReports.reduce((a, r) => a + (r.totalDifferencesDetected || 0), 0)
  const totalCorrected = orgReports.reduce((a, r) => a + Math.abs(r.difference || 0), 0)
  const pending = orgReports.filter((r) => r.difference !== 0).length

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Royalty reconciliation</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Total differences detected" value={totalDiffs} icon={AlertCircle} />
        <StatCard title="Corrected royalty amount" value={`$${totalCorrected.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Pending reconciliation" value={pending} icon={FileCheck} />
      </div>
      <RoyaltyReconciliationTool
        sales={sales}
        contracts={contracts}
        talents={talents}
        sportsBusinesses={sportsBusinesses}
        organizationId={currentOrganizationId}
        onReportCreated={refresh}
      />
      {orgReports.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Reconciliation history</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="px-4 py-2 text-left">Run at</th>
                    <th className="px-4 py-2 text-right">Expected</th>
                    <th className="px-4 py-2 text-right">Reported</th>
                    <th className="px-4 py-2 text-right">Difference</th>
                    <th className="px-4 py-2 text-right">Mismatches</th>
                  </tr>
                </thead>
                <tbody>
                  {orgReports.slice(0, 10).map((r) => (
                    <tr key={r.id} className="border-b">
                      <td className="px-4 py-2">{r.runAt ? format(new Date(r.runAt), 'PPp') : '—'}</td>
                      <td className="px-4 py-2 text-right">${Number(r.expectedRoyalty || 0).toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">${Number(r.reportedRoyalty || 0).toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">{r.difference !== 0 ? <span className="text-amber-600">${Number(r.difference).toLocaleString()}</span> : '—'}</td>
                      <td className="px-4 py-2 text-right">{r.totalDifferencesDetected ?? 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
