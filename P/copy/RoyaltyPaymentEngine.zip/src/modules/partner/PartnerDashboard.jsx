import React, { useMemo } from 'react'
import { getAll } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { forecastRevenue } from '../../utils/forecastEngine'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { LineChartCard } from '../../components/charts/LineChartCard'
import { DollarSign, Package, Users, Globe, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'

function aggregateByMonth(sales) {
  const byMonth = {}
  sales.forEach((s) => {
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function PartnerDashboard() {
  const sales = getAll('sales')
  const contracts = getAll('contracts')
  const talents = getAll('talents')
  const sportsBusinesses = getAll('sportsBusinesses')
  const invoices = getAll('invoices')

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const royaltyTotal = ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyEarned = invoices
    .filter((inv) => inv.status === 'paid')
    .reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0)
  const royaltyPending = Math.max(0, royaltyTotal - royaltyEarned)

  const totalSales = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const topProducts = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const p = s.productDescription || s.sku || 'Other'
      map[p] = (map[p] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 5)
  }, [sales])
  const topTalents = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const names = (s.talentNames || '').split(',').map((n) => n.trim()).filter(Boolean)
      names.forEach((n) => { map[n] = (map[n] || 0) + (Number(s.netSales) || 0) })
    })
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 5)
  }, [sales])
  const countryRevenue = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])

  const monthlyData = aggregateByMonth(sales)
  const royaltyByTalent = topTalents.map(([name, value]) => ({ name, value }))
  const forecastData = useMemo(() => forecastRevenue(sales, 3), [sales])

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <StatCard title="Total Sales" value={`$${totalSales.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Royalty Total" value={`$${royaltyTotal.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Earned" value={`$${royaltyEarned.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Top Products" value={topProducts.length} subtitle={topProducts[0]?.[0]} icon={Package} />
        <StatCard title="Top Talents" value={topTalents.length} subtitle={topTalents[0]?.[0]} icon={Users} />
        <StatCard title="Countries" value={countryRevenue.length} icon={Globe} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryRevenue} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <RoyaltyDistributionChart data={royaltyByTalent} />
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          <h3 className="mb-4 text-base font-medium">Revenue by Country</h3>
          <ul className="space-y-2">
            {countryRevenue.slice(0, 6).map(({ country, sales: amt }) => (
              <li key={country} className="flex justify-between text-sm">
                <span>{country}</span>
                <span className="font-medium">${Number(amt).toLocaleString()}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      {forecastData.length > 0 && (
        <LineChartCard
          title="Revenue Forecast (next 3 months)"
          description="Moving average forecast"
          data={forecastData.map((d) => ({ month: d.month, value: d.forecast }))}
          dataKey="value"
          name="Forecast"
        />
      )}
    </div>
  )
}
