import React, { useMemo } from 'react'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getReleaseDateFormatted, getDaysUntilRelease } from '../../utils/signingBonus'
import { downloadSigningBonusCertificatePDF } from '../../utils/pdfGenerator'
import { SigningBonusPDFViewer } from '../../components/forms/SigningBonusPDFViewer'
import { StatCard } from '../../components/cards/StatCard'
import { LineChartCard } from '../../components/charts/LineChartCard'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { DataTable } from '../../components/tables/DataTable'
import { DollarSign, Gift, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'

function aggregateByMonth(sales, talentId) {
  const byMonth = {}
  sales.forEach((s) => {
    if (!(s.talentIds || []).includes(talentId)) return
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, value: revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function TalentDashboard() {
  const { user } = useAuth()
  const talentId = user?.talentId
  const talents = getAll('talents')
  const sales = getAll('sales')
  const contracts = getAll('contracts')
  const sportsBusinesses = getAll('sportsBusinesses')

  const talent = useMemo(() => talents.find((t) => t.id === talentId), [talents, talentId])
  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const myLedger = useMemo(() => ledger.filter((r) => r.talentId === talentId), [ledger, talentId])
  const invoices = getAll('invoices')

  const royaltyTotal = myLedger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyEarnedPaid = useMemo(
    () =>
      invoices
        .filter((inv) => inv.talentId === talentId && inv.status === 'paid')
        .reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0),
    [invoices, talentId]
  )
  const royaltyPending = Math.max(0, royaltyTotal - royaltyEarnedPaid)

  const totalEarnings = royaltyTotal
  const monthlyEarnings = myLedger
    .filter((r) => {
      const d = r.date
      const thisMonth = format(new Date(), 'yyyy-MM')
      return d && (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) === thisMonth
    })
    .reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const pendingRoyalty = myLedger
    .filter((r) => r.date && new Date(r.date) > new Date())
    .reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const minGuarantee = contracts.find((c) => c.talentId === talentId)?.minimumGuarantee || 0
  const signingBonus = talent?.signingBonus || 0
  const signingBonusReleased = talent?.signingBonusStatus === 'released'

  const releaseDate = talent ? getReleaseDateFormatted(talent.signingDate) : 'N/A'
  const daysUntil = talent ? getDaysUntilRelease(talent.signingDate) : null
  const monthlyData = aggregateByMonth(sales, talentId)
  const [viewSigningBonusPdf, setViewSigningBonusPdf] = React.useState(false)

  const countryRevenue = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      if (!(s.talentIds || []).includes(talentId)) return
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, value]) => ({ country, value })).sort((a, b) => b.value - a.value)
  }, [sales, talentId])

  const licenseeSales = useMemo(() => {
    const byLicensee = {}
    myLedger.forEach((r) => {
      const key = r.licensee || 'Other'
      if (!byLicensee[key]) {
        byLicensee[key] = { licensee: key, netSales: 0, royaltyTotal: 0, royaltyEarned: 0 }
      }
      byLicensee[key].netSales += Number(r.netSales) || 0
      byLicensee[key].royaltyTotal += Number(r.royaltyEarned) || 0
    })
    const paidByLicensee = {}
    invoices
      .filter((inv) => inv.talentId === talentId && inv.status === 'paid')
      .forEach((inv) => {
        const key = inv.sportsBusiness || 'Other'
        paidByLicensee[key] = (paidByLicensee[key] || 0) + (Number(inv.royaltyAmount) || 0)
      })
    return Object.values(byLicensee).map((row) => ({
      ...row,
      royaltyEarned: paidByLicensee[row.licensee] || 0,
      royaltyPending: Math.max(0, row.royaltyTotal - (paidByLicensee[row.licensee] || 0)),
    }))
  }, [myLedger, invoices, talentId])

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <StatCard title="Royalty Total" value={`$${royaltyTotal.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Royalty Earned" value={`$${royaltyEarnedPaid.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={`$${royaltyPending.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Monthly Earnings" value={`$${monthlyEarnings.toLocaleString()}`} icon={TrendingUp} />
        <StatCard title="Minimum Guarantee" value={`$${Number(minGuarantee).toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Signing Bonus" value={`$${Number(signingBonus).toLocaleString()}`} icon={Gift} />
      </div>

      {talent && (
        <Card className="border-accent/40 bg-accent/5">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg text-accent">Signing Bonus</CardTitle>
            {signingBonusReleased ? (
              <div className="flex gap-2">
                <Button className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewSigningBonusPdf(true)}>
                  View Certificate PDF
                </Button>
                <Button variant="outline" className="border-accent text-accent hover:bg-accent/10" onClick={() => downloadSigningBonusCertificatePDF({ ...talent, releaseDate })}>
                  Download Certificate PDF
                </Button>
              </div>
            ) : null}
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-neutral">
              Sports Business / Sponsorship will release your signing bonus at once within 10 working days of signing. Release date: {releaseDate}.
            </p>
            {signingBonusReleased ? (
              daysUntil !== null && (
                <p className="text-lg font-semibold text-primary">
                  {daysUntil === 0 ? 'Released' : `${daysUntil} days until release`}
                </p>
              )
            ) : (
              <p className="text-sm text-amber-600">
                Your certificate and invoice will be visible here once the platform admin has generated and released your signing bonus (on or after the release date).
              </p>
            )}
          </CardContent>
        </Card>
      )}
      {talent && signingBonusReleased && (
        <SigningBonusPDFViewer
          open={viewSigningBonusPdf}
          onOpenChange={setViewSigningBonusPdf}
          talent={{ ...talent, releaseDate }}
          onDownloadPDF={(t) => downloadSigningBonusCertificatePDF(t)}
        />
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Licensee Sales (by net sales – Royalty Total, Earned, Pending)</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={[
              { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
              { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
              { id: 'royaltyTotal', header: 'Royalty Total', accessorKey: 'royaltyTotal', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
              { id: 'royaltyEarned', header: 'Royalty Earned', accessorKey: 'royaltyEarned', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
              { id: 'royaltyPending', header: 'Royalty Pending', accessorKey: 'royaltyPending', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
            ]}
            data={licenseeSales}
          />
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <LineChartCard title="Monthly Royalty" description="Your royalty by month" data={monthlyData} dataKey="value" name="Royalty" />
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sales by Product (your share)</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {Object.entries(
                myLedger.reduce((acc, r) => {
                  const key = r.product
                  acc[key] = (acc[key] || 0) + (r.royaltyEarned || 0)
                  return acc
                }, {})
              )
                .slice(0, 8)
                .map(([name, val]) => (
                  <li key={name} className="flex justify-between text-sm">
                    <span>{name}</span>
                    <span className="font-medium">${Number(val).toLocaleString()}</span>
                  </li>
                ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Country Revenue</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {countryRevenue.slice(0, 6).map(({ country, value }) => (
              <li key={country} className="flex justify-between text-sm">
                <span>{country}</span>
                <span className="font-medium">${Number(value).toLocaleString()}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
