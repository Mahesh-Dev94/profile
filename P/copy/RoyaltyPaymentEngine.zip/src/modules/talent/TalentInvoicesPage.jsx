import React from 'react'
import { useAuth } from '../../context/AuthContext'
import { useDatabase } from '../../hooks/useDatabase'
import { downloadInvoicePDF } from '../../utils/pdfGenerator'
import { InvoiceViewer } from '../../components/forms/InvoiceViewer'
import { Button } from '../../components/ui/button'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { FileDown } from 'lucide-react'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'

export function TalentInvoicesPage() {
  const { user } = useAuth()
  const { data: allInvoices } = useDatabase('invoices')
  const invoices = (allInvoices || []).filter((inv) => inv.talentId === user?.talentId)
  const [selected, setSelected] = React.useState(null)

  const columns = [
    { id: 'invoiceID', header: 'Invoice ID', accessorKey: 'invoiceID' },
    { id: 'month', header: 'Month', accessorFn: (row) => row.date ? format(new Date(row.date), 'MMM yyyy') : '—', cell: (info) => info.getValue() },
    { id: 'date', header: 'Date', accessorFn: (row) => row.date, cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'royaltyTotal', header: 'Royalty Total', accessorFn: (row) => (Number(row.royaltyAmount) || 0) + (Number(row.minimumGuarantee) || 0), cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'royaltyPaid', header: 'Royalty Paid', accessorKey: 'paidAmount', cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'royaltyPending', header: 'Royalty Pending', accessorFn: (row) => Math.max(0, ((Number(row.royaltyAmount) || 0) + (Number(row.minimumGuarantee) || 0)) - (Number(row.paidAmount) || 0)), cell: (info) => `$${Number(info.getValue() || 0).toLocaleString()}` },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'paid' ? 'success' : info.getValue() === 'partially_paid' ? 'secondary' : 'warning'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setSelected(row.original)}>View PDF</Button>
          <Button variant="outline" size="sm" onClick={() => downloadInvoicePDF(row.original)}><FileDown className="mr-1 h-3.5 w-3.5" /> Download Invoice PDF</Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">My Invoices</h2>
      <DataTable columns={columns} data={invoices} searchKey="invoiceID" searchPlaceholder="Search invoices..." />
      <InvoiceViewer open={!!selected} onOpenChange={(v) => !v && setSelected(null)} invoice={selected} onDownloadPDF={downloadInvoicePDF} />
    </div>
  )
}
