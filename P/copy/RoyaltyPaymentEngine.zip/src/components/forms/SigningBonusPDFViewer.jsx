import React, { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog'
import { Button } from '../ui/button'
import { getSigningBonusPDFBlobURL, downloadSigningBonusCertificatePDF } from '../../utils/pdfGenerator'
import { Download } from 'lucide-react'

export function SigningBonusPDFViewer({ open, onOpenChange, talent, onDownloadPDF }) {
  const [pdfUrl, setPdfUrl] = useState(null)

  useEffect(() => {
    if (!open || !talent) {
      setPdfUrl(null)
      return
    }
    const url = getSigningBonusPDFBlobURL(talent)
    setPdfUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [open, talent])

  const handleDownload = () => {
    if (talent) {
      ;(onDownloadPDF || downloadSigningBonusCertificatePDF)(talent)
    }
  }

  if (!talent) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-full h-[85vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
          <DialogTitle className="text-base">
            Signing Bonus Certificate – {talent.name}
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 min-h-0 px-6 pb-2">
          {pdfUrl && (
            <iframe
              title="Signing Bonus Certificate PDF"
              src={pdfUrl}
              className="w-full h-full min-h-[400px] rounded border border-gray-200 bg-white"
            />
          )}
        </div>
        <DialogFooter className="px-6 py-4 border-t border-gray-200 shrink-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button className="bg-primary text-white hover:bg-primary/90" onClick={handleDownload}>
            <Download className="mr-2 h-4 w-4" /> Download PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
