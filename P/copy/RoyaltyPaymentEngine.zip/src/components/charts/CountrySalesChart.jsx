import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ChartCard } from '../cards/ChartCard'

const COLORS = ['#0B3C5D', '#F97316']

export function CountrySalesChart({ data = [] }) {
  return (
    <ChartCard title="Country Sales" description="Revenue by country">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis type="number" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <YAxis dataKey="country" type="category" width={60} tick={{ fontSize: 12 }} />
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Sales']} />
          <Bar dataKey="sales" fill={COLORS[0]} radius={[0, 4, 4, 0]} name="Sales" />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
