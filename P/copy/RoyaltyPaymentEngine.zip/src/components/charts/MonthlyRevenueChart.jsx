import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ChartCard } from '../cards/ChartCard'

const COLORS = ['#0B3C5D', '#F97316', '#6B7280']

export function MonthlyRevenueChart({ data = [] }) {
  return (
    <ChartCard title="Monthly Revenue" description="Revenue by month">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Revenue']} />
          <Bar dataKey="revenue" fill={COLORS[0]} radius={[4, 4, 0, 0]} name="Revenue" />
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
