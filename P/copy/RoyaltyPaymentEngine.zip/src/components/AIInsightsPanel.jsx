import React, { useMemo } from 'react'
import { buildRoyaltyLedger } from '../utils/revenueEngine'
import { forecastRevenue } from '../utils/forecastEngine'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { TrendingUp, TrendingDown, AlertTriangle, Lightbulb } from 'lucide-react'

export function AIInsightsPanel({ sales = [], contracts = [], talents = [], sportsBusinesses = [], organizationId }) {
  const insights = useMemo(() => {
    const list = []
    if (!Array.isArray(sales) || sales.length === 0) return list

    const ledger = buildRoyaltyLedger(sales, contracts || [], talents || [], sportsBusinesses || [])
    const byTalent = {}
    ledger.forEach((r) => {
      byTalent[r.talentName] = (byTalent[r.talentName] || 0) + (r.royaltyEarned || 0)
    })
    const forecast = forecastRevenue(sales, 3)
    const avgForecast = forecast.length ? forecast.reduce((a, b) => a + (b.forecast || 0), 0) / forecast.length : 0
    const lastMonthSales = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0) / Math.max(1, sales.length)
    const growthPct = lastMonthSales > 0 ? ((avgForecast - lastMonthSales) / lastMonthSales) * 100 : 0

    Object.entries(byTalent).slice(0, 5).forEach(([name, royalty]) => {
      const projected = growthPct > 0 ? royalty * (1 + growthPct / 100) : royalty
      const pct = growthPct > 0 ? Math.round(growthPct) : 0
      if (pct >= 10) list.push({ type: 'positive', message: `${name} projected royalty increase ~${pct}% next quarter`, icon: TrendingUp })
      else if (pct <= -10) list.push({ type: 'negative', message: `${name} expected royalty decrease ~${Math.abs(pct)}%`, icon: TrendingDown })
    })

    if (growthPct <= -15) list.push({ type: 'warning', message: 'Licensee expected revenue drop in forecast', icon: AlertTriangle })
    if (list.length === 0 && sales.length > 0) list.push({ type: 'info', message: 'Forecast stable; no significant changes detected', icon: Lightbulb })
    return list.slice(0, 6)
  }, [sales, contracts, talents, sportsBusinesses])

  if (insights.length === 0) return null

  return (
    <Card>
      <CardHeader className="py-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Lightbulb className="h-4 w-4 text-primary" />
          AI insights
        </CardTitle>
      </CardHeader>
      <CardContent className="py-0 pb-2">
        <ul className="space-y-2 text-xs">
          {insights.map((i, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <i.icon className={`h-4 w-4 shrink-0 mt-0.5 ${i.type === 'positive' ? 'text-green-600' : i.type === 'negative' ? 'text-red-600' : i.type === 'warning' ? 'text-amber-600' : 'text-primary'}`} />
              <span className="text-gray-700">{i.message}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
