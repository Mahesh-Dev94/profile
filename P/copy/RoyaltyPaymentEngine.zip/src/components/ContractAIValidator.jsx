import React from 'react'
import { validateContract } from '../modules/contractAI/contractAIValidator'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { AlertTriangle, AlertCircle } from 'lucide-react'

export function ContractAIValidator({ contract, projectedSales }) {
  if (!contract) return null
  const warnings = validateContract(contract, { projectedSales })
  if (warnings.length === 0) return null

  return (
    <Card className="border-amber-200 bg-amber-50/50">
      <CardHeader className="py-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          Contract validation
        </CardTitle>
      </CardHeader>
      <CardContent className="py-0 pb-2">
        <ul className="space-y-1 text-xs">
          {warnings.map((w) => (
            <li key={w.id} className="flex items-start gap-2">
              {w.severity === 'error' ? <AlertCircle className="h-3.5 w-3.5 text-red-600 shrink-0 mt-0.5" /> : <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />}
              <span className={w.severity === 'error' ? 'text-red-700' : 'text-amber-800'}>{w.message}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

export function ContractAIValidatorList({ contracts, projectedSalesByContract }) {
  const allWarnings = []
  contracts.forEach((c) => {
    const w = validateContract(c, { projectedSales: projectedSalesByContract?.[c.id] })
    w.forEach((x) => allWarnings.push({ ...x, contractId: c.id, contractID: c.contractID, talentName: c.talentName }))
  })
  if (allWarnings.length === 0) return null

  return (
    <Card className="border-amber-200 bg-amber-50/50">
      <CardHeader className="py-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          Contract validation ({allWarnings.length} issue{allWarnings.length !== 1 ? 's' : ''})
        </CardTitle>
      </CardHeader>
      <CardContent className="py-0 pb-2">
        <ul className="space-y-1.5 text-xs max-h-40 overflow-y-auto">
          {allWarnings.map((w, i) => (
            <li key={`${w.contractId}-${w.id}-${i}`} className="flex items-start gap-2">
              {w.severity === 'error' ? <AlertCircle className="h-3.5 w-3.5 text-red-600 shrink-0 mt-0.5" /> : <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />}
              <span className={w.severity === 'error' ? 'text-red-700' : 'text-amber-800'}>
                <strong>{w.contractID}</strong> ({w.talentName}): {w.message}
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
