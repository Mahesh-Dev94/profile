import React from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { cn } from '../../utils/cn'

export function ChartCard({ title, description, children, className }) {
  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardHeader>
        <CardTitle className="text-base font-medium">{title}</CardTitle>
        {description && <p className="text-sm text-neutral">{description}</p>}
      </CardHeader>
      <CardContent className="h-[300px]">{children}</CardContent>
    </Card>
  )
}
