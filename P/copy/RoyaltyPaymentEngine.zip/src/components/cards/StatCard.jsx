import React from 'react'
import { Card, CardContent } from '../ui/card'
import { cn } from '../../utils/cn'

export function StatCard({ title, value, subtitle, icon: Icon, trend, className }) {
  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-neutral">{title}</p>
            <p className="mt-2 text-2xl font-bold text-gray-900">{value}</p>
            {subtitle && <p className="mt-1 text-xs text-neutral">{subtitle}</p>}
            {trend && (
              <p className={cn('mt-1 text-xs font-medium', trend > 0 ? 'text-green-600' : 'text-red-600')}>
                {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}% vs last period
              </p>
            )}
          </div>
          {Icon && (
            <div className="rounded-lg bg-primary/10 p-3">
              <Icon className="h-6 w-6 text-primary" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
