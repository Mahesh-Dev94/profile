import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Label } from '../ui/label'
import { Input } from '../ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select'
import { Checkbox } from '../ui/checkbox'
import { cn } from '../../utils/cn'

export function FilterPanel({
  title = 'Filters',
  filters = [],
  onApply,
  onReset,
  className,
}) {
  return (
    <Card className={cn('w-full max-w-xs', className)}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {filters.map((f) => (
          <div key={f.key} className="space-y-2">
            <Label className="text-xs">{f.label}</Label>
            {f.type === 'select' && (
              <Select value={f.value === '' || f.value == null ? '__all__' : f.value} onValueChange={(v) => f.onChange(v === '__all__' ? '' : v)}>
                <SelectTrigger>
                  <SelectValue placeholder={f.placeholder} />
                </SelectTrigger>
                <SelectContent>
                  {(f.options || []).map((opt) => {
                    const val = opt.value === '' || opt.value == null ? '__all__' : opt.value
                    return (
                      <SelectItem key={String(val)} value={String(val)}>
                        {opt.label}
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            )}
            {f.type === 'multicheckbox' && (
              <div className="space-y-2 rounded border border-gray-200 p-2">
                {f.options?.map((opt) => (
                  <label key={opt.value} className="flex cursor-pointer items-center gap-2">
                    <Checkbox
                      checked={f.value?.includes(opt.value)}
                      onCheckedChange={(checked) => {
                        const next = checked
                          ? [...(f.value || []), opt.value]
                          : (f.value || []).filter((x) => x !== opt.value)
                        f.onChange(next)
                      }}
                    />
                    <span className="text-sm">{opt.label}</span>
                  </label>
                ))}
              </div>
            )}
            {f.type === 'date' && (
              <Input
                type="date"
                value={f.value || ''}
                onChange={(e) => f.onChange(e.target.value)}
              />
            )}
            {f.type === 'daterange' && (
              <div className="flex gap-2">
                <Input
                  type="date"
                  placeholder="From"
                  value={f.value?.from || ''}
                  onChange={(e) => f.onChange({ ...f.value, from: e.target.value })}
                />
                <Input
                  type="date"
                  placeholder="To"
                  value={f.value?.to || ''}
                  onChange={(e) => f.onChange({ ...f.value, to: e.target.value })}
                />
              </div>
            )}
          </div>
        ))}
        <div className="flex gap-2 pt-2">
          <Button size="sm" onClick={onApply}>
            Apply
          </Button>
          <Button size="sm" variant="outline" onClick={onReset}>
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
