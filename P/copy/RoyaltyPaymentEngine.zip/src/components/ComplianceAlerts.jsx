import React, { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { AlertTriangle, DollarSign, FileCheck } from 'lucide-react'

const LARGE_PAYMENT_THRESHOLD = 50000
const PARTIAL_PAYMENT_COUNT_THRESHOLD = 3

export function ComplianceAlerts({ payments = [], settlements = [] }) {
  const alerts = useMemo(() => {
    const list = []
    const paymentAmounts = (payments || []).map((p) => ({ id: p.id, amount: Number(p.amount) || 0, toName: p.toName }))
    const large = paymentAmounts.filter((p) => p.amount >= LARGE_PAYMENT_THRESHOLD)
    if (large.length > 0) {
      list.push({ id: 'large_payment', severity: 'info', message: `${large.length} payment(s) exceed $${LARGE_PAYMENT_THRESHOLD.toLocaleString()}`, detail: large.map((p) => `${p.toName}: $${p.amount.toLocaleString()}`).join('; ') })
    }
    const byRecipient = {}
    paymentAmounts.forEach((p) => {
      byRecipient[p.toName] = (byRecipient[p.toName] || 0) + 1
    })
    const multiplePartials = Object.entries(byRecipient).filter(([, count]) => count >= PARTIAL_PAYMENT_COUNT_THRESHOLD)
    if (multiplePartials.length > 0) {
      list.push({ id: 'multiple_partials', severity: 'warning', message: `Multiple partial payments detected for: ${multiplePartials.map(([name]) => name).join(', ')}` })
    }
    return list
  }, [payments, settlements])

  if (alerts.length === 0) return null

  return (
    <Card className="border-amber-200 bg-amber-50/30">
      <CardHeader className="py-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          Compliance alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="py-0 pb-2">
        <ul className="space-y-1.5 text-xs">
          {alerts.map((a) => (
            <li key={a.id} className="flex items-start gap-2">
              <DollarSign className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />
              <span className="text-amber-800">{a.message}</span>
              {a.detail && <span className="text-neutral block mt-0.5">{a.detail}</span>}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
