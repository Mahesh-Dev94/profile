import { format, addMonths } from 'date-fns'

/**
 * Simple moving average forecast for next N months from sales data
 */
export function forecastRevenue(sales, monthsAhead = 3, groupBy = 'month') {
  if (!Array.isArray(sales) || sales.length === 0) return []

  const byMonth = {}
  for (const s of sales) {
    const date = s.date || s.Date
    if (!date) continue
    const key = typeof date === 'string' ? date.slice(0, 7) : format(new Date(date), 'yyyy-MM')
    byMonth[key] = (byMonth[key] || 0) + (Number(s.netSales) || 0)
  }

  const sortedKeys = Object.keys(byMonth).sort()
  if (sortedKeys.length === 0) return []

  const values = sortedKeys.map((k) => byMonth[k])
  const window = Math.min(6, Math.max(1, Math.floor(values.length / 2)))
  const movingAvg =
    values.length >= window
      ? values.slice(-window).reduce((a, b) => a + b, 0) / window
      : values.reduce((a, b) => a + b, 0) / values.length

  const lastKey = sortedKeys[sortedKeys.length - 1]
  const [y, m] = lastKey.split('-').map(Number)
  const result = []
  for (let i = 1; i <= monthsAhead; i++) {
    const next = addMonths(new Date(y, m - 1, 1), i)
    const label = format(next, 'MMM yyyy')
    result.push({ month: label, forecast: Math.round(movingAvg), actual: null })
  }
  return result
}
