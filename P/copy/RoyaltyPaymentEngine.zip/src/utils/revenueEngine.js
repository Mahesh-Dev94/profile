/**
 * Revenue calculations
 * NetSales = UnitsSold * EffectiveUnitSalesPrice
 * RoyaltyToTalent = NetSales * RoyaltyPercent
 * SportsBusinessShare = NetSales * RevenueSharePercent
 * PlatformRevenue = NetSales - RoyaltyToTalent - SportsBusinessShare
 */

export function calcNetSales(unitsSold, effectiveUnitSalesPrice) {
  return (unitsSold ?? 0) * (effectiveUnitSalesPrice ?? 0)
}

export function calcRoyaltyToTalent(netSales, royaltyPercent) {
  return (netSales ?? 0) * (royaltyPercent ?? 0)
}

export function calcSportsBusinessShare(netSales, revenueSharePercent) {
  return (netSales ?? 0) * (revenueSharePercent ?? 0)
}

export function calcPlatformRevenue(netSales, royaltyToTalent, sportsBusinessShare) {
  return (netSales ?? 0) - (royaltyToTalent ?? 0) - (sportsBusinessShare ?? 0)
}

export function buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses) {
  const ledger = []
  for (const sale of sales) {
    const netSales = sale.netSales ?? calcNetSales(sale.unitsSold, sale.effectiveUnitSalesPrice)
    const talentIds = sale.talentIds || []
    for (const tid of talentIds) {
      const contract = contracts.find(
        (c) => c.talentId === tid && (c.licenseeId === sale.licenseeId || c.licensee === sale.licensee)
      )
      const talent = talents.find((t) => t.id === tid)
      const royaltyPercent = contract?.royaltyPercent ?? 0
      const royaltyEarned = calcRoyaltyToTalent(netSales, royaltyPercent)
      const biz = sportsBusinesses.find((b) => b.id === sale.licenseeId || b.businessName === sale.licensee)
      const revenueShare = biz?.revenueSharePercent ?? 0
      const bizShare = calcSportsBusinessShare(netSales, revenueShare)
      const platform = calcPlatformRevenue(netSales, royaltyEarned, bizShare)
      ledger.push({
        saleId: sale.id,
        product: sale.productDescription || sale.sku,
        licensee: sale.licensee,
        country: sale.country,
        talentId: tid,
        talentName: talent?.name ?? 'Unknown',
        unitsSold: sale.unitsSold,
        netSales,
        royaltyPercent,
        royaltyEarned,
        revenueSharePercent: revenueShare,
        sportsBusinessShare: bizShare,
        platformRevenue: platform,
        date: sale.date,
      })
    }
  }
  return ledger
}
