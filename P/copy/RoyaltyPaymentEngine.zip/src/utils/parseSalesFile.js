import Papa from 'papaparse'
import * as XLSX from 'xlsx'

const EXPECTED_COLUMNS = [
  'ID', 'SKU', 'Licensee', 'ProductDescription', 'TalentNames', 'Country', 'Currency',
  'UnitsSold', 'EffectiveUnitSalesPrice', 'NetSales', 'TypeOfSales', 'Date',
]
const COLUMN_MAP = {
  id: ['ID', 'Id'],
  sku: ['SKU', 'Sku'],
  licensee: ['Licensee', 'LICENSEE'],
  productDescription: ['ProductDescription', 'Product Description'],
  talentNames: ['TalentNames', 'Talent Names'],
  country: ['Country', 'COUNTRY'],
  currency: ['Currency', 'CURRENCY'],
  unitsSold: ['UnitsSold', 'Units Sold'],
  effectiveUnitSalesPrice: ['EffectiveUnitSalesPrice', 'Effective Unit Sales Price'],
  netSales: ['NetSales', 'Net Sales'],
  typeOfSales: ['TypeOfSales', 'Type Of Sales'],
  date: ['Date', 'DATE'],
}

function findKey(row, aliases) {
  const keys = Object.keys(row).filter((k) => k && typeof k === 'string')
  for (const alias of aliases) {
    const found = keys.find((k) => k.trim().toLowerCase() === alias.toLowerCase())
    if (found) return found
  }
  return null
}

function normalizeRow(row, headerMap) {
  const get = (field) => {
    const key = headerMap[field]
    return key != null ? (row[key] ?? '') : ''
  }
  const unitsSold = Number(get('unitsSold')) || 0
  const effectiveUnitSalesPrice = Number(get('effectiveUnitSalesPrice')) || 0
  const netSales = Number(get('netSales')) || unitsSold * effectiveUnitSalesPrice
  return {
    id: `s-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    sku: String(get('sku')).trim() || 'N/A',
    licensee: String(get('licensee')).trim() || 'N/A',
    productDescription: String(get('productDescription')).trim() || 'N/A',
    talentNames: String(get('talentNames')).trim() || 'N/A',
    country: String(get('country')).trim() || 'N/A',
    currency: String(get('currency')).trim() || 'USD',
    unitsSold,
    effectiveUnitSalesPrice,
    netSales,
    typeOfSales: String(get('typeOfSales')).trim() || 'retail',
    date: String(get('date')).trim() || new Date().toISOString().slice(0, 10),
  }
}

function buildHeaderMap(firstRow) {
  const headerMap = {}
  for (const [field, aliases] of Object.entries(COLUMN_MAP)) {
    const key = findKey(firstRow, aliases)
    if (key) headerMap[field] = key
  }
  return headerMap
}

export function parseCSV(file) {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete(results) {
        const rows = results.data || []
        if (rows.length === 0) return resolve([])
        const headerMap = buildHeaderMap(rows[0])
        const normalized = rows.map((row) => normalizeRow(row, headerMap))
        resolve(normalized)
      },
      error(err) {
        reject(err)
      },
    })
  })
}

export function parseExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result)
        const workbook = XLSX.read(data, { type: 'array' })
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
        const rows = XLSX.utils.sheet_to_json(firstSheet)
        if (rows.length === 0) return resolve([])
        const headerMap = buildHeaderMap(rows[0])
        const normalized = rows.map((row) => normalizeRow(row, headerMap))
        resolve(normalized)
      } catch (err) {
        reject(err)
      }
    }
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsArrayBuffer(file)
  })
}

export function parseSalesFile(file) {
  const name = (file.name || '').toLowerCase()
  if (name.endsWith('.csv')) return parseCSV(file)
  if (name.endsWith('.xlsx') || name.endsWith('.xls')) return parseExcel(file)
  return Promise.reject(new Error('Unsupported format. Use CSV or Excel.'))
}
