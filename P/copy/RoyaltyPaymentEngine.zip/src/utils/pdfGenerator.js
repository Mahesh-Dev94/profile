import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import { format } from 'date-fns'
import { formatDisplayDate } from './dateFormat'

function buildContractPDF(doc, contract, talentName, licenseeName) {
  const cn = contract.contractID || contract.id
  const talent = talentName || contract.talentName
  const licensee = licenseeName || contract.licensee
  const royaltyPct = ((contract.royaltyPercent || 0) * 100).toFixed(2)
  const mg = Number(contract.minimumGuarantee || 0).toLocaleString()
  const start = formatDisplayDate(contract.startDate) || '—'
  const end = formatDisplayDate(contract.endDate) || '—'
  const status = contract.status || 'Active'

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('SPONSORSHIP & LICENSING AGREEMENT', 20, 20)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  doc.text('Sports Sponsorship & Royalty Platform', 20, 28)
  doc.text(`Contract No: ${cn}`, 120, 20)
  doc.text(`Effective: ${start}`, 120, 26)
  doc.text(`Expiry: ${end}`, 120, 32)

  let y = 42
  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.setFontSize(10)
  doc.text('PARTIES', 20, y)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  y += 6
  doc.text('This Agreement is entered into between the Licensee (Sports Business) and the Talent, represented by the Platform.', 20, y, { maxWidth: 170 })
  y += 8
  doc.text(`Licensee (Sports Business): ${licensee}`, 20, y)
  y += 5
  doc.text(`Talent: ${talent}`, 20, y)
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('1. GRANT OF RIGHTS', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('The Talent grants to the Licensee the non-exclusive right to use the Talent\'s name, likeness, and associated branding in connection with the licensed products and promotions during the Term.', 20, y, { maxWidth: 170 })
  y += 12

  doc.setFont(undefined, 'bold')
  doc.text('2. ROYALTY & MINIMUM GUARANTEE', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Royalty Rate: ${royaltyPct}% of Net Sales. Minimum Guarantee: $${mg} per contract year (or pro-rated).`, 20, y, { maxWidth: 170 })
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('3. TERM', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Start Date: ${start}. End Date: ${end}. Status: ${status}.`, 20, y, { maxWidth: 170 })
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('4. PAYMENT', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('Royalties shall be calculated monthly and paid within 30 days of month end. Minimum Guarantee shall be paid in accordance with the payment schedule agreed by the parties.', 20, y, { maxWidth: 170 })
  y += 14

  doc.line(20, y, 190, y)
  y += 6
  doc.setFontSize(8)
  doc.text('This document is generated for record-keeping. Signed originals may be held on file. Generated: ' + format(new Date(), 'PPpp'), 20, y)
}

export function downloadContractPDF(contract, talentName, licenseeName) {
  const doc = new jsPDF()
  buildContractPDF(doc, contract, talentName, licenseeName)
  doc.save(`contract-${(contract.contractID || contract.id).replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the contract PDF (revoke with URL.revokeObjectURL when done). */
export function getContractPDFBlobURL(contract, talentName, licenseeName) {
  const doc = new jsPDF()
  buildContractPDF(doc, contract, talentName, licenseeName)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

function buildInvoicePDF(invoice, doc) {
  const invId = invoice.invoiceID || invoice.id || 'N/A'
  const date = formatDisplayDate(invoice.date) || formatDisplayDate(new Date())
  const period = invoice.period || 'Monthly'
  const sponsor = invoice.sponsorCompany || '—'
  const business = invoice.sportsBusiness || '—'
  const talent = invoice.talentName || '—'
  const royalty = Number(invoice.royaltyAmount || 0)
  const minGuar = Number(invoice.minimumGuarantee || 0)
  const netSales = Number(invoice.netSales || 0)
  const total = royalty + minGuar

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('INVOICE', 20, 18)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(10)
  doc.text('Sports Sponsorship & Royalty Platform', 20, 26)
  doc.text('Invoice #', 120, 18)
  doc.text(invId, 140, 18)
  doc.text('Date', 120, 24)
  doc.text(date, 140, 24)
  doc.text('Period', 120, 30)
  doc.text(period, 140, 30)

  let y = 42
  doc.setFont(undefined, 'bold')
  doc.text('Bill To', 20, y)
  doc.text('Details', 120, y)
  doc.setFont(undefined, 'normal')
  y += 6
  doc.text(`Sponsor: ${sponsor}`, 20, y)
  y += 5
  doc.text(`Sports Business: ${business}`, 20, y)
  y += 5
  doc.text(`Talent: ${talent}`, 20, y)
  y += 10

  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.text('Description', 20, y)
  doc.text('Amount (USD)', 150, y)
  doc.setFont(undefined, 'normal')
  y += 7
  doc.line(20, y, 190, y)
  y += 7
  doc.text('Royalty', 20, y)
  doc.text(`$${royalty.toLocaleString()}`, 150, y)
  y += 6
  doc.text('Minimum Guarantee', 20, y)
  doc.text(`$${minGuar.toLocaleString()}`, 150, y)
  y += 6
  doc.text('Net Sales (reference)', 20, y)
  doc.text(`$${netSales.toLocaleString()}`, 150, y)
  y += 8
  doc.line(20, y, 190, y)
  y += 7
  doc.setFont(undefined, 'bold')
  doc.text('Total Due', 20, y)
  doc.text(`$${total.toLocaleString()}`, 150, y)
  doc.setFont(undefined, 'normal')
  y += 12
  doc.setFontSize(8)
  doc.text(`Generated on ${format(new Date(), 'PPpp')}. This is a computer-generated invoice.`, 20, y)
}

export function downloadInvoicePDF(invoice) {
  const doc = new jsPDF()
  buildInvoicePDF(invoice, doc)
  doc.save(`invoice-${(invoice.invoiceID || invoice.id || 'inv').replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the invoice PDF (revoke with URL.revokeObjectURL when done). */
export function getInvoicePDFBlobURL(invoice) {
  const doc = new jsPDF()
  buildInvoicePDF(invoice, doc)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

export function downloadSigningBonusCertificatePDF(talent) {
  const doc = new jsPDF()
  doc.setFontSize(18)
  doc.text('Signing Bonus Certificate', 20, 22)
  doc.setFontSize(10)
  doc.text('The Sports Business / Sponsorship will release the signing bonus to the Talent at once within 10 working days of signing.', 20, 32, { maxWidth: 170 })
  doc.setFontSize(12)
  doc.text(talent.name || 'Talent', 20, 48)
  doc.setFontSize(10)
  doc.text(`Signing Date: ${talent.signingDate}`, 20, 58)
  doc.text(`Signing Bonus: $${Number(talent.signingBonus || 0).toLocaleString()}`, 20, 66)
  doc.text(`Release Date: ${talent.releaseDate || 'N/A'} (10 working days after signing)`, 20, 74)
  doc.setFontSize(9)
  doc.text(`Certificate generated on ${format(new Date(), 'PPpp')}`, 20, 88)
  doc.save(`signing-bonus-${(talent.name || 'talent').replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the signing bonus certificate PDF (revoke with URL.revokeObjectURL when done). */
export function getSigningBonusPDFBlobURL(talent) {
  const doc = new jsPDF()
  doc.setFontSize(18)
  doc.text('Signing Bonus Certificate', 20, 22)
  doc.setFontSize(10)
  doc.text('The Sports Business / Sponsorship will release the signing bonus to the Talent at once within 10 working days of signing.', 20, 32, { maxWidth: 170 })
  doc.setFontSize(12)
  doc.text(talent.name || 'Talent', 20, 48)
  doc.setFontSize(10)
  doc.text(`Signing Date: ${talent.signingDate}`, 20, 58)
  doc.text(`Signing Bonus: $${Number(talent.signingBonus || 0).toLocaleString()}`, 20, 66)
  doc.text(`Release Date: ${talent.releaseDate || 'N/A'} (10 working days after signing)`, 20, 74)
  doc.setFontSize(9)
  doc.text(`Certificate generated on ${format(new Date(), 'PPpp')}`, 20, 88)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

export async function captureElementAsPDF(elementId, filename = 'export.pdf') {
  const el = document.getElementById(elementId)
  if (!el) return
  const canvas = await html2canvas(el, { scale: 2 })
  const img = canvas.toDataURL('image/png')
  const doc = new jsPDF('p', 'mm', 'a4')
  const w = doc.internal.pageSize.getWidth()
  const h = (canvas.height * w) / canvas.width
  doc.addImage(img, 'PNG', 0, 0, w, h)
  doc.save(filename)
}
