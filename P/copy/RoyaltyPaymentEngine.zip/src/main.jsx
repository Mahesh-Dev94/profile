import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { OrganizationProvider } from './context/OrganizationContext'
import { AppStoreProvider } from './context/AppStore'
import { Toaster } from 'react-hot-toast'
import { seedDatabase } from './database/seedData'
import App from './App'
import './index.css'

// Initialize local DB from seed if empty
seedDatabase()

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <OrganizationProvider>
          <AppStoreProvider>
            <App />
            <Toaster position="top-right" toastOptions={{ duration: 4000 }} />
          </AppStoreProvider>
        </OrganizationProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
