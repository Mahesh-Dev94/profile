import { useState, useEffect, useCallback } from 'react'
import { useOrganization } from '../context/OrganizationContext'
import * as db from '../database/dbService'

const ORG_COLLECTIONS = ['talents', 'sponsorshipCompanies', 'sportsBusinesses', 'contracts', 'sales', 'invoices', 'payments']

export function useOrganizationData(collection) {
  const { currentOrganizationId } = useOrganization()
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(() => {
    if (!ORG_COLLECTIONS.includes(collection)) {
      setData(db.getAll(collection))
    } else {
      setData(db.getAllByOrganization(collection, currentOrganizationId))
    }
    setLoading(false)
  }, [collection, currentOrganizationId])

  useEffect(() => {
    setLoading(true)
    refresh()
  }, [refresh])

  const create = useCallback(
    (item) => {
      const withOrg = ORG_COLLECTIONS.includes(collection) ? { ...item, organizationId: currentOrganizationId } : item
      const created = db.create(collection, withOrg)
      refresh()
      return created
    },
    [collection, currentOrganizationId, refresh]
  )

  const update = useCallback(
    (id, item) => {
      const updated = db.update(collection, id, item)
      refresh()
      return updated
    },
    [collection, refresh]
  )

  const remove = useCallback(
    (id) => {
      const ok = db.remove(collection, id)
      refresh()
      return ok
    },
    [collection, refresh]
  )

  return { data, loading, refresh, create, update, remove, getById: (id) => db.getById(collection, id) }
}
