import React, { createContext, useContext, useState, useCallback } from 'react'

const AppStoreContext = createContext(null)

export function AppStoreProvider({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [globalFilters, setGlobalFilters] = useState({})

  const toggleSidebar = useCallback(() => setSidebarOpen((v) => !v), [])
  const setFilter = useCallback((key, value) => {
    setGlobalFilters((f) => ({ ...f, [key]: value }))
  }, [])

  const value = {
    sidebarOpen,
    toggleSidebar,
    globalFilters,
    setGlobalFilters,
    setFilter,
  }
  return <AppStoreContext.Provider value={value}>{children}</AppStoreContext.Provider>
}

export function useAppStore() {
  const ctx = useContext(AppStoreContext)
  if (!ctx) throw new Error('useAppStore must be used within AppStoreProvider')
  return ctx
}
