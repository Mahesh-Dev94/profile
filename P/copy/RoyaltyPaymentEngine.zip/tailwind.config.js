/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontSize: {
        '2xs': ['9px', { lineHeight: '1.25' }],
        'xs': ['10px', { lineHeight: '1.35' }],
        'sm': ['11px', { lineHeight: '1.4' }],
        'base': ['12px', { lineHeight: '1.5' }],
        'lg': ['13px', { lineHeight: '1.5' }],
        'xl': ['13px', { lineHeight: '1.4' }],
        '2xl': ['13px', { lineHeight: '1.3' }],
        '3xl': ['13px', { lineHeight: '1.2' }],
      },
      colors: {
        primary: {
          DEFAULT: '#0B3C5D',
          50: '#e6eef3',
          100: '#b3c9db',
          200: '#80a4c3',
          300: '#4d7fab',
          400: '#265a93',
          500: '#0B3C5D',
          600: '#09304a',
          700: '#072438',
          800: '#051825',
          900: '#030c13',
        },
        accent: {
          DEFAULT: '#F97316',
          50: '#fff7ed',
          100: '#ffedd5',
          200: '#fed7aa',
          300: '#fdba74',
          400: '#fb923c',
          500: '#F97316',
          600: '#ea580c',
          700: '#c2410c',
          800: '#9a3412',
          900: '#7c2d12',
        },
        neutral: '#6B7280',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'card': '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
        'card-hover': '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
