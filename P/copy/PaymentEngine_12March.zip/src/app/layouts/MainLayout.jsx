import React from 'react'
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useAppStore } from '../../context/AppStore'
import { OrganizationSwitcher } from '../../components/OrganizationSwitcher'
import { Button } from '../../components/ui/button'
import {
  LayoutDashboard,
  FileText,
  Building2,
  Receipt,
  Upload,
  BarChart3,
  LogOut,
  Menu,
  ChevronLeft,
  Gift,
  CreditCard,
  FileSpreadsheet,
  TrendingUp,
  BookOpen,
  User,
  ChevronDown,
  PlusCircle,
} from 'lucide-react'
import { cn } from '../../utils/cn'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../../components/ui/dropdown-menu'

const adminNav = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/admin/organizations', label: 'Organizations', icon: Building2 },
  { to: '/admin/contracts', label: 'Contracts', icon: FileText },
  { to: '/admin/reconciliation', label: 'Reconciliation', icon: FileSpreadsheet },
  { to: '/admin/forecast', label: 'Forecast', icon: TrendingUp },
  { to: '/sponsorship/dashboard', label: 'Sponsorship portal', icon: CreditCard },
]

// Sport Business: Dashboard, Salary, Signing Bonus, Release Payment, Ledger, Royalties, Contracts
const sponsorshipNavSection1 = [
  { to: '/sponsorship/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sponsorship/salary', label: 'Salary', icon: Receipt },
  { to: '/sponsorship/signing-bonus', label: 'Signing Bonus', icon: Gift },
  { to: '/sponsorship/release-payment', label: 'Release Payment', icon: CreditCard },
  { to: '/sponsorship/ledger', label: 'Payment Ledger', icon: BookOpen },
  { to: '/sponsorship/general-entry', label: 'General Entry', icon: PlusCircle },
  { to: '/sponsorship/royalties', label: 'Royalties', icon: TrendingUp },
  { to: '/sponsorship/contracts', label: 'Talent Contracts', icon: FileText },
]
// Sport Business only: no Sports Platform section (Royalties, Invoices, Sports Businesses, Sponsorship Companies removed)
const sponsorshipNav = [...sponsorshipNavSection1]

const talentNav = [
  { to: '/talent/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/talent/salary', label: 'Salary', icon: Receipt },
  { to: '/talent/signing-bonus', label: 'Signing Bonus', icon: Gift },
  { to: '/talent/royalties', label: 'Royalties', icon: TrendingUp },
]

const partnerNav = [
  { to: '/partner/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/partner/upload-sales', label: 'Upload Sales', icon: Upload },
  { to: '/partner/sales', label: 'Sales', icon: BarChart3 },
  { to: '/partner/contracts', label: 'Contracts', icon: FileText },
]

export function MainLayout() {
  const { user, logout } = useAuth()
  const { sidebarOpen, toggleSidebar } = useAppStore()
  const navigate = useNavigate()
  const location = useLocation()
  const isAdminPath = location.pathname.startsWith('/admin')
  const isSponsorshipPath = location.pathname.startsWith('/sponsorship')
  const isTalentPath = location.pathname.startsWith('/talent')
  const isPartnerPath = location.pathname.startsWith('/partner')

  const nav =
    isAdminPath
      ? adminNav
      : isSponsorshipPath
      ? sponsorshipNav
      : isTalentPath
      ? talentNav
      : isPartnerPath
      ? partnerNav
      : adminNav

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <aside
        className={cn(
          'flex flex-col border-r border-gray-200 bg-white transition-all duration-200',
          sidebarOpen ? 'w-56' : 'w-16'
        )}
      >
        <div className="flex h-14 items-center justify-between border-b border-gray-200 px-4">
          <Link to={nav[0]?.to} className="flex items-center justify-center text-primary" aria-label="Home">
            <CreditCard className="h-8 w-8 shrink-0" />
          </Link>
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            {sidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-1 p-2 overflow-y-auto">
          {isSponsorshipPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Sport Business</p>}
              {sponsorshipNav.map((item) => {
                const Icon = item.icon
                const active = location.pathname === item.to
                return (
                  <Link key={item.to} to={item.to} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', active ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </Link>
                )
              })}
            </>
          ) : isTalentPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Talent</p>}
              {talentNav.map((item) => {
                const Icon = item.icon
                const active = location.pathname === item.to
                return (
                  <Link key={item.to} to={item.to} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', active ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </Link>
                )
              })}
            </>
          ) : isPartnerPath ? (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Sponsorship Partner Vendor</p>}
              {partnerNav.map((item) => {
                const Icon = item.icon
                const active = location.pathname === item.to
                return (
                  <Link key={item.to} to={item.to} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', active ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </Link>
                )
              })}
            </>
          ) : (
            <>
              {sidebarOpen && <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-500">Admin</p>}
              {adminNav.map((item) => {
                const Icon = item.icon
                const active = location.pathname === item.to
                return (
                  <Link key={item.to} to={item.to} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors', active ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100')}>
                    <Icon className="h-5 w-5 shrink-0" />
                    {sidebarOpen && <span>{item.label}</span>}
                  </Link>
                )
              })}
            </>
          )}
        </nav>
        <div className="border-t border-gray-200 p-2">
          <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
            {sidebarOpen && <span>Logout</span>}
          </Button>
        </div>
      </aside>
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 items-center justify-between border-b border-gray-200 bg-white px-6">
          <h1 className="text-lg font-semibold text-gray-900">
            {nav.find((n) => n.to === location.pathname)?.label || (isAdminPath ? 'Admin' : 'Dashboard')}
          </h1>
          <div className="flex items-center gap-3">
            {/* <OrganizationSwitcher /> */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 rounded-full pl-2 pr-3 py-1.5 hover:bg-gray-100" aria-label="User profile">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <User className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium text-gray-700 max-w-[140px] truncate">{user?.name || user?.email}</span>
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="left" className="w-72 rounded-lg shadow-lg">
                <div className="px-4 py-3 border-b border-gray-100">
                  <p className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">User information</p>
                  <p className="text-sm font-semibold text-gray-900">{user?.name || 'User'}</p>
                  <p className="text-xs text-gray-500 mt-0.5 truncate">{user?.email || '—'}</p>
                  <p className="text-xs text-primary font-medium mt-2">Login type: {user?.role?.replace(/_/g, ' ') || '—'}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer py-2.5" onSelect={() => { handleLogout(); }}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
