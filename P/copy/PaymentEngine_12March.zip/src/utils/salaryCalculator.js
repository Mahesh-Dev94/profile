/**
 * Salary calculations for talent payments.
 * Monthly salary = Annual Salary / 12 (or from contract).
 */

export function getMonthlySalary(annualSalary) {
  return (Number(annualSalary) || 0) / 12
}

export function getAnnualSalaryTotal(salaryPayments) {
  return (salaryPayments || []).reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPaidSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'paid')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPendingSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'pending')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

/** Per-talent salary totals (matches Salary page figures when summed per talent). */
export function getSalaryByTalent(salaryPayments) {
  const byTalent = {}
  ;(salaryPayments || []).forEach((s) => {
    const id = s.talentId || s.talentName
    const name = s.talentName || 'Unknown'
    if (!byTalent[id]) byTalent[id] = { talentId: s.talentId, name, value: 0 }
    byTalent[id].value += Number(s.salaryAmount) || 0
  })
  return Object.values(byTalent)
    .map(({ name, value }) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
}

/** Per-talent annual salary from contracts (one value per talent, for summary/chart). */
export function getAnnualSalaryByTalentFromContracts(contracts) {
  const byTalent = {}
  ;(contracts || []).forEach((c) => {
    const id = c.talentId
    if (!id || byTalent[id]) return
    const annual = Number(c.basicSalary2026_27 ?? c.annualSalary) || 0
    byTalent[id] = { name: c.talentName || 'Unknown', value: annual }
  })
  return Object.values(byTalent).sort((a, b) => b.value - a.value)
}
