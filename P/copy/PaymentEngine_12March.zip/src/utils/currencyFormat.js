/**
 * US Dollar number formatting (comma every 3 digits).
 * e.g. 18000000 → "18,000,000"
 */
export function formatDollar(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Math.round(Number(num))
  return n.toLocaleString('en-US')
}

/** Display as "$18,000,000" */
export function formatDollarDisplay(num) {
  return `$${formatDollar(num)}`
}

/** @deprecated Use formatDollar for display */
export function formatINR(num) {
  return formatDollar(num)
}

/** @deprecated Use formatDollarDisplay for display */
export function formatINRDisplay(num) {
  return formatDollarDisplay(num)
}

/** Default basic salary and signing bonus text for contracts */
export const DEFAULT_SALARY_2026_27 = 18000000
export const DEFAULT_SALARY_2027_28 = 20000000
export const DEFAULT_SIGNING_BONUS_INR = 3000000
export const SIGNING_BONUS_DESCRIPTION = '$3,000,000 payable within 10 business days of execution.'
