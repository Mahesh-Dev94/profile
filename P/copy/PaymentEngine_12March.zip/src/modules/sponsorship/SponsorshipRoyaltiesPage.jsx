import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { DollarSign, TrendingUp } from 'lucide-react'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

/**
 * Royalties page for Sponsorship portal – based on sales (ledger).
 * Shows Royalty Total, Royalty Paid, Royalty Pending.
 */
export function SponsorshipRoyaltiesPage() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger), [ledger])

  // Per-talent Royalty Total, Paid, Pending for the listing table
  const royaltyByTalentRows = useMemo(() => {
    const totalByTalent = {}
    ledger.forEach((r) => {
      const name = r.talentName || 'Unknown'
      totalByTalent[name] = (totalByTalent[name] || 0) + Number(r.royaltyEarned || 0)
    })
    const paidByTalent = {}
    ;(invoices || []).forEach((inv) => {
      const name = inv.talentName || 'Unknown'
      paidByTalent[name] = (paidByTalent[name] || 0) + Number(inv.paidAmount || 0)
    })
    const allNames = new Set([...Object.keys(totalByTalent), ...Object.keys(paidByTalent)])
    return Array.from(allNames)
      .map((name) => {
        const royaltyTotal = totalByTalent[name] || 0
        const royaltyPaid = paidByTalent[name] || 0
        const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)
        return { talentName: name, royaltyTotal, royaltyPaid, royaltyPending }
      })
      .filter((row) => row.royaltyTotal > 0 || row.royaltyPaid > 0)
      .sort((a, b) => b.royaltyTotal - a.royaltyTotal)
  }, [ledger, invoices])

  const ledgerColumns = [
    { id: 'product', header: 'Product', accessorKey: 'product' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue() || 0) * 100).toFixed(2)}%` },
    { id: 'royaltyEarned', header: 'Royalty Paid', accessorKey: 'royaltyEarned', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const talentSummaryColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'royaltyTotal', header: 'Royalty Total', accessorKey: 'royaltyTotal', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPaid', header: 'Royalty Paid', accessorKey: 'royaltyPaid', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPending', header: 'Royalty Pending', accessorKey: 'royaltyPending', cell: (info) => formatINRDisplay(info.getValue()) },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Royalties (based on sales)</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Royalty Total" value={formatINRDisplay(royaltyTotal)} icon={DollarSign} />
        <StatCard title="Royalty Paid" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
      </div>
      {royaltyByTalent.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <RoyaltyDistributionChart data={royaltyByTalent} title="Royalty Distribution" description="By talent (same as Total Royalty)" />
        </div>
      )}
      {royaltyByTalentRows.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-3 text-base font-medium">Royalty by talent (Total, Paid, Pending)</h3>
          <DataTable columns={talentSummaryColumns} data={royaltyByTalentRows} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}
      <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <h3 className="mb-2 text-base font-medium">Royalty ledger</h3>
        <div className="mb-3 flex flex-wrap gap-4 rounded-md bg-gray-50 px-3 py-2 text-sm">
          <span><strong>Royalty Total:</strong> {formatINRDisplay(royaltyTotal)}</span>
          <span><strong>Royalty Paid:</strong> {formatINRDisplay(royaltyPaid)}</span>
          <span><strong>Royalty Pending:</strong> {formatINRDisplay(royaltyPending)}</span>
        </div>
        <DataTable columns={ledgerColumns} data={ledger} searchKey="product" searchPlaceholder="Search by product or talent..." />
      </div>
    </div>
  )
}
