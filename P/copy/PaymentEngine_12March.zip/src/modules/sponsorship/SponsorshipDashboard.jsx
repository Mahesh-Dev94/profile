import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { getAnnualSalaryTotal, getSalaryByTalent, getAnnualSalaryByTalentFromContracts } from '../../utils/salaryCalculator'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { Button } from '../../components/ui/button'
import { DollarSign, TrendingUp, Download, Gift } from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'

function aggregateRoyaltyByMonth(ledger) {
  const byMonth = {}
  ;(ledger || []).forEach((r) => {
    const d = r.date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function SponsorshipDashboard() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const annualSalaryTotal = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  const signingBonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const signingBonusReleased = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const signingBonusPending = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])
  const royaltyPaid = useMemo(() => (invoices || []).reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0), [invoices])
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const royaltyMonthlyData = useMemo(() => aggregateRoyaltyByMonth(ledger), [ledger])
  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger).slice(0, 8), [ledger])
  // Salary Distribution: annual salary per talent from contracts (e.g. 18,000,000) to match contract figures
  const salaryDistribution = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])

  // Talent Payment Summary: salary = annual from contract; royalty = from ledger (same as Total Royalty)
  const talentPaymentSummary = useMemo(() => {
    const salaryByTalent = getAnnualSalaryByTalentFromContracts(contracts)
    const royaltyByTalentMap = {}
    ledger.forEach((r) => {
      const name = r.talentName || 'Unknown'
      royaltyByTalentMap[name] = (royaltyByTalentMap[name] || 0) + Number(r.royaltyEarned || 0)
    })
    const nameToSalary = Object.fromEntries(salaryByTalent.map(({ name, value }) => [name, value]))
    const allNames = new Set([...salaryByTalent.map((s) => s.name), ...Object.keys(royaltyByTalentMap)])
    return Array.from(allNames)
      .map((name) => {
        const salary = nameToSalary[name] || 0
        const royalty = royaltyByTalentMap[name] || 0
        return { name, salary, royalty, total: salary + royalty }
      })
      .sort((a, b) => b.total - a.total)
  }, [ledger, contracts])

  const exportRoyaltyReport = () => {
    const csv = Papa.unparse(ledger.map((r) => ({
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      UnitsSold: r.unitsSold,
      NetSales: r.netSales,
      RoyaltyEarned: r.royaltyEarned,
      Date: r.date,
    })))
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `royalty-report-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={exportRoyaltyReport}><Download className="mr-2 h-4 w-4" /> Export royalty report CSV</Button>
      </div>
      <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <StatCard title="Salary Total" value={formatINRDisplay(annualSalaryTotal)} icon={DollarSign} />
        <StatCard title="Signing Bonus Total" value={formatINRDisplay(signingBonusTotal)} icon={Gift} />
        <StatCard title="Signing Bonus Released Total" value={formatINRDisplay(signingBonusReleased)} icon={Gift} />
        <StatCard title="Signing Bonus Pending Total" value={formatINRDisplay(signingBonusPending)} icon={Gift} />
        <StatCard title="Total Royalty" value={formatINRDisplay(royaltyTotal)} icon={TrendingUp} />
        <StatCard title="Pending Royalty" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
        <StatCard title="Paid Royalty" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <MonthlyRevenueChart
            data={royaltyMonthlyData}
            title="Royalty Monthly Trend"
            description="Royalty by month"
            currency="USD"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          {salaryDistribution.length > 0 ? (
            <RoyaltyDistributionChart data={salaryDistribution} title="Salary Distribution" description="By talent" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Salary Distribution</h3>
              <p className="text-sm text-neutral">No salary data</p>
            </>
          )}
        </div>
      </div>
      {royaltyByTalent.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[380px]">
          <RoyaltyDistributionChart data={royaltyByTalent} title="Royalty Distribution" description="By talent (same as Total Royalty)" />
        </div>
      )}
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Talent Payment Summary</h3>
        <p className="text-xs text-neutral mb-3">Salary and royalty per talent (matches Salary total and Total Royalty above).</p>
        {talentPaymentSummary.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-2 px-3 font-semibold">Talent</th>
                  <th className="text-right py-2 px-3 font-semibold">Salary</th>
                  <th className="text-right py-2 px-3 font-semibold">Royalty</th>
                  <th className="text-right py-2 px-3 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody>
                {talentPaymentSummary.map(({ name, salary, royalty, total }) => (
                  <tr key={name} className="border-b border-gray-100">
                    <td className="py-2.5 px-3 font-medium">{name}</td>
                    <td className="py-2.5 px-3 text-right">{formatINRDisplay(salary)}</td>
                    <td className="py-2.5 px-3 text-right">{formatINRDisplay(royalty)}</td>
                    <td className="py-2.5 px-3 text-right font-medium">{formatINRDisplay(total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-neutral">No payment data</p>
        )}
      </div>
    </div>
  )
}
