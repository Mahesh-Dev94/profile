import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { PaymentModal } from '../../components/PaymentModal'
import { processSalaryPayment, processSigningBonusPayment, processRoyaltyPayment } from '../../utils/paymentProcessor'
import toast from 'react-hot-toast'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DollarSign, Gift, TrendingUp, Filter, Info } from 'lucide-react'
import { Checkbox } from '../../components/ui/checkbox'
import { formatINRDisplay } from '../../utils/currencyFormat'

/** Format month key "2026-06" as "Jun 2026" */
function formatMonthLabel(monthStr) {
  if (!monthStr || typeof monthStr !== 'string') return monthStr || '—'
  const [y, m] = monthStr.split('-')
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  if (idx >= 0 && idx < 12 && y) return `${months[idx]} ${y}`
  return monthStr
}

export function ReleasePaymentPage() {
  const { currentOrganizationId } = useOrganization()
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])

  const [paymentModal, setPaymentModal] = useState(null)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])

  const pendingSalary = useMemo(() => (salaryPayments || []).filter((s) => s.paymentStatus === 'pending'), [salaryPayments])
  const pendingSigningBonus = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending'), [signingBonuses])
  const pendingRoyalty = useMemo(() => (invoices || []).filter((inv) => {
    const total = Number(inv.royaltyAmount) || 0
    const paid = Number(inv.paidAmount) || 0
    return total - paid > 0
  }), [invoices])

  const talentOptions = useMemo(() => {
    const set = new Set()
    pendingSalary.forEach((s) => set.add(JSON.stringify({ id: s.talentId, name: s.talentName })))
    pendingSigningBonus.forEach((b) => set.add(JSON.stringify({ id: b.talentId, name: b.talentName })))
    pendingRoyalty.forEach((inv) => set.add(JSON.stringify({ id: inv.talentId, name: inv.talentName })))
    return Array.from(set).map((s) => JSON.parse(s)).filter((t) => t.id && t.name)
  }, [pendingSalary, pendingSigningBonus, pendingRoyalty])

  const filterByTalent = (talentId) => {
    if (selectedTalentIds.includes(talentId)) {
      setSelectedTalentIds((prev) => prev.filter((id) => id !== talentId))
    } else {
      setSelectedTalentIds((prev) => [...prev, talentId])
    }
  }

  const filteredPendingSalary = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingSalary
    return pendingSalary.filter((s) => selectedTalentIds.includes(s.talentId))
  }, [pendingSalary, selectedTalentIds])

  const filteredPendingSigningBonus = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingSigningBonus
    return pendingSigningBonus.filter((b) => selectedTalentIds.includes(b.talentId))
  }, [pendingSigningBonus, selectedTalentIds])

  const filteredPendingRoyalty = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingRoyalty
    return pendingRoyalty.filter((inv) => selectedTalentIds.includes(inv.talentId))
  }, [pendingRoyalty, selectedTalentIds])

  const handlePayNow = (type, record, amount, title) => {
    setPaymentModal({ type, record, amount, title })
  }

  const handlePaymentSuccess = ({ amount, paymentMethod }) => {
    if (!paymentModal) return
    const { type, record } = paymentModal
    try {
      if (type === 'salary') {
        processSalaryPayment(record, paymentMethod, currentOrganizationId)
        toast.success('Salary payment recorded')
      } else if (type === 'signing_bonus') {
        processSigningBonusPayment(record, paymentMethod, currentOrganizationId)
        toast.success('Signing bonus payment recorded')
      } else if (type === 'royalty') {
        processRoyaltyPayment(record, amount, paymentMethod, currentOrganizationId)
        toast.success('Royalty payment recorded')
      }
    } catch (e) {
      toast.error('Failed to record payment')
    }
    setPaymentModal(null)
  }

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filters</span>
        </div>
        <p className="text-2xs text-neutral mb-2">Filter by talent (none = all)</p>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {talentOptions.length === 0 ? (
            <p className="text-2xs text-neutral">No talents in pending items</p>
          ) : (
            talentOptions.map((t) => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
                <Checkbox
                  checked={selectedTalentIds.includes(t.id)}
                  onCheckedChange={() => filterByTalent(t.id)}
                />
                <span className="text-xs truncate">{t.name}</span>
              </label>
            ))
          )}
        </div>
        {selectedTalentIds.length > 0 && (
          <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={() => setSelectedTalentIds([])}>
            Clear filter
          </Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <div>
          <h2 className="text-xl font-semibold">Release Payment</h2>
          <p className="text-sm text-neutral mt-1">Pay pending Salary, Signing Bonus, or Royalty. Click PAY NOW to open the payment screen (Card or UPI).</p>
        </div>

        <Card className="border-l-4 border-l-amber-500 bg-amber-50/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-amber-600" />
              Pending Salary
            </CardTitle>
            <div className="flex items-start gap-2 text-xs text-neutral mt-1">
              <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
              <p>Monthly salary due to talent. Release payment to mark as paid and record in the ledger.</p>
            </div>
          </CardHeader>
          <CardContent>
            {filteredPendingSalary.length === 0 ? (
              <p className="text-sm text-neutral">No pending salary payments.</p>
            ) : (
              <ul className="space-y-3">
                {filteredPendingSalary.map((s) => (
                  <li key={s.id} className="flex justify-between items-center text-sm border-b border-amber-100/50 py-2.5 px-3 rounded-lg bg-white/60">
                    <span><span className="font-medium">{s.talentName}</span> — {formatMonthLabel(s.month)} — <span className="text-primary font-semibold">{formatINRDisplay(s.salaryAmount)}</span></span>
                    <Button className="bg-accent text-white hover:bg-accent/90 shrink-0" size="sm" onClick={() => handlePayNow('salary', s, s.salaryAmount, `Salary — ${s.talentName} — ${s.month}`)}>PAY NOW</Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-primary bg-primary/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Gift className="h-5 w-5 text-primary" />
              Pending Signing Bonus
            </CardTitle>
            <div className="flex items-start gap-2 text-xs text-neutral mt-1">
              <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
              <p>$3,000,000 payable within 10 business days of execution. Release after the contract release date.</p>
            </div>
          </CardHeader>
          <CardContent>
            {filteredPendingSigningBonus.length === 0 ? (
              <p className="text-sm text-neutral">No pending signing bonuses.</p>
            ) : (
              <ul className="space-y-3">
                {filteredPendingSigningBonus.map((b) => (
                  <li key={b.id} className="flex justify-between items-center text-sm border-b border-primary/10 py-2.5 px-3 rounded-lg bg-white/60">
                    <span><span className="font-medium">{b.talentName}</span> — <span className="text-primary font-semibold">{formatINRDisplay(b.amount)}</span></span>
                    <Button className="bg-accent text-white hover:bg-accent/90 shrink-0" size="sm" onClick={() => handlePayNow('signing_bonus', b, b.amount, `Signing Bonus — ${b.talentName}`)}>PAY NOW</Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-600 bg-green-50/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Pending Royalty
            </CardTitle>
            <div className="flex items-start gap-2 text-xs text-neutral mt-1">
              <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
              <p>Royalty from sales owed to talent. Pay the remaining amount to update invoice and ledger.</p>
            </div>
          </CardHeader>
          <CardContent>
            {filteredPendingRoyalty.length === 0 ? (
              <p className="text-sm text-neutral">No pending royalty.</p>
            ) : (
              <ul className="space-y-3">
                {filteredPendingRoyalty.map((inv) => {
                  const total = Number(inv.royaltyAmount) || 0
                  const paid = Number(inv.paidAmount) || 0
                  const due = total - paid
                  return (
                    <li key={inv.id} className="flex justify-between items-center text-sm border-b border-green-100/50 py-2.5 px-3 rounded-lg bg-white/60">
                      <span><span className="font-medium">{inv.talentName}</span> — {formatMonthLabel(inv.date?.slice(0, 7))} {inv.invoiceID && `· ${inv.invoiceID}`} — <span className="text-green-700 font-semibold">{formatINRDisplay(due)} due</span></span>
                      <Button className="bg-accent text-white hover:bg-accent/90 shrink-0" size="sm" onClick={() => handlePayNow('royalty', inv, due, `Royalty — ${inv.invoiceID}`)}>PAY NOW</Button>
                    </li>
                  )
                })}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {paymentModal && (
        <PaymentModal
          open={!!paymentModal}
          onOpenChange={(v) => !v && setPaymentModal(null)}
          amount={paymentModal.amount}
          title={paymentModal.title}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
