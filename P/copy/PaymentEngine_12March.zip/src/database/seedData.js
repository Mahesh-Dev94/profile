const STORAGE_KEY = 'royalty_payment_engine_db'

const ORG_1 = 'org-1'

// Default login: Sport Business = Metropolis Meteors, Vendor = Zenith Sportswear, Talent = Arjun "Ace" Verma
const defaultUsers = [
  { id: 'u-sb-1', email: 'club@meteors.com', password: 'admin123', role: 'sponsorship_admin', name: 'Metropolis Meteors American Football Pvt. Ltd.', organizationId: ORG_1 },
  { id: 'u-vendor-1', email: 'zenith@vendor.com', password: 'admin123', role: 'vendor_partner', name: 'Zenith Sportswear India Pvt. Ltd.', organizationId: ORG_1 },
  { id: 'u-talent-1', email: 'arjun@talent.com', password: 'talent123', role: 'talent', name: 'Arjun "Ace" Verma', talentId: 't-1', organizationId: ORG_1 },
  { id: 'u-admin-2', email: 'admin@sponsorship.com', password: 'admin123', role: 'platform_admin', name: 'Platform Admin', organizationId: ORG_1 },
  { id: 'u-talent-2', email: 'talent2@sports.com', password: 'talent123', role: 'talent', name: 'Jordan Lee', talentId: 't-2', organizationId: ORG_1 },
]

const defaultOrganizations = [
  { id: ORG_1, name: 'Metropolis Meteors American Football Pvt. Ltd.', createdAt: '2025-01-01' },
]

// Signing bonus: INR 30,00,000 payable within 10 business days of execution
const defaultTalents = [
  { id: 't-1', name: 'Arjun "Ace" Verma', signingDate: '2025-01-15', signingBonus: 3000000, releaseDate: '2025-01-29', signingBonusStatus: 'paid', organizationId: ORG_1 },
  { id: 't-2', name: 'Jordan Lee', signingDate: '2025-02-20', signingBonus: 3000000, releaseDate: '2025-03-06', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-3', name: 'Sam Williams', signingDate: '2025-03-10', signingBonus: 3000000, releaseDate: '2025-03-24', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-4', name: 'Morgan Taylor', signingDate: '2025-04-05', signingBonus: 3000000, releaseDate: '2025-04-21', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-5', name: 'Casey Kim', signingDate: '2025-05-12', signingBonus: 3000000, releaseDate: '2025-05-28', signingBonusStatus: 'pending', organizationId: ORG_1 },
]

const defaultSportsBusinesses = [
  { id: 'sb-1', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 120000, revenueSharePercent: 0.15, minimumGuarantee: 20000, talentsAssociated: ['t-1', 't-2'], organizationId: ORG_1 },
  { id: 'sb-2', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 85000, revenueSharePercent: 0.12, talentsAssociated: ['t-1', 't-3'], organizationId: ORG_1 },
  { id: 'sb-3', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 95000, revenueSharePercent: 0.14, talentsAssociated: ['t-2', 't-4'], organizationId: ORG_1 },
]

const defaultSponsorshipCompanies = [
  { id: 'sc-1', companyName: 'Zenith Sportswear India Pvt. Ltd.', country: 'India', contractValue: 500000, royaltyRate: 0.08, minimumGuarantee: 40000, organizationId: ORG_1 },
  { id: 'sc-2', companyName: 'Global Athletics', country: 'UK', contractValue: 350000, royaltyRate: 0.06, minimumGuarantee: 25000, organizationId: ORG_1 },
]

// Basic salary: 2026-27 INR 1,80,00,000; 2027-28 INR 2,00,00,000. Signing bonus: INR 30,00,000 within 10 business days.
const defaultContracts = [
  { id: 'c-1', contractID: 'CNT-2025-001', talentId: 't-1', talentName: 'Arjun "Ace" Verma', licenseeId: 'sb-1', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-1', annualSalary: 18000000, basicSalary2026_27: 18000000, basicSalary2027_28: 20000000, royaltyPercent: 0.08, signingBonus: 3000000, minimumGuarantee: 40000, skuMinimumGuaranteeAnnual: 500000, startDate: '2025-01-01', endDate: '2027-12-31', status: 'active', organizationId: ORG_1 },
  { id: 'c-2', contractID: 'CNT-2025-002', talentId: 't-2', talentName: 'Jordan Lee', licenseeId: 'sb-1', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-2', annualSalary: 18000000, basicSalary2026_27: 18000000, basicSalary2027_28: 20000000, royaltyPercent: 0.06, signingBonus: 3000000, minimumGuarantee: 25000, skuMinimumGuaranteeAnnual: 400000, startDate: '2025-02-01', endDate: '2027-12-31', status: 'active', organizationId: ORG_1 },
  { id: 'c-3', contractID: 'CNT-2025-003', talentId: 't-3', talentName: 'Sam Williams', licenseeId: 'sb-2', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-1', annualSalary: 18000000, basicSalary2026_27: 18000000, basicSalary2027_28: 20000000, royaltyPercent: 0.07, signingBonus: 3000000, skuMinimumGuaranteeAnnual: 450000, startDate: '2025-03-01', endDate: '2027-12-31', status: 'active', organizationId: ORG_1 },
  { id: 'c-4', contractID: 'CNT-2025-004', talentId: 't-4', talentName: 'Morgan Taylor', licenseeId: 'sb-3', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', annualSalary: 18000000, basicSalary2026_27: 18000000, basicSalary2027_28: 20000000, royaltyPercent: 0.065, signingBonus: 3000000, skuMinimumGuaranteeAnnual: 350000, startDate: '2025-04-15', endDate: '2027-12-31', status: 'active', organizationId: ORG_1 },
  { id: 'c-5', contractID: 'CNT-2025-005', talentId: 't-5', talentName: 'Casey Kim', licenseeId: 'sb-2', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', annualSalary: 18000000, basicSalary2026_27: 18000000, basicSalary2027_28: 20000000, royaltyPercent: 0.05, signingBonus: 3000000, skuMinimumGuaranteeAnnual: 300000, startDate: '2025-05-01', endDate: '2027-12-31', status: 'active', organizationId: ORG_1 },
]

// Salary per record: 18,000,000
const defaultSalaryPayments = [
  { id: 'sal-1', talentId: 't-1', talentName: 'Arjun "Ace" Verma', month: '2026-04', salaryAmount: 18000000, paymentStatus: 'paid', organizationId: ORG_1 },
  { id: 'sal-2', talentId: 't-1', talentName: 'Arjun "Ace" Verma', month: '2026-05', salaryAmount: 18000000, paymentStatus: 'paid', organizationId: ORG_1 },
  { id: 'sal-3', talentId: 't-1', talentName: 'Arjun "Ace" Verma', month: '2026-06', salaryAmount: 18000000, paymentStatus: 'pending', organizationId: ORG_1 },
  { id: 'sal-4', talentId: 't-2', talentName: 'Jordan Lee', month: '2026-04', salaryAmount: 18000000, paymentStatus: 'paid', organizationId: ORG_1 },
  { id: 'sal-5', talentId: 't-2', talentName: 'Jordan Lee', month: '2026-05', salaryAmount: 18000000, paymentStatus: 'pending', organizationId: ORG_1 },
  { id: 'sal-6', talentId: 't-3', talentName: 'Sam Williams', month: '2026-05', salaryAmount: 18000000, paymentStatus: 'pending', organizationId: ORG_1 },
  { id: 'sal-7', talentId: 't-4', talentName: 'Morgan Taylor', month: '2026-06', salaryAmount: 18000000, paymentStatus: 'pending', organizationId: ORG_1 },
  { id: 'sal-8', talentId: 't-5', talentName: 'Casey Kim', month: '2026-06', salaryAmount: 18000000, paymentStatus: 'pending', organizationId: ORG_1 },
]

const defaultSigningBonuses = [
  { id: 'sb-1', talentId: 't-1', talentName: 'Arjun "Ace" Verma', amount: 3000000, signingDate: '2025-01-15', releaseDate: '2025-01-29', status: 'paid', organizationId: ORG_1 },
  { id: 'sb-2', talentId: 't-2', talentName: 'Jordan Lee', amount: 3000000, signingDate: '2025-02-20', releaseDate: '2025-03-06', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-3', talentId: 't-3', talentName: 'Sam Williams', amount: 3000000, signingDate: '2025-03-10', releaseDate: '2025-03-24', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-4', talentId: 't-4', talentName: 'Morgan Taylor', amount: 3000000, signingDate: '2025-04-05', releaseDate: '2025-04-21', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-5', talentId: 't-5', talentName: 'Casey Kim', amount: 3000000, signingDate: '2025-05-12', releaseDate: '2025-05-28', status: 'pending', organizationId: ORG_1 },
]

const defaultSales = [
  { id: 's-1', sku: 'SKU-001', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productDescription: 'Jersey Line A', talentNames: 'Arjun "Ace" Verma', talentIds: ['t-1'], country: 'USA', unitsSold: 1000, effectiveUnitSalesPrice: 45, netSales: 45000, date: '2025-02-15', organizationId: ORG_1 },
  { id: 's-2', sku: 'SKU-002', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productDescription: 'Jersey Line B', talentNames: 'Jordan Lee', talentIds: ['t-2'], country: 'UK', unitsSold: 500, effectiveUnitSalesPrice: 38, netSales: 19000, date: '2025-05-20', organizationId: ORG_1 },
  { id: 's-3', sku: 'SKU-003', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productDescription: 'Equipment Pack', talentNames: 'Arjun "Ace" Verma', talentIds: ['t-1'], country: 'USA', unitsSold: 800, effectiveUnitSalesPrice: 120, netSales: 96000, date: '2025-08-25', organizationId: ORG_1 },
  { id: 's-4', sku: 'SKU-004', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productDescription: 'Accessories', talentNames: 'Sam Williams', talentIds: ['t-3'], country: 'Canada', unitsSold: 1200, effectiveUnitSalesPrice: 25, netSales: 30000, date: '2025-11-01', organizationId: ORG_1 },
  { id: 's-5', sku: 'SKU-005', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productDescription: 'Training Kit Pro', talentNames: 'Morgan Taylor', talentIds: ['t-4'], country: 'USA', unitsSold: 350, effectiveUnitSalesPrice: 89, netSales: 31150, date: '2026-01-10', organizationId: ORG_1 },
]

const defaultInvoices = [
  { id: 'inv-1', invoiceID: 'INV-2025-001', talentName: 'Arjun "Ace" Verma', talentId: 't-1', royaltyAmount: 3600, netSales: 45000, date: '2025-01-31', status: 'paid', paidAmount: 3600, organizationId: ORG_1 },
  { id: 'inv-2', invoiceID: 'INV-2025-002', talentName: 'Jordan Lee', talentId: 't-2', royaltyAmount: 1140, netSales: 19000, date: '2025-03-31', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-3', invoiceID: 'INV-2025-003', talentName: 'Arjun "Ace" Verma', talentId: 't-1', royaltyAmount: 7680, netSales: 96000, date: '2025-06-30', status: 'paid', paidAmount: 7680, organizationId: ORG_1 },
  { id: 'inv-4', invoiceID: 'INV-2025-004', talentName: 'Morgan Taylor', talentId: 't-4', royaltyAmount: 2025, netSales: 31150, date: '2025-09-30', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-5', invoiceID: 'INV-2025-005', talentName: 'Casey Kim', talentId: 't-5', royaltyAmount: 850, netSales: 17000, date: '2026-02-28', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
]

const defaultRoyaltyPayments = []

const defaultPaymentLedger = [
  { id: 'ledger-1', date: '2026-05-01', transactionId: 'TXN-93847001', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Salary', amount: 18000000, paymentMethod: 'card', status: 'completed', details: 'Salary slip Apr 2026', organizationId: ORG_1 },
  { id: 'ledger-2', date: '2025-01-25', transactionId: 'TXN-93847002', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Signing Bonus', amount: 3000000, paymentMethod: 'card', status: 'completed', details: 'Signing bonus – $3,000,000 within 10 business days', organizationId: ORG_1 },
  { id: 'ledger-3', date: '2025-02-08', transactionId: 'TXN-93847003', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Royalty', amount: 3600, paymentMethod: 'upi', status: 'completed', details: 'Royalty Jan 2025', organizationId: ORG_1 },
  { id: 'ledger-4', date: '2026-06-01', transactionId: 'TXN-93847004', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Salary', amount: 18000000, paymentMethod: 'card', status: 'completed', details: 'Salary slip May 2026', organizationId: ORG_1 },
  { id: 'ledger-5', date: '2026-05-02', transactionId: 'TXN-93847005', talentId: 't-2', talentName: 'Jordan Lee', paymentType: 'Salary', amount: 18000000, paymentMethod: 'card', status: 'completed', details: 'Salary slip Apr 2026', organizationId: ORG_1 },
]

export function getSeedData() {
  return {
    organizations: defaultOrganizations,
    users: defaultUsers,
    talents: defaultTalents,
    sportsBusinesses: defaultSportsBusinesses,
    sponsorshipCompanies: defaultSponsorshipCompanies,
    contracts: defaultContracts,
    salaryPayments: defaultSalaryPayments,
    signingBonuses: defaultSigningBonuses,
    sales: defaultSales,
    invoices: defaultInvoices,
    royaltyPayments: defaultRoyaltyPayments,
    paymentLedger: defaultPaymentLedger,
  }
}

export function seedDatabase() {
  const existing = localStorage.getItem(STORAGE_KEY)
  if (existing) return JSON.parse(existing)
  const data = getSeedData()
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  return data
}

export function resetDatabase() {
  localStorage.removeItem(STORAGE_KEY)
  return seedDatabase()
}

export { STORAGE_KEY }
