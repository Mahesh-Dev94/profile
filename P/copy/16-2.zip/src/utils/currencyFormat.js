/**
 * US Dollar number formatting (comma every 3 digits).
 * e.g. 18000000 → "18,000,000"
 */
export function formatDollar(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Math.round(Number(num))
  return n.toLocaleString('en-US')
}

/** Display as "$18,000,000" */
export function formatDollarDisplay(num) {
  return `$${formatDollar(num)}`
}

/** @deprecated Use formatDollar for display */
export function formatINR(num) {
  return formatDollar(num)
}

/** @deprecated Use formatDollarDisplay for display */
export function formatINRDisplay(num) {
  return formatDollarDisplay(num)
}

import { MONTHLY_PERFORMANCE_BONUS_AMOUNT } from './salaryCalculator'

/** Default basic salary and performance bonus text for contracts */
export const DEFAULT_SALARY_2026_27 = 18000000
export const DEFAULT_SALARY_2027_28 = 20000000
/** Monthly performance bonus (single source: salaryCalculator.MONTHLY_PERFORMANCE_BONUS_AMOUNT). */
export const DEFAULT_SIGNING_BONUS_INR = MONTHLY_PERFORMANCE_BONUS_AMOUNT
export const SIGNING_BONUS_DESCRIPTION = `$${formatDollar(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per month (monthly performance bonus).`
