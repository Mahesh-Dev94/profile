/**
 * Salary and compensation calculations for talent payments.
 * Monthly compensation = Monthly Salary + Monthly Performance Bonus + Monthly Royalty.
 * Monthly performance bonus is a fixed amount per talent per month (see MONTHLY_PERFORMANCE_BONUS_AMOUNT).
 */

/**
 * Monthly performance bonus per talent per month ($).
 * Single source of truth: change only here; salary, Performance Bonus page, and PDFs use this value.
 */
export const MONTHLY_PERFORMANCE_BONUS_AMOUNT = 10000

export function getMonthlySalary(annualSalary) {
  return (Number(annualSalary) || 0) / 12
}

/** Monthly performance bonus for a talent in a given month. Fixed at MONTHLY_PERFORMANCE_BONUS_AMOUNT per talent per month. */
export function getMonthlyPerformanceBonus(talentId, month, _signingBonuses) {
  if (!month || !talentId) return 0
  return MONTHLY_PERFORMANCE_BONUS_AMOUNT
}

/** Monthly royalty for a talent in a given month from royalty ledger. */
export function getMonthlyRoyalty(talentId, month, ledger) {
  if (!month || !ledger?.length) return 0
  const monthStr = String(month).slice(0, 7)
  return (ledger || [])
    .filter((r) => r.talentId === talentId && String(r.date || '').slice(0, 7) === monthStr)
    .reduce((sum, r) => sum + (Number(r.royaltyEarned) || 0), 0)
}

/** Enrich salary payment rows with monthly performance bonus, monthly royalty, and total earnings. */
export function enrichSalaryPayments(salaryPayments, signingBonuses, ledger) {
  return (salaryPayments || []).map((s) => {
    const monthlySalary = Number(s.salaryAmount) || 0
    const monthlyPerformanceBonus = getMonthlyPerformanceBonus(s.talentId, s.month, signingBonuses)
    const monthlyRoyalty = getMonthlyRoyalty(s.talentId, s.month, ledger)
    const totalEarnings = monthlySalary + monthlyPerformanceBonus + monthlyRoyalty
    return {
      ...s,
      monthlyPerformanceBonus,
      monthlyRoyalty,
      totalEarnings,
    }
  })
}

export function getAnnualSalaryTotal(salaryPayments) {
  return (salaryPayments || []).reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

/** Total compensation (salary + monthly performance bonus + royalty) across all rows. */
export function getTotalCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const enriched = enrichSalaryPayments(salaryPayments, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

/** Paid compensation total (paid rows only). */
export function getPaidCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const paid = (salaryPayments || []).filter((s) => s.paymentStatus === 'paid')
  const enriched = enrichSalaryPayments(paid, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

/** Pending compensation total (pending rows only). */
export function getPendingCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const pending = (salaryPayments || []).filter((s) => s.paymentStatus === 'pending')
  const enriched = enrichSalaryPayments(pending, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

export function getPaidSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'paid')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPendingSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'pending')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

/** Per-talent salary totals (matches Salary page figures when summed per talent). */
export function getSalaryByTalent(salaryPayments) {
  const byTalent = {}
  ;(salaryPayments || []).forEach((s) => {
    const id = s.talentId || s.talentName
    const name = s.talentName || 'Unknown'
    if (!byTalent[id]) byTalent[id] = { talentId: s.talentId, name, value: 0 }
    byTalent[id].value += Number(s.salaryAmount) || 0
  })
  return Object.values(byTalent)
    .map(({ name, value }) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
}

/** Per-talent annual salary from contracts (one value per talent, for summary/chart). */
export function getAnnualSalaryByTalentFromContracts(contracts) {
  const byTalent = {}
  ;(contracts || []).forEach((c) => {
    const id = c.talentId
    if (!id || byTalent[id]) return
    const annual = Number(c.basicSalary2026_27 ?? c.annualSalary) || 0
    byTalent[id] = { name: c.talentName || 'Unknown', value: annual }
  })
  return Object.values(byTalent).sort((a, b) => b.value - a.value)
}
