import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import { format } from 'date-fns'
import { formatDisplayDate } from './dateFormat'
import { formatINR, SIGNING_BONUS_DESCRIPTION } from './currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT } from './salaryCalculator'

function buildContractPDF(doc, contract, talentName, licenseeName) {
  const cn = contract.contractID || contract.id
  const talent = talentName || contract.talentName
  const licensee = licenseeName || contract.licensee
  const royaltyPct = ((contract.royaltyPercent || 0) * 100).toFixed(2)
  const mg = formatINR(contract.minimumGuarantee)
  const salary2026 = formatINR(contract.basicSalary2026_27 ?? contract.annualSalary)
  const salary2027 = formatINR(contract.basicSalary2027_28 ?? contract.annualSalary)
  const signingBonus = formatINR(contract.signingBonus)
  const start = formatDisplayDate(contract.startDate) || '—'
  const end = formatDisplayDate(contract.endDate) || '—'
  const status = contract.status || 'Active'

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('SPORTS TALENT CONTRACT', 20, 20)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  doc.text('Royalty Payment Engine', 20, 28)
  doc.text(`Contract No: ${cn}`, 120, 20)
  doc.text(`Effective: ${start}`, 120, 26)
  doc.text(`Expiry: ${end}`, 120, 32)

  let y = 42
  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.setFontSize(10)
  doc.text('PARTIES', 20, y)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  y += 6
  doc.text('This Agreement is entered into between the Licensee (Sports Business) and the Talent, represented by the Platform.', 20, y, { maxWidth: 170 })
  y += 8
  doc.text(`Licensee (Sports Business): ${licensee}`, 20, y)
  y += 5
  doc.text(`Talent: ${talent}`, 20, y)
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('1. GRANT OF RIGHTS', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('The Talent grants to the Licensee the non-exclusive right to use the Talent\'s name, likeness, and associated branding in connection with the licensed products and promotions during the Term.', 20, y, { maxWidth: 170 })
  y += 12

  doc.setFont(undefined, 'bold')
  doc.text('2. COMPENSATION', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Basic Salary: 2026-27: $${salary2026}; 2027-28: $${salary2027}. Performance Bonus: ${SIGNING_BONUS_DESCRIPTION} Royalty Rate: ${royaltyPct}% of Net Sales. Minimum Guarantee (Sports Business): $${mg} per contract year.`, 20, y, { maxWidth: 170 })
  y += 12

  doc.setFont(undefined, 'bold')
  doc.text('3. TERM', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Start Date: ${start}. End Date: ${end}. Status: ${status}.`, 20, y, { maxWidth: 170 })
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('4. PAYMENT', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('Royalties shall be calculated monthly and paid within 30 days of month end. Minimum Guarantee shall be paid in accordance with the payment schedule agreed by the parties.', 20, y, { maxWidth: 170 })
  y += 14

  doc.line(20, y, 190, y)
  y += 6
  doc.setFontSize(8)
  doc.text('This document is generated for record-keeping. Signed originals may be held on file. Generated: ' + format(new Date(), 'PPpp'), 20, y)
}

/**
 * Vendor/Sponsor agreement PDF: between Sponsorship Company and Sports Business.
 * Includes SKU minimum guarantee (Annual) and signature block (By _______, Name, Title).
 */
function buildVendorAgreementPDF(doc, contract, sponsorCompanyName, sportsBusinessName) {
  const cn = contract.contractID || contract.id
  const sponsor = sponsorCompanyName || 'Sponsorship Company'
  const sportsBiz = sportsBusinessName || contract.licensee || 'Sports Business'
  const start = formatDisplayDate(contract.startDate) || '—'
  const end = formatDisplayDate(contract.endDate) || '—'
  const royaltyPct = ((contract.royaltyPercent || 0) * 100).toFixed(2)
  const skuMg = formatINR(contract.skuMinimumGuaranteeAnnual ?? contract.minimumGuarantee)
  const productLicensing = contract.productLicensing || 'Licensed products and merchandise as agreed'

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('SPONSORSHIP / PARTNER AGREEMENT', 20, 24)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  doc.text('Royalty Payment Engine', 20, 34)
  doc.text(`Agreement No: ${cn}`, 120, 24)
  doc.text(`Effective: ${start}`, 120, 30)
  doc.text(`Expiry: ${end}`, 120, 36)

  let y = 52
  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.setFontSize(10)
  doc.text('PARTIES', 20, y)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  y += 6
  doc.text('This Agreement is entered into between the Sponsorship / Partner Vendor (Company) and the Sports Business (Club).', 20, y, { maxWidth: 170 })
  y += 8
  doc.text(`Sponsorship Company: ${sponsor}`, 20, y)
  y += 5
  doc.text(`Sports Business: ${sportsBiz}`, 20, y)
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('1. CONTRACT PERIOD', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Effective from ${start} to ${end}.`, 20, y, { maxWidth: 170 })
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('2. PRODUCT / LICENSING', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(productLicensing, 20, y, { maxWidth: 170 })
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('3. REVENUE SHARE & ROYALTY', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`Royalty: ${royaltyPct}% of Net Sales as per the terms of this agreement.`, 20, y, { maxWidth: 170 })
  y += 8

  doc.setFont(undefined, 'bold')
  doc.text('4. SKU MINIMUM GUARANTEE (ANNUAL)', 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text(`$${skuMg} per annum, as minimum guarantee for the licensed SKU(s) under this agreement.`, 20, y, { maxWidth: 170 })
  y += 14

  doc.setFont(undefined, 'bold')
  doc.setFontSize(10)
  doc.text('SIGNATURES', 20, y)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  y += 6
  doc.text('In witness whereof, the parties have executed this agreement as of the effective date.', 20, y, { maxWidth: 170 })
  y += 8
  doc.setFontSize(8)
  doc.text('Signatory / Contact – To whom contract signing: The signatories below are authorized to execute this agreement on behalf of their respective organizations. Add name, title and contact details of each signatory.', 20, y, { maxWidth: 170 })
  y += 12

  doc.setDrawColor(180, 180, 180)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.text(sponsor, 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('By', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 6
  doc.setDrawColor(180, 180, 180)
  doc.text('Name:', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 6
  doc.text('Title:', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 8
  doc.setDrawColor(180, 180, 180)

  doc.setFont(undefined, 'bold')
  doc.text(sportsBiz, 20, y)
  doc.setFont(undefined, 'normal')
  y += 5
  doc.text('By', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 6
  doc.setDrawColor(180, 180, 180)
  doc.text('Name:', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 6
  doc.text('Title:', 20, y)
  y += 4
  doc.setDrawColor(100, 100, 100)
  doc.line(20, y, 90, y)
  y += 8
  doc.setDrawColor(180, 180, 180)

  doc.line(20, y, 190, y)
  y += 6
  doc.setFontSize(8)
  doc.text('Generated: ' + format(new Date(), 'PPpp'), 20, y)
}

export function downloadVendorAgreementPDF(contract, sponsorCompanyName, sportsBusinessName) {
  const doc = new jsPDF()
  buildVendorAgreementPDF(doc, contract, sponsorCompanyName, sportsBusinessName)
  doc.save(`vendor-agreement-${(contract.contractID || contract.id).replace(/\s/g, '-')}.pdf`)
}

export function getVendorAgreementPDFBlobURL(contract, sponsorCompanyName, sportsBusinessName) {
  const doc = new jsPDF()
  buildVendorAgreementPDF(doc, contract, sponsorCompanyName, sportsBusinessName)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

export function downloadContractPDF(contract, talentName, licenseeName) {
  const doc = new jsPDF()
  buildContractPDF(doc, contract, talentName, licenseeName)
  doc.save(`contract-${(contract.contractID || contract.id).replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the contract PDF (revoke with URL.revokeObjectURL when done). */
export function getContractPDFBlobURL(contract, talentName, licenseeName) {
  const doc = new jsPDF()
  buildContractPDF(doc, contract, talentName, licenseeName)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

function buildInvoicePDF(invoice, doc) {
  const invId = invoice.invoiceID || invoice.id || 'N/A'
  const date = formatDisplayDate(invoice.date) || formatDisplayDate(new Date())
  const period = invoice.period || 'Monthly'
  const sponsor = invoice.sponsorCompany || '—'
  const business = invoice.sportsBusiness || '—'
  const talent = invoice.talentName || '—'
  const royalty = Number(invoice.royaltyAmount || 0)
  const minGuar = Number(invoice.minimumGuarantee || 0)
  const netSales = Number(invoice.netSales || 0)
  const total = royalty + minGuar

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('INVOICE', 20, 18)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(10)
  doc.text('Sports Sponsorship & Royalty Platform', 20, 26)
  doc.text('Invoice #', 120, 18)
  doc.text(invId, 140, 18)
  doc.text('Date', 120, 24)
  doc.text(date, 140, 24)
  doc.text('Period', 120, 30)
  doc.text(period, 140, 30)

  let y = 42
  doc.setFont(undefined, 'bold')
  doc.text('Bill To', 20, y)
  doc.text('Details', 120, y)
  doc.setFont(undefined, 'normal')
  y += 6
  doc.text(`Sponsor: ${sponsor}`, 20, y)
  y += 5
  doc.text(`Sports Business: ${business}`, 20, y)
  y += 5
  doc.text(`Talent: ${talent}`, 20, y)
  y += 10

  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.text('Description', 20, y)
  doc.text('Amount (USD)', 150, y)
  doc.setFont(undefined, 'normal')
  y += 7
  doc.line(20, y, 190, y)
  y += 7
  doc.text('Royalty', 20, y)
  doc.text(`$${royalty.toLocaleString()}`, 150, y)
  y += 6
  doc.text('Minimum Guarantee', 20, y)
  doc.text(`$${minGuar.toLocaleString()}`, 150, y)
  y += 6
  doc.text('Net Sales (reference)', 20, y)
  doc.text(`$${netSales.toLocaleString()}`, 150, y)
  y += 8
  doc.line(20, y, 190, y)
  y += 7
  doc.setFont(undefined, 'bold')
  doc.text('Total Due', 20, y)
  doc.text(`$${total.toLocaleString()}`, 150, y)
  doc.setFont(undefined, 'normal')
  y += 12
  doc.setFontSize(8)
  doc.text(`Generated on ${format(new Date(), 'PPpp')}. This is a computer-generated invoice.`, 20, y)
}

export function downloadInvoicePDF(invoice) {
  const doc = new jsPDF()
  buildInvoicePDF(invoice, doc)
  doc.save(`invoice-${(invoice.invoiceID || invoice.id || 'inv').replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the invoice PDF (revoke with URL.revokeObjectURL when done). */
export function getInvoicePDFBlobURL(invoice) {
  const doc = new jsPDF()
  buildInvoicePDF(invoice, doc)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

export function downloadSigningBonusCertificatePDF(talent) {
  const doc = new jsPDF()
  const amt = formatINR(talent.signingBonus ?? MONTHLY_PERFORMANCE_BONUS_AMOUNT)
  doc.setFontSize(18)
  doc.text('Performance Bonus Certificate', 20, 22)
  doc.setFontSize(10)
  doc.text(`$${formatINR(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per month (monthly performance bonus).`, 20, 32, { maxWidth: 170 })
  doc.setFontSize(12)
  doc.text(talent.name || 'Talent', 20, 48)
  doc.setFontSize(10)
  doc.text(`Signing Date: ${talent.signingDate}`, 20, 58)
  doc.text(`Performance Bonus: $${amt} per month`, 20, 66)
  doc.text(`Release Date: ${talent.releaseDate || 'N/A'}`, 20, 74)
  doc.setFontSize(9)
  doc.text(`Certificate generated on ${format(new Date(), 'PPpp')}`, 20, 88)
  doc.save(`performance-bonus-${(talent.name || 'talent').replace(/\s/g, '-')}.pdf`)
}

/** Returns object URL for the performance bonus certificate PDF (revoke with URL.revokeObjectURL when done). */
export function getSigningBonusPDFBlobURL(talent) {
  const doc = new jsPDF()
  const amt = formatINR(talent.signingBonus ?? MONTHLY_PERFORMANCE_BONUS_AMOUNT)
  doc.setFontSize(18)
  doc.text('Performance Bonus Certificate', 20, 22)
  doc.setFontSize(10)
  doc.text(`$${formatINR(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per month (monthly performance bonus).`, 20, 32, { maxWidth: 170 })
  doc.setFontSize(12)
  doc.text(talent.name || 'Talent', 20, 48)
  doc.setFontSize(10)
  doc.text(`Signing Date: ${talent.signingDate}`, 20, 58)
  doc.text(`Performance Bonus: $${amt} per month`, 20, 66)
  doc.text(`Release Date: ${talent.releaseDate || 'N/A'}`, 20, 74)
  doc.setFontSize(9)
  doc.text(`Certificate generated on ${format(new Date(), 'PPpp')}`, 20, 88)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

function buildSalarySlipPDF(doc, salaryRecord, businessName = 'Sports Business') {
  const name = salaryRecord.talentName || 'Talent'
  const month = salaryRecord.month || '—'
  const monthlySalary = Number(salaryRecord.salaryAmount || 0)
  const performanceBonus = Number(salaryRecord.monthlyPerformanceBonus ?? 0)
  const royalty = Number(salaryRecord.monthlyRoyalty ?? 0)
  const total = monthlySalary + performanceBonus + royalty
  const status = salaryRecord.paymentStatus || 'Pending'

  doc.setFontSize(16)
  doc.setFont(undefined, 'bold')
  doc.text('SALARY SLIP', 20, 20)
  doc.setFont(undefined, 'normal')
  doc.setFontSize(9)
  doc.text('Royalty Payment Engine', 20, 28)
  doc.text(`Month: ${month}`, 120, 20)
  doc.text(`Status: ${status}`, 120, 26)

  let y = 42
  doc.setDrawColor(200, 200, 200)
  doc.line(20, y, 190, y)
  y += 8
  doc.setFont(undefined, 'bold')
  doc.text('Employee', 20, y)
  doc.text('Employer', 120, y)
  doc.setFont(undefined, 'normal')
  y += 6
  doc.text(name, 20, y)
  doc.text(businessName, 120, y)
  y += 10

  doc.setFont(undefined, 'bold')
  doc.text('Earnings', 20, y)
  doc.text('Amount ($)', 150, y)
  doc.setFont(undefined, 'normal')
  y += 7
  doc.line(20, y, 190, y)
  y += 7
  doc.text('Monthly Salary', 20, y)
  doc.text(`$${formatINR(monthlySalary)}`, 150, y)
  y += 7
  doc.text('Performance Bonus', 20, y)
  doc.text(`$${formatINR(performanceBonus)}`, 150, y)
  y += 7
  doc.text('Royalty', 20, y)
  doc.text(`$${formatINR(royalty)}`, 150, y)
  y += 10
  doc.line(20, y, 190, y)
  y += 7
  doc.setFont(undefined, 'bold')
  doc.text('Net Pay', 20, y)
  doc.text(`$${formatINR(total)}`, 150, y)
  doc.setFont(undefined, 'normal')
  y += 12
  doc.setFontSize(8)
  doc.text(`Generated on ${format(new Date(), 'PPpp')}. This is a computer-generated salary slip.`, 20, y)
}

export function downloadSalarySlipPDF(salaryRecord, businessName) {
  const doc = new jsPDF()
  buildSalarySlipPDF(doc, salaryRecord, businessName)
  doc.save(`salary-slip-${(salaryRecord.talentName || 'talent').replace(/\s/g, '-')}-${salaryRecord.month || 'month'}.pdf`)
}

/** Returns object URL for the salary slip PDF (revoke with URL.revokeObjectURL when done). */
export function getSalarySlipPDFBlobURL(salaryRecord, businessName) {
  const doc = new jsPDF()
  buildSalarySlipPDF(doc, salaryRecord, businessName)
  const blob = doc.output('blob')
  return URL.createObjectURL(blob)
}

export async function captureElementAsPDF(elementId, filename = 'export.pdf') {
  const el = document.getElementById(elementId)
  if (!el) return
  const canvas = await html2canvas(el, { scale: 2 })
  const img = canvas.toDataURL('image/png')
  const doc = new jsPDF('p', 'mm', 'a4')
  const w = doc.internal.pageSize.getWidth()
  const h = (canvas.height * w) / canvas.width
  doc.addImage(img, 'PNG', 0, 0, w, h)
  doc.save(filename)
}
