import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT } from '../../utils/salaryCalculator'
import { DollarSign, Gift } from 'lucide-react'

function aggregatePerformanceBonusByMonth(signingBonuses) {
  const byMonth = {}
  ;(signingBonuses || []).forEach((b) => {
    const d = b.signingDate
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(b.amount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function getPerformanceBonusByTalent(signingBonuses) {
  return (signingBonuses || [])
    .map((b) => ({ name: b.talentName || 'Unknown', value: Number(b.amount) || 0 }))
    .filter((x) => x.value > 0)
    .sort((a, b) => b.value - a.value)
}

/**
 * Performance Bonus page for Sponsorship portal – same structure as Royalties page.
 * One-time bonus (signing/release) + monthly performance bonus (MONTHLY_PERFORMANCE_BONUS_AMOUNT per talent per month, from salaryCalculator).
 */
export function SigningBonusPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading performance bonuses...', 'Performance bonus data loaded')
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])

  const bonusTotal = useMemo(() => (signingBonuses || []).reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const bonusPaid = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'paid').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])
  const bonusPending = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending').reduce((a, b) => a + (Number(b.amount) || 0), 0), [signingBonuses])

  const bonusMonthlyData = useMemo(() => aggregatePerformanceBonusByMonth(signingBonuses), [signingBonuses])
  const bonusByTalent = useMemo(() => getPerformanceBonusByTalent(signingBonuses), [signingBonuses])

  const bonusByTalentRows = useMemo(() => {
    const totalByTalent = {}
    const paidByTalent = {}
    ;(signingBonuses || []).forEach((b) => {
      const name = b.talentName || 'Unknown'
      totalByTalent[name] = (totalByTalent[name] || 0) + (Number(b.amount) || 0)
      if (b.status === 'paid') paidByTalent[name] = (paidByTalent[name] || 0) + (Number(b.amount) || 0)
    })
    const allNames = new Set([...Object.keys(totalByTalent)])
    return Array.from(allNames)
      .map((name) => {
        const total = totalByTalent[name] || 0
        const paid = paidByTalent[name] || 0
        const pending = Math.max(0, total - paid)
        return { talentName: name, bonusTotal: total, bonusPaid: paid, bonusPending: pending }
      })
      .filter((row) => row.bonusTotal > 0)
      .sort((a, b) => b.bonusTotal - a.bonusTotal)
  }, [signingBonuses])

  const ledgerColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'amount', header: 'Performance Bonus ($)', accessorKey: 'amount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'signingDate', header: 'Signing Date', accessorKey: 'signingDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'releaseDate', header: 'Release Date', accessorKey: 'releaseDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
  ]

  const talentSummaryColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'bonusTotal', header: 'Bonus Total', accessorKey: 'bonusTotal', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'bonusPaid', header: 'Bonus Paid', accessorKey: 'bonusPaid', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'bonusPending', header: 'Bonus Pending', accessorKey: 'bonusPending', cell: (info) => formatINRDisplay(info.getValue()) },
  ]

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Performance Bonus</h2>
      <p className="text-sm text-neutral">
        One-time performance bonus (signing/release) below. Monthly performance bonus: <strong>{formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}</strong> per talent per month (included in salary slips).
      </p>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Performance Bonus Total" value={formatINRDisplay(bonusTotal)} icon={DollarSign} />
        <StatCard title="Performance Bonus Paid" value={formatINRDisplay(bonusPaid)} icon={Gift} />
        <StatCard title="Performance Bonus Pending" value={formatINRDisplay(bonusPending)} icon={DollarSign} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          <MonthlyRevenueChart
            data={bonusMonthlyData}
            title="Performance Bonus Monthly Trend"
            description="One-time bonus by month (signing date)"
            currency="USD"
            valueLabel="Bonus"
          />
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
          {bonusByTalent.length > 0 ? (
            <RoyaltyDistributionChart data={bonusByTalent} title="Performance Bonus Distribution" description="By talent" />
          ) : (
            <div>
              <h3 className="mb-4 text-base font-medium">Performance Bonus Distribution</h3>
              <p className="text-sm text-neutral">No performance bonus data</p>
            </div>
          )}
        </div>
      </div>

      {bonusByTalentRows.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-3 text-base font-medium">Performance bonus by talent (Total, Paid, Pending)</h3>
          <DataTable columns={talentSummaryColumns} data={bonusByTalentRows} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}

      <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <h3 className="mb-2 text-base font-medium">Performance bonus ledger</h3>
        <div className="mb-3 flex flex-wrap gap-4 rounded-md bg-gray-50 px-3 py-2 text-sm">
          <span><strong>Monthly performance bonus:</strong> {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per talent per month</span>
          <span><strong>Bonus Total (one-time):</strong> {formatINRDisplay(bonusTotal)}</span>
          <span><strong>Bonus Paid:</strong> {formatINRDisplay(bonusPaid)}</span>
          <span><strong>Bonus Pending:</strong> {formatINRDisplay(bonusPending)}</span>
        </div>
        <DataTable columns={ledgerColumns} data={signingBonuses || []} searchKey="talentName" searchPlaceholder="Search by talent..." />
      </div>
    </div>
  )
}
