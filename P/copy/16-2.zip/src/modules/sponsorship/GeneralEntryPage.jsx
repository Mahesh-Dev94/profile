import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DataTable } from '../../components/tables/DataTable'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { Receipt } from 'lucide-react'

export function GeneralEntryPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading journal entries...', 'Journal entry data loaded')
  const ledger = useMemo(() => getAllByOrganization('paymentLedger', currentOrganizationId) || [], [currentOrganizationId])

  // Only paid/completed Salary and Performance Bonus entries (display only, do not add to ledger)
  const paidSalaryAndSigningBonus = useMemo(
    () =>
      ledger
        .filter(
          (r) =>
            (r.paymentType === 'Salary' || r.paymentType === 'Signing Bonus' || r.paymentType === 'Performance Bonus') &&
            (r.status === 'completed' || r.status === 'paid')
        )
        .sort((a, b) => (b.date || '').localeCompare(a.date || '')),
    [ledger]
  )

  const columns = [
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'transactionId', header: 'Transaction ID', accessorKey: 'transactionId' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'paymentType', header: 'Payment Type', accessorKey: 'paymentType', cell: (info) => (info.getValue() === 'Signing Bonus' ? 'Performance Bonus' : String(info.getValue() || '—')) },
    { id: 'amount', header: 'Amount', accessorKey: 'amount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'paymentMethod', header: 'Payment Method', accessorKey: 'paymentMethod', cell: (info) => String(info.getValue() || '').toUpperCase() },
    { id: 'status', header: 'Status', accessorKey: 'status' },
    { id: 'details', header: 'Details', accessorKey: 'details', cell: (info) => <span className="text-xs text-neutral">{info.getValue() || '—'}</span> },
  ]

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Journal Entry</h2>
        <p className="text-sm text-neutral mt-1">Payments already marked paid or done (Salary and Performance Bonus). This list is from the payment ledger — display only.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Receipt className="h-5 w-5" />
            Paid Salary &amp; Performance Bonus
          </CardTitle>
          <p className="text-xs text-neutral">Completed Salary and Performance Bonus entries from the ledger. No new entries are added here.</p>
        </CardHeader>
        <CardContent>
          {paidSalaryAndSigningBonus.length > 0 ? (
            <DataTable
              columns={columns}
              data={paidSalaryAndSigningBonus}
              searchKey="talentName"
              searchPlaceholder="Search by talent or transaction..."
            />
          ) : (
            <p className="text-sm text-neutral">No paid salary or performance bonus entries in the ledger yet.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
