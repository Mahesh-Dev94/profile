import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getAnnualSalaryByTalentFromContracts, enrichSalaryPayments } from '../../utils/salaryCalculator'
import { DataTable } from '../../components/tables/DataTable'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { SalarySlipPDFViewer } from '../../components/forms/SalarySlipPDFViewer'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { downloadSalarySlipPDF } from '../../utils/pdfGenerator'
import { FileText, Download, Filter, User, Calendar, DollarSign, CalendarDays } from 'lucide-react'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { formatDisplayDate } from '../../utils/dateFormat'
import { Checkbox } from '../../components/ui/checkbox'

function monthLabel(month) {
  if (!month || typeof month !== 'string') return '—'
  const [y, m] = month.split('-')
  const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : month
}

function aggregateSalaryByMonth(salaryPayments) {
  const byMonth = {}
  ;(salaryPayments || []).forEach((s) => {
    const key = s.month || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.salaryAmount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function SalaryPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Calculating talents salaries...', 'Salary data loaded')
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const ledger = useMemo(() => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses), [sales, contracts, talents, sportsBusinesses])
  const [viewingSlip, setViewingSlip] = useState(null)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])

  const businessName = sportsBusinesses[0]?.businessName || 'Sports Business'

  // Talent-wise joining date (contract start) and contract signing date (from seed: talents.signingDate)
  const talentWiseDates = useMemo(() => {
    const byTalent = new Map()
    ;(contracts || []).forEach((c) => {
      if (!c.talentId || byTalent.has(c.talentId)) return
      byTalent.set(c.talentId, {
        talentId: c.talentId,
        talentName: c.talentName || '—',
        joiningDate: c.startDate || null,
        contractSigningDate: null,
      })
    })
    ;(talents || []).forEach((t) => {
      const row = byTalent.get(t.id)
      if (row) row.contractSigningDate = t.signingDate || null
      else
        byTalent.set(t.id, {
          talentId: t.id,
          talentName: t.name || '—',
          joiningDate: null,
          contractSigningDate: t.signingDate || null,
        })
    })
    return Array.from(byTalent.values()).sort((a, b) => (a.talentName || '').localeCompare(b.talentName || ''))
  }, [contracts, talents])

  const salaryMonthlyData = useMemo(() => aggregateSalaryByMonth(salaryPayments), [salaryPayments])
  const salaryDistribution = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])

  const talentOptions = useMemo(() => {
    const map = new Map()
    ;(salaryPayments || []).forEach((s) => {
      if (s.talentId && s.talentName) map.set(s.talentId, s.talentName)
    })
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }))
  }, [salaryPayments])

  const filterByTalent = (talentId) => {
    setSelectedTalentIds((prev) =>
      prev.includes(talentId) ? prev.filter((id) => id !== talentId) : [...prev, talentId]
    )
  }

  const filteredSalaries = useMemo(() => {
    if (selectedTalentIds.length === 0) return salaryPayments || []
    return (salaryPayments || []).filter((s) => selectedTalentIds.includes(s.talentId))
  }, [salaryPayments, selectedTalentIds])

  /** Enrich each row with monthly performance bonus and royalty for table and PDF. */
  const enrichedSalaries = useMemo(
    () => enrichSalaryPayments(filteredSalaries || [], signingBonuses, ledger),
    [filteredSalaries, signingBonuses, ledger]
  )

  const summary = useMemo(() => {
    const totalAmount = enrichedSalaries.reduce((a, s) => a + (s.totalEarnings || 0), 0)
    const paidCount = enrichedSalaries.filter((s) => s.paymentStatus === 'paid').length
    const pendingCount = enrichedSalaries.filter((s) => s.paymentStatus === 'pending').length
    const paidAmount = enrichedSalaries.filter((s) => s.paymentStatus === 'paid').reduce((a, s) => a + (s.totalEarnings || 0), 0)
    return { totalAmount, paidCount, pendingCount, paidAmount, recordCount: enrichedSalaries.length }
  }, [enrichedSalaries])

  const columns = [
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'month', header: 'Period', accessorKey: 'month', cell: (info) => <span title={info.getValue()}>{monthLabel(info.getValue())}</span> },
    { id: 'salaryAmount', header: 'Monthly Salary ($)', accessorKey: 'salaryAmount', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'monthlyPerformanceBonus', header: 'Performance Bonus ($)', accessorKey: 'monthlyPerformanceBonus', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'monthlyRoyalty', header: 'Royalty ($)', accessorKey: 'monthlyRoyalty', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'totalEarnings', header: 'Total ($)', accessorKey: 'totalEarnings', cell: (info) => <span className="font-medium">{formatINRDisplay(info.getValue())}</span> },
    { id: 'paymentStatus', header: 'Status', accessorKey: 'paymentStatus', cell: (info) => (
      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
        {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
      </span>
    )},
    { id: 'actions', header: 'Actions', cell: ({ row }) => (
      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="bg-primary text-white hover:bg-primary/90 border-primary text-xs" onClick={() => setViewingSlip(row.original)}>
          <FileText className="h-4 w-4 mr-1" /> View Salary Slip PDF
        </Button>
        <Button variant="outline" size="sm" className="text-xs" onClick={() => downloadSalarySlipPDF(row.original, businessName)}>
          <Download className="h-4 w-4 mr-1" /> Download PDF
        </Button>
      </div>
    )},
  ]

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filter by talent</span>
        </div>
        <p className="text-2xs text-neutral mb-2">Check talent to show only their salaries (none = all)</p>
        <div className="space-y-2 max-h-[70vh] overflow-y-auto">
          {talentOptions.length === 0 ? (
            <p className="text-2xs text-neutral">No talent data</p>
          ) : (
            talentOptions.map((t) => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
                <Checkbox
                  checked={selectedTalentIds.includes(t.id)}
                  onCheckedChange={() => filterByTalent(t.id)}
                />
                <span className="text-xs truncate">{t.name}</span>
              </label>
            ))
          )}
        </div>
        {selectedTalentIds.length > 0 && (
          <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={() => setSelectedTalentIds([])}>
            Show all talents
          </Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <h2 className="text-xl font-semibold">Salary</h2>
        <p className="text-sm text-neutral">Monthly compensation includes base salary, monthly performance bonus (from performance bonus release/signing month), and monthly royalty. View or download salary slip PDF; use the left panel to filter by talent.</p>

        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="text-sm font-semibold mb-3 flex items-center gap-1"><CalendarDays className="h-4 w-4 text-primary" /> Talent-wise joining date & contract signing date</h3>
          <p className="text-2xs text-neutral mb-3">From contract start date and talent signing date (seed data).</p>
          {talentWiseDates.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2 px-3 font-semibold">Talent Name</th>
                    <th className="text-left py-2 px-3 font-semibold">Joining Date</th>
                    <th className="text-left py-2 px-3 font-semibold">Contract Signing Date</th>
                  </tr>
                </thead>
                <tbody>
                  {talentWiseDates.map((row) => (
                    <tr key={row.talentId} className="border-b border-gray-100">
                      <td className="py-2 px-3 font-medium">{row.talentName}</td>
                      <td className="py-2 px-3">{row.joiningDate ? formatDisplayDate(row.joiningDate) : '—'}</td>
                      <td className="py-2 px-3">{row.contractSigningDate ? formatDisplayDate(row.contractSigningDate) : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-neutral">No talent/contract data.</p>
          )}
        </div>

        <div className="grid gap-4 grid-cols-2 lg:grid-cols-5">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><User className="h-3.5 w-3.5" /> Records</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold">{summary.recordCount}</p>
              <p className="text-2xs text-neutral">compensation entries</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><DollarSign className="h-3.5 w-3.5" /> Total Compensation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold">{formatINRDisplay(summary.totalAmount)}</p>
              <p className="text-2xs text-neutral">salary + monthly perf. bonus + royalty</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral">Paid</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-green-700">{summary.paidCount}</p>
              <p className="text-2xs text-neutral">{formatINRDisplay(summary.paidAmount)} paid</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-amber-700">{summary.pendingCount}</p>
              <p className="text-2xs text-neutral">awaiting payment</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium text-neutral flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Period</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs font-medium">Monthly</p>
              <p className="text-2xs text-neutral">per talent</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
            <MonthlyRevenueChart
              data={salaryMonthlyData}
              title="Salary Monthly Trend"
              description="Salary by month (matches totals above)"
              currency="USD"
              valueLabel="Salary"
            />
          </div>
          <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
            {salaryDistribution.length > 0 ? (
              <RoyaltyDistributionChart data={salaryDistribution} title="Salary Distribution" description="By talent" />
            ) : (
              <div>
                <h3 className="mb-4 text-base font-medium">Salary Distribution</h3>
                <p className="text-sm text-neutral">No salary data</p>
              </div>
            )}
          </div>
        </div>

        <DataTable columns={columns} data={enrichedSalaries} searchKey="talentName" searchPlaceholder="Search by talent..." />
      </div>

      <SalarySlipPDFViewer open={!!viewingSlip} onOpenChange={(v) => !v && setViewingSlip(null)} salaryRecord={viewingSlip} businessName={businessName} />
    </div>
  )
}
