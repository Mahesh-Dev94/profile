import React, { useMemo } from 'react'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getReleaseDateFormatted, getDaysUntilRelease } from '../../utils/signingBonus'
import { getAnnualSalaryTotal } from '../../utils/salaryCalculator'
import { downloadSigningBonusCertificatePDF } from '../../utils/pdfGenerator'
import { SigningBonusPDFViewer } from '../../components/forms/SigningBonusPDFViewer'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { MonthlyRevenueStackedChart } from '../../components/charts/MonthlyRevenueStackedChart'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { DollarSign, Gift, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT } from '../../utils/salaryCalculator'

export function TalentDashboard() {
  const { user } = useAuth()
  const { loading, loadMessage } = usePageLoadAuto('Loading your dashboard...', 'Dashboard loaded')
  const talentId = user?.talentId
  const talents = getAll('talents')
  const sales = getAll('sales')
  const contracts = getAll('contracts')
  const sportsBusinesses = getAll('sportsBusinesses')

  const talent = useMemo(() => talents.find((t) => t.id === talentId), [talents, talentId])
  const salaryPayments = useMemo(() => (getAll('salaryPayments') || []).filter((s) => s.talentId === talentId), [talentId])
  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const myLedger = useMemo(() => ledger.filter((r) => r.talentId === talentId), [ledger, talentId])
  const invoices = getAll('invoices')

  const annualSalary = useMemo(() => getAnnualSalaryTotal(salaryPayments), [salaryPayments])
  // Total Royalty = total owed (from invoices); Royalty Paid = paid so far; ensure Total >= Paid
  const royaltyTotal = useMemo(
    () => (invoices || []).filter((inv) => inv.talentId === talentId).reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0),
    [invoices, talentId]
  )
  const royaltyEarnedPaid = useMemo(
    () =>
      (invoices || [])
        .filter((inv) => inv.talentId === talentId)
        .reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0),
    [invoices, talentId]
  )
  const royaltyPending = Math.max(0, royaltyTotal - royaltyEarnedPaid)
  const signingBonus = talent?.signingBonus || 0
  const signingBonusReleased = talent?.signingBonusStatus === 'released' || talent?.signingBonusStatus === 'paid'

  const releaseDate = talent ? getReleaseDateFormatted(talent.signingDate) : 'N/A'
  const daysUntil = talent ? getDaysUntilRelease(talent.signingDate) : null
  const monthlySalaryData = useMemo(() => {
    const byMonth = {}
    salaryPayments.forEach((s) => {
      const key = s.month || 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (Number(s.salaryAmount) || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [salaryPayments])
  const monthlyRoyaltyData = useMemo(() => {
    const byMonth = {}
    myLedger.forEach((r) => {
      const d = r.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (r.royaltyEarned || 0)
    })
    return Object.entries(byMonth)
      .map(([month, revenue]) => ({ month, revenue }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [myLedger])

  // Combined monthly revenue (salary + royalty) for review — revenue by month
  const monthlyRevenueCombined = useMemo(() => {
    const byMonth = {}
    salaryPayments.forEach((s) => {
      const key = s.month || 'unknown'
      if (!byMonth[key]) byMonth[key] = { month: key, salary: 0, royalty: 0 }
      byMonth[key].salary += Number(s.salaryAmount) || 0
    })
    myLedger.forEach((r) => {
      const d = r.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      if (!byMonth[key]) byMonth[key] = { month: key, salary: 0, royalty: 0 }
      byMonth[key].royalty += r.royaltyEarned || 0
    })
    return Object.values(byMonth)
      .map((row) => ({ ...row, total: row.salary + row.royalty }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12)
  }, [salaryPayments, myLedger])

  const [viewSigningBonusPdf, setViewSigningBonusPdf] = React.useState(false)

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <StatCard title="Annual Salary" value={formatINRDisplay(annualSalary)} icon={DollarSign} />
        <StatCard title="Performance Bonus" value={formatINRDisplay(signingBonus)} icon={Gift} />
        <StatCard title="Total Royalty" value={formatINRDisplay(royaltyTotal)} icon={TrendingUp} />
        <StatCard title="Royalty Earned" value={formatINRDisplay(royaltyEarnedPaid)} icon={TrendingUp} />
        <StatCard title="Royalty Pending" value={formatINRDisplay(royaltyPending)} icon={DollarSign} />
      </div>

      {talent && (
        <Card className="border-accent/40 bg-accent/5">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg text-accent">Performance Bonus</CardTitle>
            {signingBonusReleased ? (
              <div className="flex gap-2">
                <Button className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewSigningBonusPdf(true)}>
                  View Certificate PDF
                </Button>
                <Button variant="outline" className="border-accent text-accent hover:bg-accent/10" onClick={() => downloadSigningBonusCertificatePDF({ ...talent, releaseDate })}>
                  Download Certificate PDF
                </Button>
              </div>
            ) : null}
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm text-neutral">
              {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per month (monthly performance bonus). Release date: {releaseDate}.
            </p>
            {signingBonusReleased ? (
              daysUntil !== null && (
                <p className="text-lg font-semibold text-primary">
                  {daysUntil === 0 ? 'Released' : `${daysUntil} days until release`}
                </p>
              )
            ) : (
              <p className="text-sm text-amber-600">
                Your certificate and invoice will be visible here once the platform admin has generated and released your performance bonus (on or after the release date).
              </p>
            )}
          </CardContent>
        </Card>
      )}
      {talent && signingBonusReleased && (
        <SigningBonusPDFViewer
          open={viewSigningBonusPdf}
          onOpenChange={setViewSigningBonusPdf}
          talent={{ ...talent, releaseDate }}
          onDownloadPDF={(t) => downloadSigningBonusCertificatePDF(t)}
        />
      )}

      {/* Monthly Revenue Review — revenue by month (salary + royalty) */}
      <MonthlyRevenueStackedChart
        data={monthlyRevenueCombined}
        title="Monthly Revenue Review"
        description="Revenue by month: salary and royalty. Check which revenue is from salary vs royalty below."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          {monthlySalaryData.length > 0 ? (
            <MonthlyRevenueChart data={monthlySalaryData} title="Monthly Salary Trend" description="Salary by month" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Monthly Salary Trend</h3>
              <p className="text-sm text-neutral">No salary data</p>
            </>
          )}
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
          {monthlyRoyaltyData.length > 0 ? (
            <MonthlyRevenueChart data={monthlyRoyaltyData} title="Royalty Earnings by Month" description="Royalty by month" />
          ) : (
            <>
              <h3 className="mb-4 text-base font-medium">Royalty Earnings by Month</h3>
              <p className="text-sm text-neutral">No royalty data</p>
            </>
          )}
        </div>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Royalty by Product</CardTitle>
          <p className="text-xs text-neutral mt-1">Royalty earned per product</p>
        </CardHeader>
        <CardContent>
          {myLedger.length === 0 ? (
            <p className="text-sm text-neutral">No royalty data by product yet.</p>
          ) : (
            <ul className="space-y-2">
              {Object.entries(
                myLedger.reduce((acc, r) => {
                  const key = r.product || 'Other'
                  acc[key] = (acc[key] || 0) + (r.royaltyEarned || 0)
                  return acc
                }, {})
              )
                .slice(0, 8)
                .map(([name, val]) => (
                  <li key={name} className="flex justify-between text-sm">
                    <span>{name}</span>
                    <span className="font-medium">{formatINRDisplay(val)}</span>
                  </li>
                ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
