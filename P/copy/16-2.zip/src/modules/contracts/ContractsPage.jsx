import React, { useState } from 'react'
import { useOrganizationData } from '../../hooks/useOrganizationData'
import { getAllByOrganization } from '../../database/dbService'
import { useOrganization } from '../../context/OrganizationContext'
import { downloadContractPDF } from '../../utils/pdfGenerator'
import { ContractAIValidatorList } from '../../components/ContractAIValidator'
import toast from 'react-hot-toast'
import { ContractViewer } from '../../components/forms/ContractViewer'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { ContractDetailsViewer } from '../../components/forms/ContractDetailsViewer'
import { Card, CardContent } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { Plus, Pencil, Trash2, FileDown, FileText, FileSpreadsheet } from 'lucide-react'
import { Loader } from '../../components/ui/Loader'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

export function ContractsPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading: pageLoading, loadMessage } = usePageLoadAuto('Loading contracts...', 'Contracts loaded')
  const { data: contracts, loading: contractsLoading, create, update, remove } = useOrganizationData('contracts')
  const talents = getAllByOrganization('talents', currentOrganizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', currentOrganizationId)
  const sponsorshipCompanies = getAllByOrganization('sponsorshipCompanies', currentOrganizationId)
  const [editing, setEditing] = useState(null)
  const [open, setOpen] = useState(false)
  const [viewContract, setViewContract] = useState(null)
  const [viewPdfContract, setViewPdfContract] = useState(null)
  const [viewDetailsContract, setViewDetailsContract] = useState(null)
  const [form, setForm] = useState({
    contractID: '',
    talentId: '',
    licenseeId: '',
    sponsorId: '',
    basicSalary2026_27: '',
    basicSalary2027_28: '',
    signingBonus: '',
    royaltyPercent: '',
    startDate: '',
    endDate: '',
    status: 'active',
  })

  const resetForm = () => {
    setForm({
      contractID: '',
      talentId: '',
      licenseeId: '',
      sponsorId: '',
      basicSalary2026_27: '',
      basicSalary2027_28: '',
      signingBonus: '',
      royaltyPercent: '',
      startDate: '',
      endDate: '',
      status: 'active',
    })
    setEditing(null)
    setOpen(false)
  }

  const talentName = talents.find((t) => t.id === form.talentId)?.name || ''
  const licensee = sportsBusinesses.find((b) => b.id === form.licenseeId)
  const licenseeName = licensee?.businessName || ''

  const handleSubmit = (e) => {
    e.preventDefault()
    const talent = talents.find((t) => t.id === form.talentId)
    const licenseeBiz = sportsBusinesses.find((b) => b.id === form.licenseeId)
    const annualSalary = Number(form.basicSalary2026_27) || 0
    const payload = {
      contractID: form.contractID || `CNT-${Date.now()}`,
      talentId: form.talentId,
      talentName: talent?.name || '',
      licenseeId: form.licenseeId,
      licensee: licenseeBiz?.businessName || '',
      sponsorId: form.sponsorId,
      organizationId: currentOrganizationId,
      annualSalary,
      basicSalary2026_27: Number(form.basicSalary2026_27) || 0,
      basicSalary2027_28: Number(form.basicSalary2027_28) || 0,
      signingBonus: Number(form.signingBonus) || 0,
      royaltyPercent: Number(form.royaltyPercent) / 100 || 0,
      startDate: form.startDate,
      endDate: form.endDate,
      status: form.status,
    }
    if (editing) {
      update(editing.id, payload)
      toast.success('Contract updated')
    } else {
      create(payload)
      toast.success('Contract created')
    }
    resetForm()
  }

  const handleRemove = (id) => {
    remove(id)
    toast.success('Contract removed')
  }

  const openEdit = (row) => {
    setEditing(row)
    setForm({
      contractID: row.contractID || '',
      talentId: row.talentId || '',
      licenseeId: row.licenseeId || '',
      sponsorId: row.sponsorId || '',
      basicSalary2026_27: String(row.basicSalary2026_27 ?? row.annualSalary ?? ''),
      basicSalary2027_28: String(row.basicSalary2027_28 ?? row.annualSalary ?? ''),
      signingBonus: String(row.signingBonus ?? ''),
      royaltyPercent: String((row.royaltyPercent ?? 0) * 100),
      startDate: row.startDate || '',
      endDate: row.endDate || '',
      status: row.status || 'active',
    })
    setOpen(true)
  }

  const columns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'talentName', header: 'Talent Name', accessorKey: 'talentName' },
    { id: 'startDate', header: 'Contract Start', accessorKey: 'startDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'endDate', header: 'Contract End', accessorKey: 'endDate', cell: (info) => formatDisplayDate(info.getValue()) },
    { id: 'basicSalary2026_27', header: 'Basic Salary 2026-27', accessorKey: 'basicSalary2026_27', cell: (info) => info.getValue() != null ? formatINRDisplay(info.getValue()) : '—' },
    { id: 'basicSalary2027_28', header: 'Basic Salary 2027-28', accessorKey: 'basicSalary2027_28', cell: (info) => info.getValue() != null ? formatINRDisplay(info.getValue()) : '—' },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => info.getValue() != null ? `${((info.getValue()) * 100).toFixed(2)}%` : '—' },
    { id: 'signingBonus', header: 'Performance Bonus', accessorKey: 'signingBonus', cell: (info) => info.getValue() != null ? formatINRDisplay(info.getValue()) : '—' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex flex-wrap gap-2">
          <Button variant="ghost" size="icon" onClick={() => setViewContract(row.original)} title="View details"><FileText className="h-4 w-4" /></Button>
          <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewPdfContract(row.original)} title="View PDF">View PDF</Button>
          <Button variant="outline" size="sm" onClick={() => setViewDetailsContract(row.original)} title="View contract detailed info">
            <FileSpreadsheet className="h-4 w-4 mr-1" /> View contract detailed info
          </Button>
          <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}><Pencil className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={() => handleRemove(row.original.id)}><Trash2 className="h-4 w-4 text-red-600" /></Button>
        </div>
      ),
    },
  ]

  if (pageLoading) return <PageLoaderWithSkeleton message={loadMessage} />
  if (contractsLoading) return <Loader />
  return (
    <div className="space-y-6">
      <ContractAIValidatorList contracts={contracts} />
      <div className="flex justify-between">
        <h2 className="text-xl font-semibold">Contracts</h2>
        <Button onClick={() => { setEditing(null); setForm({ contractID: '', talentId: '', licenseeId: '', sponsorId: '', basicSalary2026_27: '', basicSalary2027_28: '', signingBonus: '', royaltyPercent: '', startDate: '', endDate: '', status: 'active' }); setOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" /> Create Contract
        </Button>
      </div>
      <DataTable columns={columns} data={contracts} searchKey="contractID" searchPlaceholder="Search contracts..." />

      <Dialog open={open} onOpenChange={(v) => !v && resetForm()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Contract' : 'Create Contract'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Contract ID</Label>
              <Input value={form.contractID} onChange={(e) => setForm((f) => ({ ...f, contractID: e.target.value }))} placeholder="CNT-2024-001" />
            </div>
            <div className="space-y-2">
              <Label>Talent</Label>
              <Select value={form.talentId} onValueChange={(v) => setForm((f) => ({ ...f, talentId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select talent" /></SelectTrigger>
                <SelectContent>
                  {talents.map((t) => (<SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sports Business (Club)</Label>
              <Select value={form.licenseeId} onValueChange={(v) => setForm((f) => ({ ...f, licenseeId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select sports business (club)" /></SelectTrigger>
                <SelectContent>
                  {sportsBusinesses.map((b) => (<SelectItem key={b.id} value={b.id}>{b.businessName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Sponsor</Label>
              <Select value={form.sponsorId} onValueChange={(v) => setForm((f) => ({ ...f, sponsorId: v }))}>
                <SelectTrigger><SelectValue placeholder="Select sponsor" /></SelectTrigger>
                <SelectContent>
                  {sponsorshipCompanies.map((c) => (<SelectItem key={c.id} value={c.id}>{c.companyName}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Basic Salary 2026-27 ($)</Label>
                <Input type="number" value={form.basicSalary2026_27} onChange={(e) => setForm((f) => ({ ...f, basicSalary2026_27: e.target.value }))} placeholder="e.g. 18000000" />
              </div>
              <div className="space-y-2">
                <Label>Basic Salary 2027-28 ($)</Label>
                <Input type="number" value={form.basicSalary2027_28} onChange={(e) => setForm((f) => ({ ...f, basicSalary2027_28: e.target.value }))} placeholder="e.g. 20000000" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Performance Bonus ($) — per month</Label>
              <Input type="number" value={form.signingBonus} onChange={(e) => setForm((f) => ({ ...f, signingBonus: e.target.value }))} placeholder="e.g. 10000 (monthly)" />
            </div>
            <div className="space-y-2">
              <Label>Royalty %</Label>
              <Input type="number" step="0.01" value={form.royaltyPercent} onChange={(e) => setForm((f) => ({ ...f, royaltyPercent: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input type="date" value={form.startDate} onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input type="date" value={form.endDate} onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetForm}>Cancel</Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ContractViewer
        open={!!viewContract}
        onOpenChange={(v) => !v && setViewContract(null)}
        contract={viewContract}
        onGeneratePDF={(c) => downloadContractPDF(c, c.talentName, c.licensee)}
      />
      <ContractPDFViewer
        open={!!viewPdfContract}
        onOpenChange={(v) => !v && setViewPdfContract(null)}
        contract={viewPdfContract}
        onDownloadPDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)}
      />
      <ContractDetailsViewer
        open={!!viewDetailsContract}
        onOpenChange={(v) => !v && setViewDetailsContract(null)}
        contract={viewDetailsContract}
      />
    </div>
  )
}
