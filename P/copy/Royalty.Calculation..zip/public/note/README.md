# Sports Sponsorship, Talent Royalty & Partner Sales Platform

A production-style React dashboard for managing sports sponsorship, talent royalties, and partner sales—**100% client-side** with a **local JSON/localStorage "database"** (no backend).

## Tech Stack

- **React 18** + **Vite**
- **React Router v6**
- **Context API** (Auth + App Store)
- **TailwindCSS** + **ShadCN-style (Radix)** + **Lucide Icons**
- **TanStack Table**, **Recharts**, **React Hook Form** + **Zod**
- **PapaParse** (CSV), **XLSX** (Excel), **jsPDF** + **html2canvas**
- **date-fns**, **uuid**

## Run the app

```bash
npm install
npm run dev
```

Open **http://localhost:5173**. Use the login page; **choosing a role auto-fills demo credentials**.

### Demo logins (autofill when you select role)

| Role                     | Email                    | Password   |
|--------------------------|--------------------------|------------|
| Sponsorship Platform Admin | admin@sponsorship.com  | admin123   |
| Talent User             | talent@sports.com        | talent123  |
| Partner Vendor           | partner@vendor.com       | partner123 |

## Features

### Portal 1 – Sponsorship & loyalties (admin)

- **Dashboard**: Total revenue, royalty paid, active guarantees, top talents, top sponsors; monthly revenue, royalty distribution, country sales, licensee sales.
- **Sports businesses**: CRUD (name, revenue recognized, revenue share %, minimum guarantee, talents).
- **Sponsorship companies**: CRUD (name, country, contract value, royalty rate, minimum guarantee).
- **Contracts**: Create/edit contracts (talent, licensee, sponsor, royalty %, dates, status); generate contract PDF.
- **Invoices**: List; generate monthly invoices from ledger; view and download invoice PDF; export.
- **Revenue engine**: Net sales, royalty to talent, sports business share, platform revenue; royalty ledger.
- **Export**: Royalty report CSV, contract PDFs, invoice PDFs.

### Portal 2 – Talent

- **Dashboard**: Total/monthly earnings, pending royalty, minimum guarantee, signing bonus; signing bonus countdown (release = signing + 10 working days); download signing bonus certificate PDF; monthly royalty and country revenue charts.
- **Royalties**: Table (product, licensee, units, net sales, royalty %, royalty earned) with filters (licensee, country, date range).
- **Invoices**: List and download PDFs for the logged-in talent.

### Portal 3 – Partner

- **Dashboard**: Total sales, top products/talents, country revenue; monthly revenue, country sales, royalty distribution; **revenue forecast** (next 3 months, moving average).
- **Upload sales**: CSV or Excel with columns: ID, SKU, Licensee, ProductDescription, TalentNames, Country, Currency, UnitsSold, EffectiveUnitSalesPrice, NetSales, TypeOfSales, Date. Parsed and stored locally.
- **Sales**: TanStack Table with search, sort, pagination, checkbox filters (e.g. licensee), export sales CSV.
- **Contracts**: List and generate contract PDFs.

## Data & "database"

- **Persistence**: `localStorage` key `sports_platform_db`. Seed data is applied on first load if the key is missing.
- **Collections**: `users`, `talents`, `sponsorshipCompanies`, `sportsBusinesses`, `contracts`, `sales`, `invoices`.
- **API**: `database/dbService.js` – `getAll(collection)`, `getById(collection, id)`, `create(collection, data)`, `update(collection, id, data)`, `remove(collection, id)`.

## Theme

- Primary: **#0B3C5D**
- Accent: **#F97316**
- Background: **#FFFFFF**
- Neutral: **#6B7280**

## Routes

- `/login` – Role selection + email/password (autofill for demo).
- `/sponsorship/dashboard`, `/sponsorship/businesses`, `/sponsorship/companies`, `/sponsorship/contracts`, `/sponsorship/invoices`
- `/talent/dashboard`, `/talent/royalties`, `/talent/invoices`
- `/partner/dashboard`, `/partner/upload-sales`, `/partner/sales`, `/partner/contracts`

Sidebar and top bar adapt by role; routes are protected by role.
