import React from 'react'
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useAppStore } from '../../context/AppStore'
import { Button } from '../../components/ui/button'
import {
  LayoutDashboard,
  FileText,
  Building2,
  Users,
  Receipt,
  Upload,
  BarChart3,
  LogOut,
  Menu,
  ChevronLeft,
  Gift,
} from 'lucide-react'
import { cn } from '../../utils/cn'

const sponsorshipNav = [
  { to: '/sponsorship/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sponsorship/businesses', label: 'Sports Businesses', icon: Building2 },
  { to: '/sponsorship/companies', label: 'Sponsorship Companies', icon: Users },
  { to: '/sponsorship/contracts', label: 'Contracts', icon: FileText },
  { to: '/sponsorship/invoices', label: 'Invoices', icon: Receipt },
  { to: '/sponsorship/signing-bonus', label: 'Signing Bonus', icon: Gift },
]

const talentNav = [
  { to: '/talent/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/talent/sales', label: 'Sales', icon: BarChart3 },
  { to: '/talent/royalties', label: 'Royalties', icon: Receipt },
  { to: '/talent/invoices', label: 'Invoices', icon: FileText },
  { to: '/talent/signing-bonus', label: 'Signing Bonus', icon: Gift },
]

const partnerNav = [
  { to: '/partner/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/partner/upload-sales', label: 'Upload Sales', icon: Upload },
  { to: '/partner/sales', label: 'Sales', icon: BarChart3 },
  { to: '/partner/contracts', label: 'Contracts', icon: FileText },
]

export function MainLayout() {
  const { user, logout } = useAuth()
  const { sidebarOpen, toggleSidebar } = useAppStore()
  const navigate = useNavigate()
  const location = useLocation()

  const nav =
    user?.role === 'sponsorship_admin'
      ? sponsorshipNav
      : user?.role === 'talent'
      ? talentNav
      : partnerNav

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <aside
        className={cn(
          'flex flex-col border-r border-gray-200 bg-white transition-all duration-200',
          sidebarOpen ? 'w-56' : 'w-16'
        )}
      >
        <div className="flex h-14 items-center justify-between border-b border-gray-200 px-4">
          {sidebarOpen && (
            <Link to={nav[0]?.to} className="text-lg font-bold text-primary">
              Sports Platform
            </Link>
          )}
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            {sidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-1 p-2">
          {nav.map((item) => {
            const Icon = item.icon
            const active = location.pathname === item.to
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  active ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100'
                )}
              >
                <Icon className="h-5 w-5 shrink-0" />
                {sidebarOpen && <span>{item.label}</span>}
              </Link>
            )
          })}
        </nav>
        <div className="border-t border-gray-200 p-2">
          <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
            {sidebarOpen && <span>Logout</span>}
          </Button>
        </div>
      </aside>
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 items-center justify-between border-b border-gray-200 bg-white px-6">
          <h1 className="text-lg font-semibold text-gray-900">
            {nav.find((n) => n.to === location.pathname)?.label || 'Dashboard'}
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-neutral">{user?.name || user?.email}</span>
            <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              {user?.role?.replace('_', ' ')}
            </span>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
