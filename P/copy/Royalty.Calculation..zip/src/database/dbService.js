import { seedDatabase, resetDatabase } from './seedData'

const STORAGE_KEY = 'sports_platform_db'

function getDb() {
  let db = null
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) db = JSON.parse(raw)
  } catch (_) {}
  if (!db || typeof db !== 'object') {
    db = seedDatabase()
  }
  return db
}

function saveDb(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db))
  return db
}

export function getAll(collection) {
  const db = getDb()
  const list = db[collection]
  return Array.isArray(list) ? [...list] : []
}

export function getById(collection, id) {
  const list = getAll(collection)
  return list.find((item) => item.id === id) ?? null
}

export function create(collection, data) {
  const db = getDb()
  if (!Array.isArray(db[collection])) db[collection] = []
  const id = data.id || `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
  const record = { ...data, id }
  db[collection].push(record)
  saveDb(db)
  return record
}

export function update(collection, id, data) {
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return null
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return null
  const updated = { ...list[index], ...data, id }
  list[index] = updated
  saveDb(db)
  return updated
}

export function remove(collection, id) {
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return false
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return false
  list.splice(index, 1)
  saveDb(db)
  return true
}

export function getDbRaw() {
  return getDb()
}

export function resetDb() {
  return resetDatabase()
}
