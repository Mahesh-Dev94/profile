const STORAGE_KEY = 'sports_platform_db'

const defaultUsers = [
  { id: 'u-admin-1', email: 'admin@sponsorship.com', password: 'admin123', role: 'sponsorship_admin', name: 'Platform Admin' },
  { id: 'u-talent-1', email: 'talent@sports.com', password: 'talent123', role: 'talent', name: 'Alex Rivera', talentId: 't-1' },
  { id: 'u-partner-1', email: 'partner@vendor.com', password: 'partner123', role: 'partner', name: 'Vendor Partner' },
]

const defaultTalents = [
  { id: 't-1', name: 'Alex Rivera', signingDate: '2024-01-15', signingBonus: 50000, country: 'USA', signingBonusStatus: 'released' },
  { id: 't-2', name: 'Jordan Lee', signingDate: '2024-02-20', signingBonus: 75000, country: 'UK', signingBonusStatus: 'pending' },
  { id: 't-3', name: 'Sam Williams', signingDate: '2024-03-10', signingBonus: 35000, country: 'Canada', signingBonusStatus: 'pending' },
  { id: 't-4', name: 'Morgan Taylor', signingDate: '2024-04-05', signingBonus: 60000, country: 'USA', signingBonusStatus: 'pending' },
  { id: 't-5', name: 'Casey Kim', signingDate: '2024-05-12', signingBonus: 42000, country: 'Australia', signingBonusStatus: 'pending' },
]

const defaultSponsorshipCompanies = [
  { id: 'sc-1', companyName: 'SportGear Inc', country: 'USA', contractValue: 500000, royaltyRate: 0.08, minimumGuarantee: 40000 },
  { id: 'sc-2', companyName: 'Global Athletics', country: 'UK', contractValue: 350000, royaltyRate: 0.06, minimumGuarantee: 25000 },
  { id: 'sc-3', companyName: 'Peak Performance', country: 'Germany', contractValue: 280000, royaltyRate: 0.07, minimumGuarantee: 22000 },
  { id: 'sc-4', companyName: 'Apex Sports', country: 'USA', contractValue: 420000, royaltyRate: 0.065, minimumGuarantee: 30000 },
  { id: 'sc-5', companyName: 'Velocity Brands', country: 'Canada', contractValue: 190000, royaltyRate: 0.05, minimumGuarantee: 15000 },
]

const defaultSportsBusinesses = [
  { id: 'sb-1', businessName: 'Elite Sports LLC', revenueRecognized: 120000, revenueSharePercent: 0.15, minimumGuarantee: 20000, talentsAssociated: ['t-1', 't-2'] },
  { id: 'sb-2', businessName: 'Pro Athletes Co', revenueRecognized: 85000, revenueSharePercent: 0.12, minimumGuarantee: 15000, talentsAssociated: ['t-1', 't-3'] },
  { id: 'sb-3', businessName: 'Champion Sports Group', revenueRecognized: 95000, revenueSharePercent: 0.14, minimumGuarantee: 18000, talentsAssociated: ['t-2', 't-4'] },
  { id: 'sb-4', businessName: 'Prime Athletics', revenueRecognized: 72000, revenueSharePercent: 0.11, minimumGuarantee: 12000, talentsAssociated: ['t-3', 't-5'] },
  { id: 'sb-5', businessName: 'Summit Sports Inc', revenueRecognized: 110000, revenueSharePercent: 0.13, minimumGuarantee: 22000, talentsAssociated: ['t-1', 't-4', 't-5'] },
]

const defaultContracts = [
  { id: 'c-1', contractID: 'CNT-2024-001', talentId: 't-1', talentName: 'Alex Rivera', licenseeId: 'sb-1', licensee: 'Elite Sports LLC', sponsorId: 'sc-1', royaltyPercent: 0.08, minimumGuarantee: 40000, startDate: '2024-01-01', endDate: '2025-12-31', status: 'active' },
  { id: 'c-2', contractID: 'CNT-2024-002', talentId: 't-2', talentName: 'Jordan Lee', licenseeId: 'sb-1', licensee: 'Elite Sports LLC', sponsorId: 'sc-2', royaltyPercent: 0.06, minimumGuarantee: 25000, startDate: '2024-02-01', endDate: '2025-01-31', status: 'active' },
  { id: 'c-3', contractID: 'CNT-2024-003', talentId: 't-3', talentName: 'Sam Williams', licenseeId: 'sb-2', licensee: 'Pro Athletes Co', sponsorId: 'sc-1', royaltyPercent: 0.07, minimumGuarantee: 18000, startDate: '2024-03-01', endDate: '2025-02-28', status: 'active' },
  { id: 'c-4', contractID: 'CNT-2024-004', talentId: 't-4', talentName: 'Morgan Taylor', licenseeId: 'sb-3', licensee: 'Champion Sports Group', sponsorId: 'sc-4', royaltyPercent: 0.065, minimumGuarantee: 28000, startDate: '2024-04-15', endDate: '2025-04-14', status: 'active' },
  { id: 'c-5', contractID: 'CNT-2024-005', talentId: 't-5', talentName: 'Casey Kim', licenseeId: 'sb-4', licensee: 'Prime Athletics', sponsorId: 'sc-5', royaltyPercent: 0.05, minimumGuarantee: 12000, startDate: '2024-05-01', endDate: '2025-04-30', status: 'active' },
]

const defaultSales = [
  { id: 's-1', sku: 'SKU-001', licensee: 'Elite Sports LLC', productDescription: 'Jersey Line A', talentNames: 'Alex Rivera', talentIds: ['t-1'], country: 'USA', currency: 'USD', unitsSold: 1000, effectiveUnitSalesPrice: 45, netSales: 45000, typeOfSales: 'retail', date: '2024-10-15' },
  { id: 's-2', sku: 'SKU-002', licensee: 'Elite Sports LLC', productDescription: 'Jersey Line B', talentNames: 'Jordan Lee', talentIds: ['t-2'], country: 'UK', currency: 'GBP', unitsSold: 500, effectiveUnitSalesPrice: 38, netSales: 19000, typeOfSales: 'wholesale', date: '2024-10-20' },
  { id: 's-3', sku: 'SKU-003', licensee: 'Pro Athletes Co', productDescription: 'Equipment Pack', talentNames: 'Alex Rivera', talentIds: ['t-1'], country: 'USA', currency: 'USD', unitsSold: 800, effectiveUnitSalesPrice: 120, netSales: 96000, typeOfSales: 'retail', date: '2024-10-25' },
  { id: 's-4', sku: 'SKU-004', licensee: 'Elite Sports LLC', productDescription: 'Accessories', talentNames: 'Sam Williams', talentIds: ['t-3'], country: 'Canada', currency: 'CAD', unitsSold: 1200, effectiveUnitSalesPrice: 25, netSales: 30000, typeOfSales: 'retail', date: '2024-11-01' },
  { id: 's-5', sku: 'SKU-005', licensee: 'Champion Sports Group', productDescription: 'Training Kit Pro', talentNames: 'Morgan Taylor', talentIds: ['t-4'], country: 'USA', currency: 'USD', unitsSold: 350, effectiveUnitSalesPrice: 89, netSales: 31150, typeOfSales: 'retail', date: '2024-11-10' },
]

const defaultInvoices = [
  { id: 'inv-1', invoiceID: 'INV-2024-001', sponsorCompany: 'SportGear Inc', sportsBusiness: 'Elite Sports LLC', talentName: 'Alex Rivera', talentId: 't-1', royaltyAmount: 3600, minimumGuarantee: 3333, netSales: 45000, date: '2024-10-31', period: 'monthly', status: 'paid' },
  { id: 'inv-2', invoiceID: 'INV-2024-002', sponsorCompany: 'Global Athletics', sportsBusiness: 'Elite Sports LLC', talentName: 'Jordan Lee', talentId: 't-2', royaltyAmount: 1140, minimumGuarantee: 2083, netSales: 19000, date: '2024-10-31', period: 'monthly', status: 'pending' },
  { id: 'inv-3', invoiceID: 'INV-2024-003', sponsorCompany: 'SportGear Inc', sportsBusiness: 'Pro Athletes Co', talentName: 'Sam Williams', talentId: 't-3', royaltyAmount: 6720, minimumGuarantee: 1500, netSales: 96000, date: '2024-10-31', period: 'monthly', status: 'paid' },
  { id: 'inv-4', invoiceID: 'INV-2024-004', sponsorCompany: 'Apex Sports', sportsBusiness: 'Champion Sports Group', talentName: 'Morgan Taylor', talentId: 't-4', royaltyAmount: 2025, minimumGuarantee: 2333, netSales: 31150, date: '2024-11-30', period: 'monthly', status: 'pending' },
  { id: 'inv-5', invoiceID: 'INV-2024-005', sponsorCompany: 'Velocity Brands', sportsBusiness: 'Prime Athletics', talentName: 'Casey Kim', talentId: 't-5', royaltyAmount: 850, minimumGuarantee: 1000, netSales: 17000, date: '2024-11-30', period: 'monthly', status: 'pending' },
]

export function getSeedData() {
  return {
    users: defaultUsers,
    talents: defaultTalents,
    sponsorshipCompanies: defaultSponsorshipCompanies,
    sportsBusinesses: defaultSportsBusinesses,
    contracts: defaultContracts,
    sales: defaultSales,
    invoices: defaultInvoices,
  }
}

export function seedDatabase() {
  const existing = localStorage.getItem(STORAGE_KEY)
  if (existing) return JSON.parse(existing)
  const data = getSeedData()
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  return data
}

export function resetDatabase() {
  localStorage.removeItem(STORAGE_KEY)
  return seedDatabase()
}

export { STORAGE_KEY }
