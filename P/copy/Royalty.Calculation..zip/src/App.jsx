import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import { AuthLayout } from './app/layouts/AuthLayout'
import { MainLayout } from './app/layouts/MainLayout'
import { ProtectedRoute } from './app/routes/ProtectedRoute'
import { LoginPage } from './modules/auth/LoginPage'
import { SponsorshipDashboard } from './modules/sponsorship/SponsorshipDashboard'
import { SportsBusinessesPage } from './modules/sponsorship/SportsBusinessesPage'
import { SponsorshipCompaniesPage } from './modules/sponsorship/SponsorshipCompaniesPage'
import { ContractsPage } from './modules/contracts/ContractsPage'
import { InvoicesPage } from './modules/invoices/InvoicesPage'
import { SigningBonusPage } from './modules/sponsorship/SigningBonusPage'
import { TalentDashboard } from './modules/talent/TalentDashboard'
import { TalentRoyaltiesPage } from './modules/talent/TalentRoyaltiesPage'
import { TalentInvoicesPage } from './modules/talent/TalentInvoicesPage'
import { TalentSalesPage } from './modules/talent/TalentSalesPage'
import { TalentSigningBonusPage } from './modules/talent/TalentSigningBonusPage'
import { PartnerDashboard } from './modules/partner/PartnerDashboard'
import { PartnerUploadSalesPage } from './modules/partner/PartnerUploadSalesPage'
import { PartnerSalesPage } from './modules/partner/PartnerSalesPage'
import { PartnerContractsPage } from './modules/partner/PartnerContractsPage'

export default function App() {
  const { user } = useAuth()

  return (
    <Routes>
      <Route path="/login" element={
        user ? (
          <Navigate to={
            user.role === 'sponsorship_admin' ? '/sponsorship/dashboard' :
            user.role === 'talent' ? '/talent/dashboard' : '/partner/dashboard'
          } replace />
        ) : (
          <AuthLayout />
        )
      }>
        <Route index element={<LoginPage />} />
      </Route>
      <Route path="/sponsorship" element={
        <ProtectedRoute allowedRoles={['sponsorship_admin']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<SponsorshipDashboard />} />
        <Route path="businesses" element={<SportsBusinessesPage />} />
        <Route path="companies" element={<SponsorshipCompaniesPage />} />
        <Route path="contracts" element={<ContractsPage />} />
        <Route path="invoices" element={<InvoicesPage />} />
        <Route path="signing-bonus" element={<SigningBonusPage />} />
      </Route>
      <Route path="/talent" element={
        <ProtectedRoute allowedRoles={['talent']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<TalentDashboard />} />
        <Route path="sales" element={<TalentSalesPage />} />
        <Route path="royalties" element={<TalentRoyaltiesPage />} />
        <Route path="invoices" element={<TalentInvoicesPage />} />
        <Route path="signing-bonus" element={<TalentSigningBonusPage />} />
      </Route>
      <Route path="/partner" element={
        <ProtectedRoute allowedRoles={['partner']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<PartnerDashboard />} />
        <Route path="upload-sales" element={<PartnerUploadSalesPage />} />
        <Route path="sales" element={<PartnerSalesPage />} />
        <Route path="contracts" element={<PartnerContractsPage />} />
      </Route>
      <Route path="/" element={
        <Navigate to={
          user
            ? user.role === 'sponsorship_admin'
              ? '/sponsorship/dashboard'
              : user.role === 'talent'
              ? '/talent/dashboard'
              : '/partner/dashboard'
            : '/login'
        } replace />
      } />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
