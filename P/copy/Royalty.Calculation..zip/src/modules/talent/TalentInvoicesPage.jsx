import React from 'react'
import { useAuth } from '../../context/AuthContext'
import { useDatabase } from '../../hooks/useDatabase'
import { downloadInvoicePDF } from '../../utils/pdfGenerator'
import { InvoiceViewer } from '../../components/forms/InvoiceViewer'
import { Button } from '../../components/ui/button'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { FileDown } from 'lucide-react'
import { format } from 'date-fns'

export function TalentInvoicesPage() {
  const { user } = useAuth()
  const { data: allInvoices } = useDatabase('invoices')
  const invoices = allInvoices.filter((inv) => inv.talentId === user?.talentId)
  const [selected, setSelected] = React.useState(null)

  const columns = [
    { id: 'invoiceID', header: 'Invoice ID', accessorKey: 'invoiceID' },
    { id: 'month', header: 'Month', accessorFn: (row) => row.date ? format(new Date(row.date), 'MMM yyyy') : '—', cell: (info) => info.getValue() },
    { id: 'sponsorCompany', header: 'Sponsor', accessorKey: 'sponsorCompany' },
    { id: 'royaltyAmount', header: 'Royalty', accessorKey: 'royaltyAmount', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'minimumGuarantee', header: 'Min. Guarantee', accessorKey: 'minimumGuarantee', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'netSales', header: 'Net Sales', accessorKey: 'netSales', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'date', header: 'Date', accessorKey: 'date' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'paid' ? 'success' : 'warning'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setSelected(row.original)}>View PDF</Button>
          <Button variant="outline" size="sm" onClick={() => downloadInvoicePDF(row.original)}><FileDown className="h-4 w-4" /></Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">My Invoices</h2>
      <DataTable columns={columns} data={invoices} searchKey="invoiceID" searchPlaceholder="Search invoices..." />
      <InvoiceViewer open={!!selected} onOpenChange={(v) => !v && setSelected(null)} invoice={selected} onDownloadPDF={downloadInvoicePDF} />
    </div>
  )
}
