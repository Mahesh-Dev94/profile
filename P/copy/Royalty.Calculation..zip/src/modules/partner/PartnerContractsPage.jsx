import React, { useState } from 'react'
import { getAll } from '../../database/dbService'
import { downloadContractPDF } from '../../utils/pdfGenerator'
import { ContractPDFViewer } from '../../components/forms/ContractPDFViewer'
import { DataTable } from '../../components/tables/DataTable'
import { Badge } from '../../components/ui/badge'
import { Button } from '../../components/ui/button'
import { FileDown } from 'lucide-react'

export function PartnerContractsPage() {
  const contracts = getAll('contracts')
  const [viewPdfContract, setViewPdfContract] = useState(null)

  const columns = [
    { id: 'contractID', header: 'Contract ID', accessorKey: 'contractID' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'licensee', header: 'Licensee', accessorKey: 'licensee' },
    { id: 'royaltyPercent', header: 'Royalty %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue()) * 100).toFixed(2)}%` },
    { id: 'minimumGuarantee', header: 'Min. Guarantee', accessorKey: 'minimumGuarantee', cell: (info) => `$${Number(info.getValue()).toLocaleString()}` },
    { id: 'startDate', header: 'Start', accessorKey: 'startDate' },
    { id: 'endDate', header: 'End', accessorKey: 'endDate' },
    { id: 'status', header: 'Status', accessorKey: 'status', cell: (info) => <Badge variant={info.getValue() === 'active' ? 'success' : 'secondary'}>{info.getValue()}</Badge> },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <Button size="sm" className="bg-primary text-white hover:bg-primary/90" onClick={() => setViewPdfContract(row.original)}>
          <FileDown className="mr-1 h-4 w-4" /> View PDF
        </Button>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Contracts</h2>
      <DataTable columns={columns} data={contracts} searchKey="contractID" searchPlaceholder="Search contracts..." />
      <ContractPDFViewer
        open={!!viewPdfContract}
        onOpenChange={(v) => !v && setViewPdfContract(null)}
        contract={viewPdfContract}
        onDownloadPDF={(c) => downloadContractPDF(c, c?.talentName, c?.licensee)}
      />
    </div>
  )
}
