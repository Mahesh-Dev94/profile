import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useAuth } from '../../context/AuthContext'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'

const roles = [
  { value: 'sponsorship_admin', label: 'Sponsorship Platform Admin' },
  { value: 'talent', label: 'Talent User' },
  { value: 'partner', label: 'Partner Vendor' },
]

const demoCredentials = {
  sponsorship_admin: { email: 'admin@sponsorship.com', password: 'admin123' },
  talent: { email: 'talent@sports.com', password: 'talent123' },
  partner: { email: 'partner@vendor.com', password: 'partner123' },
}

const schema = z.object({
  role: z.enum(['sponsorship_admin', 'talent', 'partner']),
  email: z.string().email('Invalid email'),
  password: z.string().min(1, 'Password required'),
})

export function LoginPage() {
  const navigate = useNavigate()
  const { login } = useAuth()
  const {
    register,
    setValue,
    watch,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: { role: '', email: '', password: '' },
    resolver: zodResolver(schema),
  })

  const selectedRole = watch('role')

  React.useEffect(() => {
    if (selectedRole && demoCredentials[selectedRole]) {
      setValue('email', demoCredentials[selectedRole].email)
      setValue('password', demoCredentials[selectedRole].password)
    }
  }, [selectedRole, setValue])

  const onSubmit = (data) => {
    const result = login(data.email, data.password, data.role)
    if (result.success) {
      if (data.role === 'sponsorship_admin') navigate('/sponsorship/dashboard')
      else if (data.role === 'talent') navigate('/talent/dashboard')
      else navigate('/partner/dashboard')
    } else {
      alert(result.error || 'Login failed')
    }
  }

  return (
    <Card className="border border-gray-200 bg-white shadow-lg">
      <CardHeader className="space-y-1 text-center p-5">
        <CardTitle className="text-lg font-bold text-primary">Sports Platform</CardTitle>
        <p className="text-xs text-neutral">Sign in to your account</p>
      </CardHeader>
      <CardContent className="p-5 pt-0">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs">Role</Label>
            <Select
              value={watch('role') || undefined}
              onValueChange={(v) => setValue('role', v)}
            >
              <SelectTrigger className="text-sm h-8">
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                {roles.map((r) => (
                  <SelectItem key={r.value} value={r.value} className="text-sm">
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-2xs text-neutral">Choosing a role auto-fills demo credentials</p>
          </div>
          <div className="space-y-1">
            <Label htmlFor="email" className="text-xs">Email</Label>
            <Input
              id="email"
              type="email"
              className="text-sm h-8"
              placeholder="you@example.com"
              {...register('email')}
            />
            {errors.email && (
              <p className="text-2xs text-red-600">{errors.email.message}</p>
            )}
          </div>
          <div className="space-y-1">
            <Label htmlFor="password" className="text-xs">Password</Label>
            <Input
              id="password"
              type="password"
              className="text-sm h-8"
              placeholder="••••••••"
              {...register('password')}
            />
            {errors.password && (
              <p className="text-2xs text-red-600">{errors.password.message}</p>
            )}
          </div>
          <Button type="submit" className="w-full text-sm h-9" disabled={isSubmitting}>
            Sign in
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
