import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { AppStoreProvider } from './context/AppStore'
import { seedDatabase } from './database/seedData'
import App from './App'
import './index.css'

// Initialize local DB from seed if empty
seedDatabase()

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <AppStoreProvider>
          <App />
        </AppStoreProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
