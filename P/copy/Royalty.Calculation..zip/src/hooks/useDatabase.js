import { useState, useEffect, useCallback } from 'react'
import * as db from '../database/dbService'

const COLLECTIONS = [
  'users',
  'talents',
  'sponsorshipCompanies',
  'sportsBusinesses',
  'contracts',
  'sales',
  'invoices',
]

export function useDatabase(collection) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(() => {
    if (!COLLECTIONS.includes(collection)) {
      setData([])
      setLoading(false)
      return
    }
    setLoading(true)
    setData(db.getAll(collection))
    setLoading(false)
  }, [collection])

  useEffect(() => {
    refresh()
  }, [refresh])

  const create = useCallback(
    (item) => {
      const created = db.create(collection, item)
      refresh()
      return created
    },
    [collection, refresh]
  )

  const update = useCallback(
    (id, item) => {
      const updated = db.update(collection, id, item)
      refresh()
      return updated
    },
    [collection, refresh]
  )

  const remove = useCallback(
    (id) => {
      const ok = db.remove(collection, id)
      refresh()
      return ok
    },
    [collection, refresh]
  )

  const getById = useCallback(
    (id) => db.getById(collection, id),
    [collection]
  )

  return { data, loading, refresh, create, update, remove, getById }
}
