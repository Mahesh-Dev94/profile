import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentRosterYearTotals } from '../../repositories/sportsBusinessRepository'
import { resolveDefaultPaymentReportYear } from '../../utils/paymentSummaryYears'
import { useSportsBusinessFinanceViewModel } from '../../hooks/useSportsBusinessFinanceViewModel'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import {
  getAnnualSalaryByTalentFromContracts,
  getPayrollPerformanceBonusByTalentName,
} from '../../utils/salaryCalculator'
import { StatCard } from '../../components/cards/StatCard'
import { PaymentBucketsPieChart } from '../../components/charts/PaymentBucketsPieChart'
import { TopTalentHorizontalBarChart } from '../../components/charts/TopTalentHorizontalBarChart'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Card, CardContent } from '../../components/ui/card'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import {
  DollarSign,
  TrendingUp,
  Download,
  Gift,
  Search,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Users,
  FileText,
  Wallet,
  ArrowRight,
} from 'lucide-react'
import { format } from 'date-fns'
import Papa from 'papaparse'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { MONTHLY_PERFORMANCE_BONUS_AMOUNT } from '../../utils/salaryCalculator'
import { cn } from '../../utils/cn'
import { getTalentEmployeeIdDisplay, talentMatchesSearch } from '../../utils/talentEmployeeId'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'

const TALENT_CARDS_PAGE_SIZE = 6

function paymentsDetailHref(tab) {
  const q = new URLSearchParams({ tab, from: 'dashboard' })
  return `/sponsorship/payments?${q.toString()}`
}

function talentInitials(name) {
  if (!name || typeof name !== 'string') return '?'
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

function PaymentTypeDashboardCard({
  title,
  icon: Icon,
  payableRowLabel,
  paidRowLabel,
  outstandingRowLabel,
  payable,
  paid,
  outstanding,
  isSelected,
  onSelect,
  onViewMore,
}) {
  return (
    <Card
      className={cn(
        'flex cursor-pointer overflow-hidden rounded-xl border border-primary/15 bg-white shadow-md transition-all duration-200',
        'hover:border-accent/40 hover:shadow-lg hover:shadow-accent/5',
        isSelected && 'ring-2 ring-accent ring-offset-2 ring-offset-[#f3f7fb]'
      )}
      onClick={onSelect}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          onSelect()
        }
      }}
    >
      <div
        className="w-1.5 shrink-0 bg-gradient-to-b from-accent-300 via-accent-500 to-accent-700 sm:w-2"
        aria-hidden
      />
      <CardContent className="relative min-h-[240px] flex-1 space-y-3 bg-gradient-to-r from-accent/[0.04] to-white p-4 pb-14 sm:min-h-[230px] sm:p-5 sm:pb-14">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 pr-2">
            <p className="text-2xs font-bold uppercase tracking-wide text-primary-900">{title}</p>
            <p className="mt-1 text-2xs text-primary-700/75">Tap card to show charts below</p>
          </div>
          {Icon && (
            <div className="rounded-lg border border-accent/35 bg-accent/12 p-2 shadow-sm">
              <Icon className="h-4 w-4 text-accent-700" />
            </div>
          )}
        </div>
        <div className="space-y-0 divide-y divide-primary/10 rounded-md border border-primary/12 bg-white/95 px-3 py-0.5 shadow-inner">
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{payableRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-primary-900">{formatINRDisplay(payable)}</span>
          </div>
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{paidRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-primary-600">{formatINRDisplay(paid)}</span>
          </div>
          <div className="flex w-full flex-wrap items-baseline justify-between gap-x-2 gap-y-1 py-2.5 text-xs sm:text-sm">
            <span className="min-w-0 text-primary-800/90">{outstandingRowLabel}:</span>
            <span className="shrink-0 text-right font-bold tabular-nums text-accent-700">{formatINRDisplay(outstanding)}</span>
          </div>
        </div>
        <div className="pointer-events-none absolute bottom-3 right-3 flex justify-end">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="pointer-events-auto h-8 border-accent/40 text-2xs font-semibold text-accent-800 hover:bg-accent/12"
            onClick={(e) => {
              e.stopPropagation()
              onViewMore()
            }}
          >
            View more <ArrowRight className="ml-1 h-3.5 w-3.5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export function ClubDashboardPage() {
  const navigate = useNavigate()
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const { metrics: dashboardMetrics, revenueRollup } = useSportsBusinessFinanceViewModel()
  const { loading, loadMessage } = usePageLoadAuto('Calculating dashboard analytics...', 'Dashboard loaded')
  const [talentSearch, setTalentSearch] = useState('')
  const [talentPage, setTalentPage] = useState(0)
  const [paymentSummaryExpandedId, setPaymentSummaryExpandedId] = useState(null)
  const [talentsInformationOpen, setTalentsInformationOpen] = useState(true)
  const [paymentSummaryDistributionOpen, setPaymentSummaryDistributionOpen] = useState(true)
  /** Payment summary tab: which category drives the charts below (default salary). */
  const [paymentCategoryFocus, setPaymentCategoryFocus] = useState('salary')

  const sales = useMemo(
    () => getAllByOrganization('sales', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const salaryPayments = useMemo(
    () => getAllByOrganization('salaryPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const signingBonuses = useMemo(
    () => getAllByOrganization('signingBonuses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const miscellaneousPayments = useMemo(
    () => getAllByOrganization('miscellaneousPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const reportYear = useMemo(
    () => resolveDefaultPaymentReportYear(currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const ledger = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )

  const royaltyTotal = useMemo(() => ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledger])

  const performanceBonusByTalent = useMemo(
    () => getPayrollPerformanceBonusByTalentName(salaryPayments),
    [salaryPayments]
  )
  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledger), [ledger])
  const salaryDistribution = useMemo(() => getAnnualSalaryByTalentFromContracts(contracts), [contracts])
  const miscDistributionByTalent = useMemo(() => {
    const m = {}
    for (const r of miscellaneousPayments || []) {
      const name = r.talentName || '—'
      m[name] = (m[name] || 0) + (Number(r.amount) || 0)
    }
    return Object.entries(m)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
  }, [miscellaneousPayments])

  const contractHighlights = useMemo(() => (revenueRollup?.byContract || []).slice(0, 4), [revenueRollup])

  const filteredTalentsForCards = useMemo(() => {
    const list = [...(talents || [])]
    const q = (talentSearch || '').toLowerCase().trim()
    if (q) return list.filter((t) => talentMatchesSearch(t, q))
    return list
  }, [talents, talentSearch])

  const paginatedTalents = useMemo(() => {
    const start = talentPage * TALENT_CARDS_PAGE_SIZE
    return filteredTalentsForCards.slice(start, start + TALENT_CARDS_PAGE_SIZE)
  }, [filteredTalentsForCards, talentPage])

  const talentCardsTotalPages = Math.ceil(filteredTalentsForCards.length / TALENT_CARDS_PAGE_SIZE) || 1

  const exportReport = () => {
    const salaryRows = (salaryPayments || []).map((s) => ({
      Type: 'Salary',
      Talent: s.talentName,
      Period: s.month,
      Amount: s.salaryAmount,
      Status: s.paymentStatus,
    }))
    const bonusRows = (signingBonuses || []).map((b) => ({
      Type: 'Performance Bonus',
      Talent: b.talentName,
      Amount: b.amount,
      SigningDate: b.signingDate,
      ReleaseDate: b.releaseDate,
      Status: b.status,
    }))
    const royaltyRows = ledger.map((r) => ({
      Type: 'Revenue share',
      Product: r.product,
      Licensee: r.licensee,
      Talent: r.talentName,
      RevenueShareEarned: r.royaltyEarned,
      Date: r.date,
    }))
    const all = [...salaryRows, ...bonusRows, ...royaltyRows]
    const csv = Papa.unparse(all)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = `report-salary-bonus-revenue-share-${format(new Date(), 'yyyy-MM-dd')}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  const clubName = (sportsBusinesses && sportsBusinesses[0]?.businessName) || 'this club'

  const salaryM = dashboardMetrics?.salary ?? { payable: 0, paid: 0, outstanding: 0 }
  const bonusM = dashboardMetrics?.bonus ?? { payable: 0, paid: 0, outstanding: 0 }
  const revM = dashboardMetrics?.revenueShare ?? { payable: 0, paid: 0, outstanding: 0 }
  const miscM = dashboardMetrics?.miscellaneous ?? { payable: 0, paid: 0, outstanding: 0 }

  const focusPie = useMemo(() => {
    switch (paymentCategoryFocus) {
      case 'bonus':
        return {
          payable: bonusM.payable,
          paid: bonusM.paid,
          outstanding: bonusM.outstanding,
          payableLabel: 'Total payable bonus',
          paidLabel: 'Total paid bonus',
          outstandingLabel: 'Total outstanding bonus',
          pieTitle: 'Bonus — payable, paid & outstanding',
          pieDescription: 'Share of bonus pool by payment status.',
          distTitle: 'Top bonus by talent',
          distDescription: 'Largest 10 from payroll; remaining grouped as Others.',
          distData: performanceBonusByTalent,
          barUniformColor: '#0B3C5D',
        }
      case 'revenue-share':
        return {
          payable: revM.payable,
          paid: revM.paid,
          outstanding: revM.outstanding,
          payableLabel: 'Total payable revenue share',
          paidLabel: 'Total paid revenue share',
          outstandingLabel: 'Total outstanding revenue share',
          pieTitle: 'Revenue share — payable, paid & outstanding',
          pieDescription: 'Ledger and invoice positions by status.',
          distTitle: 'Top revenue share by talent',
          distDescription: 'Largest 10 from the central ledger; Others combines the rest.',
          distData: royaltyByTalent,
          barUniformColor: '#09304a',
        }
      case 'miscellaneous':
        return {
          payable: miscM.payable,
          paid: miscM.paid,
          outstanding: miscM.outstanding,
          payableLabel: 'Total payable miscellaneous',
          paidLabel: 'Total paid miscellaneous',
          outstandingLabel: 'Total outstanding miscellaneous',
          pieTitle: 'Miscellaneous — payable, paid & outstanding',
          pieDescription: 'Other line items by status.',
          distTitle: 'Top miscellaneous by talent',
          distDescription: 'Largest 10 from the misc register; Others combines the rest.',
          distData: miscDistributionByTalent,
          barUniformColor: '#072438',
        }
      default:
        return {
          payable: salaryM.payable,
          paid: salaryM.paid,
          outstanding: salaryM.outstanding,
          payableLabel: 'Total payable salary',
          paidLabel: 'Total paid salary',
          outstandingLabel: 'Total outstanding salary',
          pieTitle: 'Salary — payable, paid & outstanding',
          pieDescription: 'Contract salary pool by payment status.',
          distTitle: 'Top contract salary by talent',
          distDescription: 'Largest 10 annual contract values; Others groups remaining talents.',
          distData: salaryDistribution,
          barUniformColor: '#0B3C5D',
        }
    }
  }, [
    paymentCategoryFocus,
    salaryM,
    bonusM,
    revM,
    miscM,
    performanceBonusByTalent,
    royaltyByTalent,
    miscDistributionByTalent,
    salaryDistribution,
  ])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="space-y-6">
      <Tabs defaultValue="summary" className="w-full space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
          <TabsList className="grid h-auto min-h-11 w-full grid-cols-2 gap-1.5 p-1.5 sm:max-w-md">
            <TabsTrigger
              value="summary"
              className="gap-2 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-sm data-[state=active]:ring-1 data-[state=active]:ring-primary/35"
            >
              <TrendingUp className="h-4 w-4 shrink-0 opacity-90" aria-hidden />
              Payment summary
            </TabsTrigger>
            <TabsTrigger
              value="talents"
              className="gap-2 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-sm data-[state=active]:ring-1 data-[state=active]:ring-primary/35"
            >
              <Users className="h-4 w-4 shrink-0 opacity-90" aria-hidden />
              Talent summary
            </TabsTrigger>
          </TabsList>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 border-primary/25 text-primary hover:bg-primary/10 hover:border-primary/40 hover:text-primary-700"
            onClick={exportReport}
          >
            <Download className="mr-2 h-4 w-4" /> Export CSV
          </Button>
        </div>

        <TabsContent value="talents" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <StatCard
          accentIcon
          className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
          title="Total talents"
          value={String(dashboardMetrics?.talentCount ?? (talents || []).length)}
          icon={Users}
        />
        <StatCard
          accentIcon
          className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
          title="Active contracts"
          value={String(dashboardMetrics?.activeContracts ?? 0)}
          icon={FileText}
        />
        <StatCard
          accentIcon
          className="border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.06] to-white shadow-sm"
          title="Revenue distribution (ledger)"
          value={formatINRDisplay(royaltyTotal)}
          icon={TrendingUp}
          subtitle="Central sales → contract %"
          onClick={() => navigate(paymentsDetailHref('revenue-share'))}
        />
      </div>

      {contractHighlights.length > 0 && (
        <Card className="mb-4 border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.05] to-white shadow-md">
          <CardContent className="p-4 sm:p-5">
            <p className="text-xs font-bold text-primary-900">Contract highlights</p>
            <p className="mt-1 text-2xs text-slate-600">Top revenue-share outcomes by agreement (from processed sales).</p>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {contractHighlights.map((c) => (
                <li
                  key={`${c.talentId}-${c.contractID || c.contractId || 'x'}`}
                  className="flex items-center justify-between rounded-lg border border-slate-200/80 bg-slate-50/60 px-3 py-2 text-2xs"
                >
                  <span className="min-w-0 truncate font-medium text-primary-900">
                    {c.contractID || c.contractId} · {c.talentName}
                  </span>
                  <span className="shrink-0 font-mono font-semibold text-accent-700">{formatINRDisplay(c.royaltyEarned)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* All Talent Information — roster with expandable payment summary per talent */}
      <Card className="overflow-hidden rounded-lg border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.04] to-white shadow-md">
        <button
          type="button"
          className={cn('expand-trigger', talentsInformationOpen && 'expand-trigger--open')}
          onClick={() => setTalentsInformationOpen((v) => !v)}
          aria-expanded={talentsInformationOpen}
          aria-controls="dashboard-talents-information-panel"
          id="dashboard-talents-information-trigger"
        >
          <div className="flex min-w-0 flex-1 items-start gap-3 sm:gap-4">
            <div className="mt-0.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10 sm:h-12 sm:w-12">
              <Users className="h-5 w-5 sm:h-6 sm:w-6" aria-hidden />
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-bold tracking-tight text-primary-900">Talent roster &amp; payouts</p>
                <span className="rounded-md bg-primary/10 px-2 py-0.5 text-2xs font-semibold tabular-nums text-primary-800 ring-1 ring-primary/12">
                  {filteredTalentsForCards.length} {filteredTalentsForCards.length === 1 ? 'talent' : 'talents'}
                </span>
              </div>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600">
                Totals for {reportYear} (same as Payment summary) · tap a row for salary, bonus &amp; revenue share
              </p>
            </div>
          </div>
          <span className="expand-chevron-wrap" aria-hidden>
            {talentsInformationOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </span>
        </button>
        {talentsInformationOpen ? (
          <CardContent id="dashboard-talents-information-panel" className="space-y-0 border-t border-slate-200/90 p-0" role="region" aria-labelledby="dashboard-talents-information-trigger">
           
            <div className="divide-y divide-slate-200/80 bg-slate-50/40">
              {paginatedTalents.map((talent, rowIdx) => {
                const totals = getTalentRosterYearTotals(talent.id, currentOrganizationId, reportYear)
                const psOpen = paymentSummaryExpandedId === talent.id
                return (
                  <div
                    key={talent.id}
                    className={cn(
                      'w-full transition-colors duration-200',
                      psOpen
                        ? 'bg-primary/[0.04]'
                        : rowIdx % 2 === 1
                          ? 'bg-white hover:bg-slate-50/90'
                          : 'bg-slate-50/30 hover:bg-slate-100/50'
                    )}
                  >
                    <div
                      className={cn(
                        'flex min-w-0 flex-col border-l-[3px]',
                        psOpen ? 'border-l-primary' : 'border-l-transparent hover:border-l-slate-300'
                      )}
                    >
                      <button
                        type="button"
                        className={cn(
                          'flex w-full min-w-0 items-center gap-3 px-4 py-3 text-left outline-none transition-colors sm:gap-4 sm:py-3.5',
                          'focus-visible:bg-primary/[0.06] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/25'
                        )}
                        onClick={() =>
                          setPaymentSummaryExpandedId((id) => (id === talent.id ? null : talent.id))
                        }
                        aria-expanded={psOpen}
                        aria-label={`${psOpen ? 'Collapse' : 'Expand'} payment summary for ${talent.name}`}
                      >
                        <div
                          className={cn(
                            'flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold shadow-inner sm:h-12 sm:w-12 sm:text-base',
                            psOpen
                              ? 'bg-primary text-white ring-2 ring-primary/30'
                              : 'border border-primary/15 bg-primary/[0.08] text-primary-900'
                          )}
                          aria-hidden
                        >
                          {talentInitials(talent.name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold text-primary-900">{talent.name}</p>
                          <p className="mt-0.5 text-2xs text-slate-600">
                            <span className="font-mono font-semibold text-primary-800">
                              {getTalentEmployeeIdDisplay(talent)}
                            </span>
                            <span className="mx-1.5 text-slate-300">·</span>
                            <span className="text-slate-600">Signed</span>{' '}
                            <span className="font-medium text-primary-800">{talent.signingDate || '—'}</span>
                          </p>
                          {!psOpen && (
                            <>
                              <div className="mt-2 flex flex-wrap gap-2">
                                <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                  Outstanding {formatINRDisplay(totals.grand.outstanding)}
                                </span>
                                <span className="inline-flex items-center rounded-full border border-slate-200 bg-white px-2.5 py-0.5 text-2xs font-medium text-slate-700">
                                  Paid {formatINRDisplay(totals.grand.paid)}
                                </span>
                              </div>
                              <p className="mt-1.5 text-[10px] font-medium uppercase tracking-wide text-primary/50">
                                Tap for payment summary
                              </p>
                            </>
                          )}
                        </div>
                        <span
                          className={cn(
                            'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border text-primary',
                            psOpen ? 'border-primary/25 bg-primary/10' : 'border-slate-200 bg-white shadow-sm'
                          )}
                          aria-hidden
                        >
                          <ChevronRight
                            className={cn(
                              'h-4 w-4 transition-transform duration-200 ease-out sm:h-[18px] sm:w-[18px]',
                              psOpen ? 'rotate-90' : 'rotate-0'
                            )}
                          />
                        </span>
                      </button>
                    {psOpen && (
                      <div className="border-t border-primary/12 bg-primary/[0.04] px-4 pb-4 pt-3 sm:px-5">
                        <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-primary-800">
                          Payment summary · {reportYear}
                        </p>
                        <div className="overflow-x-auto rounded-lg border-2 border-primary/18 bg-white/95 shadow-inner shadow-primary/[0.08] ring-1 ring-primary/[0.05]">
                          <table className="w-full min-w-[520px] text-2xs">
                            <thead>
                              <tr className="border-b border-primary/15 bg-primary/12 text-left text-primary-900">
                                <th className="px-3 py-2 text-2xs font-bold">Type</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Payable</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Paid</th>
                                <th className="px-3 py-2 text-right text-2xs font-bold">Outstanding</th>
                              </tr>
                            </thead>
                            <tbody>
                              {[
                                { label: 'Salary', ...totals.salary },
                                { label: 'Bonus', ...totals.bonus },
                                { label: 'Revenue share', ...totals.royalty },
                              ].map((row) => (
                                <tr
                                  key={row.label}
                                  className="border-b border-primary/[0.08] last:border-0 odd:bg-primary/[0.02]"
                                >
                                  <td className="px-3 py-2 text-2xs font-semibold text-primary-900">{row.label}</td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-gray-800">
                                    {formatINRDisplay(row.payable)}
                                  </td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-green-700">
                                    {formatINRDisplay(row.paid)}
                                  </td>
                                  <td className="px-3 py-2 text-right text-2xs tabular-nums text-amber-700">
                                    {formatINRDisplay(row.outstanding)}
                                  </td>
                                </tr>
                              ))}
                              <tr className="bg-primary/15 text-xs font-bold text-primary-950">
                                <td className="px-3 py-2">Total</td>
                                <td className="px-3 py-2 text-right tabular-nums">
                                  {formatINRDisplay(totals.grand.payable)}
                                </td>
                                <td className="px-3 py-2 text-right tabular-nums text-green-900">
                                  {formatINRDisplay(totals.grand.paid)}
                                </td>
                                <td className="px-3 py-2 text-right tabular-nums text-amber-900">
                                  {formatINRDisplay(totals.grand.outstanding)}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        <div className="flex justify-end border-t border-slate-200/90 bg-slate-50/60 px-1 py-3">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-7 border-primary/30 px-2.5 text-2xs font-semibold text-primary hover:bg-primary/10"
                            onClick={() => navigate(`/sponsorship/talents/${talent.id}`)}
                          >
                            View more
                          </Button>
                        </div>
                      </div>
                    )}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="space-y-3 border-t border-slate-200/90 bg-slate-50/50 px-4 py-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-2xs text-neutral">
                  Showing {paginatedTalents.length} of {filteredTalentsForCards.length} talent
                  {filteredTalentsForCards.length !== 1 ? 's' : ''} · page {talentPage + 1} of {talentCardsTotalPages}
                </p>
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-primary/50" />
                  <Input
                    placeholder="Search talent..."
                    value={talentSearch}
                    onChange={(e) => {
                      setTalentSearch(e.target.value)
                      setTalentPage(0)
                    }}
                    className="h-8 border-primary/15 pl-8 text-2xs focus-visible:border-primary/30 focus-visible:ring-primary/20"
                  />
                </div>
              </div>
              {filteredTalentsForCards.length === 0 && (
                <p className="text-2xs text-neutral">No talents match search.</p>
              )}
              {talentCardsTotalPages > 1 && (
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                    disabled={talentPage === 0}
                    onClick={() => setTalentPage((p) => p - 1)}
                  >
                    Previous
                  </Button>
                  <span className="text-2xs font-medium text-primary-800">
                    Page {talentPage + 1} of {talentCardsTotalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 border-primary/25 text-2xs text-primary hover:bg-primary/10"
                    disabled={talentPage >= talentCardsTotalPages - 1}
                    onClick={() => setTalentPage((p) => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        ) : null}
      </Card>
        </TabsContent>

        <TabsContent value="summary" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
      <Card className="overflow-hidden rounded-lg border border-primary/12 border-l-4 border-l-accent bg-gradient-to-r from-accent/[0.04] to-white shadow-md">
        <button
          type="button"
          className={cn('expand-trigger', paymentSummaryDistributionOpen && 'expand-trigger--open')}
          onClick={() => setPaymentSummaryDistributionOpen((v) => !v)}
          aria-expanded={paymentSummaryDistributionOpen}
          aria-controls="dashboard-payment-summary-distribution-panel"
          id="dashboard-payment-summary-distribution-trigger"
        >
          <div className="flex min-w-0 flex-1 items-start gap-3 sm:gap-4">
            <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
              <TrendingUp className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1 text-left">
              <p className="text-sm font-bold tracking-tight text-primary-900">Payment summary &amp; distribution</p>
              <p className="mt-1 text-2xs leading-relaxed text-slate-600 sm:text-xs">
                Opens on <span className="font-medium text-primary-800">salary</span> by default. Tap a card to switch charts; use{' '}
                <span className="font-medium text-primary-800">View more</span> (bottom-right on each card) for the full payment
                summary tab.
              </p>
            </div>
          </div>
          <span className="expand-chevron-wrap" aria-hidden>
            {paymentSummaryDistributionOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </span>
        </button>
        {paymentSummaryDistributionOpen ? (
          <CardContent
            id="dashboard-payment-summary-distribution-panel"
            className="space-y-4 border-t border-slate-200/90 bg-slate-50/40 px-4 pb-4 pt-4 sm:px-5"
            role="region"
            aria-labelledby="dashboard-payment-summary-distribution-trigger"
          >
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
              <PaymentTypeDashboardCard
                title="Salary"
                icon={DollarSign}
                payableRowLabel="Total payable salary"
                paidRowLabel="Total paid salary"
                outstandingRowLabel="Total outstanding salary"
                payable={salaryM.payable}
                paid={salaryM.paid}
                outstanding={salaryM.outstanding}
                isSelected={paymentCategoryFocus === 'salary'}
                onSelect={() => setPaymentCategoryFocus('salary')}
                onViewMore={() => navigate(paymentsDetailHref('salary'))}
              />
              <PaymentTypeDashboardCard
                title="Bonus"
                icon={Gift}
                payableRowLabel="Total payable bonus"
                paidRowLabel="Total paid bonus"
                outstandingRowLabel="Total outstanding bonus"
                payable={bonusM.payable}
                paid={bonusM.paid}
                outstanding={bonusM.outstanding}
                isSelected={paymentCategoryFocus === 'bonus'}
                onSelect={() => setPaymentCategoryFocus('bonus')}
                onViewMore={() => navigate(paymentsDetailHref('bonus'))}
              />
              <PaymentTypeDashboardCard
                title="Revenue share"
                icon={TrendingUp}
                payableRowLabel="Total payable revenue share"
                paidRowLabel="Total paid revenue share"
                outstandingRowLabel="Total outstanding revenue share"
                payable={revM.payable}
                paid={revM.paid}
                outstanding={revM.outstanding}
                isSelected={paymentCategoryFocus === 'revenue-share'}
                onSelect={() => setPaymentCategoryFocus('revenue-share')}
                onViewMore={() => navigate(paymentsDetailHref('revenue-share'))}
              />
              <PaymentTypeDashboardCard
                title="Miscellaneous"
                icon={Wallet}
                payableRowLabel="Total payable miscellaneous"
                paidRowLabel="Total paid miscellaneous"
                outstandingRowLabel="Total outstanding miscellaneous"
                payable={miscM.payable}
                paid={miscM.paid}
                outstanding={miscM.outstanding}
                isSelected={paymentCategoryFocus === 'miscellaneous'}
                onSelect={() => setPaymentCategoryFocus('miscellaneous')}
                onViewMore={() => navigate(paymentsDetailHref('miscellaneous'))}
              />
            </div>

            <p className="border-t border-primary/10 pt-3 text-right text-xs text-primary-700/70">
              Bonus rule of thumb: {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)}/talent/mo · revenue share for{' '}
              <span className="font-medium text-primary-800">{clubName}</span> · vendor uploads refresh the ledger.
            </p>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="group min-h-[320px] space-y-3 rounded-2xl border border-primary/12 bg-gradient-to-b from-white via-white to-primary/[0.03] p-4 shadow-lg shadow-primary/10 ring-1 ring-primary/10 transition-shadow duration-300 hover:shadow-xl hover:ring-primary/15">
                <PaymentBucketsPieChart
                  payable={focusPie.payable}
                  paid={focusPie.paid}
                  outstanding={focusPie.outstanding}
                  payableLabel={focusPie.payableLabel}
                  paidLabel={focusPie.paidLabel}
                  outstandingLabel={focusPie.outstandingLabel}
                  title={focusPie.pieTitle}
                  description={focusPie.pieDescription}
                />
                <ul className="space-y-2 rounded-xl border border-primary/12 bg-white/95 px-3 py-3 text-xs shadow-inner sm:text-sm">
                  <li className="flex flex-wrap items-baseline justify-between gap-2 border-b border-primary/10 pb-2">
                    <span className="font-medium text-primary-800/90">{focusPie.payableLabel}:</span>
                    <span className="font-bold tabular-nums text-primary-900">{formatINRDisplay(focusPie.payable)}</span>
                  </li>
                  <li className="flex flex-wrap items-baseline justify-between gap-2 border-b border-primary/10 pb-2">
                    <span className="font-medium text-primary-800/90">{focusPie.paidLabel}:</span>
                    <span className="font-bold tabular-nums text-primary-600">{formatINRDisplay(focusPie.paid)}</span>
                  </li>
                  <li className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-medium text-primary-800/90">{focusPie.outstandingLabel}:</span>
                    <span className="font-bold tabular-nums text-accent-700">{formatINRDisplay(focusPie.outstanding)}</span>
                  </li>
                </ul>
              </div>
              <div className="min-h-[320px] rounded-2xl border border-primary/12 bg-gradient-to-b from-white via-white to-primary/[0.03] p-4 shadow-lg shadow-primary/10 ring-1 ring-primary/10 transition-shadow duration-300 hover:shadow-xl hover:ring-primary/15">
                {focusPie.distData?.length > 0 ? (
                  <TopTalentHorizontalBarChart
                    data={focusPie.distData}
                    title={focusPie.distTitle}
                    description={focusPie.distDescription}
                    topN={10}
                    uniformBarColor={focusPie.barUniformColor}
                    othersBarColor="#F97316"
                  />
                ) : (
                  <div className="flex h-[300px] flex-col justify-center rounded-xl border border-dashed border-slate-200 bg-slate-50/50 p-6 text-center">
                    <h3 className="text-base font-semibold text-slate-800">{focusPie.distTitle}</h3>
                    <p className="mt-2 text-sm text-slate-500">No per-talent amounts for this category yet.</p>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="mx-auto mt-4 border-accent/45 text-accent-800 hover:bg-accent/12"
                      onClick={() => navigate(paymentsDetailHref('summary'))}
                    >
                      Open payment summary <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        ) : null}
      </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
