import React, { useState, useMemo, useEffect } from 'react'
import { cn } from '../../utils/cn'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import {
  enrichSalaryPayments,
  getAnnualSalaryTotal,
  getPaidSalaryTotal,
  getPendingSalaryTotal,
  getSalaryByTalent,
} from '../../utils/salaryCalculator'
import { DataTable } from '../../components/tables/DataTable'
import { Button } from '../../components/ui/button'
import { Card, CardContent } from '../../components/ui/card'
import { SalarySlipPDFViewer } from '../../components/forms/SalarySlipPDFViewer'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { downloadSalarySlipPDF } from '../../utils/pdfGenerator'
import { FileText, Download, Filter, User, DollarSign } from 'lucide-react'
import { StatCard } from '../../components/cards/StatCard'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { Checkbox } from '../../components/ui/checkbox'
import { PaymentTripleAmountBarChart } from '../../components/charts/PaymentTripleAmountBarChart'
import { PaymentPaidOutstandingDonutChart } from '../../components/charts/PaymentPaidOutstandingDonutChart'
import { PaymentTabIntroStrip, PAYMENT_TAB_CHART_SHELL } from './paymentSummaryTabIntro'

function monthLabel(month) {
  if (!month || typeof month !== 'string') return '—'
  const [y, m] = month.split('-')
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : month
}

function aggregateSalaryByMonth(salaryPayments) {
  const byMonth = {}
  ;(salaryPayments || []).forEach((s) => {
    const key = s.month || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.salaryAmount || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

/** All 12 months for calendar year (including zeros) for charts when filtering by year. */
function aggregateSalaryByMonthForYear(salaryPayments, year) {
  const y = String(year)
  const keys = []
  for (let m = 1; m <= 12; m++) keys.push(`${y}-${String(m).padStart(2, '0')}`)
  const byMonth = Object.fromEntries(keys.map((k) => [k, 0]))
  ;(salaryPayments || []).forEach((s) => {
    const key = String(s.month || '')
    if (!key.startsWith(`${y}-`)) return
    byMonth[key] = (byMonth[key] || 0) + Number(s.salaryAmount || 0)
  })
  return keys.map((month) => ({ month, revenue: byMonth[month] || 0 }))
}

/**
 * Club salary workspace — full payslip table, charts, PDF.
 * @param {{ embedded?: boolean, filterYear?: string | number | null, filterTalentId?: string | null, fromDashboard?: boolean, engineTotals?: { payable: number, paid: number, outstanding: number } | null }} props Payment summary passes `engineTotals` (year engine) and `fromDashboard` to show “Filter by talent” only when linked from the dashboard.
 */
export function ClubSalaryPage({
  embedded = false,
  filterYear = null,
  filterTalentId = null,
  fromDashboard = false,
  engineTotals = null,
} = {}) {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto(
    'Calculating salaries...',
    'Salary data loaded',
    embedded ? 400 : 600,
    embedded
  )
  const salaryPaymentsAll = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const yearKey = filterYear != null && filterYear !== '' ? String(filterYear) : null
  const salaryPayments = useMemo(() => {
    if (!yearKey) return salaryPaymentsAll || []
    return (salaryPaymentsAll || []).filter((s) => String(s.month || '').startsWith(`${yearKey}-`))
  }, [salaryPaymentsAll, yearKey])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const ledger = useMemo(() => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses), [sales, contracts, talents, sportsBusinesses])
  const [viewingSlip, setViewingSlip] = useState(null)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const talentFilterLocked = Boolean(embedded && filterTalentId)
  const paymentSummaryEmbed = Boolean(embedded && engineTotals)

  useEffect(() => {
    if (embedded && filterTalentId) setSelectedTalentIds([filterTalentId])
  }, [embedded, filterTalentId])

  const lockedTalentName = useMemo(() => {
    if (!filterTalentId) return ''
    const t = (talents || []).find((x) => x.id === filterTalentId)
    return t?.name || ''
  }, [filterTalentId, talents])

  const businessName = sportsBusinesses[0]?.businessName || 'Sports Business'

  const talentWiseDates = useMemo(() => {
    const byTalent = new Map()
    ;(contracts || []).forEach((c) => {
      if (!c.talentId || byTalent.has(c.talentId)) return
      byTalent.set(c.talentId, {
        talentId: c.talentId,
        talentName: c.talentName || '—',
        joiningDate: c.startDate || null,
        contractSigningDate: null,
      })
    })
    ;(talents || []).forEach((t) => {
      const row = byTalent.get(t.id)
      if (row) row.contractSigningDate = t.signingDate || null
      else
        byTalent.set(t.id, {
          talentId: t.id,
          talentName: t.name || '—',
          joiningDate: null,
          contractSigningDate: t.signingDate || null,
        })
    })
    return Array.from(byTalent.values()).sort((a, b) => (a.talentName || '').localeCompare(b.talentName || ''))
  }, [contracts, talents])

  const talentOptions = useMemo(() => {
    const map = new Map()
    ;(salaryPayments || []).forEach((s) => {
      if (s.talentId && s.talentName) map.set(s.talentId, s.talentName)
    })
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }))
  }, [salaryPayments])

  const filteredSalaries = useMemo(() => {
    if (selectedTalentIds.length === 0) return salaryPayments || []
    return (salaryPayments || []).filter((s) => selectedTalentIds.includes(s.talentId))
  }, [salaryPayments, selectedTalentIds])

  const salaryMonthlyData = useMemo(() => {
    if (yearKey) return aggregateSalaryByMonthForYear(filteredSalaries, yearKey)
    return aggregateSalaryByMonth(filteredSalaries)
  }, [filteredSalaries, yearKey])
  /** Pie chart follows the same rows as the table (year + talent checkboxes). */
  const salaryDistribution = useMemo(() => getSalaryByTalent(filteredSalaries), [filteredSalaries])

  const salaryChartsKey = useMemo(
    () => `${yearKey ?? 'all'}:${[...selectedTalentIds].sort().join('|')}`,
    [yearKey, selectedTalentIds]
  )

  const enrichedSalaries = useMemo(
    () => enrichSalaryPayments(filteredSalaries || [], signingBonuses, ledger),
    [filteredSalaries, signingBonuses, ledger]
  )

  /** Base salary amounts only (salary column), respects talent filter */
  const salaryTotals = useMemo(
    () => ({
      payable: getAnnualSalaryTotal(filteredSalaries),
      paid: getPaidSalaryTotal(filteredSalaries),
      outstanding: getPendingSalaryTotal(filteredSalaries),
    }),
    [filteredSalaries]
  )

  /** Cards + triple chart: org engine from parent, or filtered rows when dashboard user picks talents, or single-talent engine when deep-linked. */
  const headerSalary = useMemo(() => {
    if (!paymentSummaryEmbed || !engineTotals) return null
    if (filterTalentId) return engineTotals
    if (!fromDashboard || selectedTalentIds.length === 0) return engineTotals
    return salaryTotals
  }, [
    paymentSummaryEmbed,
    engineTotals,
    filterTalentId,
    fromDashboard,
    selectedTalentIds.length,
    salaryTotals,
  ])

  const showDashboardTalentFilter = paymentSummaryEmbed && fromDashboard && !filterTalentId

  const columns = [
    {
      id: 'talentName',
      header: 'Talent',
      accessorKey: 'talentName',
      cell: (info) => <span className="font-medium">{info.getValue()}</span>,
    },
    {
      id: 'month',
      header: 'Period',
      accessorKey: 'month',
      cell: (info) => <span title={info.getValue()}>{monthLabel(info.getValue())}</span>,
    },
    {
      id: 'salaryAmount',
      header: 'Monthly salary',
      accessorKey: 'salaryAmount',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'monthlyPerformanceBonus',
      header: 'Perf. bonus',
      accessorKey: 'monthlyPerformanceBonus',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'monthlyRoyalty',
      header: 'Revenue share',
      accessorKey: 'monthlyRoyalty',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'totalEarnings',
      header: 'Period total',
      accessorKey: 'totalEarnings',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'paymentStatus',
      header: 'Status',
      accessorKey: 'paymentStatus',
      cell: (info) => (
        <span
          className={cn(
            'rounded-full px-2 py-0.5 text-2xs font-medium',
            info.getValue() === 'paid' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'
          )}
        >
          {info.getValue() === 'paid' ? 'Paid' : 'Pending'}
        </span>
      ),
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex flex-wrap gap-1">
          <Button
            variant="outline"
            size="sm"
            className="h-7 border-primary/25 px-2 text-2xs text-primary hover:bg-primary/10"
            onClick={() => setViewingSlip(row.original)}
          >
            <FileText className="mr-1 h-3 w-3" /> PDF
          </Button>
          <Button variant="outline" size="sm" className="h-7 px-2 text-2xs" onClick={() => downloadSalarySlipPDF(row.original, businessName)}>
            <Download className="mr-1 h-3 w-3" />
          </Button>
        </div>
      ),
    },
  ]

  if (loading && !embedded) return <PageLoaderWithSkeleton message={loadMessage} />
  if (loading && embedded) {
    return <div className="py-8 text-center text-xs text-neutral">{loadMessage}</div>
  }

  return (
    <div className={cn('space-y-4', embedded && 'space-y-3')}>
      {!embedded && (
        <>
          <h2 className="theme-page-title">Salary</h2>
          <p className="theme-section-summary max-w-2xl">
            Monthly salary rows with performance bonus and revenue share on slips. Filter by talent or open a profile for contracts.
          </p>
        </>
      )}

      {paymentSummaryEmbed && yearKey && <PaymentTabIntroStrip tabKey="salary" year={yearKey} />}

      {!embedded && talentWiseDates.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <p className="mb-3 text-2xs font-semibold uppercase tracking-wide text-primary-800">Contract & signing dates</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {talentWiseDates.map((row) => (
                <div key={row.talentId} className="theme-card-muted rounded-md border border-primary/10 px-3 py-2 text-2xs">
                  <p className="font-medium text-primary-900">{row.talentName}</p>
                  <p className="text-neutral">Join: {row.joiningDate || '—'}</p>
                  <p className="text-neutral">Signing: {row.contractSigningDate || '—'}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment summary embed: cards → payable/paid/outstanding bar + salary by month */}
      {paymentSummaryEmbed && headerSalary && yearKey && (
        <>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <StatCard
              title="Total payable salary"
              value={formatINRDisplay(headerSalary.payable)}
              icon={DollarSign}
              className="border-primary/15"
              subtitle={
                filterTalentId && lockedTalentName
                  ? `${lockedTalentName} · ${yearKey}`
                  : !fromDashboard || selectedTalentIds.length === 0
                    ? `Calendar year ${yearKey} · club roster`
                    : undefined
              }
            />
            <StatCard
              title="Total paid salary"
              value={formatINRDisplay(headerSalary.paid)}
              icon={DollarSign}
              className="border-primary/15"
              subtitle={yearKey ? `Recognized in ${yearKey}` : undefined}
            />
            <StatCard
              title="Total outstanding salary"
              value={formatINRDisplay(headerSalary.outstanding)}
              icon={DollarSign}
              className={cn(
                'border-primary/15',
                filterTalentId && 'border-accent/30 bg-gradient-to-br from-accent/[0.08] to-white'
              )}
              valueClassName={filterTalentId ? 'text-accent-900' : undefined}
              subtitle="Pending salary rows for the year"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <div className={PAYMENT_TAB_CHART_SHELL}>
              <PaymentTripleAmountBarChart
                kind="salary"
                payable={headerSalary.payable}
                paid={headerSalary.paid}
                outstanding={headerSalary.outstanding}
                year={yearKey}
                scopeNote={filterTalentId ? lockedTalentName || undefined : undefined}
              />
            </div>
            <div className={PAYMENT_TAB_CHART_SHELL}>
              {filterTalentId ? (
                <PaymentPaidOutstandingDonutChart
                  title="Paid vs outstanding · Salary"
                  payable={headerSalary.payable}
                  paid={headerSalary.paid}
                  outstanding={headerSalary.outstanding}
                  description={`${lockedTalentName || 'Talent'} · ${yearKey}`}
                />
              ) : (
                <div className="h-full min-h-[280px] px-1 py-1">
                  <MonthlyRevenueChart
                    data={salaryMonthlyData}
                    title={`Salary by month (${yearKey})`}
                    description="Base salary per month for the current filter (none = all talents)"
                    currency="USD"
                    valueLabel="Salary"
                  />
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {/* Standalone / legacy embedded: filter + cards + charts */}
      {!paymentSummaryEmbed && (
        <>
          <div
            className={cn(
              'rounded-lg border border-primary/15 bg-primary/[0.04] p-3',
              embedded && 'bg-white'
            )}
          >
            {talentFilterLocked ? (
              <>
                <div className="mb-2 flex items-center gap-2 text-primary-900">
                  <User className="h-3.5 w-3.5 text-accent-600" />
                  <span className="text-2xs font-bold uppercase tracking-wider">Talent scope</span>
                </div>
                <p className="text-2xs text-neutral">
                  Showing salary for <span className="font-semibold text-primary-800">{lockedTalentName || 'this roster member'}</span>.
                </p>
              </>
            ) : (
              <>
                <div className="mb-2 flex items-center gap-2 text-primary-900">
                  <Filter className="h-3.5 w-3.5 text-accent-600" />
                  <span className="text-2xs font-bold uppercase tracking-wider">Filter by talent</span>
                </div>
                <p className="mb-2 text-2xs text-neutral">Check talents to narrow rows (none = all).</p>
                <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto">
                  {talentOptions.length === 0 ? (
                    <span className="text-2xs text-neutral">No salary rows yet.</span>
                  ) : (
                    talentOptions.map((t) => (
                      <label
                        key={t.id}
                        className={cn(
                          'flex cursor-pointer items-center gap-1.5 rounded-md border px-2 py-1 text-2xs transition-colors',
                          selectedTalentIds.includes(t.id)
                            ? 'border-primary/40 bg-primary/10 font-medium text-primary-900'
                            : 'border-gray-200 bg-white hover:border-primary/25'
                        )}
                      >
                        <Checkbox
                          checked={selectedTalentIds.includes(t.id)}
                          onCheckedChange={() =>
                            setSelectedTalentIds((prev) =>
                              prev.includes(t.id) ? prev.filter((x) => x !== t.id) : [...prev, t.id]
                            )
                          }
                        />
                        <User className="h-3 w-3 text-primary/70" />
                        <span className="max-w-[140px] truncate">{t.name}</span>
                      </label>
                    ))
                  )}
                </div>
                {selectedTalentIds.length > 0 && (
                  <Button variant="ghost" size="sm" className="mt-2 h-7 text-2xs" onClick={() => setSelectedTalentIds([])}>
                    Clear filter
                  </Button>
                )}
              </>
            )}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <StatCard
              title="Total payable salary"
              value={formatINRDisplay(salaryTotals.payable)}
              icon={DollarSign}
              className="border-primary/15"
            />
            <StatCard
              title="Total paid salary"
              value={formatINRDisplay(salaryTotals.paid)}
              icon={DollarSign}
              className="border-primary/15"
            />
            <StatCard
              title="Total outstanding salary"
              value={formatINRDisplay(salaryTotals.outstanding)}
              icon={DollarSign}
              className="border-primary/15"
            />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="theme-card min-h-[260px] p-4" key={`salary-trend-${salaryChartsKey}`}>
              <MonthlyRevenueChart
                data={salaryMonthlyData}
                title={yearKey ? `Salary by month (${yearKey})` : 'Salary monthly trend'}
                description={
                  yearKey
                    ? 'Base salary per month (respects talent filter above)'
                    : 'Base salary by month (respects talent filter above)'
                }
                currency="USD"
                valueLabel="Salary"
              />
            </div>
            <div className="theme-card min-h-[260px] p-4" key={`salary-pie-${salaryChartsKey}`}>
              {salaryDistribution.length > 0 ? (
                <RoyaltyDistributionChart
                  data={salaryDistribution}
                  title="Salary by talent"
                  description={yearKey ? `Base salary total per talent (${yearKey})` : 'Base salary total per talent (filtered rows)'}
                />
              ) : (
                <div>
                  <h3 className="mb-2 text-sm font-medium text-primary-900">Salary by talent</h3>
                  <p className="text-xs text-neutral">No contract salary data</p>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {/* Payment summary: filter only when opened from dashboard (not deep-linked to one talent) */}
      {showDashboardTalentFilter && (
        <div className={cn('rounded-lg border border-primary/15 bg-primary/[0.04] p-3', 'bg-white')}>
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <Filter className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Filter by talent</span>
          </div>
          <p className="mb-2 text-2xs text-neutral">Linked from dashboard · check talents to narrow rows and totals (none = all).</p>
          <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto">
            {talentOptions.length === 0 ? (
              <span className="text-2xs text-neutral">No salary rows yet.</span>
            ) : (
              talentOptions.map((t) => (
                <label
                  key={t.id}
                  className={cn(
                    'flex cursor-pointer items-center gap-1.5 rounded-md border px-2 py-1 text-2xs transition-colors',
                    selectedTalentIds.includes(t.id)
                      ? 'border-primary/40 bg-primary/10 font-medium text-primary-900'
                      : 'border-gray-200 bg-white hover:border-primary/25'
                  )}
                >
                  <Checkbox
                    checked={selectedTalentIds.includes(t.id)}
                    onCheckedChange={() =>
                      setSelectedTalentIds((prev) =>
                        prev.includes(t.id) ? prev.filter((x) => x !== t.id) : [...prev, t.id]
                      )
                    }
                  />
                  <User className="h-3 w-3 text-primary/70" />
                  <span className="max-w-[140px] truncate">{t.name}</span>
                </label>
              ))
            )}
          </div>
          {selectedTalentIds.length > 0 && (
            <Button variant="ghost" size="sm" className="mt-2 h-7 text-2xs" onClick={() => setSelectedTalentIds([])}>
              Clear filter
            </Button>
          )}
        </div>
      )}

      {paymentSummaryEmbed && filterTalentId && (
        <div className="rounded-lg border border-primary/15 bg-white p-3">
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <User className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Talent scope</span>
          </div>
          <p className="text-2xs text-neutral">
            Showing salary for <span className="font-semibold text-primary-800">{lockedTalentName || 'this roster member'}</span>{' '}
            only (opened from talent detail).
          </p>
        </div>
      )}

      {/* Row 3 — table */}
      <div className="theme-card overflow-hidden p-3">
        <h3 className="mb-2 text-sm font-semibold text-primary-900">Salary payments</h3>
        <p className="mb-3 text-2xs text-neutral">
          Rows show monthly salary plus performance bonus and revenue share for each period (period total).
        </p>
        <DataTable columns={columns} data={enrichedSalaries} searchKey="talentName" searchPlaceholder="Search talent or month…" />
      </div>

      <SalarySlipPDFViewer
        open={!!viewingSlip}
        onOpenChange={(v) => !v && setViewingSlip(null)}
        salaryRecord={viewingSlip}
        businessName={businessName}
      />
    </div>
  )
}
