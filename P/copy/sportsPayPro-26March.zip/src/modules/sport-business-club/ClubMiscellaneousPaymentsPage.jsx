import React, { useMemo, useState, useEffect } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import { StatCard } from '../../components/cards/StatCard'
import { DollarSign, Wallet, Filter, User } from 'lucide-react'
import { Checkbox } from '../../components/ui/checkbox'
import { Button } from '../../components/ui/button'
import { PaymentTripleAmountBarChart } from '../../components/charts/PaymentTripleAmountBarChart'
import { PaymentPaidOutstandingDonutChart } from '../../components/charts/PaymentPaidOutstandingDonutChart'
import { PaymentTabIntroStrip, PAYMENT_TAB_CHART_SHELL } from './paymentSummaryTabIntro'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'

function aggregateMiscByMonthForYear(rows, year) {
  const y = String(year)
  const keys = []
  for (let m = 1; m <= 12; m++) keys.push(`${y}-${String(m).padStart(2, '0')}`)
  const byMonth = Object.fromEntries(keys.map((k) => [k, 0]))
  for (const r of rows || []) {
    const key = String(r.periodMonth || '').slice(0, 7)
    if (!key.startsWith(`${y}-`)) continue
    byMonth[key] = (byMonth[key] || 0) + (Number(r.amount) || 0)
  }
  return keys.map((month) => ({ month, revenue: byMonth[month] || 0 }))
}

function miscTotalsFromRows(rows) {
  const payable = (rows || []).reduce((a, r) => a + (Number(r.amount) || 0), 0)
  const paid = (rows || []).filter((r) => r.paymentStatus === 'paid').reduce((a, r) => a + (Number(r.amount) || 0), 0)
  const outstanding = (rows || []).filter((r) => r.paymentStatus === 'pending').reduce((a, r) => a + (Number(r.amount) || 0), 0)
  return { payable, paid, outstanding }
}

/**
 * Miscellaneous register embedded under Payment summary (summary strip, KPIs, charts, optional dashboard talent filter, table).
 */
export function ClubMiscellaneousPaymentsPage({
  embedded = false,
  filterYear = null,
  filterTalentId = null,
  fromDashboard = false,
  engineTotals = null,
} = {}) {
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const miscRowsAll = useMemo(
    () => getAllByOrganization('miscellaneousPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId, dataRevision])

  const yearKey = filterYear != null && filterYear !== '' ? String(filterYear) : null
  const paymentSummaryEmbed = Boolean(embedded && engineTotals)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])

  useEffect(() => {
    if (embedded && filterTalentId) setSelectedTalentIds([filterTalentId])
  }, [embedded, filterTalentId])

  const lockedTalentName = useMemo(() => {
    if (!filterTalentId) return ''
    return (talents || []).find((t) => t.id === filterTalentId)?.name || ''
  }, [filterTalentId, talents])

  const miscDisplayed = useMemo(() => {
    let rows = [...(miscRowsAll || [])]
    if (filterTalentId) return rows.filter((r) => r.talentId === filterTalentId)
    if (paymentSummaryEmbed && fromDashboard && selectedTalentIds.length > 0) {
      return rows.filter((r) => selectedTalentIds.includes(r.talentId))
    }
    return rows
  }, [miscRowsAll, filterTalentId, paymentSummaryEmbed, fromDashboard, selectedTalentIds])

  const rowMiscTotals = useMemo(() => miscTotalsFromRows(miscDisplayed), [miscDisplayed])

  const headerMisc = useMemo(() => {
    if (!paymentSummaryEmbed || !engineTotals) return null
    if (filterTalentId) return engineTotals
    if (!fromDashboard || selectedTalentIds.length === 0) return engineTotals
    return rowMiscTotals
  }, [paymentSummaryEmbed, engineTotals, filterTalentId, fromDashboard, selectedTalentIds.length, rowMiscTotals])

  const showDashboardTalentFilter = paymentSummaryEmbed && fromDashboard && !filterTalentId

  const talentOptions = useMemo(() => {
    const map = new Map()
    ;(miscRowsAll || []).forEach((r) => {
      if (r.talentId && r.talentName) map.set(r.talentId, r.talentName)
    })
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }))
  }, [miscRowsAll])

  const miscMonthlyData = useMemo(() => {
    if (!yearKey) return []
    return aggregateMiscByMonthForYear(miscDisplayed, yearKey)
  }, [miscDisplayed, yearKey])

  if (!embedded) {
    return (
      <div className="rounded-lg border border-dashed border-primary/20 bg-primary/[0.03] p-6 text-center text-sm text-primary-800/80">
        Open Payment summary to view miscellaneous payments in context.
      </div>
    )
  }

  return (
    <div className={cn('space-y-4', embedded && 'space-y-3')}>
      {paymentSummaryEmbed && yearKey && <PaymentTabIntroStrip tabKey="miscellaneous" year={yearKey} />}

      {paymentSummaryEmbed && headerMisc && yearKey && (
        <>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <StatCard
              title="Total payable miscellaneous"
              value={formatINRDisplay(headerMisc.payable)}
              icon={DollarSign}
              className="border-primary/15"
              subtitle={
                filterTalentId && lockedTalentName
                  ? `${lockedTalentName} · misc register`
                  : !fromDashboard || selectedTalentIds.length === 0
                    ? 'All talents · misc register'
                    : undefined
              }
            />
            <StatCard
              title="Total paid miscellaneous"
              value={formatINRDisplay(headerMisc.paid)}
              icon={Wallet}
              className="border-primary/15"
              subtitle="Recorded as paid"
            />
            <StatCard
              title="Total outstanding miscellaneous"
              value={formatINRDisplay(headerMisc.outstanding)}
              icon={DollarSign}
              className={cn(
                'border-primary/15',
                filterTalentId && 'border-accent/30 bg-gradient-to-br from-accent/[0.08] to-white'
              )}
              valueClassName={filterTalentId ? 'text-accent-900' : undefined}
              subtitle="Pending misc rows"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <div className={PAYMENT_TAB_CHART_SHELL}>
              <PaymentTripleAmountBarChart
                kind="misc"
                payable={headerMisc.payable}
                paid={headerMisc.paid}
                outstanding={headerMisc.outstanding}
                year={yearKey}
                scopeNote={filterTalentId ? lockedTalentName || undefined : undefined}
              />
            </div>
            <div className={PAYMENT_TAB_CHART_SHELL}>
              {filterTalentId ? (
                <PaymentPaidOutstandingDonutChart
                  title="Paid vs outstanding · Miscellaneous"
                  payable={headerMisc.payable}
                  paid={headerMisc.paid}
                  outstanding={headerMisc.outstanding}
                  description={`${lockedTalentName || 'Talent'} · misc register`}
                />
              ) : (
                <div className="h-full min-h-[280px] px-1 py-1">
                  <MonthlyRevenueChart
                    data={miscMonthlyData}
                    title={`Miscellaneous by month (${yearKey})`}
                    description="Misc amounts in period month for the current filter (none = all talents)"
                    currency="USD"
                    valueLabel="Misc"
                  />
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {showDashboardTalentFilter && (
        <div className={cn('rounded-lg border border-primary/15 bg-primary/[0.04] p-3', 'bg-white')}>
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <Filter className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Filter by talent</span>
          </div>
          <p className="mb-2 text-2xs text-neutral">Linked from dashboard · check talents to narrow rows and totals (none = all).</p>
          <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto">
            {talentOptions.length === 0 ? (
              <span className="text-2xs text-neutral">No miscellaneous rows yet.</span>
            ) : (
              talentOptions.map((t) => (
                <label
                  key={t.id}
                  className={cn(
                    'flex cursor-pointer items-center gap-1.5 rounded-md border px-2 py-1 text-2xs transition-colors',
                    selectedTalentIds.includes(t.id)
                      ? 'border-primary/40 bg-primary/10 font-medium text-primary-900'
                      : 'border-gray-200 bg-white hover:border-primary/25'
                  )}
                >
                  <Checkbox
                    checked={selectedTalentIds.includes(t.id)}
                    onCheckedChange={() =>
                      setSelectedTalentIds((prev) =>
                        prev.includes(t.id) ? prev.filter((x) => x !== t.id) : [...prev, t.id]
                      )
                    }
                  />
                  <User className="h-3 w-3 text-primary/70" />
                  <span className="max-w-[140px] truncate">{t.name}</span>
                </label>
              ))
            )}
          </div>
          {selectedTalentIds.length > 0 && (
            <Button variant="ghost" size="sm" className="mt-2 h-7 text-2xs" onClick={() => setSelectedTalentIds([])}>
              Clear filter
            </Button>
          )}
        </div>
      )}

      {paymentSummaryEmbed && filterTalentId && (
        <div className="rounded-lg border border-primary/15 bg-white p-3">
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <User className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Talent scope</span>
          </div>
          <p className="text-2xs text-neutral">
            Showing miscellaneous for <span className="font-semibold text-primary-800">{lockedTalentName || 'this roster member'}</span>{' '}
            only (opened from talent detail).
          </p>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-primary/10 shadow-inner">
        <h3 className="border-b border-primary/10 bg-gradient-to-r from-slate-100 to-slate-50 px-3 py-2 text-sm font-semibold text-primary-900">
          Miscellaneous payments
        </h3>
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b border-primary/10 bg-gradient-to-r from-slate-100 to-slate-50 text-left">
              <th className="px-3 py-2 font-semibold">Talent</th>
              <th className="px-3 py-2 font-semibold">Category</th>
              <th className="px-3 py-2 font-semibold">Period</th>
              <th className="px-3 py-2 text-right font-semibold">Amount</th>
              <th className="px-3 py-2 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {miscDisplayed.map((r) => (
              <tr key={r.id} className="border-b border-gray-100">
                <td className="px-3 py-2 font-medium text-primary-900">{r.talentName}</td>
                <td className="px-3 py-2">{r.category}</td>
                <td className="px-3 py-2 font-mono text-xs">{r.periodMonth}</td>
                <td className="px-3 py-2 text-right tabular-nums">{formatINRDisplay(r.amount)}</td>
                <td className="px-3 py-2 capitalize">{r.paymentStatus}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {miscDisplayed.length === 0 && <p className="p-4 text-sm text-neutral">No miscellaneous payments recorded.</p>}
      </div>
    </div>
  )
}
