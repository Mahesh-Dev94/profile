import React, { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { format } from 'date-fns'
import { Info, FileSpreadsheet, BarChart3 } from 'lucide-react'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'

/**
 * Sport Business / Club: read-only view of sales files and batches uploaded by the sponsorship partner vendor.
 * Upload is only available under Sponsorship / Vendor Portal → Upload Sales.
 */
export function ClubVendorUploadsPage() {
  const { loading, loadMessage } = usePageLoadAuto('Loading partner uploads...', 'Partner uploads loaded')
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()

  const importBatches = useMemo(() => {
    const list = getAllByOrganization('vendorImportBatches', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || '')))
  }, [currentOrganizationId, dataRevision])

  const committedSales = useMemo(() => {
    const list = getAllByOrganization('sales', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')))
  }, [currentOrganizationId, dataRevision])

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-primary-800">Vendor — Partner uploads</h2>
        <p className="mt-1 text-sm text-neutral">
          Files submitted by your Sport / Partner Vendor. Your club cannot upload sales files here; uploads run in the vendor portal.
        </p>
      </div>

      <div
        className="flex gap-3 rounded-lg border border-amber-200/90 bg-amber-50/90 px-4 py-3 text-sm text-amber-950 shadow-sm"
        role="status"
      >
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" aria-hidden />
        <div>
          <p className="font-medium text-amber-900">Uploads are vendor-only</p>
          <p className="mt-1 text-amber-900/90">
            When the partner processes a file, you will see a confirmation toast and the batch appears below. Revenue share on Payments and
            Talents updates automatically.
          </p>
        </div>
      </div>

      <Card className="border-primary/15 shadow-sm">
        <CardHeader className="flex flex-col gap-2 border-b border-slate-200/90 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2">
            <FileSpreadsheet className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden />
            <div>
              <CardTitle className="text-base">Uploaded sales files (partner)</CardTitle>
              <p className="text-2xs text-neutral">Each row is a file the partner imported into your organization&apos;s ledger.</p>
            </div>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link to="/partner/sales" className="inline-flex items-center gap-1.5">
              <BarChart3 className="h-4 w-4" />
              Full sales &amp; revenue share
            </Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {importBatches.length === 0 ? (
            <p className="p-4 text-sm text-neutral">No partner uploads yet. After the vendor uploads and processes a sales file, it will list here.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-2xs sm:text-xs">
                <thead>
                  <tr className="border-b bg-slate-50 text-left">
                    <th className="px-3 py-2 font-semibold">File name</th>
                    <th className="px-3 py-2 font-semibold">Uploaded</th>
                    <th className="px-3 py-2 text-right font-semibold">Rows processed</th>
                    <th className="px-3 py-2 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {importBatches.map((b) => (
                    <tr key={b.id} className="border-b border-slate-100">
                      <td className="px-3 py-2 font-medium">{b.fileName || '—'}</td>
                      <td className="px-3 py-2 font-mono text-neutral">
                        {b.uploadedAt ? format(new Date(b.uploadedAt), 'yyyy-MM-dd HH:mm') : '—'}
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums">
                        {b.processedCount ?? 0} / {b.rowCount ?? 0}
                      </td>
                      <td className="px-3 py-2 capitalize">{b.status || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-primary/15 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Recent sales lines (from partner uploads)</CardTitle>
          <p className="text-2xs text-neutral">Latest committed rows in your org ledger (same data powers payment and talent revenue share).</p>
        </CardHeader>
        <CardContent className="p-0">
          {committedSales.length === 0 ? (
            <p className="p-4 text-sm text-neutral">No sales in the ledger yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-2xs sm:text-xs">
                <thead>
                  <tr className="border-b bg-slate-50 text-left">
                    <th className="px-3 py-2 font-semibold">SKU</th>
                    <th className="px-3 py-2 font-semibold">Licensee</th>
                    <th className="px-3 py-2 font-semibold">Product</th>
                    <th className="px-3 py-2 text-right font-semibold">Net sales</th>
                    <th className="px-3 py-2 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {committedSales.slice(0, 15).map((row) => (
                    <tr key={row.id} className="border-b border-slate-100">
                      <td className="px-3 py-2 font-mono">{row.sku}</td>
                      <td className="px-3 py-2">{row.licensee}</td>
                      <td className="max-w-[200px] truncate px-3 py-2" title={row.productDescription}>
                        {row.productDescription}
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums">{Number(row.netSales || 0).toLocaleString()}</td>
                      <td className="px-3 py-2 font-mono">{row.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
