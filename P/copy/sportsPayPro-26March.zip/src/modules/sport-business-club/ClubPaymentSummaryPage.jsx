import React, { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { getTalentYearPaymentBreakdown, getMiscellaneousPaymentTotals } from '../../repositories/sportsBusinessRepository'
import {
  inferPaymentSummaryYearOptions,
  EXCLUDED_PAYMENT_REPORT_YEARS,
} from '../../utils/paymentSummaryYears'
import { Card, CardContent } from '../../components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { cn } from '../../utils/cn'
import {
  CalendarRange,
  ChevronDown,
  Gift,
  Layers,
  LayoutGrid,
  Receipt,
  TrendingUp,
  Wallet,
  X,
} from 'lucide-react'
import { ClubPerformanceBonusPage } from './ClubPerformanceBonusPage'
import { ClubRoyaltiesPage } from './ClubRoyaltiesPage'
import { ClubSalaryPage } from './ClubSalaryPage'
import { ClubMiscellaneousPaymentsPage } from './ClubMiscellaneousPaymentsPage'
import { Button } from '../../components/ui/button'

const EXCLUDED_REPORT_YEARS = EXCLUDED_PAYMENT_REPORT_YEARS
const TAB_VALUES = ['summary', 'salary', 'bonus', 'revenue-share', 'miscellaneous']

const TAB_INTRO = {
  summary: {
    title: 'Summary',
    line1: 'Organization-wide payable, paid, and outstanding for the selected year—plus per-talent cards and a consolidated total.',
    line2: 'Salary, bonus, and revenue share follow calendar year; miscellaneous uses the full misc register.',
  },
  salary: {
    title: 'Salary',
    line1: `Contract and payroll salary for the reporting year.`,
    line2: 'Use the chart for top contract values; the table holds full salary line detail.',
  },
  bonus: {
    title: 'Bonus',
    line1: 'Performance and signing bonus totals tied to payroll for the reporting year.',
    line2: 'Chart shows largest accruals by talent; expand the grid for schedules and rows.',
  },
  'revenue-share': {
    title: 'Revenue share',
    line1: 'Revenue share from vendor sales × contract percentages—same ledger as talent and partner views.',
    line2: 'Refreshes when partner uploads are processed; drill into the table for invoice-level detail.',
  },
  miscellaneous: {
    title: 'Miscellaneous',
    line1: 'Fees, stipends, and other payments outside salary, bonus, and revenue-share ledgers.',
    line2: 'Amounts are all-time from the misc register; chart highlights top talents by volume.',
  },
}

function TabIntroStrip({ tabKey, year }) {
  const c = TAB_INTRO[tabKey]
  if (!c) return null
  const line1 =
    tabKey === 'salary'
      ? `Contract and payroll salary for ${year}.`
      : tabKey === 'bonus'
        ? `Performance and signing bonus tied to payroll for ${year}.`
        : c.line1
  return (
    <div className="mb-4 rounded-xl border border-primary/12 bg-gradient-to-r from-slate-100 via-white to-accent/[0.06] px-4 py-3 shadow-sm sm:px-5">
      <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-primary-800">Summary</p>
      <p className="mt-1.5 text-2xs font-medium leading-relaxed text-primary-950/95">{line1}</p>
      <p className="mt-1 text-2xs leading-relaxed text-primary-800/80">{c.line2}</p>
    </div>
  )
}

/** Segmented tabs on navy: inactive glass, active blue + orange accent.
 *  Override shared TabsTrigger inactive text-slate-600 so labels stay readable on dark header. */
function paymentSummaryTabTriggerClass() {
  return cn(
    'flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-lg border px-2 py-2 text-2xs font-semibold transition-all duration-200 sm:gap-2 sm:px-3 sm:text-xs',
    'border-transparent bg-white/5 text-white/90 hover:bg-white/10 hover:text-white',
    'data-[state=inactive]:text-white/90 data-[state=inactive]:hover:bg-white/10 data-[state=inactive]:hover:text-white',
    'data-[state=active]:border-accent/50 data-[state=active]:bg-gradient-to-br data-[state=active]:from-slate-800 data-[state=active]:to-primary-950',
    'data-[state=active]:text-white data-[state=active]:shadow-md',
    'data-[state=active]:ring-1 data-[state=active]:ring-accent/45',
    'data-[state=active]:[box-shadow:inset_0_-2px_0_0_#f97316]'
  )
}

function tripleLabels(kind) {
  if (kind === 'salary')
    return { p: 'Total payable salary', d: 'Total paid salary', o: 'Total outstanding salary' }
  if (kind === 'bonus')
    return { p: 'Total payable bonus', d: 'Total paid bonus', o: 'Total outstanding bonus' }
  if (kind === 'royalty')
    return {
      p: 'Total payable revenue share',
      d: 'Total paid revenue share',
      o: 'Total outstanding revenue share',
    }
  return { p: 'Payable', d: 'Paid', o: 'Outstanding' }
}

function TripleAmountCell({ payable, paid, outstanding, kind, variant = 'table' }) {
  const labels = tripleLabels(kind)
  const stacked = variant === 'stacked'
  return (
    <div className={cn('flex flex-col gap-1.5', stacked ? 'w-full items-stretch' : 'items-end')}>
      <span
        className={cn(
          'flex flex-col gap-0.5 rounded-lg border border-primary/12 bg-white px-2 py-1.5 shadow-sm',
          stacked ? 'w-full' : 'w-full max-w-[14rem] text-left sm:max-w-none'
        )}
        title={`${labels.p}: ${formatINRDisplay(payable)}`}
      >
        <span className="text-[10px] font-semibold uppercase tracking-wide text-primary-800/85">{labels.p}</span>
        <span
          className={cn(
            'text-xs font-bold tabular-nums text-primary-900',
            stacked ? 'text-left' : 'text-right'
          )}
        >
          {formatINRDisplay(payable)}
        </span>
      </span>
      <span
        className={cn(
          'flex flex-col gap-0.5 rounded-lg border border-primary/20 bg-primary/[0.06] px-2 py-1.5 shadow-sm',
          stacked ? 'w-full' : 'w-full max-w-[14rem] text-left sm:max-w-none'
        )}
        title={`${labels.d}: ${formatINRDisplay(paid)}`}
      >
        <span className="text-[10px] font-semibold uppercase tracking-wide text-primary-800">{labels.d}</span>
        <span
          className={cn(
            'text-xs font-bold tabular-nums text-primary-700',
            stacked ? 'text-left' : 'text-right'
          )}
        >
          {formatINRDisplay(paid)}
        </span>
      </span>
      <span
        className={cn(
          'flex flex-col gap-0.5 rounded-lg border border-accent/25 bg-accent/[0.08] px-2 py-1.5 shadow-sm',
          stacked ? 'w-full' : 'w-full max-w-[14rem] text-left sm:max-w-none'
        )}
        title={`${labels.o}: ${formatINRDisplay(outstanding)}`}
      >
        <span className="text-[10px] font-semibold uppercase tracking-wide text-accent-900">{labels.o}</span>
        <span
          className={cn(
            'text-xs font-bold tabular-nums text-accent-800',
            stacked ? 'text-left' : 'text-right'
          )}
        >
          {formatINRDisplay(outstanding)}
        </span>
      </span>
    </div>
  )
}

function talentSummaryInitials(name) {
  if (!name || typeof name !== 'string') return '?'
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

function PaymentSummaryKpiCard({ label, value, hint, emphasis }) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl border px-4 py-3 shadow-sm',
        emphasis
          ? 'border-accent/30 bg-gradient-to-br from-accent/[0.12] to-white'
          : 'border-primary/12 bg-gradient-to-br from-slate-50 to-white'
      )}
    >
      <p className="text-[10px] font-bold uppercase tracking-wide text-primary-800/75">{label}</p>
      <p className={cn('mt-1 text-sm font-bold tabular-nums sm:text-base', emphasis ? 'text-accent-900' : 'text-primary-900')}>
        {value}
      </p>
      {hint && <p className="mt-0.5 text-2xs text-primary-700/65">{hint}</p>}
    </div>
  )
}

function TalentPaymentSummaryCard({ talent, b, summaryYear, miscTalent, grandOutstanding, focusTalentId }) {
  const expandedByDefault = !focusTalentId || focusTalentId === talent.id
  const [detailOpen, setDetailOpen] = useState(expandedByDefault)
  const headerId = `payment-summary-talent-h-${talent.id}`
  const panelId = `payment-summary-talent-p-${talent.id}`

  useEffect(() => {
    setDetailOpen(!focusTalentId || focusTalentId === talent.id)
  }, [focusTalentId, talent.id])

  return (
    <div
      id={`payment-summary-roster-talent-${talent.id}`}
      className="flex scroll-mt-24 overflow-hidden rounded-xl border border-primary/12 bg-white shadow-md shadow-primary/5"
    >
      <div
        className="w-1.5 shrink-0 bg-gradient-to-b from-accent-400 via-accent-500 to-accent-600 sm:w-2"
        aria-hidden
      />
      <div className="min-w-0 flex-1 space-y-3 bg-gradient-to-r from-accent/[0.03] to-white p-4 sm:p-5">
        <button
          type="button"
          id={headerId}
          className="flex w-full flex-wrap items-center gap-3 rounded-lg border-b border-primary/10 pb-3 text-left transition-colors hover:bg-primary/[0.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/25"
          onClick={() => setDetailOpen((v) => !v)}
          aria-expanded={detailOpen}
          aria-controls={panelId}
        >
          <div
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/15 bg-primary/[0.08] text-2xs font-bold text-primary-900"
            aria-hidden
          >
            {talentSummaryInitials(talent.name)}
          </div>
          <div className="min-w-0 flex-1">
            <span className="block text-sm font-bold tracking-tight text-primary-950">{talent.name || '—'}</span>
            <p className="mt-0.5 text-2xs text-primary-700/80">
              Payment position · calendar {summaryYear} · salary, bonus &amp; revenue share; misc all-time
            </p>
          </div>
          <div className="rounded-lg border border-accent/30 bg-accent/[0.1] px-3 py-2 text-right">
            <p className="text-[9px] font-bold uppercase tracking-wide text-accent-900">Total outstanding</p>
            <p className="text-sm font-bold tabular-nums text-accent-900">{formatINRDisplay(grandOutstanding)}</p>
          </div>
          <ChevronDown
            className={cn(
              'h-4 w-4 shrink-0 text-primary-700 transition-transform duration-200',
              detailOpen && 'rotate-180'
            )}
            aria-hidden
          />
        </button>
        {detailOpen ? (
          <div
            id={panelId}
            role="region"
            aria-labelledby={headerId}
            className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4"
          >
          <div className="rounded-lg border border-primary/10 bg-white/90 p-2.5 shadow-inner">
            <p className="mb-2 border-b border-primary/10 pb-1 text-[10px] font-bold uppercase tracking-wide text-primary-900">
              Salary
            </p>
            <TripleAmountCell
              payable={b.salary.payable}
              paid={b.salary.paid}
              outstanding={b.salary.outstanding}
              kind="salary"
              variant="stacked"
            />
          </div>
          <div className="rounded-lg border border-primary/10 bg-white/90 p-2.5 shadow-inner">
            <p className="mb-2 border-b border-primary/10 pb-1 text-[10px] font-bold uppercase tracking-wide text-primary-900">
              Bonus
            </p>
            <TripleAmountCell
              payable={b.bonus.payable}
              paid={b.bonus.paid}
              outstanding={b.bonus.outstanding}
              kind="bonus"
              variant="stacked"
            />
          </div>
          <div className="rounded-lg border border-primary/10 bg-white/90 p-2.5 shadow-inner">
            <p className="mb-2 border-b border-primary/10 pb-1 text-[10px] font-bold uppercase tracking-wide text-primary-900">
              Revenue share
            </p>
            <TripleAmountCell
              payable={b.royalty.payable}
              paid={b.royalty.paid}
              outstanding={b.royalty.outstanding}
              kind="royalty"
              variant="stacked"
            />
          </div>
          <div className="flex flex-col justify-between rounded-lg border border-primary/10 bg-white/90 p-2.5 shadow-inner">
            <p className="mb-2 border-b border-primary/10 pb-1 text-[10px] font-bold uppercase tracking-wide text-primary-900">
              Miscellaneous
            </p>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-primary-800/80">Total miscellaneous</p>
            <p className="mt-1 text-base font-bold tabular-nums text-primary-900">{formatINRDisplay(miscTalent)}</p>
            <p className="mt-2 text-2xs leading-snug text-primary-700/70">All periods from misc register</p>
          </div>
        </div>
        ) : null}
      </div>
    </div>
  )
}

export function ClubPaymentSummaryPage() {
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const [searchParams, setSearchParams] = useSearchParams()
  const { loading, loadMessage } = usePageLoadAuto('Loading payment summary...', 'Payment summary loaded')

  const tabFromUrl = searchParams.get('tab') || 'summary'
  const activeTab = TAB_VALUES.includes(tabFromUrl) ? tabFromUrl : 'summary'

  const yearOptions = useMemo(() => {
    const filtered = inferPaymentSummaryYearOptions(currentOrganizationId).filter((y) => !EXCLUDED_REPORT_YEARS.has(y))
    const cur = String(new Date().getFullYear())
    if (filtered.length > 0) return filtered
    return EXCLUDED_REPORT_YEARS.has(cur) ? ['2026', '2025', '2024'] : [cur]
  }, [currentOrganizationId, dataRevision])

  const defaultYear = useMemo(() => {
    const cur = String(new Date().getFullYear())
    if (yearOptions.includes(cur)) return cur
    return yearOptions[0] || cur
  }, [yearOptions])

  const [summaryYear, setSummaryYear] = useState(() => String(new Date().getFullYear()))
  const [rosterDetailOpen, setRosterDetailOpen] = useState(true)

  const yearFromUrl = searchParams.get('year')
  const fromParam = searchParams.get('from') || ''
  const focusTalentId = searchParams.get('talentId') || searchParams.get('talent') || ''

  useEffect(() => {
    setSummaryYear((prev) => (yearOptions.includes(prev) ? prev : defaultYear))
  }, [currentOrganizationId, yearOptions, defaultYear])

  useEffect(() => {
    if (yearFromUrl && yearOptions.includes(yearFromUrl)) setSummaryYear(yearFromUrl)
  }, [yearFromUrl, yearOptions])

  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const miscRows = useMemo(
    () => getAllByOrganization('miscellaneousPayments', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const talentsSorted = useMemo(
    () => [...(talents || [])].sort((a, b) => (a.name || '').localeCompare(b.name || '')),
    [talents]
  )

  /** Deep-linked from dashboard → always org-wide. Otherwise `talentId` in URL scopes salary/bonus/revenue/misc to that roster member. */
  const scopedTalentId = useMemo(() => {
    if (fromParam === 'dashboard') return ''
    if (!focusTalentId) return ''
    return (talentsSorted || []).some((t) => t.id === focusTalentId) ? focusTalentId : ''
  }, [fromParam, focusTalentId, talentsSorted])

  const scopedTalentName = useMemo(
    () => (scopedTalentId ? talentsSorted.find((t) => t.id === scopedTalentId)?.name : '') || '',
    [scopedTalentId, talentsSorted]
  )

  const breakdownByTalent = useMemo(() => {
    return talentsSorted.map((t) => ({
      talent: t,
      b: getTalentYearPaymentBreakdown(t.id, currentOrganizationId, summaryYear),
    }))
  }, [talentsSorted, currentOrganizationId, summaryYear, dataRevision])

  useEffect(() => {
    if (!focusTalentId || activeTab !== 'summary') return
    setRosterDetailOpen(true)
    const elId = `payment-summary-roster-talent-${focusTalentId}`
    const t = window.setTimeout(() => {
      document.getElementById(elId)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 120)
    return () => window.clearTimeout(t)
  }, [focusTalentId, activeTab, breakdownByTalent.length, loading])

  const breakdownTotals = useMemo(() => {
    const z = () => ({ payable: 0, paid: 0, outstanding: 0 })
    const acc = { salary: z(), bonus: z(), royalty: z() }
    for (const { b } of breakdownByTalent) {
      acc.salary.payable += b.salary.payable
      acc.salary.paid += b.salary.paid
      acc.salary.outstanding += b.salary.outstanding
      acc.bonus.payable += b.bonus.payable
      acc.bonus.paid += b.bonus.paid
      acc.bonus.outstanding += b.bonus.outstanding
      acc.royalty.payable += b.royalty.payable
      acc.royalty.paid += b.royalty.paid
      acc.royalty.outstanding += b.royalty.outstanding
    }
    const misc = getMiscellaneousPaymentTotals(currentOrganizationId)
    const grandOut = acc.salary.outstanding + acc.bonus.outstanding + acc.royalty.outstanding + misc.outstanding
    return { ...acc, misc, grandOut }
  }, [breakdownByTalent, currentOrganizationId, dataRevision])

  /** Org totals, or single-talent slice when scoped (matches talent detail / year breakdown). */
  const tabTotals = useMemo(() => {
    if (!scopedTalentId) return breakdownTotals
    const b = getTalentYearPaymentBreakdown(scopedTalentId, currentOrganizationId, summaryYear)
    const rows = (miscRows || []).filter((r) => r.talentId === scopedTalentId)
    const misc = {
      payable: rows.reduce((a, r) => a + (Number(r.amount) || 0), 0),
      paid: rows.filter((r) => r.paymentStatus === 'paid').reduce((a, r) => a + (Number(r.amount) || 0), 0),
      outstanding: rows.filter((r) => r.paymentStatus === 'pending').reduce((a, r) => a + (Number(r.amount) || 0), 0),
    }
    const grandOut = b.salary.outstanding + b.bonus.outstanding + b.royalty.outstanding + misc.outstanding
    return { salary: b.salary, bonus: b.bonus, royalty: b.royalty, misc, grandOut }
  }, [scopedTalentId, breakdownTotals, currentOrganizationId, summaryYear, miscRows, dataRevision])

  const breakdownByTalentForSummary = useMemo(() => {
    if (!scopedTalentId) return breakdownByTalent
    return breakdownByTalent.filter(({ talent }) => talent.id === scopedTalentId)
  }, [breakdownByTalent, scopedTalentId])

  const summaryOverviewKpis = useMemo(() => {
    const s = tabTotals.salary
    const b = tabTotals.bonus
    const r = tabTotals.royalty
    const m = tabTotals.misc
    return {
      payable: s.payable + b.payable + r.payable + m.payable,
      paid: s.paid + b.paid + r.paid + m.paid,
      outstanding: s.outstanding + b.outstanding + r.outstanding + m.outstanding,
      talentCount: scopedTalentId ? 1 : breakdownByTalent.length,
    }
  }, [tabTotals, scopedTalentId, breakdownByTalent.length])

  const setTab = (v) => {
    const next = new URLSearchParams(searchParams)
    next.set('tab', v)
    if (next.get('from') === 'dashboard') next.delete('from')
    if (summaryYear && yearOptions.includes(summaryYear)) next.set('year', summaryYear)
    setSearchParams(next, { replace: true })
  }

  const handleSummaryYearChange = (y) => {
    setSummaryYear(y)
    const next = new URLSearchParams(searchParams)
    next.set('year', y)
    setSearchParams(next, { replace: true })
  }

  const fromDashboard = fromParam === 'dashboard'

  const clearTalentScope = () => {
    const next = new URLSearchParams(searchParams)
    next.delete('talentId')
    next.delete('talent')
    next.delete('from')
    setSearchParams(next, { replace: true })
  }

  const dismissFromDashboard = () => {
    const next = new URLSearchParams(searchParams)
    next.delete('from')
    setSearchParams(next, { replace: true })
  }

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <Tabs value={activeTab} onValueChange={setTab} className="w-full">
      <div className="overflow-hidden rounded-2xl border border-primary/15 bg-white shadow-[0_12px_40px_-12px_rgba(11,60,93,0.22)]">
        <div className="relative bg-gradient-to-br from-slate-800 via-slate-700 to-primary-800 px-5 pb-0 pt-8 sm:px-8">
          <div
            className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-accent/12"
            aria-hidden
          />
          <div className="relative flex flex-col gap-4">
            {fromDashboard && (
              <div className="flex flex-col gap-3 rounded-xl border border-white/25 bg-white/[0.12] px-4 py-3 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
                <p className="text-2xs leading-relaxed text-white/90 sm:text-xs">
                  <span className="font-semibold text-accent">Linked from the club dashboard.</span> Tab selection matches the
                  category you opened; figures use the same rules as dashboard charts.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="shrink-0 border-white/40 bg-white/95 text-primary hover:bg-white"
                  onClick={dismissFromDashboard}
                >
                  <X className="mr-1 h-4 w-4" aria-hidden />
                  Dismiss
                </Button>
              </div>
            )}
            {scopedTalentId && !fromDashboard && (
              <div className="flex flex-col gap-3 rounded-xl border border-accent/40 bg-accent/[0.15] px-4 py-3 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
                <p className="text-2xs leading-relaxed text-white/95 sm:text-xs">
                  <span className="font-semibold text-white">Viewing one roster member:</span>{' '}
                  <span className="font-bold text-accent">{scopedTalentName || 'Talent'}</span>. Salary, Bonus, Revenue share, and Misc
                  tabs show amounts for this talent only. Open Payment summary without a talent link to see the full club.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="shrink-0 border-white/40 bg-white/95 text-primary hover:bg-white"
                  onClick={clearTalentScope}
                >
                  <X className="mr-1 h-4 w-4" aria-hidden />
                  View all talents
                </Button>
              </div>
            )}

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
              <div className="flex w-full flex-col gap-2 rounded-xl border border-white/15 bg-white/10 px-4 py-3 shadow-inner backdrop-blur-md sm:ml-auto sm:w-auto sm:flex-row sm:items-center">
                <div className="flex items-center gap-2 text-white">
                  <CalendarRange className="h-4 w-4 shrink-0 text-white/90" aria-hidden />
                  <span className="text-2xs font-semibold uppercase tracking-wide text-white/85">Reporting year</span>
                </div>
                <Select value={summaryYear} onValueChange={handleSummaryYearChange}>
                  <SelectTrigger className="h-9 w-full border-0 bg-white font-mono text-sm font-bold text-primary shadow-md sm:w-[112px]">
                    <SelectValue placeholder="Year" />
                  </SelectTrigger>
                  <SelectContent>
                    {yearOptions.map((y) => (
                      <SelectItem key={y} value={y}>
                        {y}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsList className="grid h-auto w-full grid-cols-2 gap-1.5 rounded-xl border border-white/10 bg-black/20 p-1.5 sm:grid-cols-5">
              {[
                { v: 'summary', label: 'Summary', icon: Layers },
                { v: 'salary', label: 'Salary', icon: Receipt },
                { v: 'bonus', label: 'Bonus', icon: Gift },
                { v: 'revenue-share', label: 'Revenue share', icon: TrendingUp },
                { v: 'miscellaneous', label: 'Misc', icon: Wallet },
              ].map(({ v, label, icon: Icon }) => (
                <TabsTrigger key={v} value={v} className={paymentSummaryTabTriggerClass()}>
                  <Icon className="h-3.5 w-3.5 shrink-0 opacity-90" aria-hidden />
                  <span className="text-center leading-tight">{label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </div>

        <div className="border-t border-slate-200/90 bg-gradient-to-b from-slate-50/95 to-slate-100/50 px-4 py-5 sm:px-6 sm:py-6">
          <TabsContent value="summary" className="mt-0 rounded-none border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
          <Card className="rounded-xl border border-primary/10 bg-white shadow-md shadow-primary/5">
            <CardContent className="space-y-4 p-4 sm:p-6">
              <TabIntroStrip tabKey="summary" year={summaryYear} />

              <div className="rounded-xl border border-primary/10 bg-gradient-to-r from-slate-50 to-white px-4 py-3 shadow-inner">
                <div className="flex flex-wrap items-center gap-2">
                  <LayoutGrid className="h-4 w-4 text-primary" aria-hidden />
                  <span className="text-2xs font-bold uppercase tracking-wide text-primary-900">
                    {scopedTalentId ? 'Talent snapshot' : 'Organization snapshot'}
                  </span>
                  <span className="text-2xs text-primary-700/70">
                    · {summaryYear} payroll &amp; ledger
                    {scopedTalentId && scopedTalentName ? ` · ${scopedTalentName}` : ''}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
                  <PaymentSummaryKpiCard
                    label="Total payable"
                    value={formatINRDisplay(summaryOverviewKpis.payable)}
                    hint="Salary + bonus + revenue share + misc"
                  />
                  <PaymentSummaryKpiCard
                    label="Total paid"
                    value={formatINRDisplay(summaryOverviewKpis.paid)}
                    hint={`Recognized in ${summaryYear} (streams above)`}
                  />
                  <PaymentSummaryKpiCard
                    label="Total outstanding"
                    value={formatINRDisplay(summaryOverviewKpis.outstanding)}
                    hint="Pending across all streams"
                    emphasis
                  />
                  <PaymentSummaryKpiCard
                    label={scopedTalentId ? 'Roster focus' : 'Talents in view'}
                    value={String(summaryOverviewKpis.talentCount)}
                    hint={scopedTalentId ? 'Single talent (deep link)' : 'Cards listed below'}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <button
                  type="button"
                  className={cn(
                    'flex w-full items-center justify-between gap-3 rounded-xl border border-primary/12 bg-primary/[0.04] px-3 py-2.5 text-left shadow-sm transition-colors hover:bg-primary/[0.07]',
                    rosterDetailOpen && 'rounded-b-none border-b-0 bg-primary/[0.06]'
                  )}
                  onClick={() => setRosterDetailOpen((v) => !v)}
                  aria-expanded={rosterDetailOpen}
                  id="payment-summary-roster-detail-trigger"
                >
                  <div className="min-w-0">
                    <h3 className="text-2xs font-bold uppercase tracking-wide text-primary-900">Roster detail</h3>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <span className="text-2xs font-medium text-primary-800/80">
                      {breakdownByTalentForSummary.length} talent(s)
                    </span>
                    <ChevronDown
                      className={cn('h-4 w-4 text-primary-700 transition-transform duration-200', rosterDetailOpen && 'rotate-180')}
                      aria-hidden
                    />
                  </div>
                </button>
                {rosterDetailOpen ? (
                  <div
                    className="space-y-4 border border-t-0 border-primary/12 bg-white/40 px-3 pb-3 pt-2 sm:px-4 sm:pb-4"
                    role="region"
                    aria-labelledby="payment-summary-roster-detail-trigger"
                  >
                    {breakdownByTalentForSummary.map(({ talent, b }) => {
                      const miscTalent = (miscRows || [])
                        .filter((r) => r.talentId === talent.id)
                        .reduce((a, r) => a + (Number(r.amount) || 0), 0)
                      const miscOut = (miscRows || [])
                        .filter((r) => r.talentId === talent.id && r.paymentStatus === 'pending')
                        .reduce((a, r) => a + (Number(r.amount) || 0), 0)
                      const gOut =
                        (b.salary?.outstanding || 0) +
                        (b.bonus?.outstanding || 0) +
                        (b.royalty?.outstanding || 0) +
                        miscOut
                      return (
                        <TalentPaymentSummaryCard
                          key={talent.id}
                          talent={talent}
                          b={b}
                          summaryYear={summaryYear}
                          miscTalent={miscTalent}
                          grandOutstanding={gOut}
                          focusTalentId={focusTalentId}
                        />
                      )
                    })}
                  </div>
                ) : null}
              </div>

              {breakdownByTalentForSummary.length > 0 && (
                <div className="flex flex-col gap-4 rounded-xl border-2 border-primary/20 bg-gradient-to-br from-slate-100 via-white to-accent/[0.06] p-4 shadow-lg shadow-primary/10 sm:flex-row sm:items-stretch sm:justify-between sm:p-5">
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-primary-900">
                      {scopedTalentId ? 'Talent total' : 'Organization total'}
                    </p>
                    <p className="mt-1 text-sm font-bold text-primary-950">
                      {scopedTalentId ? `${scopedTalentName || 'Talent'} · ${summaryYear}` : `All talents · ${summaryYear}`}
                    </p>
                    <p className="mt-1 text-2xs text-primary-800/75">
                      {scopedTalentId
                        ? 'Salary, bonus, and revenue share for this talent and year; miscellaneous rows for this talent only.'
                        : 'Aggregated salary, bonus, and revenue share for the year; miscellaneous from full register.'}
                    </p>
                  </div>
                  <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-3">
                    <div className="rounded-lg border border-primary/12 bg-white/90 p-3 shadow-sm">
                      <p className="text-[9px] font-bold uppercase text-primary-800">Salary</p>
                      <TripleAmountCell
                        payable={tabTotals.salary.payable}
                        paid={tabTotals.salary.paid}
                        outstanding={tabTotals.salary.outstanding}
                        kind="salary"
                        variant="stacked"
                      />
                    </div>
                    <div className="rounded-lg border border-primary/12 bg-white/90 p-3 shadow-sm">
                      <p className="text-[9px] font-bold uppercase text-primary-800">Bonus</p>
                      <TripleAmountCell
                        payable={tabTotals.bonus.payable}
                        paid={tabTotals.bonus.paid}
                        outstanding={tabTotals.bonus.outstanding}
                        kind="bonus"
                        variant="stacked"
                      />
                    </div>
                    <div className="rounded-lg border border-primary/12 bg-white/90 p-3 shadow-sm">
                      <p className="text-[9px] font-bold uppercase text-primary-800">Revenue share</p>
                      <TripleAmountCell
                        payable={tabTotals.royalty.payable}
                        paid={tabTotals.royalty.paid}
                        outstanding={tabTotals.royalty.outstanding}
                        kind="royalty"
                        variant="stacked"
                      />
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col justify-center gap-2 rounded-xl border border-accent/35 bg-white/95 px-4 py-3 text-center shadow-md sm:max-w-[200px]">
                    <p className="text-[10px] font-bold uppercase tracking-wide text-accent-900">Grand outstanding</p>
                    <p className="text-lg font-bold tabular-nums text-accent-900">{formatINRDisplay(tabTotals.grandOut)}</p>
                    <p className="text-2xs text-primary-800/70">Misc payable (register): {formatINRDisplay(tabTotals.misc.payable)}</p>
                  </div>
                </div>
              )}

              {breakdownByTalentForSummary.length === 0 && (
                <p className="rounded-lg border border-dashed border-primary/20 bg-primary/[0.03] py-8 text-center text-sm text-primary-800/80">
                  No talents in this organization.
                </p>
              )}
              <p className="text-2xs text-primary-800/65">
                Revenue share follows the central sales ledger. Per-talent outstanding includes pending miscellaneous for that
                talent.
              </p>
            </CardContent>
          </Card>
          </TabsContent>

          <TabsContent value="salary" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
          <Card className="rounded-xl border border-primary/10 bg-white shadow-md shadow-primary/5">
            <CardContent className="space-y-4 p-4 sm:p-6">
              <div className={cn(!scopedTalentId && 'max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1')}>
                <ClubSalaryPage
                  key={`salary-${summaryYear}-${scopedTalentId || 'all'}-${dataRevision}`}
                  embedded
                  filterYear={summaryYear}
                  filterTalentId={scopedTalentId || null}
                  fromDashboard={fromDashboard}
                  engineTotals={tabTotals.salary}
                />
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          <TabsContent value="bonus" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
          <Card className="rounded-xl border border-primary/10 bg-white shadow-md shadow-primary/5">
            <CardContent className="space-y-4 p-4 sm:p-6">
              <div className={cn(!scopedTalentId && 'max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1')}>
                <ClubPerformanceBonusPage
                  key={`bonus-${summaryYear}-${scopedTalentId || 'all'}-${dataRevision}`}
                  embedded
                  filterYear={summaryYear}
                  filterTalentId={scopedTalentId || null}
                  fromDashboard={fromDashboard}
                  engineTotals={tabTotals.bonus}
                />
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          <TabsContent value="revenue-share" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
          <Card className="rounded-xl border border-primary/10 bg-white shadow-md shadow-primary/5">
            <CardContent className="space-y-4 p-4 sm:p-6">
              <div className={cn(!scopedTalentId && 'max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1')}>
                <ClubRoyaltiesPage
                  key={`royalty-${summaryYear}-${scopedTalentId || 'all'}-${dataRevision}`}
                  embedded
                  filterYear={summaryYear}
                  filterTalentId={scopedTalentId || null}
                  fromDashboard={fromDashboard}
                  engineTotals={tabTotals.royalty}
                />
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          <TabsContent value="miscellaneous" className="mt-0 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0">
          <Card className="rounded-xl border border-primary/10 bg-white shadow-md shadow-primary/5">
            <CardContent className="space-y-4 p-4 sm:p-6">
              <div className={cn(!scopedTalentId && 'max-h-[75vh] overflow-y-auto overflow-x-hidden pr-1')}>
                <ClubMiscellaneousPaymentsPage
                  key={`misc-${summaryYear}-${scopedTalentId || 'all'}-${dataRevision}`}
                  embedded
                  filterYear={summaryYear}
                  filterTalentId={scopedTalentId || null}
                  fromDashboard={fromDashboard}
                  engineTotals={tabTotals.misc}
                />
              </div>
            </CardContent>
          </Card>
          </TabsContent>
        </div>
      </div>
    </Tabs>
  )
}
