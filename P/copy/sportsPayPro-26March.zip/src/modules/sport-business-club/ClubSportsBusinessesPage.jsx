import React, { useState } from 'react'
import { useDatabase } from '../../hooks/useDatabase'
import { getAll } from '../../database/dbService'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Label } from '../../components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../components/ui/dialog'
import { DataTable } from '../../components/tables/DataTable'
import { Plus, Pencil, Trash2 } from 'lucide-react'

const columns = [
  { id: 'businessName', header: 'Business Name', accessorKey: 'businessName', cell: (v) => v.getValue() },
  { id: 'revenueRecognized', header: 'Revenue Recognized', accessorKey: 'revenueRecognized', cell: (v) => `$${Number(v.getValue()).toLocaleString()}` },
  { id: 'revenueSharePercent', header: 'Revenue Share %', accessorKey: 'revenueSharePercent', cell: (v) => `${((v.getValue()) * 100).toFixed(1)}%` },
  { id: 'minimumGuarantee', header: 'Min. Guarantee', accessorKey: 'minimumGuarantee', cell: (v) => `$${Number(v.getValue()).toLocaleString()}` },
]

export function ClubSportsBusinessesPage() {
  const { data, create, update, remove } = useDatabase('sportsBusinesses')
  const talents = getAll('talents')
  const [editing, setEditing] = useState(null)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({
    businessName: '',
    revenueRecognized: '',
    revenueSharePercent: '',
    minimumGuarantee: '',
    talentsAssociated: [],
  })

  const resetForm = () => {
    setForm({
      businessName: '',
      revenueRecognized: '',
      revenueSharePercent: '',
      minimumGuarantee: '',
      talentsAssociated: [],
    })
    setEditing(null)
    setOpen(false)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const payload = {
      businessName: form.businessName,
      revenueRecognized: Number(form.revenueRecognized) || 0,
      revenueSharePercent: Number(form.revenueSharePercent) / 100 || 0,
      minimumGuarantee: Number(form.minimumGuarantee) || 0,
      talentsAssociated: form.talentsAssociated,
    }
    if (editing) {
      update(editing.id, payload)
    } else {
      create(payload)
    }
    resetForm()
  }

  const openEdit = (row) => {
    setEditing(row)
    setForm({
      businessName: row.businessName || '',
      revenueRecognized: String(row.revenueRecognized ?? ''),
      revenueSharePercent: String((row.revenueSharePercent ?? 0) * 100),
      minimumGuarantee: String(row.minimumGuarantee ?? ''),
      talentsAssociated: row.talentsAssociated || [],
    })
    setOpen(true)
  }

  const cols = [
    ...columns,
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => remove(row.original.id)}>
            <Trash2 className="h-4 w-4 text-red-600" />
          </Button>
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <h2 className="text-xl font-semibold">Sports Businesses</h2>
        <Button onClick={() => { setEditing(null); setForm({ businessName: '', revenueRecognized: '', revenueSharePercent: '', minimumGuarantee: '', talentsAssociated: [] }); setOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" /> Add Business
        </Button>
      </div>
      <DataTable columns={cols} data={data} searchKey="businessName" searchPlaceholder="Search businesses..." />

      <Dialog open={open} onOpenChange={(v) => !v && resetForm()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Business' : 'Add Business'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Business Name</Label>
              <Input value={form.businessName} onChange={(e) => setForm((f) => ({ ...f, businessName: e.target.value }))} required />
            </div>
            <div className="space-y-2">
              <Label>Revenue Recognized</Label>
              <Input type="number" value={form.revenueRecognized} onChange={(e) => setForm((f) => ({ ...f, revenueRecognized: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Revenue Share %</Label>
              <Input type="number" step="0.1" value={form.revenueSharePercent} onChange={(e) => setForm((f) => ({ ...f, revenueSharePercent: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Minimum Guarantee</Label>
              <Input type="number" value={form.minimumGuarantee} onChange={(e) => setForm((f) => ({ ...f, minimumGuarantee: e.target.value }))} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={resetForm}>Cancel</Button>
              <Button type="submit">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
