import React, { useMemo, useState, useEffect } from 'react'
import { cn } from '../../utils/cn'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger, getRoyaltyByTalent } from '../../utils/revenueEngine'
import { StatCard } from '../../components/cards/StatCard'
import { DataTable } from '../../components/tables/DataTable'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { DollarSign, TrendingUp, Filter, User } from 'lucide-react'
import { Checkbox } from '../../components/ui/checkbox'
import { Button } from '../../components/ui/button'
import { PaymentTripleAmountBarChart } from '../../components/charts/PaymentTripleAmountBarChart'
import { PaymentPaidOutstandingDonutChart } from '../../components/charts/PaymentPaidOutstandingDonutChart'
import { PaymentTabIntroStrip, PAYMENT_TAB_CHART_SHELL } from './paymentSummaryTabIntro'
import { format } from 'date-fns'
import { formatDisplayDate } from '../../utils/dateFormat'
import { formatINRDisplay } from '../../utils/currencyFormat'

function rowBookingMonth(row) {
  const d = row?.date
  if (!d) return null
  return typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')
}

function monthLabel(ym) {
  if (!ym || typeof ym !== 'string') return '—'
  const [y, m] = ym.split('-')
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  return idx >= 0 && idx < 12 ? `${names[idx]} ${y}` : ym
}

function invoiceBookingMonth(inv) {
  const d = inv?.date || inv?.issueDate || inv?.invoiceDate
  return d ? String(d).slice(0, 7) : null
}

function aggregateRoyaltyByMonth(ledger) {
  const byMonth = {}
  ;(ledger || []).forEach((r) => {
    const key = rowBookingMonth(r) || 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

function aggregateRoyaltyByMonthForYear(ledger, year) {
  const y = String(year)
  const keys = []
  for (let m = 1; m <= 12; m++) keys.push(`${y}-${String(m).padStart(2, '0')}`)
  const byMonth = Object.fromEntries(keys.map((k) => [k, 0]))
  ;(ledger || []).forEach((r) => {
    const key = rowBookingMonth(r)
    if (!key || !key.startsWith(`${y}-`)) return
    byMonth[key] = (byMonth[key] || 0) + Number(r.royaltyEarned || 0)
  })
  return keys.map((month) => ({ month, revenue: byMonth[month] || 0 }))
}

/**
 * Club royalties page (Sport Business / Club) – based on sales (ledger).
 * Shows revenue share total, paid, and pending.
 */
/**
 * @param {{ embedded?: boolean, filterYear?: string | number | null, filterTalentId?: string | null, fromDashboard?: boolean, engineTotals?: { payable: number, paid: number, outstanding: number } | null }} props
 * When `filterYear` is set, stats, charts, and tables (except full standalone ledger) are scoped to that calendar year.
 * When `filterTalentId` is set, scope ledger and invoices to that talent (Payment summary from talent detail).
 */
export function ClubRoyaltiesPage({
  embedded = false,
  filterYear = null,
  filterTalentId = null,
  fromDashboard = false,
  engineTotals = null,
} = {}) {
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()
  const { loading, loadMessage } = usePageLoadAuto('Calculating revenue share...', 'Revenue share data loaded', 600, embedded)
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId, dataRevision])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId, dataRevision])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId, dataRevision])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId, dataRevision])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId, dataRevision])

  const lockedTalentName = useMemo(() => {
    if (!filterTalentId) return ''
    return (talents || []).find((t) => t.id === filterTalentId)?.name || ''
  }, [filterTalentId, talents])

  const paymentSummaryEmbed = Boolean(embedded && engineTotals)
  const paymentSummaryEmbedLocked = Boolean(embedded && filterTalentId)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])

  useEffect(() => {
    if (embedded && filterTalentId) setSelectedTalentIds([filterTalentId])
  }, [embedded, filterTalentId])

  const ledgerAll = useMemo(
    () => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses),
    [sales, contracts, talents, sportsBusinesses]
  )
  const yearKey = filterYear != null && filterYear !== '' ? String(filterYear) : null

  const ledgerInYear = useMemo(() => {
    let rows = ledgerAll || []
    if (yearKey) {
      rows = rows.filter((r) => {
        const ym = rowBookingMonth(r)
        return ym && ym.startsWith(`${yearKey}-`)
      })
    }
    return rows
  }, [ledgerAll, yearKey])

  const ledgerDisplayed = useMemo(() => {
    let rows = ledgerInYear
    if (filterTalentId) return rows.filter((r) => r.talentId === filterTalentId)
    if (paymentSummaryEmbed && fromDashboard && selectedTalentIds.length > 0) {
      return rows.filter((r) => selectedTalentIds.includes(r.talentId))
    }
    return rows
  }, [ledgerInYear, filterTalentId, paymentSummaryEmbed, fromDashboard, selectedTalentIds])

  const invoicesInYear = useMemo(() => {
    let inv = invoices || []
    if (yearKey) {
      inv = inv.filter((row) => {
        const ym = invoiceBookingMonth(row)
        return ym && ym.startsWith(`${yearKey}-`)
      })
    }
    return inv
  }, [invoices, yearKey])

  const invoicesDisplayed = useMemo(() => {
    let inv = invoicesInYear
    if (filterTalentId) return inv.filter((row) => row.talentId === filterTalentId)
    if (paymentSummaryEmbed && fromDashboard && selectedTalentIds.length > 0) {
      return inv.filter((row) => selectedTalentIds.includes(row.talentId))
    }
    return inv
  }, [invoicesInYear, filterTalentId, paymentSummaryEmbed, fromDashboard, selectedTalentIds])

  const talentOptions = useMemo(() => {
    const map = new Map()
    ledgerInYear.forEach((r) => {
      if (r.talentId && r.talentName) map.set(r.talentId, r.talentName)
    })
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }))
  }, [ledgerInYear])

  const royaltyTotal = useMemo(() => ledgerDisplayed.reduce((a, r) => a + (r.royaltyEarned || 0), 0), [ledgerDisplayed])
  const royaltyPaid = useMemo(
    () => invoicesDisplayed.reduce((a, inv) => a + (Number(inv.paidAmount) || 0), 0),
    [invoicesDisplayed]
  )
  const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)

  const headerRoyalty = useMemo(() => {
    if (!paymentSummaryEmbed || !engineTotals) return null
    if (filterTalentId) return engineTotals
    if (!fromDashboard || selectedTalentIds.length === 0) return engineTotals
    return { payable: royaltyTotal, paid: royaltyPaid, outstanding: royaltyPending }
  }, [
    paymentSummaryEmbed,
    engineTotals,
    filterTalentId,
    fromDashboard,
    selectedTalentIds.length,
    royaltyTotal,
    royaltyPaid,
    royaltyPending,
  ])

  const showDashboardTalentFilter = paymentSummaryEmbed && fromDashboard && !filterTalentId

  const royaltyByTalent = useMemo(() => getRoyaltyByTalent(ledgerDisplayed), [ledgerDisplayed])
  const royaltyMonthlyData = useMemo(() => {
    if (yearKey) return aggregateRoyaltyByMonthForYear(ledgerDisplayed, yearKey)
    return aggregateRoyaltyByMonth(ledgerDisplayed)
  }, [ledgerDisplayed, yearKey])

  // Per-talent revenue share total, paid, pending for the listing table
  const royaltyByTalentRows = useMemo(() => {
    const totalByTalent = {}
    ledgerDisplayed.forEach((r) => {
      const name = r.talentName || 'Unknown'
      totalByTalent[name] = (totalByTalent[name] || 0) + Number(r.royaltyEarned || 0)
    })
    const paidByTalent = {}
    invoicesDisplayed.forEach((inv) => {
      const name = inv.talentName || 'Unknown'
      paidByTalent[name] = (paidByTalent[name] || 0) + Number(inv.paidAmount || 0)
    })
    const allNames = new Set([...Object.keys(totalByTalent), ...Object.keys(paidByTalent)])
    return Array.from(allNames)
      .map((name) => {
        const royaltyTotal = totalByTalent[name] || 0
        const royaltyPaid = paidByTalent[name] || 0
        const royaltyPending = Math.max(0, royaltyTotal - royaltyPaid)
        return { talentName: name, royaltyTotal, royaltyPaid, royaltyPending }
      })
      .filter((row) => row.royaltyTotal > 0 || row.royaltyPaid > 0)
      .sort((a, b) => b.royaltyTotal - a.royaltyTotal)
  }, [ledgerDisplayed, invoicesDisplayed])

  /** Same column shape as Salary payments (Payment summary): period rows with revenue share as period total. */
  const royaltyPeriodRowsEmbedded = useMemo(() => {
    return (ledgerDisplayed || [])
      .map((r) => {
        const ym = rowBookingMonth(r)
        const roy = Number(r.royaltyEarned) || 0
        return {
          id: r.id || `${r.talentName}-${r.date}-${r.product}`,
          talentName: r.talentName || '—',
          month: ym || '—',
          monthlyRoyalty: roy,
          totalEarnings: roy,
        }
      })
      .sort((a, b) => {
        const cm = String(a.month).localeCompare(String(b.month))
        if (cm !== 0) return cm
        return String(a.talentName || '').localeCompare(String(b.talentName || ''))
      })
  }, [ledgerDisplayed])

  const royaltyEmbeddedPaymentColumns = [
    {
      id: 'talentName',
      header: 'Talent',
      accessorKey: 'talentName',
      cell: (info) => <span className="font-medium">{info.getValue()}</span>,
    },
    {
      id: 'month',
      header: 'Period',
      accessorKey: 'month',
      cell: (info) => monthLabel(info.getValue()),
    },
    { id: 'salaryAmount', header: 'Monthly salary', cell: () => <span className="text-neutral">—</span> },
    { id: 'perfBonus', header: 'Perf. bonus', cell: () => <span className="text-neutral">—</span> },
    {
      id: 'monthlyRoyalty',
      header: 'Revenue share',
      accessorKey: 'monthlyRoyalty',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'totalEarnings',
      header: 'Period total',
      accessorKey: 'totalEarnings',
      cell: (info) => formatINRDisplay(info.getValue()),
    },
    {
      id: 'status',
      header: 'Status',
      cell: () => (
        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-2xs font-medium text-slate-700">Earned</span>
      ),
    },
  ]

  const ledgerColumns = [
    { id: 'product', header: 'Product', accessorKey: 'product' },
    { id: 'licensee', header: 'Sports Business (Club)', accessorKey: 'licensee' },
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName' },
    { id: 'royaltyPercent', header: 'Revenue share %', accessorKey: 'royaltyPercent', cell: (info) => `${((info.getValue() || 0) * 100).toFixed(2)}%` },
    { id: 'royaltyEarned', header: 'Revenue share earned', accessorKey: 'royaltyEarned', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'date', header: 'Date', accessorKey: 'date', cell: (info) => formatDisplayDate(info.getValue()) },
  ]

  const talentSummaryColumns = [
    { id: 'talentName', header: 'Talent', accessorKey: 'talentName', cell: (info) => <span className="font-medium">{info.getValue()}</span> },
    { id: 'royaltyTotal', header: 'Revenue share total', accessorKey: 'royaltyTotal', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPaid', header: 'Revenue share paid', accessorKey: 'royaltyPaid', cell: (info) => formatINRDisplay(info.getValue()) },
    { id: 'royaltyPending', header: 'Revenue share pending', accessorKey: 'royaltyPending', cell: (info) => formatINRDisplay(info.getValue()) },
  ]

  if (loading && !embedded) return <PageLoaderWithSkeleton message={loadMessage} />
  if (loading && embedded) {
    return <div className="py-10 text-center text-sm text-neutral">{loadMessage}</div>
  }

  return (
    <div className={cn('space-y-6', embedded && 'space-y-4')}>
      {!embedded && <h2 className="text-xl font-semibold">Revenue share (based on sales)</h2>}

      {paymentSummaryEmbed && yearKey && <PaymentTabIntroStrip tabKey="revenue-share" year={yearKey} />}

      {paymentSummaryEmbed && headerRoyalty && yearKey && (
        <>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <StatCard
              title="Total payable revenue share"
              value={formatINRDisplay(headerRoyalty.payable)}
              icon={DollarSign}
              className="border-primary/15"
              subtitle={
                filterTalentId && lockedTalentName
                  ? `${lockedTalentName} · ${yearKey}`
                  : !fromDashboard || selectedTalentIds.length === 0
                    ? `Ledger · ${yearKey} · club roster`
                    : undefined
              }
            />
            <StatCard
              title="Total paid revenue share"
              value={formatINRDisplay(headerRoyalty.paid)}
              icon={TrendingUp}
              className="border-primary/15"
              subtitle="From invoices (same scope)"
            />
            <StatCard
              title="Total outstanding revenue share"
              value={formatINRDisplay(headerRoyalty.outstanding)}
              icon={DollarSign}
              className={cn(
                'border-primary/15',
                filterTalentId && 'border-accent/30 bg-gradient-to-br from-accent/[0.08] to-white'
              )}
              valueClassName={filterTalentId ? 'text-accent-900' : undefined}
              subtitle="Earned less paid"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <div className={PAYMENT_TAB_CHART_SHELL}>
              <PaymentTripleAmountBarChart
                kind="royalty"
                payable={headerRoyalty.payable}
                paid={headerRoyalty.paid}
                outstanding={headerRoyalty.outstanding}
                year={yearKey}
                scopeNote={filterTalentId ? lockedTalentName || undefined : undefined}
              />
            </div>
            <div className={PAYMENT_TAB_CHART_SHELL}>
              {filterTalentId ? (
                <PaymentPaidOutstandingDonutChart
                  title="Paid vs outstanding · Revenue share"
                  payable={headerRoyalty.payable}
                  paid={headerRoyalty.paid}
                  outstanding={headerRoyalty.outstanding}
                  description={`${lockedTalentName || 'Talent'} · ${yearKey}`}
                />
              ) : (
                <div className="h-full min-h-[280px] px-1 py-1">
                  <MonthlyRevenueChart
                    data={royaltyMonthlyData}
                    title={`Revenue share by month (${yearKey})`}
                    description="Earned revenue share per month for the current filter (none = all talents)"
                    currency="USD"
                    valueLabel="Revenue share"
                  />
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {!paymentSummaryEmbed && (
        <>
          {embedded && !paymentSummaryEmbedLocked && (
            <p className="text-xs text-neutral">
              {yearKey ? (
                <>
                  Revenue share for <span className="font-semibold text-primary-800">{yearKey}</span> (ledger + invoices booked in that year).
                </>
              ) : (
                'Revenue share from sales ledger and invoice payments.'
              )}
            </p>
          )}
          <div className="grid gap-4 md:grid-cols-3">
            <StatCard title="Revenue share total" value={formatINRDisplay(royaltyTotal)} icon={DollarSign} className="border-primary/15" />
            <StatCard title="Revenue share paid" value={formatINRDisplay(royaltyPaid)} icon={TrendingUp} className="border-primary/15" />
            <StatCard title="Revenue share pending" value={formatINRDisplay(royaltyPending)} icon={DollarSign} className="border-primary/15" />
          </div>
          <div className={cn('grid gap-6', !paymentSummaryEmbedLocked && 'lg:grid-cols-2')}>
            <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
              <MonthlyRevenueChart
                data={royaltyMonthlyData}
                title={yearKey ? `Revenue share by month (${yearKey})` : 'Revenue share monthly trend'}
                description={
                  paymentSummaryEmbedLocked
                    ? `Earned revenue share per month · ${lockedTalentName || 'Talent'}`
                    : yearKey
                      ? 'Earned revenue share per month in selected year (cards = same scope)'
                      : 'Revenue share by month (matches totals above)'
                }
                currency="USD"
                valueLabel="Revenue share"
              />
            </div>
            {!paymentSummaryEmbedLocked && (
              <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card min-h-[320px]">
                {royaltyByTalent.length > 0 ? (
                  <RoyaltyDistributionChart data={royaltyByTalent} title="Revenue share distribution" description="By talent" />
                ) : (
                  <div>
                    <h3 className="mb-4 text-base font-medium">Revenue share distribution</h3>
                    <p className="text-sm text-neutral">No revenue share data</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}

      {showDashboardTalentFilter && (
        <div className={cn('rounded-lg border border-primary/15 bg-primary/[0.04] p-3', 'bg-white')}>
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <Filter className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Filter by talent</span>
          </div>
          <p className="mb-2 text-2xs text-neutral">Linked from dashboard · check talents to narrow rows and totals (none = all).</p>
          <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto">
            {talentOptions.length === 0 ? (
              <span className="text-2xs text-neutral">No ledger rows in this year.</span>
            ) : (
              talentOptions.map((t) => (
                <label
                  key={t.id}
                  className={cn(
                    'flex cursor-pointer items-center gap-1.5 rounded-md border px-2 py-1 text-2xs transition-colors',
                    selectedTalentIds.includes(t.id)
                      ? 'border-primary/40 bg-primary/10 font-medium text-primary-900'
                      : 'border-gray-200 bg-white hover:border-primary/25'
                  )}
                >
                  <Checkbox
                    checked={selectedTalentIds.includes(t.id)}
                    onCheckedChange={() =>
                      setSelectedTalentIds((prev) =>
                        prev.includes(t.id) ? prev.filter((x) => x !== t.id) : [...prev, t.id]
                      )
                    }
                  />
                  <User className="h-3 w-3 text-primary/70" />
                  <span className="max-w-[140px] truncate">{t.name}</span>
                </label>
              ))
            )}
          </div>
          {selectedTalentIds.length > 0 && (
            <Button variant="ghost" size="sm" className="mt-2 h-7 text-2xs" onClick={() => setSelectedTalentIds([])}>
              Clear filter
            </Button>
          )}
        </div>
      )}

      {paymentSummaryEmbed && filterTalentId && (
        <div className="rounded-lg border border-primary/15 bg-white p-3">
          <div className="mb-2 flex items-center gap-2 text-primary-900">
            <User className="h-3.5 w-3.5 text-accent-600" />
            <span className="text-2xs font-bold uppercase tracking-wider">Talent scope</span>
          </div>
          <p className="text-2xs text-neutral">
            Showing revenue share for <span className="font-semibold text-primary-800">{lockedTalentName || 'this roster member'}</span>{' '}
            only (opened from talent detail).
          </p>
        </div>
      )}

      {embedded && (
        <div className="theme-card overflow-hidden p-3">
          <h3 className="mb-2 text-sm font-semibold text-primary-900">Revenue share payments</h3>
          <p className="mb-3 text-2xs text-neutral">
            Rows follow the same layout as Salary payments: monthly salary and perf. bonus are not in this ledger; revenue share is the amount for each sales period (period total = revenue share).
          </p>
          {royaltyPeriodRowsEmbedded.length > 0 ? (
            <DataTable
              columns={royaltyEmbeddedPaymentColumns}
              data={royaltyPeriodRowsEmbedded}
              searchKey="talentName"
              searchPlaceholder="Search talent or period…"
            />
          ) : (
            <p className="text-sm text-neutral">No revenue share ledger rows for this scope.</p>
          )}
        </div>
      )}
      {!embedded && royaltyByTalentRows.length > 0 && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-3 text-base font-medium">Revenue share by talent (total, paid, pending)</h3>
          <DataTable columns={talentSummaryColumns} data={royaltyByTalentRows} searchKey="talentName" searchPlaceholder="Search by talent..." />
        </div>
      )}
      {!embedded && (
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-card">
          <h3 className="mb-2 text-base font-medium">Revenue share ledger</h3>
          <div className="mb-3 flex flex-wrap gap-4 rounded-md bg-gray-50 px-3 py-2 text-sm">
            <span><strong>Revenue share total:</strong> {formatINRDisplay(royaltyTotal)}</span>
            <span><strong>Revenue share paid:</strong> {formatINRDisplay(royaltyPaid)}</span>
            <span><strong>Revenue share pending:</strong> {formatINRDisplay(royaltyPending)}</span>
          </div>
          <DataTable columns={ledgerColumns} data={ledgerAll} searchKey="product" searchPlaceholder="Search by product or talent..." />
        </div>
      )}
      {embedded && !paymentSummaryEmbed && (
        <p className="text-2xs text-neutral">
          Full line-item revenue share ledger (all periods) is on the standalone <strong>Revenue share</strong> page from the club menu.
        </p>
      )}
    </div>
  )
}
