import React, { useState, useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import {
  enrichSalaryPayments,
  MONTHLY_PERFORMANCE_BONUS_AMOUNT,
  PERFORMANCE_BONUS_PAYROLL_LABEL,
} from '../../utils/salaryCalculator'
import { PaymentModal } from '../../components/PaymentModal'
import { PageLoaderWithSkeleton } from '../../components/ui/PageLoaderWithSkeleton'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { processSalaryPayment, processSigningBonusPayment, processRoyaltyPayment } from '../../utils/paymentProcessor'
import toast from 'react-hot-toast'
import { Button } from '../../components/ui/button'
import { Card, CardContent } from '../../components/ui/card'
import { DollarSign, Gift, TrendingUp, Filter, Info, ChevronDown, ChevronUp } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Checkbox } from '../../components/ui/checkbox'
import { formatINRDisplay } from '../../utils/currencyFormat'

/** Format month key "2026-06" as "Jun 2026" */
function formatMonthLabel(monthStr) {
  if (!monthStr || typeof monthStr !== 'string') return monthStr || '—'
  const [y, m] = monthStr.split('-')
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const idx = parseInt(m, 10) - 1
  if (idx >= 0 && idx < 12 && y) return `${months[idx]} ${y}`
  return monthStr
}

export function ClubReleasePaymentPage() {
  const { currentOrganizationId } = useOrganization()
  const { loading, loadMessage } = usePageLoadAuto('Loading pending payments...', 'Release payment data loaded')
  const salaryPayments = useMemo(() => getAllByOrganization('salaryPayments', currentOrganizationId), [currentOrganizationId])
  const signingBonuses = useMemo(() => getAllByOrganization('signingBonuses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const ledger = useMemo(() => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses), [sales, contracts, talents, sportsBusinesses])

  const [paymentModal, setPaymentModal] = useState(null)
  const [selectedTalentIds, setSelectedTalentIds] = useState([])
  const [selectedSalaryIds, setSelectedSalaryIds] = useState([])
  const [selectedBonusIds, setSelectedBonusIds] = useState([])
  const [selectedRoyaltyIds, setSelectedRoyaltyIds] = useState([])
  const [openSalary, setOpenSalary] = useState(true)
  const [openBonus, setOpenBonus] = useState(true)
  const [openRoyalty, setOpenRoyalty] = useState(true)

  const pendingSalaryRaw = useMemo(() => (salaryPayments || []).filter((s) => s.paymentStatus === 'pending'), [salaryPayments])
  const pendingSalary = useMemo(() => enrichSalaryPayments(pendingSalaryRaw, signingBonuses, ledger), [pendingSalaryRaw, signingBonuses, ledger])
  const pendingPerformanceBonus = useMemo(() => (signingBonuses || []).filter((b) => b.status === 'pending'), [signingBonuses])
  const pendingRoyalty = useMemo(() => (invoices || []).filter((inv) => {
    const total = Number(inv.royaltyAmount) || 0
    const paid = Number(inv.paidAmount) || 0
    return total - paid > 0
  }), [invoices])

  const talentOptions = useMemo(() => {
    const set = new Set()
    pendingSalary.forEach((s) => set.add(JSON.stringify({ id: s.talentId, name: s.talentName })))
    pendingPerformanceBonus.forEach((b) => set.add(JSON.stringify({ id: b.talentId, name: b.talentName })))
    pendingRoyalty.forEach((inv) => set.add(JSON.stringify({ id: inv.talentId, name: inv.talentName })))
    return Array.from(set).map((s) => JSON.parse(s)).filter((t) => t.id && t.name)
  }, [pendingSalary, pendingPerformanceBonus, pendingRoyalty])

  const filteredPendingSalary = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingSalary
    return pendingSalary.filter((s) => selectedTalentIds.includes(s.talentId))
  }, [pendingSalary, selectedTalentIds])

  const filteredPendingPerformanceBonus = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingPerformanceBonus
    return pendingPerformanceBonus.filter((b) => selectedTalentIds.includes(b.talentId))
  }, [pendingPerformanceBonus, selectedTalentIds])

  const filteredPendingRoyalty = useMemo(() => {
    if (selectedTalentIds.length === 0) return pendingRoyalty
    return pendingRoyalty.filter((inv) => selectedTalentIds.includes(inv.talentId))
  }, [pendingRoyalty, selectedTalentIds])

  const toggleSalary = (id) => setSelectedSalaryIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])
  const toggleBonus = (id) => setSelectedBonusIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])
  const toggleRoyalty = (id) => setSelectedRoyaltyIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])

  const selectedSalaryItems = useMemo(() => filteredPendingSalary.filter((s) => selectedSalaryIds.includes(s.id)), [filteredPendingSalary, selectedSalaryIds])
  const selectedBonusItems = useMemo(() => filteredPendingPerformanceBonus.filter((b) => selectedBonusIds.includes(b.id)), [filteredPendingPerformanceBonus, selectedBonusIds])
  const selectedRoyaltyItems = useMemo(() => filteredPendingRoyalty.filter((inv) => selectedRoyaltyIds.includes(inv.id)), [filteredPendingRoyalty, selectedRoyaltyIds])

  const totalSelectedAmount = useMemo(() => {
    let sum = selectedSalaryItems.reduce((a, s) => a + (s.totalEarnings || Number(s.salaryAmount) || 0), 0)
    sum += selectedBonusItems.reduce((a, b) => a + (Number(b.amount) || 0), 0)
    selectedRoyaltyItems.forEach((inv) => {
      sum += (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
    })
    return sum
  }, [selectedSalaryItems, selectedBonusItems, selectedRoyaltyItems])

  const handlePayNow = () => {
    if (totalSelectedAmount <= 0) {
      toast.error('Select at least one payment')
      return
    }
    setPaymentModal({ total: totalSelectedAmount })
  }

  const handlePaymentSuccess = ({ amount, paymentMethod }) => {
    try {
      selectedSalaryItems.forEach((s) => processSalaryPayment(s, paymentMethod, currentOrganizationId))
      selectedBonusItems.forEach((b) => processSigningBonusPayment(b, paymentMethod, currentOrganizationId))
      selectedRoyaltyItems.forEach((inv) => {
        const due = (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
        if (due > 0) processRoyaltyPayment(inv, due, paymentMethod, currentOrganizationId)
      })
      toast.success('Payments recorded and synced to ledger')
      setPaymentModal(null)
      setSelectedSalaryIds([])
      setSelectedBonusIds([])
      setSelectedRoyaltyIds([])
      setTimeout(() => window.location.reload(), 800)
    } catch (e) {
      toast.error('Failed to record payments')
      setPaymentModal(null)
    }
  }

  const salaryByMonth = useMemo(() => {
    const byMonth = {}
    ;(filteredPendingSalary || []).forEach((s) => {
      const key = s.month || 'unknown'
      if (!byMonth[key]) byMonth[key] = []
      byMonth[key].push(s)
    })
    return Object.entries(byMonth).sort((a, b) => a[0].localeCompare(b[0]))
  }, [filteredPendingSalary])

  if (loading) return <PageLoaderWithSkeleton message={loadMessage} />

  return (
    <div className="flex gap-6">
      <aside className="w-72 shrink-0 rounded-lg border border-gray-200 bg-white p-4 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral">Filter by talent</span>
        </div>
        <p className="text-2xs text-neutral mb-2">Filter list (none = all). Use checkboxes in sections to select payments, then Pay now below.</p>
        <div className="space-y-2 max-h-[50vh] overflow-y-auto">
          {talentOptions.length === 0 ? (
            <p className="text-2xs text-neutral">No talents in pending items</p>
          ) : (
            talentOptions.map((t) => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 rounded px-2 py-1.5">
                <Checkbox
                  checked={selectedTalentIds.includes(t.id)}
                  onCheckedChange={() => setSelectedTalentIds((prev) => prev.includes(t.id) ? prev.filter((id) => id !== t.id) : [...prev, t.id])}
                />
                <span className="text-xs truncate">{t.name}</span>
              </label>
            ))
          )}
        </div>
        {selectedTalentIds.length > 0 && (
          <Button variant="ghost" size="sm" className="mt-3 text-xs" onClick={() => setSelectedTalentIds([])}>Clear filter</Button>
        )}
      </aside>

      <div className="flex-1 min-w-0 space-y-6">
        <div>
          <h2 className="text-xl font-semibold">Release Payment</h2>
          <p className="text-sm text-neutral mt-1">Select payments with checkboxes (salary, bonus, revenue share). One Pay now at bottom — monthly-wise release. Data syncs to payment ledger.</p>
        </div>

        {/* Collapsible: Pending Salary */}
        <Card className="overflow-hidden rounded-lg border border-slate-200/90 border-l-[3px] border-l-primary bg-white shadow-sm">
          <button
            type="button"
            className={cn('expand-trigger', openSalary && 'expand-trigger--open')}
            onClick={() => setOpenSalary(!openSalary)}
          >
            <div className="flex min-w-0 flex-1 items-start gap-3">
              <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
                <DollarSign className="h-4 w-4" />
              </div>
              <div className="min-w-0 text-left">
                <div className="text-base font-semibold text-primary-900">Pending Salary</div>
                <div className="mt-1 flex items-start gap-2 text-xs text-slate-600">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary/45" />
                  <p>Monthly salary. Select rows and pay via Pay now below.</p>
                </div>
              </div>
            </div>
            <span className="expand-chevron-wrap">
              {openSalary ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </span>
          </button>
          {openSalary && (
            <CardContent className="border-t border-slate-200/90 bg-slate-50/50 pt-4">
              {salaryByMonth.length === 0 ? (
                <p className="text-sm text-neutral">No pending salary.</p>
              ) : (
                <ul className="space-y-3">
                  {salaryByMonth.map(([month, items]) => (
                    <li key={month}>
                      <p className="mb-1 text-xs font-semibold text-slate-600">{formatMonthLabel(month)}</p>
                      {items.map((s) => (
                        <div
                          key={s.id}
                          className="mb-1 flex items-center justify-between rounded-md border border-slate-200/80 bg-white py-2 px-3"
                        >
                          <label className="flex items-center gap-2 cursor-pointer flex-1 min-w-0">
                            <Checkbox checked={selectedSalaryIds.includes(s.id)} onCheckedChange={() => toggleSalary(s.id)} />
                            <span><span className="font-medium">{s.talentName}</span> — <span className="text-primary font-semibold">{formatINRDisplay(s.totalEarnings ?? s.salaryAmount)}</span></span>
                          </label>
                        </div>
                      ))}
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          )}
        </Card>

        {/* Collapsible: Pending Performance Bonus */}
        <Card className="overflow-hidden rounded-lg border border-slate-200/90 border-l-[3px] border-l-primary/60 bg-white shadow-sm">
          <button
            type="button"
            className={cn('expand-trigger', openBonus && 'expand-trigger--open')}
            onClick={() => setOpenBonus(!openBonus)}
          >
            <div className="flex min-w-0 flex-1 items-start gap-3">
              <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
                <Gift className="h-4 w-4" />
              </div>
              <div className="min-w-0 text-left">
                <div className="text-base font-semibold text-primary-900">Pending Performance Bonus</div>
                <div className="mt-1 flex items-start gap-2 text-xs text-slate-600">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary/45" />
                  <p>
                    {formatINRDisplay(MONTHLY_PERFORMANCE_BONUS_AMOUNT)} per talent per month ({PERFORMANCE_BONUS_PAYROLL_LABEL}). Select talents and pay via Pay now below.
                  </p>
                </div>
              </div>
            </div>
            <span className="expand-chevron-wrap">
              {openBonus ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </span>
          </button>
          {openBonus && (
            <CardContent className="border-t border-slate-200/90 bg-slate-50/50 pt-4">
              {filteredPendingPerformanceBonus.length === 0 ? (
                <p className="text-sm text-neutral">No pending performance bonuses.</p>
              ) : (
                <ul className="space-y-2">
                  {filteredPendingPerformanceBonus.map((b) => (
                    <div
                      key={b.id}
                      className="flex items-center justify-between rounded-md border border-slate-200/80 bg-white py-2 px-3"
                    >
                      <label className="flex items-center gap-2 cursor-pointer flex-1">
                        <Checkbox checked={selectedBonusIds.includes(b.id)} onCheckedChange={() => toggleBonus(b.id)} />
                        <span><span className="font-medium">{b.talentName}</span> — <span className="text-primary font-semibold">{formatINRDisplay(b.amount)}</span></span>
                      </label>
                    </div>
                  ))}
                </ul>
              )}
            </CardContent>
          )}
        </Card>

        {/* Collapsible: Pending revenue share (invoices) */}
        <Card className="overflow-hidden rounded-lg border border-slate-200/90 border-l-[3px] border-l-primary-300 bg-white shadow-sm">
          <button
            type="button"
            className={cn('expand-trigger', openRoyalty && 'expand-trigger--open')}
            onClick={() => setOpenRoyalty(!openRoyalty)}
          >
            <div className="flex min-w-0 flex-1 items-start gap-3">
              <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/15 bg-white text-primary shadow-sm ring-1 ring-primary/10">
                <TrendingUp className="h-4 w-4" />
              </div>
              <div className="min-w-0 text-left">
                <div className="text-base font-semibold text-primary-900">Pending revenue share</div>
                <div className="mt-1 flex items-start gap-2 text-xs text-slate-600">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary/45" />
                  <p>Select invoices and pay via Pay now below.</p>
                </div>
              </div>
            </div>
            <span className="expand-chevron-wrap">
              {openRoyalty ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </span>
          </button>
          {openRoyalty && (
            <CardContent className="border-t border-slate-200/90 bg-slate-50/50 pt-4">
              {filteredPendingRoyalty.length === 0 ? (
                <p className="text-sm text-neutral">No pending revenue share.</p>
              ) : (
                <ul className="space-y-2">
                  {filteredPendingRoyalty.map((inv) => {
                    const due = (Number(inv.royaltyAmount) || 0) - (Number(inv.paidAmount) || 0)
                    return (
                      <div
                        key={inv.id}
                        className="flex items-center justify-between rounded-md border border-slate-200/80 bg-white py-2 px-3"
                      >
                        <label className="flex min-w-0 flex-1 cursor-pointer items-center gap-2">
                          <Checkbox checked={selectedRoyaltyIds.includes(inv.id)} onCheckedChange={() => toggleRoyalty(inv.id)} />
                          <span className="text-sm">
                            <span className="font-medium">{inv.talentName}</span> — {formatMonthLabel(inv.date?.slice(0, 7))} —{' '}
                            <span className="font-semibold text-slate-800">{formatINRDisplay(due)} due</span>
                          </span>
                        </label>
                      </div>
                    )
                  })}
                </ul>
              )}
            </CardContent>
          )}
        </Card>

        <div className="flex items-center justify-end gap-4 border-t border-slate-200/90 pt-4">
          <span className="text-sm font-medium">Selected total: {formatINRDisplay(totalSelectedAmount)}</span>
          <Button className="bg-primary text-white hover:bg-primary/90" onClick={handlePayNow} disabled={totalSelectedAmount <= 0}>
            Pay now
          </Button>
        </div>
      </div>

      {paymentModal && (
        <PaymentModal
          open
          onOpenChange={(v) => !v && setPaymentModal(null)}
          amount={paymentModal.total}
          title="Release payment (selected items)"
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
