import React, { useMemo } from 'react'
import { getAllByOrganization } from '../../database/dbService'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { StatCard } from '../../components/cards/StatCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { DollarSign, Building2, FileText, TrendingUp, Upload } from 'lucide-react'
import { format } from 'date-fns'
import { Link } from 'react-router-dom'
import { Button } from '../../components/ui/button'

function aggregateByMonth(sales) {
  const byMonth = {}
  sales.forEach((s) => {
    const d = s.date || s.Date
    const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
    byMonth[key] = (byMonth[key] || 0) + Number(s.netSales || 0)
  })
  return Object.entries(byMonth)
    .map(([month, revenue]) => ({ month, revenue }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)
}

export function PartnerDashboard() {
  const { loading, loadMessage } = usePageLoadAuto('Loading partner dashboard...', 'Dashboard loaded')
  const { currentOrganizationId } = useOrganization()
  const { dataRevision } = useAppStore()

  const sales = useMemo(
    () => getAllByOrganization('sales', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const contracts = useMemo(
    () => getAllByOrganization('contracts', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sponsorshipCompanies = useMemo(
    () => getAllByOrganization('sponsorshipCompanies', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const sportsBusinesses = useMemo(
    () => getAllByOrganization('sportsBusinesses', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const invoices = useMemo(
    () => getAllByOrganization('invoices', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )
  const importBatches = useMemo(
    () =>
      [...(getAllByOrganization('vendorImportBatches', currentOrganizationId) || [])].sort((a, b) =>
        String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || ''))
      ),
    [currentOrganizationId, dataRevision]
  )

  const activeContracts = useMemo(() => contracts.filter((c) => c.status === 'active'), [contracts])
  const partnerCompaniesCount = sponsorshipCompanies.length
  const totalSales = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const royaltyContributions = useMemo(() => {
    return (invoices || []).reduce((a, inv) => a + (Number(inv.royaltyAmount) || 0), 0)
  }, [invoices])

  const countryRevenue = useMemo(() => {
    const map = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      map[c] = (map[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(map).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])

  const monthlyData = aggregateByMonth(sales)

  const clubPartners = useMemo(() => {
    const set = new Set()
    contracts.forEach((c) => {
      if (c.licensee) set.add(c.licensee)
    })
    return Array.from(set)
  }, [contracts])

  if (loading) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral">
          Vendor summary for your organization — uploads update club revenue share and talent distribution.
        </p>
        <Button asChild variant="accent" size="sm" className="shrink-0 gap-2">
          <Link to="/partner/upload-sales">
            <Upload className="h-4 w-4" />
            Upload sales file
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Partner Companies" value={partnerCompaniesCount} icon={Building2} subtitle="Sport / vendor partners" />
        <StatCard title="Active Contracts" value={activeContracts.length} icon={FileText} subtitle="With sports businesses (clubs)" />
        <StatCard title="Revenue share contributions" value={`$${royaltyContributions.toLocaleString()}`} icon={TrendingUp} subtitle="Total revenue share from sales" />
        <StatCard title="Total Sales" value={`$${totalSales.toLocaleString()}`} icon={DollarSign} subtitle="Net sales volume" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <MonthlyRevenueChart data={monthlyData} />
        <CountrySalesChart data={countryRevenue} />
      </div>
      <Card className="border-accent/20 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Recent vendor uploads</CardTitle>
          <p className="text-2xs text-neutral">Processed batches notify the Sport Business workspace and rebuild payment snapshots.</p>
        </CardHeader>
        <CardContent>
          {importBatches.length === 0 ? (
            <p className="text-sm text-neutral">No imports yet. Use Upload sales to add revenue share data.</p>
          ) : (
            <ul className="space-y-3">
              {importBatches.slice(0, 6).map((b) => {
                let summary = null
                try {
                  summary = b.summaryJson ? JSON.parse(b.summaryJson) : null
                } catch {
                  summary = null
                }
                return (
                  <li
                    key={b.id}
                    className="flex flex-col gap-1 rounded-lg border border-slate-200/90 bg-slate-50/50 px-3 py-2 text-sm sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <p className="font-medium text-primary-900">{b.fileName || 'Upload'}</p>
                      <p className="text-2xs text-neutral">
                        {b.uploadedAt ? format(new Date(b.uploadedAt), 'PPp') : '—'} · {b.processedCount ?? 0} / {b.rowCount ?? 0}{' '}
                        rows · {b.status}
                      </p>
                    </div>
                    {summary?.byTalent?.length > 0 && (
                      <p className="text-2xs text-slate-600">
                        Top talent: <span className="font-semibold text-accent-700">{summary.byTalent[0]?.name}</span>
                      </p>
                    )}
                  </li>
                )
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
        <h3 className="mb-4 text-base font-medium">Sports Businesses (Clubs) under contract</h3>
        <ul className="space-y-2">
          {clubPartners.length === 0 ? (
            <p className="text-sm text-neutral">No clubs linked yet</p>
          ) : (
            clubPartners.map((name) => (
              <li key={name} className="flex justify-between text-sm">
                <span>{name}</span>
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  )
}
