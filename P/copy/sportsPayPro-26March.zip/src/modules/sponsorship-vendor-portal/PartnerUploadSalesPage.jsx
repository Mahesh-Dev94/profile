import React, { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useOrganization } from '../../context/OrganizationContext'
import { useAppStore } from '../../context/AppStore'
import { create, getAllByOrganization } from '../../database/dbService'
import { rebuildTalentMonthPaymentSnapshotsForOrganization } from '../../repositories/talentMonthPaymentSnapshots'
import { UploadZone } from '../../components/forms/UploadZone'
import { parseSalesFile } from '../../utils/parseSalesFile'
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card'
import { Button } from '../../components/ui/button'
import { Input } from '../../components/ui/input'
import { Checkbox } from '../../components/ui/checkbox'
import { PageLoader } from '../../components/ui/PageLoader'
import { usePageLoadAuto } from '../../hooks/usePageLoad'
import { Download, Trash2, Pencil, CheckSquare, Square } from 'lucide-react'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../../components/ui/dialog'
import { Label } from '../../components/ui/label'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { getRoyaltyByTalent } from '../../utils/revenueShareEngine'

function mapTalentIdsForOrg(talentNamesStr, talents) {
  if (!talentNamesStr) return []
  const names = String(talentNamesStr)
    .split(/[,;]/)
    .map((n) => n.trim())
    .filter(Boolean)
  return names.map((name) => talents.find((t) => t.name === name)?.id).filter(Boolean)
}

/** When several sportsBusiness rows share the same businessName, pick licenseeId from the active contract for a resolved talent. */
function resolveLicenseeIdForSale(rest, talentIds, businesses, contracts) {
  const candidates = businesses.filter((b) => b.businessName === rest.licensee)
  let id = candidates[0]?.id || rest.licenseeId
  if (candidates.length <= 1 || !talentIds?.length) return id
  for (const tid of talentIds) {
    const c = contracts.find((x) => x.talentId === tid && candidates.some((b) => b.id === x.licenseeId))
    if (c?.licenseeId) return c.licenseeId
  }
  return id
}

export function PartnerUploadSalesPage() {
  const { loading: pageLoad, loadMessage } = usePageLoadAuto('Loading upload...', 'Upload page loaded')
  const { currentOrganizationId } = useOrganization()
  const { bumpDataRevision, dataRevision } = useAppStore()

  const talents = useMemo(
    () => getAllByOrganization('talents', currentOrganizationId),
    [currentOrganizationId, dataRevision]
  )

  const [parsing, setParsing] = useState(false)
  const [stagedRows, setStagedRows] = useState([])
  const [selectedIds, setSelectedIds] = useState(() => new Set())
  const [editRow, setEditRow] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [lastBatchId, setLastBatchId] = useState(null)

  const committedSales = useMemo(() => {
    const list = getAllByOrganization('sales', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')))
  }, [currentOrganizationId, dataRevision])
  const importBatches = useMemo(() => {
    const list = getAllByOrganization('vendorImportBatches', currentOrganizationId) || []
    return [...list].sort((a, b) => String(b.uploadedAt || '').localeCompare(String(a.uploadedAt || '')))
  }, [currentOrganizationId, dataRevision])

  const allSelected = stagedRows.length > 0 && stagedRows.every((r) => selectedIds.has(r._stagedId))
  const setAllSelectedState = (checked) => {
    if (checked === true) setSelectedIds(new Set(stagedRows.map((r) => r._stagedId)))
    else setSelectedIds(new Set())
  }

  const toggleOne = (id, checked) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (checked === true) next.add(id)
      else next.delete(id)
      return next
    })
  }

  const handleFile = async (file) => {
    setParsing(true)
    try {
      const rows = await parseSalesFile(file)
      const withIds = rows.map((r) => ({
        ...r,
        _stagedId: globalThis.crypto?.randomUUID?.() || `st-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
        _fileName: file.name,
      }))
      setStagedRows(withIds)
      setSelectedIds(new Set(withIds.map((x) => x._stagedId)))
      toast.success(`Loaded ${withIds.length} row(s). Review and process.`)
    } catch (err) {
      toast.error(err.message || String(err))
    } finally {
      setParsing(false)
    }
  }

  const deleteRow = (id) => {
    setStagedRows((list) => list.filter((r) => r._stagedId !== id))
    setSelectedIds((prev) => {
      const next = new Set(prev)
      next.delete(id)
      return next
    })
  }

  const deleteSelected = () => {
    setStagedRows((list) => list.filter((r) => !selectedIds.has(r._stagedId)))
    setSelectedIds(new Set())
    toast.success('Removed selected rows')
  }

  const openEdit = (row) => {
    setEditRow(row)
    setEditForm({ ...row })
  }

  const saveEdit = () => {
    if (!editRow) return
    setStagedRows((list) =>
      list.map((r) => (r._stagedId === editRow._stagedId ? { ...editForm, _stagedId: r._stagedId, _fileName: r._fileName } : r))
    )
    setEditRow(null)
    toast.success('Row updated')
  }

  const processRecords = () => {
    const toProcess = stagedRows.filter((r) => selectedIds.has(r._stagedId))
    if (toProcess.length === 0) {
      toast.error('Select at least one row to process')
      return
    }
    if (!currentOrganizationId) {
      toast.error('No organization context')
      return
    }
    const businesses = getAllByOrganization('sportsBusinesses', currentOrganizationId)
    const contracts = getAllByOrganization('contracts', currentOrganizationId)
    let ok = 0
    for (const row of toProcess) {
      const { _stagedId, _fileName, id: _oldId, ...rest } = row
      const talentIds = mapTalentIdsForOrg(rest.talentNames, talents)
      const licenseeId = resolveLicenseeIdForSale(rest, talentIds, businesses, contracts)
      create('sales', {
        ...rest,
        organizationId: currentOrganizationId,
        talentIds,
        licenseeId: licenseeId || undefined,
      })
      ok++
    }
    const impact = computeDistributionImpact(currentOrganizationId)
    const batch = create('vendorImportBatches', {
      organizationId: currentOrganizationId,
      fileName: toProcess[0]?._fileName || 'upload',
      uploadedAt: new Date().toISOString(),
      rowCount: toProcess.length,
      processedCount: ok,
      status: 'completed',
      summaryJson: JSON.stringify(impact),
    })
    setLastBatchId(batch?.id)
    try {
      rebuildTalentMonthPaymentSnapshotsForOrganization(currentOrganizationId)
    } catch (e) {
      console.warn('Talent month payment snapshot rebuild after vendor import failed', e)
    }
    bumpDataRevision()
    window.dispatchEvent(new CustomEvent('sports-pay-vendor-import', { detail: { count: ok } }))
    toast.success(`${ok} sales row(s) committed. Club dashboards updated.`)
    setStagedRows([])
    setSelectedIds(new Set())
  }

  if (pageLoad) return <PageLoader message={loadMessage} />

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-accent-800">Upload revenue share file</h2>
        <p className="mt-1 text-sm text-neutral">
          CSV / Excel → review in the table → process into sales. The central ledger recalculates talent and contract revenue share
          automatically.
        </p>
      </div>

      <Card className="border-accent/20 shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">File upload</CardTitle>
          <p className="text-sm text-neutral">
            Required-style columns: SKU, Licensee, ProductDescription, TalentNames, Country, UnitsSold, EffectiveUnitSalesPrice, NetSales,
            Date. Optional: ID, Currency, TypeOfSales. Talent names must match roster exactly; comma or semicolon between multiple names.
          </p>
          <a
            href="/sample/sales.csv"
            download="sales-sample.csv"
            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
          >
            <Download className="h-4 w-4" /> Download sample sales.csv
          </a>
        </CardHeader>
        <CardContent>
          <UploadZone onFile={handleFile} disabled={parsing} />
          {parsing && <p className="mt-2 text-sm text-neutral">Parsing file…</p>}
        </CardContent>
      </Card>

      <Card className="border-accent/20 shadow-sm">
        <CardHeader className="flex flex-col gap-2 border-b border-slate-200/90 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="text-base">Committed sales (this organization)</CardTitle>
            <p className="text-2xs text-neutral">
              Rows already written to the ledger. New uploads appear here after you process them.
            </p>
          </div>
          <Link to="/partner/sales" className="text-sm font-medium text-primary hover:underline">
            View all sales →
          </Link>
        </CardHeader>
        <CardContent className="p-0">
          {committedSales.length === 0 ? (
            <p className="p-4 text-sm text-neutral">No committed sales yet for this organization.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-2xs sm:text-xs">
                <thead>
                  <tr className="border-b bg-slate-50 text-left">
                    <th className="px-3 py-2 font-semibold">SKU</th>
                    <th className="px-3 py-2 font-semibold">Licensee</th>
                    <th className="px-3 py-2 font-semibold">Product</th>
                    <th className="px-3 py-2 font-semibold">Talents</th>
                    <th className="px-3 py-2 text-right font-semibold">Net sales</th>
                    <th className="px-3 py-2 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {committedSales.slice(0, 12).map((row) => (
                    <tr key={row.id} className="border-b border-slate-100">
                      <td className="px-3 py-2 font-mono">{row.sku}</td>
                      <td className="px-3 py-2">{row.licensee}</td>
                      <td className="max-w-[180px] truncate px-3 py-2" title={row.productDescription}>
                        {row.productDescription}
                      </td>
                      <td className="px-3 py-2">{row.talentNames}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{Number(row.netSales || 0).toLocaleString()}</td>
                      <td className="px-3 py-2 font-mono">{row.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {importBatches.length > 0 && (
        <Card className="border-accent/20 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Recent vendor imports</CardTitle>
            <p className="text-2xs text-neutral">Batches created when you click Process records.</p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <table className="w-full text-2xs sm:text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-left">
                  <th className="px-3 py-2 font-semibold">File</th>
                  <th className="px-3 py-2 font-semibold">When</th>
                  <th className="px-3 py-2 text-right font-semibold">Rows</th>
                  <th className="px-3 py-2 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {importBatches.slice(0, 8).map((b) => (
                  <tr key={b.id} className="border-b border-slate-100">
                    <td className="px-3 py-2">{b.fileName}</td>
                    <td className="px-3 py-2 font-mono text-neutral">
                      {b.uploadedAt ? format(new Date(b.uploadedAt), 'yyyy-MM-dd HH:mm') : '—'}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums">
                      {b.processedCount ?? 0} / {b.rowCount ?? 0}
                    </td>
                    <td className="px-3 py-2">{b.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {stagedRows.length > 0 && (
        <Card className="border-primary/15 shadow-md">
          <CardHeader className="flex flex-col gap-3 border-b border-slate-200/90 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle className="text-base">Data processing</CardTitle>
              <p className="text-2xs text-neutral">
                Select rows, edit inline via dialog, or remove. Only selected rows are written to sales on process.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setAllSelectedState(!allSelected)}>
                {allSelected ? (
                  <>
                    <Square className="mr-1 h-4 w-4" /> Deselect all
                  </>
                ) : (
                  <>
                    <CheckSquare className="mr-1 h-4 w-4" /> Select all
                  </>
                )}
              </Button>
              <Button type="button" variant="outline" size="sm" className="border-red-200 text-red-600" onClick={deleteSelected}>
                <Trash2 className="mr-1 h-4 w-4" />
                Delete selected
              </Button>
              <Button type="button" variant="accent" size="sm" onClick={processRecords}>
                Process records
              </Button>
            </div>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <table className="w-full min-w-[880px] text-2xs sm:text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-left">
                  <th className="w-10 px-2 py-2">
                    <Checkbox
                      checked={allSelected}
                      onCheckedChange={(v) => setAllSelectedState(v === true)}
                      aria-label="Select all"
                    />
                  </th>
                  <th className="px-2 py-2 font-semibold">SKU</th>
                  <th className="px-2 py-2 font-semibold">Licensee</th>
                  <th className="px-2 py-2 font-semibold">Product</th>
                  <th className="px-2 py-2 font-semibold">Talents</th>
                  <th className="px-2 py-2 text-right font-semibold">Net sales</th>
                  <th className="px-2 py-2 font-semibold">Date</th>
                  <th className="px-2 py-2 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {stagedRows.map((row) => (
                  <tr key={row._stagedId} className="border-b border-slate-100 hover:bg-slate-50/80">
                    <td className="px-2 py-2">
                      <Checkbox
                        checked={selectedIds.has(row._stagedId)}
                        onCheckedChange={(v) => toggleOne(row._stagedId, v === true)}
                        aria-label="Select row"
                      />
                    </td>
                    <td className="px-2 py-2 font-mono">{row.sku}</td>
                    <td className="px-2 py-2">{row.licensee}</td>
                    <td className="max-w-[200px] truncate px-2 py-2" title={row.productDescription}>
                      {row.productDescription}
                    </td>
                    <td className="px-2 py-2">{row.talentNames}</td>
                    <td className="px-2 py-2 text-right tabular-nums">{Number(row.netSales || 0).toLocaleString()}</td>
                    <td className="px-2 py-2 font-mono">{row.date}</td>
                    <td className="px-2 py-2">
                      <div className="flex gap-1">
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(row)}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-600"
                          onClick={() => deleteRow(row._stagedId)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {lastBatchId && (
        <p className="text-2xs text-neutral">
          Last batch id: <span className="font-mono">{lastBatchId}</span> · stored in vendor import history (see vendor dashboard).
        </p>
      )}

      <Dialog open={!!editRow} onOpenChange={(v) => !v && setEditRow(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit staged row</DialogTitle>
          </DialogHeader>
          <div className="grid gap-3 py-2">
            <div>
              <Label>SKU</Label>
              <Input value={editForm.sku || ''} onChange={(e) => setEditForm((f) => ({ ...f, sku: e.target.value }))} />
            </div>
            <div>
              <Label>Licensee</Label>
              <Input value={editForm.licensee || ''} onChange={(e) => setEditForm((f) => ({ ...f, licensee: e.target.value }))} />
            </div>
            <div>
              <Label>Product</Label>
              <Input
                value={editForm.productDescription || ''}
                onChange={(e) => setEditForm((f) => ({ ...f, productDescription: e.target.value }))}
              />
            </div>
            <div>
              <Label>Talent names (comma-separated)</Label>
              <Input value={editForm.talentNames || ''} onChange={(e) => setEditForm((f) => ({ ...f, talentNames: e.target.value }))} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Units</Label>
                <Input
                  type="number"
                  value={editForm.unitsSold ?? ''}
                  onChange={(e) => setEditForm((f) => ({ ...f, unitsSold: e.target.value }))}
                />
              </div>
              <div>
                <Label>Unit price</Label>
                <Input
                  type="number"
                  value={editForm.effectiveUnitSalesPrice ?? ''}
                  onChange={(e) => setEditForm((f) => ({ ...f, effectiveUnitSalesPrice: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label>Net sales</Label>
              <Input type="number" value={editForm.netSales ?? ''} onChange={(e) => setEditForm((f) => ({ ...f, netSales: e.target.value }))} />
            </div>
            <div>
              <Label>Date</Label>
              <Input type="date" value={(editForm.date || '').slice(0, 10)} onChange={(e) => setEditForm((f) => ({ ...f, date: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setEditRow(null)}>
              Cancel
            </Button>
            <Button type="button" variant="accent" onClick={saveEdit}>
              Save row
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function computeDistributionImpact(organizationId) {
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
  const byTalent = getRoyaltyByTalent(ledger)
  return {
    generatedAt: format(new Date(), "yyyy-MM-dd'T'HH:mm:ss"),
    ledgerLineCount: ledger.length,
    byTalent,
  }
}
