# Talents / Players Portal

Talent-facing views: dashboard, salary, performance bonus, royalties (and related talent-only screens).
