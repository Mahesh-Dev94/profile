import React, { useMemo } from 'react'
import { useOrganization } from '../../context/OrganizationContext'
import { getAll, getAllByOrganization } from '../../database/dbService'
import { buildRoyaltyLedger } from '../../utils/revenueEngine'
import { forecastRevenue } from '../../utils/forecastEngine'
import { StatCard } from '../../components/cards/StatCard'
import { ChartCard } from '../../components/cards/ChartCard'
import { MonthlyRevenueChart } from '../../components/charts/MonthlyRevenueChart'
import { CountrySalesChart } from '../../components/charts/CountrySalesChart'
import { RoyaltyDistributionChart } from '../../components/charts/RoyaltyDistributionChart'
import { RevenueForecastChart } from '../../components/RevenueForecastChart'
import { AIInsightsPanel } from '../../components/AIInsightsPanel'
import { ComplianceAlerts } from '../../components/ComplianceAlerts'
import { DollarSign, FileCheck, TrendingUp, Users, Receipt } from 'lucide-react'
import { format } from 'date-fns'

export function AdminDashboard() {
  const { currentOrganizationId } = useOrganization()
  const sales = useMemo(() => getAllByOrganization('sales', currentOrganizationId), [currentOrganizationId])
  const contracts = useMemo(() => getAllByOrganization('contracts', currentOrganizationId), [currentOrganizationId])
  const talents = useMemo(() => getAllByOrganization('talents', currentOrganizationId), [currentOrganizationId])
  const sportsBusinesses = useMemo(() => getAllByOrganization('sportsBusinesses', currentOrganizationId), [currentOrganizationId])
  const invoices = useMemo(() => getAllByOrganization('invoices', currentOrganizationId), [currentOrganizationId])
  const payments = useMemo(() => getAllByOrganization('payments', currentOrganizationId), [currentOrganizationId])

  const ledger = useMemo(() => buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses), [sales, contracts, talents, sportsBusinesses])
  const totalRevenue = sales.reduce((a, s) => a + (Number(s.netSales) || 0), 0)
  const royaltyTotal = ledger.reduce((a, r) => a + (r.royaltyEarned || 0), 0)
  const royaltyPaid = invoices.filter((i) => i.status === 'paid').reduce((a, i) => a + (Number(i.royaltyAmount) || 0), 0)
  const pendingSettlements = invoices.filter((i) => i.status === 'pending').length
  const forecastData = useMemo(() => forecastRevenue(sales, 12), [sales])
  const monthlyData = useMemo(() => {
    const byMonth = {}
    sales.forEach((s) => {
      const d = s.date
      const key = d ? (typeof d === 'string' ? d.slice(0, 7) : format(new Date(d), 'yyyy-MM')) : 'unknown'
      byMonth[key] = (byMonth[key] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byMonth).map(([month, revenue]) => ({ month, revenue })).sort((a, b) => a.month.localeCompare(b.month)).slice(-12)
  }, [sales])
  const countryData = useMemo(() => {
    const byCountry = {}
    sales.forEach((s) => {
      const c = s.country || 'Other'
      byCountry[c] = (byCountry[c] || 0) + (Number(s.netSales) || 0)
    })
    return Object.entries(byCountry).map(([country, salesAmt]) => ({ country, sales: salesAmt })).sort((a, b) => b.sales - a.sales)
  }, [sales])
  const royaltyByTalent = useMemo(() => {
    const map = {}
    ledger.forEach((r) => { map[r.talentName] = (map[r.talentName] || 0) + (r.royaltyEarned || 0) })
    return Object.entries(map).map(([name, value]) => ({ name, value })).slice(0, 6)
  }, [ledger])

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Revenue share performance dashboard</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <StatCard title="Total revenue" value={`$${totalRevenue.toLocaleString()}`} icon={DollarSign} />
        <StatCard title="Revenue share paid" value={`$${royaltyPaid.toLocaleString()}`} icon={Receipt} />
        <StatCard title="Active contracts" value={contracts.filter((c) => c.status === 'active').length} icon={FileCheck} />
        <StatCard title="Pending settlements" value={pendingSettlements} icon={TrendingUp} />
        <StatCard title="Forecasted revenue (3mo)" value={`$${forecastData.slice(0, 3).reduce((a, b) => a + (b.forecast || 0), 0).toLocaleString()}`} icon={DollarSign} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <ComplianceAlerts payments={payments} />
        <AIInsightsPanel sales={sales} contracts={contracts} talents={talents} sportsBusinesses={sportsBusinesses} organizationId={currentOrganizationId} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <RevenueForecastChart data={forecastData} title="Revenue forecast" description="Next 12 months" />
        <MonthlyRevenueChart data={monthlyData} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <RoyaltyDistributionChart data={royaltyByTalent} />
        <CountrySalesChart data={countryData} />
      </div>
    </div>
  )
}
