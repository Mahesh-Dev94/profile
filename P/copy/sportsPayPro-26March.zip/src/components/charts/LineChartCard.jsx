import React from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { chartSeries } from '../../theme/chartTheme'

export function LineChartCard({ title, description, data = [], dataKey = 'value', name = 'Value' }) {
  return (
    <ChartCard title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, name]} />
          <Line type="monotone" dataKey={dataKey} stroke={chartSeries.primary} strokeWidth={2} dot={{ r: 4 }} name={name} />
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
