import React from 'react'
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { chartTheme, chartSeries } from '../../theme/chartTheme'

/**
 * Donut of paid vs outstanding share of payable (when payable &gt; 0).
 */
export function PaymentPaidOutstandingDonutChart({
  payable = 0,
  paid = 0,
  outstanding = 0,
  title = 'Paid vs outstanding',
  description,
}) {
  const p = Math.max(0, Number(payable) || 0)
  const d = Math.max(0, Number(paid) || 0)
  const o = Math.max(0, Number(outstanding) || 0)

  const data =
    p <= 0
      ? []
      : [
          { name: 'Paid', value: d, fill: chartTheme.primary[300] },
          { name: 'Outstanding', value: o, fill: chartSeries.accent },
        ].filter((x) => x.value > 0)

  if (p <= 0 || data.length === 0) {
    return (
      <ChartCard title={title} description={description || 'No payable amount in this scope'}>
        <div className="flex h-full items-center justify-center text-sm text-slate-500">No data to chart</div>
      </ChartCard>
    )
  }

  return (
    <ChartCard title={title} description={description || `Share of total payable (${formatMoney(p)})`}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius={58}
            outerRadius={88}
            paddingAngle={2}
          >
            {data.map((entry) => (
              <Cell key={entry.name} fill={entry.fill} />
            ))}
          </Pie>
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Amount']} />
        </PieChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}

function formatMoney(v) {
  const n = Number(v)
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}k`
  return `$${Math.round(n)}`
}
