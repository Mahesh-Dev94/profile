import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { formatINRDisplay } from '../../utils/currencyFormat'
import { chartCategoricalFills } from '../../theme/chartTheme'
import { capDistributionForBarChart } from '../../utils/chartDistributionUtils'

function formatAxisTick(num) {
  const n = Number(num) || 0
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${Math.round(n / 1_000)}k`
  return String(Math.round(n))
}

function BarTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const row = payload[0]?.payload
  if (!row) return null
  return (
    <div className="rounded-lg border border-slate-200/90 bg-white px-3 py-2 text-xs shadow-lg">
      <p className="max-w-[220px] font-semibold leading-snug text-slate-800">{row.name}</p>
      <p className="mt-1 tabular-nums font-bold text-slate-900">{formatINRDisplay(row.value)}</p>
    </div>
  )
}

export function TopTalentHorizontalBarChart({
  data = [],
  title,
  description,
  topN = 10,
  /** Single fill for all bars except "Others" (Material-style flat bars). */
  uniformBarColor = null,
  /** Aggregated "Others" bar — orange accent when using uniform theme bars. */
  othersBarColor = '#94a3b8',
}) {
  const chartData = useMemo(() => capDistributionForBarChart(data, topN), [data, topN])

  if (chartData.length === 0) {
    return (
      <ChartCard title={title} description={description}>
        <div className="flex h-full items-center justify-center text-sm text-slate-500">No data to chart yet.</div>
      </ChartCard>
    )
  }

  return (
    <ChartCard title={title} description={description} className="shadow-md shadow-slate-200/50">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          layout="vertical"
          data={chartData}
          margin={{ top: 4, right: 16, left: 4, bottom: 4 }}
          barCategoryGap={10}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
          <XAxis type="number" tickFormatter={formatAxisTick} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} />
          <YAxis
            type="category"
            dataKey="name"
            width={118}
            tick={{ fontSize: 11, fill: '#334155' }}
            axisLine={false}
            tickLine={false}
            interval={0}
          />
          <Tooltip content={<BarTooltip />} cursor={{ fill: 'rgba(11, 60, 93, 0.07)' }} />
          <Bar dataKey="value" radius={[0, 8, 8, 0]} animationDuration={500} maxBarSize={28}>
            {chartData.map((entry, index) => {
              const isOthers = typeof entry.name === 'string' && entry.name.startsWith('Others')
              const fill = isOthers
                ? othersBarColor
                : uniformBarColor || chartCategoricalFills[index % chartCategoricalFills.length]
              return <Cell key={`${entry.name}-${index}`} fill={fill} />
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
