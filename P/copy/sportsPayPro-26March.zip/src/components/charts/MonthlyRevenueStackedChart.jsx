import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { formatDollar } from '../../utils/currencyFormat'
import { chartSeries } from '../../theme/chartTheme'

/** Compact axis label (e.g. $15k, $1.5M) */
function formatShort(num) {
  if (num == null || Number.isNaN(Number(num))) return '—'
  const n = Number(num)
  if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`
  if (n >= 1000) return `$${(n / 1000).toFixed(0)}k`
  return `$${n}`
}

/**
 * Stacked bar chart: Revenue by month with salary and revenue share.
 * data: [{ month, salary, royalty, total }, ...]
 */
export function MonthlyRevenueStackedChart({
  data = [],
  title = 'Monthly Revenue (Salary + Revenue share)',
  description = 'Revenue by month: salary and revenue share',
}) {
  const displayData = data.map((d) => ({
    ...d,
    monthLabel: d.month ? (() => {
      const [y, m] = String(d.month).split('-')
      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
      const idx = parseInt(m, 10) - 1
      return idx >= 0 && idx < 12 ? `${months[idx]} ${y}` : d.month
    })() : d.month,
  }))

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-card">
      <h3 className="mb-1 text-base font-medium">{title}</h3>
      {description && <p className="mb-4 text-xs text-neutral">{description}</p>}
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={displayData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }} stackOffset="none">
            <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
            <XAxis dataKey="monthLabel" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => formatShort(v)} />
            <Tooltip
              formatter={(value) => [`$${formatDollar(value)}`, '']}
              labelFormatter={(label) => `Month: ${label}`}
              content={({ active, payload, label }) => {
                if (!active || !payload?.length) return null
                const row = payload[0]?.payload
                return (
                  <div className="rounded-md border border-gray-200 bg-white px-3 py-2 text-xs shadow-md">
                    <p className="font-medium text-gray-900">{label}</p>
                    <p className="mt-1 text-primary">Salary: $ {formatDollar(row?.salary ?? 0)}</p>
                    <p className="text-accent">Revenue share: $ {formatDollar(row?.royalty ?? 0)}</p>
                    <p className="mt-1 border-t border-gray-100 pt-1 font-medium">Total: $ {formatDollar(row?.total ?? 0)}</p>
                  </div>
                )
              }}
            />
            <Legend formatter={(value) => (value === 'salary' ? 'Salary' : value === 'royalty' ? 'Revenue share' : value)} />
            <Bar dataKey="salary" name="salary" stackId="rev" fill={chartSeries.primary} radius={[0, 0, 0, 0]} />
            <Bar dataKey="royalty" name="royalty" stackId="rev" fill={chartSeries.accent} radius={[0, 0, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
