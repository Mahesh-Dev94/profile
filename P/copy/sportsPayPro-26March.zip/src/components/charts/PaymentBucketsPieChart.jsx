import React, { useMemo } from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { formatINRDisplay } from '../../utils/currencyFormat'

/** Theme: payable dark blue, paid steel blue, outstanding orange */
const BUCKET_COLORS = ['#0B3C5D', '#3d7aad', '#F97316']

function PieTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const row = payload[0]
  const name = row.name
  const value = row.value
  return (
    <div className="rounded-xl border border-slate-200/90 bg-white px-3 py-2.5 text-sm shadow-lg">
      <p className="font-semibold text-slate-800">{name}</p>
      <p className="mt-0.5 tabular-nums text-base font-bold text-slate-900">{formatINRDisplay(value)}</p>
    </div>
  )
}

export function PaymentBucketsPieChart({
  payable,
  paid,
  outstanding,
  payableLabel = 'Total payable',
  paidLabel = 'Total paid',
  outstandingLabel = 'Total outstanding',
  title,
  description,
}) {
  const data = useMemo(() => {
    const p = Math.max(0, Number(payable) || 0)
    const pd = Math.max(0, Number(paid) || 0)
    const o = Math.max(0, Number(outstanding) || 0)
    return [
      { name: payableLabel, value: p },
      { name: paidLabel, value: pd },
      { name: outstandingLabel, value: o },
    ]
  }, [payable, paid, outstanding, payableLabel, paidLabel, outstandingLabel])

  const total = data.reduce((a, d) => a + d.value, 0)

  if (total <= 0) {
    return (
      <ChartCard title={title} description={description} className="shadow-md shadow-slate-200/50">
        <div className="flex h-full items-center justify-center text-sm text-slate-500">No amounts to chart yet.</div>
      </ChartCard>
    )
  }

  return (
    <ChartCard title={title} description={description} className="shadow-md shadow-slate-200/50">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={56}
            outerRadius={86}
            paddingAngle={2}
            dataKey="value"
            nameKey="name"
            label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
            labelLine={{ stroke: '#94a3b8', strokeWidth: 1 }}
          >
            {data.map((_, i) => (
              <Cell key={i} fill={BUCKET_COLORS[i % BUCKET_COLORS.length]} stroke="#fff" strokeWidth={1} />
            ))}
          </Pie>
          <Tooltip content={<PieTooltip />} />
          <Legend
            verticalAlign="bottom"
            formatter={(value) => <span className="text-xs text-slate-700">{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
