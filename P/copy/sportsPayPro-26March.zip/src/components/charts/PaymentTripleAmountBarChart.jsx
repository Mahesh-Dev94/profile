import React from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ChartCard } from '../cards/ChartCard'
import { chartTheme, chartSeries } from '../../theme/chartTheme'

const KIND_LABELS = {
  salary: {
    payable: 'Total payable salary',
    paid: 'Total paid salary',
    outstanding: 'Total outstanding salary',
  },
  bonus: {
    payable: 'Total payable bonus',
    paid: 'Total paid bonus',
    outstanding: 'Total outstanding bonus',
  },
  royalty: {
    payable: 'Total payable revenue share',
    paid: 'Total paid revenue share',
    outstanding: 'Total outstanding revenue share',
  },
  misc: {
    payable: 'Total payable miscellaneous',
    paid: 'Total paid miscellaneous',
    outstanding: 'Total outstanding miscellaneous',
  },
}

const FILLS = [chartSeries.primary, chartTheme.primary[300], chartSeries.accent]

function formatAxis(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) return ''
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}k`
  return `$${Math.round(n)}`
}

/**
 * Vertical bars for payable / paid / outstanding (Payment summary tab strip).
 */
export function PaymentTripleAmountBarChart({
  payable = 0,
  paid = 0,
  outstanding = 0,
  kind = 'salary',
  year,
  scopeNote,
}) {
  const labels = KIND_LABELS[kind] || KIND_LABELS.salary
  const data = [
    { key: 'payable', label: labels.payable, short: 'Payable', value: Math.max(0, Number(payable) || 0), fill: FILLS[0] },
    { key: 'paid', label: labels.paid, short: 'Paid', value: Math.max(0, Number(paid) || 0), fill: FILLS[1] },
    {
      key: 'outstanding',
      label: labels.outstanding,
      short: 'Outstanding',
      value: Math.max(0, Number(outstanding) || 0),
      fill: FILLS[2],
    },
  ]

  const title =
    kind === 'salary'
      ? 'Payable, paid & outstanding · Salary'
      : kind === 'bonus'
        ? 'Payable, paid & outstanding · Bonus'
        : kind === 'royalty'
          ? 'Payable, paid & outstanding · Revenue share'
          : 'Payable, paid & outstanding · Miscellaneous'

  const description = [year && `Reporting year ${year}`, scopeNote].filter(Boolean).join(' · ') || 'Organization totals for the selected scope'

  return (
    <ChartCard title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: 4, bottom: 8 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="short" tick={{ fontSize: 11 }} interval={0} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={formatAxis} width={48} />
          <Tooltip
            formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Amount']}
            labelFormatter={(_, payload) => (payload?.[0]?.payload?.label ? String(payload[0].payload.label) : '')}
          />
          <Bar dataKey="value" radius={[4, 4, 0, 0]} name="Amount">
            {data.map((entry) => (
              <Cell key={entry.key} fill={entry.fill} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
