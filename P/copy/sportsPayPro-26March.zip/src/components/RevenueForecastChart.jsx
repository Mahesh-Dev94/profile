import React from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { ChartCard } from './cards/ChartCard'
import { chartSeries } from '../theme/chartTheme'

export function RevenueForecastChart({ data = [], title = 'Revenue forecast', description = 'Next 3–12 months' }) {
  return (
    <ChartCard title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" />
          <XAxis dataKey="month" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
          <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, 'Forecast']} />
          <Legend />
          <Line type="monotone" dataKey="forecast" stroke={chartSeries.primary} strokeWidth={2} name="Forecast" dot={{ r: 3 }} />
          {data.some((d) => d.actual != null) && (
            <Line type="monotone" dataKey="actual" stroke={chartSeries.accent} strokeWidth={1} name="Actual" dot={{ r: 2 }} />
          )}
        </LineChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
