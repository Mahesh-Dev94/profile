import React from 'react'
import { cn } from '../../utils/cn'
import { ThemedSpinner } from './ThemedSpinner'

/**
 * Skeleton layout with themed overlay — circle spinner + message.
 */
export function PageLoaderWithSkeleton({ message = 'Loading…', className }) {
  return (
    <div className={cn('relative min-h-[400px]', className)}>
      <div className="space-y-6 animate-pulse">
        <div className="flex justify-end">
          <div className="h-8 w-24 rounded-md bg-primary/10" />
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div
              key={i}
              className="theme-card-muted rounded-lg border border-primary/10 p-4"
            >
              <div className="mb-3 h-3 w-16 rounded bg-primary/10" />
              <div className="h-6 w-20 rounded bg-primary/15" />
            </div>
          ))}
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="theme-card-muted min-h-[280px] rounded-lg border border-primary/10 p-5">
            <div className="mb-3 h-4 w-32 rounded bg-primary/10" />
            <div className="h-[200px] rounded bg-primary/10" />
          </div>
          <div className="theme-card-muted min-h-[280px] rounded-lg border border-primary/10 p-5">
            <div className="mb-3 h-4 w-32 rounded bg-primary/10" />
            <div className="h-[200px] rounded bg-primary/10" />
          </div>
        </div>
        <div className="theme-card-muted min-h-[160px] rounded-lg border border-primary/10 p-5">
          <div className="mb-3 h-4 w-40 rounded bg-primary/10" />
          <div className="mb-2 h-3 w-full rounded bg-primary/10" />
          <div className="mb-2 h-3 w-full rounded bg-primary/10" />
          <div className="h-3 w-3/4 rounded bg-primary/10" />
        </div>
      </div>

      <div className="absolute inset-0 flex items-center justify-center rounded-lg bg-white/85 backdrop-blur-[2px]">
        <div className="theme-card-muted border-primary/15 px-10 py-8 shadow-card">
          <ThemedSpinner message={message} size="lg" />
        </div>
      </div>
    </div>
  )
}
