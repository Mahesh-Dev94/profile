import React from 'react'
import { cn } from '../../utils/cn'
import { ThemedSpinner } from './ThemedSpinner'

export function PageLoader({ message = 'Loading…', className }) {
  return (
    <div
      className={cn(
        'flex min-h-[280px] flex-col items-center justify-center p-8',
        className
      )}
    >
      <div className="theme-card-muted flex flex-col items-center px-8 py-7">
        <ThemedSpinner message={message} size="md" />
      </div>
    </div>
  )
}
