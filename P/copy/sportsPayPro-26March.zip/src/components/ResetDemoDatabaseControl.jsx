import React, { useState } from 'react'
import { resetDb } from '../database/dbService'
import { Button } from './ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog'
import toast from 'react-hot-toast'
import { cn } from '../utils/cn'
import { DatabaseBackup } from 'lucide-react'

/**
 * Wipes local demo data (SQLite / IndexedDB or localStorage) and reloads seed data, then hard-refreshes the app.
 */
export function ResetDemoDatabaseControl({
  variant = 'default',
  className,
  sidebarOpen = true,
}) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  const runReset = () => {
    setBusy(true)
    try {
      resetDb()
      toast.success('Demo database restored from seed. Reloading…', { duration: 2500 })
      setOpen(false)
      window.setTimeout(() => {
        window.location.href = '/'
      }, 350)
    } catch (e) {
      console.error(e)
      toast.error('Could not reset database.')
      setBusy(false)
    }
  }

  const triggerClass =
    variant === 'landing'
      ? cn(
          'inline-flex items-center justify-center gap-2 rounded-lg border border-white/20 bg-white/5 px-4 py-2.5 text-2xs font-semibold text-white transition-colors hover:bg-white/10',
          className
        )
      : cn(
          'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-2xs font-medium text-red-700 transition-colors hover:bg-red-50',
          !sidebarOpen && 'justify-center px-0 text-red-600',
          className
        )

  return (
    <>
      <button
        type="button"
        className={triggerClass}
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        title={!sidebarOpen && variant === 'sidebar' ? 'Reset demo database' : undefined}
      >
        <DatabaseBackup
          className={cn('h-4 w-4 shrink-0', variant === 'landing' ? 'text-accent' : 'text-red-600')}
          aria-hidden
        />
        {(variant === 'landing' || sidebarOpen) && <span>Reset demo database</span>}
      </button>

      <Dialog open={open} onOpenChange={(v) => !busy && setOpen(v)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Reset demo database?</DialogTitle>
            <DialogDescription>
              This removes all local changes (sales uploads, edits, payments) and restores the built-in seed dataset. Your browser
              session will reload on the welcome screen.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" disabled={busy} onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="button" variant="destructive" disabled={busy} onClick={runReset}>
              {busy ? 'Resetting…' : 'Reset to seed data'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
