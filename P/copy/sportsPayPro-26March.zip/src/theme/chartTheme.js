/**
 * Chart colors aligned with tailwind.config.js (primary blue, accent orange).
 * — Yellow (#EAB308) → accent orange
 * — Green (#10B981) → primary-300 sky blue (distinct, on-brand, not green)
 */
export const chartTheme = {
  primary: {
    DEFAULT: '#0B3C5D',
    300: '#6d9cc4',
    400: '#3d7aad',
    500: '#0B3C5D',
    600: '#09304a',
    700: '#072438',
    800: '#051825',
  },
  accent: {
    DEFAULT: '#F97316',
    300: '#fdba74',
    400: '#fb923c',
    500: '#F97316',
    600: '#ea580c',
    700: '#c2410c',
  },
}

export const chartSeries = {
  primary: chartTheme.primary[500],
  accent: chartTheme.accent[500],
}

/** Pie / multi-series: navy, orange, sky-blue (replaces green), then alternating shades */
export const chartCategoricalFills = [
  chartTheme.primary[500],
  chartTheme.accent[500],
  chartTheme.primary[300],
  chartTheme.accent[400],
  chartTheme.primary[600],
  chartTheme.accent[600],
  chartTheme.primary[400],
  chartTheme.accent[300],
  chartTheme.primary[700],
  chartTheme.accent[700],
]
