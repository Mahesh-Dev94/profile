/**
 * Central revenue-share surface: re-exports ledger math and adds per-contract / per-talent rollups
 * so Sport Business, Talent, and Vendor modules stay consistent.
 */
import { getAllByOrganization } from '../database/dbService'
import {
  buildRoyaltyLedger,
  calcNetSales,
  calcRoyaltyToTalent,
  getRoyaltyByTalent,
} from './revenueEngine'

export { buildRoyaltyLedger, calcNetSales, calcRoyaltyToTalent, getRoyaltyByTalent }

/** Group ledger rows by talent + contract (via sale matching contract talentId + licensee). */
export function buildPerContractRoyaltyTotals(sales, contracts, talents, sportsBusinesses) {
  const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
  const saleById = new Map((sales || []).map((s) => [s.id, s]))
  const map = new Map()
  for (const row of ledger) {
    const sale = saleById.get(row.saleId)
    const contract = contracts.find(
      (c) =>
        c.talentId === row.talentId &&
        (c.licenseeId === sale?.licenseeId || c.licensee === row.licensee || c.licensee === sale?.licensee)
    )
    const cid = contract?.id || contract?.contractID || 'unmatched'
    const key = `${row.talentId}::${cid}`
    const prev = map.get(key) || {
      talentId: row.talentId,
      talentName: row.talentName,
      contractId: contract?.id,
      contractID: contract?.contractID,
      productType: contract?.productType || row.product,
      royaltyPercent: row.royaltyPercent,
      totalNetSales: 0,
      royaltyEarned: 0,
      rowCount: 0,
    }
    prev.totalNetSales += Number(row.netSales) || 0
    prev.royaltyEarned += Number(row.royaltyEarned) || 0
    prev.rowCount += 1
    map.set(key, prev)
  }
  return [...map.values()].sort((a, b) => b.royaltyEarned - a.royaltyEarned)
}

export function getOrganizationRevenueShareContext(organizationId) {
  const sales = getAllByOrganization('sales', organizationId)
  const contracts = getAllByOrganization('contracts', organizationId)
  const talents = getAllByOrganization('talents', organizationId)
  const sportsBusinesses = getAllByOrganization('sportsBusinesses', organizationId)
  const revenueShareContracts = getAllByOrganization('revenueShareContracts', organizationId)
  const ledger = buildRoyaltyLedger(sales, contracts, talents, sportsBusinesses)
  const byContract = buildPerContractRoyaltyTotals(sales, contracts, talents, sportsBusinesses)
  const byTalentChart = getRoyaltyByTalent(ledger)
  return {
    sales,
    contracts,
    talents,
    sportsBusinesses,
    revenueShareContracts,
    ledger,
    byContract,
    byTalentChart,
  }
}
