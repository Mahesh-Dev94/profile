/**
 * Reporting years for Payment summary and roster breakdowns (must stay in sync).
 */
import { getAllByOrganization } from '../database/dbService'

const FALLBACK_YEARS = ['2027', '2026', '2025', '2024']

/** Years excluded from the payment summary year picker (demo / product rule). */
export const EXCLUDED_PAYMENT_REPORT_YEARS = new Set(['2028'])

export function inferPaymentSummaryYearOptions(organizationId) {
  const ys = new Set(FALLBACK_YEARS)
  const add = (d) => {
    if (d == null) return
    const s = String(d)
    if (s.length >= 4 && /^\d{4}/.test(s)) ys.add(s.slice(0, 4))
  }
  ;(getAllByOrganization('salaryPayments', organizationId) || []).forEach((s) => add(s.month))
  ;(getAllByOrganization('invoices', organizationId) || []).forEach((inv) => {
    add(inv.date)
    add(inv.issueDate)
    add(inv.invoiceDate)
  })
  ;(getAllByOrganization('signingBonuses', organizationId) || []).forEach((b) => {
    add(b.signingDate)
    add(b.releaseDate)
  })
  ;(getAllByOrganization('sales', organizationId) || []).forEach((sale) => add(sale.date))
  ys.add(String(new Date().getFullYear()))
  return [...ys].sort((a, b) => Number(b) - Number(a))
}

/**
 * Default calendar year for dashboard / talents list totals — same logic as Payment summary
 * when no `year` is in the URL (current year if allowed, else first available).
 */
export function resolveDefaultPaymentReportYear(organizationId) {
  const options = inferPaymentSummaryYearOptions(organizationId).filter((y) => !EXCLUDED_PAYMENT_REPORT_YEARS.has(y))
  const cur = String(new Date().getFullYear())
  if (options.length === 0) return EXCLUDED_PAYMENT_REPORT_YEARS.has(cur) ? '2026' : cur
  if (options.includes(cur)) return cur
  return options[0]
}
