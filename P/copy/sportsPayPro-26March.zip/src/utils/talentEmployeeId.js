/** Display label for HR / payroll employee id on talent records. */
export function getTalentEmployeeIdDisplay(talent) {
  if (!talent) return '—'
  const v = (talent.employeeId ?? '').toString().trim()
  return v || '—'
}

export function talentMatchesSearch(talent, queryLower) {
  if (!queryLower) return true
  const name = (talent?.name || '').toLowerCase()
  const emp = (talent?.employeeId || '').toLowerCase()
  return name.includes(queryLower) || emp.includes(queryLower)
}
