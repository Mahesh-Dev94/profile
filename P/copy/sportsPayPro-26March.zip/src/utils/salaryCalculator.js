/**
 * Salary and compensation calculations for talent payments.
 * Monthly compensation = Monthly Salary + Monthly Performance Bonus + Monthly Royalty.
 *
 * Performance bonus on payroll: **$180,000 per month** for each month in
 * **2025-01 … 2025-12** and **2026-01 … 2026-03** only. Outside that range: $0 on slips.
 * (Annual pool if all 12 months paid = $2.16M ≈ 12% of $18M standard annual.)
 */

/** First and last yyyy-MM (inclusive) that receive the fixed monthly performance bonus. */
export const PERFORMANCE_BONUS_PAYROLL_FIRST_YM = '2025-01'
export const PERFORMANCE_BONUS_PAYROLL_LAST_YM = '2026-03'

/** Human-readable payroll window for UI / PDF copy. */
export const PERFORMANCE_BONUS_PAYROLL_LABEL = 'Jan 2025–Dec 2025 & Jan–Mar 2026'

/** Standard annual salary per talent (contract baseline). */
export const STANDARD_ANNUAL_SALARY = 18_000_000

/** Fixed monthly performance bonus during {@link PERFORMANCE_BONUS_PAYROLL_LABEL}. */
export const MONTHLY_PERFORMANCE_BONUS_AMOUNT = 180_000

/** Full-year pool at $180k × 12 (signing-bonus ledger / certificate headline). */
export const ANNUAL_PERFORMANCE_BONUS_AMOUNT = MONTHLY_PERFORMANCE_BONUS_AMOUNT * 12

/** Effective share of standard annual (2.16M / 18M). */
export const PERFORMANCE_BONUS_PERCENT_OF_ANNUAL = ANNUAL_PERFORMANCE_BONUS_AMOUNT / STANDARD_ANNUAL_SALARY

export function isPayrollPerformanceBonusMonth(monthYm) {
  const ym = String(monthYm || '').slice(0, 7)
  if (!/^\d{4}-\d{2}$/.test(ym)) return false
  return ym >= PERFORMANCE_BONUS_PAYROLL_FIRST_YM && ym <= PERFORMANCE_BONUS_PAYROLL_LAST_YM
}

export function getMonthlySalary(annualSalary) {
  return (Number(annualSalary) || 0) / 12
}

/** Sum monthly performance bonus (payroll window) from salary payment rows. */
export function getPayrollPerformanceBonusTotalsFromSalaryRows(salaryPayments) {
  let payable = 0
  let paid = 0
  let outstanding = 0
  ;(salaryPayments || []).forEach((s) => {
    const key = String(s.month || '').slice(0, 7)
    if (!isPayrollPerformanceBonusMonth(key)) return
    const per = MONTHLY_PERFORMANCE_BONUS_AMOUNT
    payable += per
    if (s.paymentStatus === 'paid') paid += per
    if (s.paymentStatus === 'pending') outstanding += per
  })
  return { payable, paid, outstanding }
}

/** For charts: total payroll performance bonus per talent name. */
export function getPayrollPerformanceBonusByTalentName(salaryPayments) {
  const byName = {}
  ;(salaryPayments || []).forEach((s) => {
    const key = String(s.month || '').slice(0, 7)
    if (!isPayrollPerformanceBonusMonth(key)) return
    const name = s.talentName || 'Unknown'
    byName[name] = (byName[name] || 0) + MONTHLY_PERFORMANCE_BONUS_AMOUNT
  })
  return Object.entries(byName)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
}

/**
 * Monthly performance bonus: $180,000 only for months in the payroll window
 * ({@link PERFORMANCE_BONUS_PAYROLL_FIRST_YM}–{@link PERFORMANCE_BONUS_PAYROLL_LAST_YM}); else 0.
 */
export function getMonthlyPerformanceBonus(talentId, month, _signingBonuses, _annualSalary = STANDARD_ANNUAL_SALARY) {
  if (!month || !talentId) return 0
  if (!isPayrollPerformanceBonusMonth(month)) return 0
  return MONTHLY_PERFORMANCE_BONUS_AMOUNT
}

/** Monthly royalty for a talent in a given month from royalty ledger. */
export function getMonthlyRoyalty(talentId, month, ledger) {
  if (!month || !ledger?.length) return 0
  const monthStr = String(month).slice(0, 7)
  return (ledger || [])
    .filter((r) => r.talentId === talentId && String(r.date || '').slice(0, 7) === monthStr)
    .reduce((sum, r) => sum + (Number(r.royaltyEarned) || 0), 0)
}

/** Enrich salary payment rows with monthly performance bonus, monthly royalty, and total earnings. */
export function enrichSalaryPayments(salaryPayments, signingBonuses, ledger, annualSalaryByTalentId = {}) {
  return (salaryPayments || []).map((s) => {
    const monthlySalary = Number(s.salaryAmount) || 0
    const annualForTalent = annualSalaryByTalentId[s.talentId]
    const monthlyPerformanceBonus = getMonthlyPerformanceBonus(s.talentId, s.month, signingBonuses, annualForTalent)
    const monthlyRoyalty = getMonthlyRoyalty(s.talentId, s.month, ledger)
    const totalEarnings = monthlySalary + monthlyPerformanceBonus + monthlyRoyalty
    return {
      ...s,
      monthlyPerformanceBonus,
      monthlyRoyalty,
      totalEarnings,
    }
  })
}

export function getAnnualSalaryTotal(salaryPayments) {
  return (salaryPayments || []).reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

/** Total compensation (salary + monthly performance bonus + royalty) across all rows. */
export function getTotalCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const enriched = enrichSalaryPayments(salaryPayments, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

/** Paid compensation total (paid rows only). */
export function getPaidCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const paid = (salaryPayments || []).filter((s) => s.paymentStatus === 'paid')
  const enriched = enrichSalaryPayments(paid, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

/** Pending compensation total (pending rows only). */
export function getPendingCompensationTotal(salaryPayments, signingBonuses, ledger) {
  const pending = (salaryPayments || []).filter((s) => s.paymentStatus === 'pending')
  const enriched = enrichSalaryPayments(pending, signingBonuses, ledger)
  return enriched.reduce((sum, s) => sum + (s.totalEarnings || 0), 0)
}

export function getPaidSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'paid')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

export function getPendingSalaryTotal(salaryPayments) {
  return (salaryPayments || [])
    .filter((s) => s.paymentStatus === 'pending')
    .reduce((sum, s) => sum + (Number(s.salaryAmount) || 0), 0)
}

/** Per-talent salary totals (matches Salary page figures when summed per talent). */
export function getSalaryByTalent(salaryPayments) {
  const byTalent = {}
  ;(salaryPayments || []).forEach((s) => {
    const id = s.talentId || s.talentName
    const name = s.talentName || 'Unknown'
    if (!byTalent[id]) byTalent[id] = { talentId: s.talentId, name, value: 0 }
    byTalent[id].value += Number(s.salaryAmount) || 0
  })
  return Object.values(byTalent)
    .map(({ name, value }) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
}

/** Per-talent annual salary from contracts (one value per talent, for summary/chart). */
export function getAnnualSalaryByTalentFromContracts(contracts) {
  const byTalent = {}
  ;(contracts || []).forEach((c) => {
    const id = c.talentId
    if (!id || byTalent[id]) return
    const annual = Number(c.basicSalary2026_27 ?? c.annualSalary) || 0
    byTalent[id] = { name: c.talentName || 'Unknown', value: annual }
  })
  return Object.values(byTalent).sort((a, b) => b.value - a.value)
}
