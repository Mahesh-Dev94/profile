import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { getAll } from '../database/dbService'
import { DEFAULT_PORTAL_ROLE_PRIORITY } from '../config/defaultSession'

const AUTH_STORAGE_KEY = 'sports_platform_auth'

const AuthContext = createContext(null)

function pickDefaultClubUser() {
  const users = getAll('users')
  return users.find((u) => DEFAULT_PORTAL_ROLE_PRIORITY.includes(u.role)) || users[0] || null
}

function buildSessionFromUser(match) {
  return {
    id: match.id,
    email: match.email,
    role: match.role,
    name: match.name,
    talentId: match.talentId,
    organizationId: match.organizationId,
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTH_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (parsed?.id && parsed?.email) {
          setUser(parsed)
          return
        }
      }
      const match = pickDefaultClubUser()
      if (match) {
        const session = buildSessionFromUser(match)
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
        setUser(session)
      }
    } catch (_) {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }, [])

  const roleAllowed = (selectedRole, dbRole) => {
    if (selectedRole === dbRole) return true
    if (selectedRole === 'sponsorship_admin' && (dbRole === 'platform_admin' || dbRole === 'finance_manager')) return true
    if (selectedRole === 'vendor_partner' && dbRole === 'partner') return true
    return false
  }

  const login = useCallback((email, password, role) => {
    const users = getAll('users')
    const match = users.find(
      (u) => u.email === email && u.password === password && roleAllowed(role, u.role)
    )
    if (!match) return { success: false, error: 'Invalid credentials or role' }
    const session = buildSessionFromUser(match)
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_STORAGE_KEY)
    setUser(null)
  }, [])

  const loginAsFirstUserForRole = useCallback((role) => {
    const users = getAll('users')
    let match = null
    if (role === 'sponsorship_admin') {
      match = users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role))
    } else if (role === 'talent') {
      match = users.find((u) => u.role === 'talent')
    } else if (role === 'vendor_partner') {
      match = users.find((u) => u.role === 'vendor_partner' || u.role === 'partner')
    }
    if (!match) return { success: false }
    const session = buildSessionFromUser(match)
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }, [])

  const value = { user, loading, login, loginAsFirstUserForRole, logout, isAuthenticated: !!user }
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
