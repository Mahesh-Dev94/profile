import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { OrganizationProvider } from './context/OrganizationContext'
import { AppStoreProvider } from './context/AppStore'
import { Toaster } from 'react-hot-toast'
import { initDatabase } from './database/dbService'
import App from './App'
import './index.css'

const TOAST_BASE = {
  fontSize: '12px',
  fontWeight: 500,
  maxWidth: 'min(400px, 92vw)',
  borderRadius: '10px',
  boxShadow: '0 8px 24px rgba(11, 60, 93, 0.12)',
}

const root = ReactDOM.createRoot(document.getElementById('root'))

function renderApp() {
  root.render(
    <React.StrictMode>
      <BrowserRouter>
        <AuthProvider>
          <OrganizationProvider>
            <AppStoreProvider>
              <App />
              <Toaster
                position="top-right"
                containerStyle={{ top: 12, right: 12 }}
                toastOptions={{
                  duration: 4000,
                  className: '!font-sans',
                  style: {
                    ...TOAST_BASE,
                    background: '#ffffff',
                    color: '#0B3C5D',
                    border: '1px solid rgba(11, 60, 93, 0.18)',
                  },
                  success: {
                    style: {
                      ...TOAST_BASE,
                      background: '#0B3C5D',
                      color: '#ffffff',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                    },
                    iconTheme: {
                      primary: '#ffffff',
                      secondary: '#0B3C5D',
                    },
                  },
                  error: {
                    style: {
                      ...TOAST_BASE,
                      background: '#c2410c',
                      color: '#ffffff',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                    },
                    iconTheme: {
                      primary: '#ffffff',
                      secondary: '#c2410c',
                    },
                  },
                  loading: {
                    style: {
                      ...TOAST_BASE,
                      background: '#265a93',
                      color: '#ffffff',
                      border: '1px solid rgba(255, 255, 255, 0.15)',
                    },
                    iconTheme: {
                      primary: '#ffffff',
                      secondary: '#265a93',
                    },
                  },
                }}
              />
            </AppStoreProvider>
          </OrganizationProvider>
        </AuthProvider>
      </BrowserRouter>
    </React.StrictMode>,
  )
}

// Initialize db (sql.js + IndexedDB, or fallback to localStorage), then render
initDatabase().then(renderApp)
