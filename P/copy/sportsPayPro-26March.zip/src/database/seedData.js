import { ANNUAL_PERFORMANCE_BONUS_AMOUNT } from '../utils/salaryCalculator'

const STORAGE_KEY = 'royalty_payment_engine_db'

const ORG_1 = 'org-1'

// Default login: Sport Business = Metropolis Meteors, Vendor = Zenith Sportswear, Talent = Arjun "Ace" Verma
const defaultUsers = [
  { id: 'u-sb-1', email: 'club@meteors.com', password: 'admin123', role: 'sponsorship_admin', name: 'Metropolis Meteors American Football Pvt. Ltd.', organizationId: ORG_1 },
  { id: 'u-vendor-1', email: 'zenith@vendor.com', password: 'admin123', role: 'vendor_partner', name: 'Zenith Sportswear India Pvt. Ltd.', organizationId: ORG_1 },
  { id: 'u-talent-1', email: 'arjun@talent.com', password: 'talent123', role: 'talent', name: 'Arjun "Ace" Verma', talentId: 't-1', organizationId: ORG_1 },
  { id: 'u-admin-2', email: 'admin@sponsorship.com', password: 'admin123', role: 'platform_admin', name: 'Platform Admin', organizationId: ORG_1 },
  { id: 'u-talent-2', email: 'talent2@sports.com', password: 'talent123', role: 'talent', name: 'Jordan Lee', talentId: 't-2', organizationId: ORG_1 },
]

const defaultOrganizations = [
  { id: ORG_1, name: 'Metropolis Meteors American Football Pvt. Ltd.', createdAt: '2025-01-01' },
]

/** Annual salary 18M; performance bonus pool = 12 × $180k/mo payroll line (Jan 2025–Dec 2025 & Jan–Mar 2026 on slips). */
const ANNUAL_SALARY = 18_000_000
const ANNUAL_PERFORMANCE_BONUS = ANNUAL_PERFORMANCE_BONUS_AMOUNT

const defaultTalents = [
  { id: 't-1', name: 'Arjun "Ace" Verma', employeeId: 'EMP-2025-001', signingDate: '2025-01-15', signingBonus: ANNUAL_PERFORMANCE_BONUS, releaseDate: '2025-01-29', signingBonusStatus: 'paid', organizationId: ORG_1 },
  { id: 't-2', name: 'Jordan Lee', employeeId: 'EMP-2025-002', signingDate: '2025-02-20', signingBonus: ANNUAL_PERFORMANCE_BONUS, releaseDate: '2025-03-06', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-3', name: 'Sam Williams', employeeId: 'EMP-2025-003', signingDate: '2025-03-10', signingBonus: ANNUAL_PERFORMANCE_BONUS, releaseDate: '2025-03-24', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-4', name: 'Morgan Taylor', employeeId: 'EMP-2025-004', signingDate: '2025-04-05', signingBonus: ANNUAL_PERFORMANCE_BONUS, releaseDate: '2025-04-21', signingBonusStatus: 'pending', organizationId: ORG_1 },
  { id: 't-5', name: 'Casey Kim', employeeId: 'EMP-2025-005', signingDate: '2025-05-12', signingBonus: ANNUAL_PERFORMANCE_BONUS, releaseDate: '2025-05-28', signingBonusStatus: 'pending', organizationId: ORG_1 },
]

const defaultSportsBusinesses = [
  { id: 'sb-1', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 120000, revenueSharePercent: 0.15, minimumGuarantee: 20000, talentsAssociated: ['t-1', 't-2'], organizationId: ORG_1 },
  { id: 'sb-2', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 85000, revenueSharePercent: 0.12, talentsAssociated: ['t-1', 't-3'], organizationId: ORG_1 },
  { id: 'sb-3', businessName: 'Metropolis Meteors American Football Pvt. Ltd.', revenueRecognized: 95000, revenueSharePercent: 0.14, talentsAssociated: ['t-2', 't-4'], organizationId: ORG_1 },
]

const defaultSponsorshipCompanies = [
  { id: 'sc-1', companyName: 'Zenith Sportswear India Pvt. Ltd.', country: 'India', contractValue: 500000, royaltyRate: 0.28, minimumGuarantee: 40000, organizationId: ORG_1 },
  { id: 'sc-2', companyName: 'Global Athletics', country: 'UK', contractValue: 350000, royaltyRate: 0.26, minimumGuarantee: 25000, organizationId: ORG_1 },
]

// Annual salary 18M each; performance bonus 10% of annual on contract / signing bonus records.
const defaultContracts = [
  { id: 'c-1', contractID: 'CNT-2025-001', talentId: 't-1', talentName: 'Arjun "Ace" Verma', licenseeId: 'sb-1', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-1', productType: 'Jersey & apparel endorsement', annualSalary: ANNUAL_SALARY, basicSalary2026_27: ANNUAL_SALARY, basicSalary2027_28: ANNUAL_SALARY, royaltyPercent: 0.28, signingBonus: ANNUAL_PERFORMANCE_BONUS, minimumGuarantee: 40000, skuMinimumGuaranteeAnnual: 500000, startDate: '2025-01-01', endDate: '2027-12-31', status: 'active', contractSummary: 'Primary jersey and co-branded apparel; 28% net sales revenue share with MG.', contractSigningDate: '2024-12-18', organizationId: ORG_1 },
  { id: 'c-2', contractID: 'CNT-2025-002', talentId: 't-2', talentName: 'Jordan Lee', licenseeId: 'sb-1', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-2', productType: 'Equipment & training kit', annualSalary: ANNUAL_SALARY, basicSalary2026_27: ANNUAL_SALARY, basicSalary2027_28: ANNUAL_SALARY, royaltyPercent: 0.26, signingBonus: ANNUAL_PERFORMANCE_BONUS, minimumGuarantee: 25000, skuMinimumGuaranteeAnnual: 400000, startDate: '2025-02-01', endDate: '2027-12-31', status: 'active', contractSummary: 'Training kit and equipment line; 26% net sales revenue share.', contractSigningDate: '2025-01-22', organizationId: ORG_1 },
  { id: 'c-3', contractID: 'CNT-2025-003', talentId: 't-3', talentName: 'Sam Williams', licenseeId: 'sb-2', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', sponsorId: 'sc-1', productType: 'Jersey Line B', annualSalary: ANNUAL_SALARY, basicSalary2026_27: ANNUAL_SALARY, basicSalary2027_28: ANNUAL_SALARY, royaltyPercent: 0.27, signingBonus: ANNUAL_PERFORMANCE_BONUS, skuMinimumGuaranteeAnnual: 450000, startDate: '2025-03-01', endDate: '2027-12-31', status: 'active', contractSummary: 'Alternate jersey program with vendor Zenith; 27% revenue share aligned to SKU MG.', contractSigningDate: '2025-02-10', organizationId: ORG_1 },
  { id: 'c-4', contractID: 'CNT-2025-004', talentId: 't-4', talentName: 'Morgan Taylor', licenseeId: 'sb-3', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productType: 'Training & accessories', annualSalary: ANNUAL_SALARY, basicSalary2026_27: ANNUAL_SALARY, basicSalary2027_28: ANNUAL_SALARY, royaltyPercent: 0.25, signingBonus: ANNUAL_PERFORMANCE_BONUS, skuMinimumGuaranteeAnnual: 350000, startDate: '2025-04-15', endDate: '2027-12-31', status: 'active', contractSummary: 'Accessories and training wear; 25% net sales revenue share.', contractSigningDate: '2025-03-28', organizationId: ORG_1 },
  { id: 'c-5', contractID: 'CNT-2025-005', talentId: 't-5', talentName: 'Casey Kim', licenseeId: 'sb-2', licensee: 'Metropolis Meteors American Football Pvt. Ltd.', productType: 'Multi-SKU apparel', annualSalary: ANNUAL_SALARY, basicSalary2026_27: ANNUAL_SALARY, basicSalary2027_28: ANNUAL_SALARY, royaltyPercent: 0.3, signingBonus: ANNUAL_PERFORMANCE_BONUS, skuMinimumGuaranteeAnnual: 300000, startDate: '2025-05-01', endDate: '2027-12-31', status: 'active', contractSummary: 'Multi-SKU bundle with tiered MG; 30% revenue share for vendor upload splits.', contractSigningDate: '2025-04-12', organizationId: ORG_1 },
]

/** Mirrors product-level revenue share % used by the central ledger (sales × contract royalty). */
const defaultRevenueShareContracts = [
  { id: 'rsc-1', organizationId: ORG_1, talentId: 't-1', talentName: 'Arjun "Ace" Verma', linkedContractId: 'c-1', title: 'RS — Jersey & apparel', summary: 'Engine row: net sales attributed to CNT-2025-001 at 28%.', signingDate: '2024-12-18', startDate: '2025-01-01', endDate: '2027-12-31', productType: 'Jersey & apparel endorsement', revenueSharePercent: 0.28, status: 'active' },
  { id: 'rsc-2', organizationId: ORG_1, talentId: 't-2', talentName: 'Jordan Lee', linkedContractId: 'c-2', title: 'RS — Equipment & kit', summary: 'Engine row: equipment SKUs at 26%.', signingDate: '2025-01-22', startDate: '2025-02-01', endDate: '2027-12-31', productType: 'Equipment & training kit', revenueSharePercent: 0.26, status: 'active' },
  { id: 'rsc-3', organizationId: ORG_1, talentId: 't-3', talentName: 'Sam Williams', linkedContractId: 'c-3', title: 'RS — Jersey Line B', summary: 'Vendor-aligned program at 27%.', signingDate: '2025-02-10', startDate: '2025-03-01', endDate: '2027-12-31', productType: 'Jersey Line B', revenueSharePercent: 0.27, status: 'active' },
]

const defaultMiscellaneousPayments = [
  { id: 'misc-1', organizationId: ORG_1, talentId: 't-1', talentName: 'Arjun "Ace" Verma', category: 'Appearance', amount: 250000, paymentStatus: 'paid', periodMonth: '2025-06', description: 'League media day appearance fee' },
  { id: 'misc-2', organizationId: ORG_1, talentId: 't-2', talentName: 'Jordan Lee', category: 'Stipend', amount: 120000, paymentStatus: 'pending', periodMonth: '2026-01', description: 'Training camp travel stipend' },
  { id: 'misc-3', organizationId: ORG_1, talentId: 't-4', talentName: 'Morgan Taylor', category: 'Other', amount: 75000, paymentStatus: 'pending', periodMonth: '2025-11', description: 'Community clinic honorarium' },
]

const defaultVendorImportBatches = []

/** Monthly base salary = annual ÷ 12 */
const MONTHLY_SALARY = Math.round(ANNUAL_SALARY / 12)

function eachMonthInclusive(fromYm, toYm) {
  const out = []
  const [ey, em] = toYm.split('-').map(Number)
  let y
  let m
  ;[y, m] = fromYm.split('-').map(Number)
  for (;;) {
    const ym = `${y}-${String(m).padStart(2, '0')}`
    out.push(ym)
    if (y === ey && m === em) break
    m += 1
    if (m > 12) {
      m = 1
      y += 1
    }
  }
  return out
}

/**
 * Payroll: 2025 from contract start month through Dec 2025, plus 2026 Jan–Mar only.
 * lastPaidYm = last month marked paid (yyyy-MM string compare).
 */
function buildSalaryPayments() {
  const rows = []
  const addMonths = (talentId, talentName, fromYm, toYm, lastPaidYm) => {
    for (const month of eachMonthInclusive(fromYm, toYm)) {
      rows.push({
        id: `sal-${talentId}-${month}`,
        talentId,
        talentName,
        month,
        salaryAmount: MONTHLY_SALARY,
        paymentStatus: month <= lastPaidYm ? 'paid' : 'pending',
        organizationId: ORG_1,
      })
    }
  }
  const specs = [
    { talentId: 't-1', talentName: 'Arjun "Ace" Verma', contractStart: '2025-01-01', lastPaidYm: '2026-01' },
    { talentId: 't-2', talentName: 'Jordan Lee', contractStart: '2025-02-01', lastPaidYm: '2025-11' },
    { talentId: 't-3', talentName: 'Sam Williams', contractStart: '2025-03-01', lastPaidYm: '2025-10' },
    { talentId: 't-4', talentName: 'Morgan Taylor', contractStart: '2025-04-15', lastPaidYm: '2025-12' },
    { talentId: 't-5', talentName: 'Casey Kim', contractStart: '2025-05-01', lastPaidYm: '2025-12' },
  ]
  for (const s of specs) {
    const startYm = s.contractStart.slice(0, 7)
    addMonths(s.talentId, s.talentName, startYm, '2025-12', s.lastPaidYm)
    addMonths(s.talentId, s.talentName, '2026-01', '2026-03', s.lastPaidYm)
  }
  return rows
}

const defaultSalaryPayments = buildSalaryPayments()

const defaultSigningBonuses = [
  { id: 'sb-1', talentId: 't-1', talentName: 'Arjun "Ace" Verma', amount: ANNUAL_PERFORMANCE_BONUS, signingDate: '2025-01-15', releaseDate: '2025-01-29', status: 'paid', organizationId: ORG_1 },
  { id: 'sb-2', talentId: 't-2', talentName: 'Jordan Lee', amount: ANNUAL_PERFORMANCE_BONUS, signingDate: '2025-02-20', releaseDate: '2025-03-06', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-3', talentId: 't-3', talentName: 'Sam Williams', amount: ANNUAL_PERFORMANCE_BONUS, signingDate: '2025-03-10', releaseDate: '2025-03-24', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-4', talentId: 't-4', talentName: 'Morgan Taylor', amount: ANNUAL_PERFORMANCE_BONUS, signingDate: '2025-04-05', releaseDate: '2025-04-21', status: 'pending', organizationId: ORG_1 },
  { id: 'sb-5', talentId: 't-5', talentName: 'Casey Kim', amount: ANNUAL_PERFORMANCE_BONUS, signingDate: '2025-05-12', releaseDate: '2025-05-28', status: 'pending', organizationId: ORG_1 },
]

const METEORS = 'Metropolis Meteors American Football Pvt. Ltd.'
const defaultSales = [
  /* t-1 Arjun — contract ~28% RS; ledger month = sale date; aligns with invoices where noted */
  { id: 's-1', sku: 'SKU-001', licenseeId: 'sb-1', licensee: METEORS, productDescription: 'Jersey Line A', talentNames: 'Arjun "Ace" Verma', talentIds: ['t-1'], country: 'USA', unitsSold: 1000, effectiveUnitSalesPrice: 45, netSales: 45000, date: '2025-01-20', organizationId: ORG_1 },
  { id: 's-2', sku: 'SKU-002', licenseeId: 'sb-1', licensee: METEORS, productDescription: 'Jersey Line B', talentNames: 'Jordan Lee', talentIds: ['t-2'], country: 'UK', unitsSold: 500, effectiveUnitSalesPrice: 38, netSales: 19000, date: '2025-03-18', organizationId: ORG_1 },
  { id: 's-3', sku: 'SKU-003', licenseeId: 'sb-1', licensee: METEORS, productDescription: 'Equipment Pack', talentNames: 'Arjun "Ace" Verma', talentIds: ['t-1'], country: 'USA', unitsSold: 800, effectiveUnitSalesPrice: 120, netSales: 96000, date: '2025-06-22', organizationId: ORG_1 },
  { id: 's-4', sku: 'SKU-004', licenseeId: 'sb-2', licensee: METEORS, productDescription: 'Accessories', talentNames: 'Sam Williams', talentIds: ['t-3'], country: 'Canada', unitsSold: 1200, effectiveUnitSalesPrice: 25, netSales: 30000, date: '2025-10-12', organizationId: ORG_1 },
  { id: 's-5', sku: 'SKU-005', licenseeId: 'sb-3', licensee: METEORS, productDescription: 'Training Kit Pro', talentNames: 'Morgan Taylor', talentIds: ['t-4'], country: 'USA', unitsSold: 350, effectiveUnitSalesPrice: 89, netSales: 31150, date: '2025-09-08', organizationId: ORG_1 },
  { id: 's-6', sku: 'SKU-006', licenseeId: 'sb-2', licensee: METEORS, productDescription: 'Spring drop', talentNames: 'Casey Kim', talentIds: ['t-5'], country: 'USA', unitsSold: 400, effectiveUnitSalesPrice: 42.5, netSales: 17000, date: '2026-02-14', organizationId: ORG_1 },
  { id: 's-7', sku: 'SKU-007', licenseeId: 'sb-1', licensee: METEORS, productDescription: 'Q1 jersey run', talentNames: 'Arjun "Ace" Verma', talentIds: ['t-1'], country: 'USA', unitsSold: 600, effectiveUnitSalesPrice: 50, netSales: 30000, date: '2026-01-18', organizationId: ORG_1 },
  { id: 's-8', sku: 'SKU-008', licenseeId: 'sb-1', licensee: METEORS, productDescription: 'Feb equipment', talentNames: 'Jordan Lee', talentIds: ['t-2'], country: 'UK', unitsSold: 200, effectiveUnitSalesPrice: 95, netSales: 19000, date: '2026-02-25', organizationId: ORG_1 },
  { id: 's-9', sku: 'SKU-009', licenseeId: 'sb-2', licensee: METEORS, productDescription: 'Mar apparel', talentNames: 'Sam Williams', talentIds: ['t-3'], country: 'USA', unitsSold: 900, effectiveUnitSalesPrice: 28, netSales: 25200, date: '2026-03-20', organizationId: ORG_1 },
]

const defaultInvoices = [
  { id: 'inv-1', invoiceID: 'INV-2025-001', talentName: 'Arjun "Ace" Verma', talentId: 't-1', royaltyAmount: 12600, netSales: 45000, date: '2025-01-31', issueDate: '2025-01-31', status: 'paid', paidAmount: 12600, organizationId: ORG_1 },
  { id: 'inv-2', invoiceID: 'INV-2025-002', talentName: 'Jordan Lee', talentId: 't-2', royaltyAmount: 4940, netSales: 19000, date: '2025-03-31', issueDate: '2025-03-31', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-3', invoiceID: 'INV-2025-003', talentName: 'Arjun "Ace" Verma', talentId: 't-1', royaltyAmount: 26880, netSales: 96000, date: '2025-06-30', issueDate: '2025-06-30', status: 'paid', paidAmount: 26880, organizationId: ORG_1 },
  { id: 'inv-4', invoiceID: 'INV-2025-004', talentName: 'Sam Williams', talentId: 't-3', royaltyAmount: 8100, netSales: 30000, date: '2025-10-31', issueDate: '2025-10-31', status: 'paid', paidAmount: 8100, organizationId: ORG_1 },
  { id: 'inv-5', invoiceID: 'INV-2025-005', talentName: 'Morgan Taylor', talentId: 't-4', royaltyAmount: 7788, netSales: 31150, date: '2025-09-30', issueDate: '2025-09-30', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-6', invoiceID: 'INV-2026-001', talentName: 'Arjun "Ace" Verma', talentId: 't-1', royaltyAmount: 8400, netSales: 30000, date: '2026-01-31', issueDate: '2026-01-31', status: 'paid', paidAmount: 8400, organizationId: ORG_1 },
  { id: 'inv-7', invoiceID: 'INV-2026-002', talentName: 'Jordan Lee', talentId: 't-2', royaltyAmount: 4940, netSales: 19000, date: '2026-02-28', issueDate: '2026-02-28', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-8', invoiceID: 'INV-2026-003', talentName: 'Casey Kim', talentId: 't-5', royaltyAmount: 5100, netSales: 17000, date: '2026-02-28', issueDate: '2026-02-28', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
  { id: 'inv-9', invoiceID: 'INV-2026-004', talentName: 'Sam Williams', talentId: 't-3', royaltyAmount: 6804, netSales: 25200, date: '2026-03-31', issueDate: '2026-03-31', status: 'pending', paidAmount: 0, organizationId: ORG_1 },
]

const defaultRoyaltyPayments = []

const defaultPaymentLedger = [
  { id: 'ledger-1', date: '2025-02-01', transactionId: 'TXN-93847001', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Salary', amount: MONTHLY_SALARY, paymentMethod: 'card', status: 'completed', details: 'Salary Jan 2025 (monthly)', organizationId: ORG_1 },
  { id: 'ledger-2', date: '2025-01-25', transactionId: 'TXN-93847002', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Signing Bonus', amount: ANNUAL_PERFORMANCE_BONUS, paymentMethod: 'card', status: 'completed', details: 'Performance bonus — $180k/mo payroll (2025 Jan–Dec & 2026 Jan–Mar); annual pool 2.16M', organizationId: ORG_1 },
  { id: 'ledger-3', date: '2025-02-08', transactionId: 'TXN-93847003', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Royalty', amount: 12600, paymentMethod: 'upi', status: 'completed', details: 'Revenue share Jan 2025', organizationId: ORG_1 },
  { id: 'ledger-4', date: '2026-02-01', transactionId: 'TXN-93847004', talentId: 't-1', talentName: 'Arjun "Ace" Verma', paymentType: 'Salary', amount: MONTHLY_SALARY, paymentMethod: 'card', status: 'completed', details: 'Salary Jan 2026 (monthly)', organizationId: ORG_1 },
  { id: 'ledger-5', date: '2025-12-02', transactionId: 'TXN-93847005', talentId: 't-2', talentName: 'Jordan Lee', paymentType: 'Salary', amount: MONTHLY_SALARY, paymentMethod: 'card', status: 'completed', details: 'Salary Nov 2025 (monthly)', organizationId: ORG_1 },
]

export function getSeedData() {
  return {
    organizations: defaultOrganizations,
    users: defaultUsers,
    talents: defaultTalents,
    sportsBusinesses: defaultSportsBusinesses,
    sponsorshipCompanies: defaultSponsorshipCompanies,
    contracts: defaultContracts,
    salaryPayments: defaultSalaryPayments,
    signingBonuses: defaultSigningBonuses,
    sales: defaultSales,
    invoices: defaultInvoices,
    royaltyPayments: defaultRoyaltyPayments,
    paymentLedger: defaultPaymentLedger,
    revenueShareContracts: defaultRevenueShareContracts,
    vendorImportBatches: defaultVendorImportBatches,
    miscellaneousPayments: defaultMiscellaneousPayments,
  }
}

export function seedDatabase() {
  const existing = localStorage.getItem(STORAGE_KEY)
  if (existing) return JSON.parse(existing)
  const data = getSeedData()
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  return data
}

export function resetDatabase() {
  localStorage.removeItem(STORAGE_KEY)
  return seedDatabase()
}

export { STORAGE_KEY }
