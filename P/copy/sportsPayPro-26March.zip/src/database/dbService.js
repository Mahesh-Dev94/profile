/**
 * Database service — uses sql.js + IndexedDB when available, falls back to localStorage.
 * Call initDatabase() before first render (see main.jsx).
 */

import {
  initSqliteDb,
  getAll as sqlGetAll,
  getById as sqlGetById,
  getAllByOrganization as sqlGetAllByOrganization,
  create as sqlCreate,
  update as sqlUpdate,
  remove as sqlRemove,
  getDbRaw as sqlGetDbRaw,
  resetDb as sqlResetDb,
  isSqliteReady,
} from './sqliteDb'
import { seedDatabase, resetDatabase, STORAGE_KEY } from './seedData'

// Legacy localStorage backend (used when sql.js fails or isn't ready)
function getDb() {
  let db = null
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) db = JSON.parse(raw)
  } catch (_) {}
  if (!db || typeof db !== 'object') {
    db = seedDatabase()
  }
  if (!Array.isArray(db.organizations)) db.organizations = []
  if (!Array.isArray(db.salaryPayments)) db.salaryPayments = []
  if (!Array.isArray(db.signingBonuses)) db.signingBonuses = []
  if (!Array.isArray(db.royaltyPayments)) db.royaltyPayments = []
  if (!Array.isArray(db.paymentLedger)) db.paymentLedger = []
  if (!Array.isArray(db.invoices)) db.invoices = []
  if (!Array.isArray(db.talentMonthPayments)) db.talentMonthPayments = []
  if (!Array.isArray(db.revenueShareContracts)) db.revenueShareContracts = []
  if (!Array.isArray(db.vendorImportBatches)) db.vendorImportBatches = []
  if (!Array.isArray(db.miscellaneousPayments)) db.miscellaneousPayments = []
  return db
}

function saveDb(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db))
  return db
}

const ORG_COLLECTIONS = [
  'talents',
  'sponsorshipCompanies',
  'sportsBusinesses',
  'contracts',
  'sales',
  'invoices',
  'salaryPayments',
  'signingBonuses',
  'royaltyPayments',
  'paymentLedger',
  'talentMonthPayments',
  'revenueShareContracts',
  'vendorImportBatches',
  'miscellaneousPayments',
]

const PAYOUT_SNAPSHOT_SOURCE_COLLECTIONS = new Set(['salaryPayments', 'signingBonuses', 'invoices', 'sales', 'contracts'])

function notifyPayoutSnapshotSourceChanged(collection, record) {
  if (!PAYOUT_SNAPSHOT_SOURCE_COLLECTIONS.has(collection)) return
  const organizationId = record?.organizationId
  if (!organizationId) return
  import('../repositories/talentMonthPaymentSnapshots.js').then((m) => {
    m.scheduleRebuildTalentMonthPaymentSnapshots(organizationId)
  })
}

export function getAll(collection) {
  if (isSqliteReady()) return sqlGetAll(collection)
  const db = getDb()
  const list = db[collection]
  return Array.isArray(list) ? [...list] : []
}

export function getById(collection, id) {
  if (isSqliteReady()) return sqlGetById(collection, id)
  const list = getAll(collection)
  return list.find((item) => item.id === id) ?? null
}

export function getAllByOrganization(collection, organizationId) {
  if (isSqliteReady()) return sqlGetAllByOrganization(collection, organizationId)
  const list = getAll(collection)
  if (!organizationId || !ORG_COLLECTIONS.includes(collection)) return list
  return list.filter((item) => item.organizationId === organizationId)
}

export function create(collection, data) {
  if (isSqliteReady()) {
    const record = sqlCreate(collection, data)
    notifyPayoutSnapshotSourceChanged(collection, record)
    return record
  }
  const db = getDb()
  if (!Array.isArray(db[collection])) db[collection] = []
  const id = data.id || `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
  const record = { ...data, id }
  db[collection].push(record)
  saveDb(db)
  notifyPayoutSnapshotSourceChanged(collection, record)
  return record
}

export function update(collection, id, data) {
  if (isSqliteReady()) {
    const updated = sqlUpdate(collection, id, data)
    if (updated) notifyPayoutSnapshotSourceChanged(collection, updated)
    return updated
  }
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return null
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return null
  const updated = { ...list[index], ...data, id }
  list[index] = updated
  saveDb(db)
  notifyPayoutSnapshotSourceChanged(collection, updated)
  return updated
}

export function remove(collection, id) {
  if (isSqliteReady()) {
    const prev = sqlGetById(collection, id)
    const ok = sqlRemove(collection, id)
    if (ok && prev) notifyPayoutSnapshotSourceChanged(collection, prev)
    return ok
  }
  const db = getDb()
  const list = db[collection]
  if (!Array.isArray(list)) return false
  const index = list.findIndex((item) => item.id === id)
  if (index === -1) return false
  const prev = list[index]
  list.splice(index, 1)
  saveDb(db)
  notifyPayoutSnapshotSourceChanged(collection, prev)
  return true
}

export function getDbRaw() {
  if (isSqliteReady()) return sqlGetDbRaw()
  return getDb()
}

export function resetDb() {
  const out = isSqliteReady() ? sqlResetDb() : resetDatabase()
  import('../repositories/talentMonthPaymentSnapshots.js').then((m) => {
    try {
      m.rebuildAllTalentMonthPaymentSnapshots()
    } catch (e) {
      console.warn('Snapshot rebuild after reset failed', e)
    }
  })
  return out
}

/** Always resolves; on sql.js failure we use localStorage so the app still runs. */
export function initDatabase() {
  return initSqliteDb()
    .catch((err) => {
      console.warn('SQLite init failed, using localStorage:', err)
    })
    .then(() => {
      import('../repositories/talentMonthPaymentSnapshots.js').then((m) => {
        try {
          const SNAP_V = '5'
          const needVersion =
            typeof localStorage !== 'undefined' &&
            localStorage.getItem('talent_month_snap_v') !== SNAP_V
          if (needVersion || getAll('talentMonthPayments').length === 0) {
            m.rebuildAllTalentMonthPaymentSnapshots()
            if (typeof localStorage !== 'undefined') {
              localStorage.setItem('talent_month_snap_v', SNAP_V)
            }
          }
        } catch (e) {
          console.warn('talentMonthPayments initial snapshot rebuild failed', e)
        }
      })
    })
}

export { isSqliteReady }
