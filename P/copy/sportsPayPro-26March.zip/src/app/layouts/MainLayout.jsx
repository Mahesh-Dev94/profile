import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { useAuth } from '../../context/AuthContext'
import { useAppStore } from '../../context/AppStore'
import { Button } from '../../components/ui/button'
import {
  LayoutDashboard,
  FileText,
  Building2,
  Receipt,
  Upload,
  BarChart3,
  Menu,
  ChevronLeft,
  ChevronDown,
  Gift,
  CreditCard,
  FileSpreadsheet,
  TrendingUp,
  BookOpen,
  User,
  Calculator,
  Store,
  Inbox,
} from 'lucide-react'
import { cn } from '../../utils/cn'
import { portalRoleForTargetPath, userMatchesPortalRole } from '../../utils/portalSession'
import { ResetDemoDatabaseControl } from '../../components/ResetDemoDatabaseControl'

const adminNav = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/admin/organizations', label: 'Organizations', icon: Building2 },
  { to: '/admin/contracts', label: 'Contracts', icon: FileText },
  { to: '/admin/reconciliation', label: 'Reconciliation', icon: FileSpreadsheet },
  { to: '/admin/forecast', label: 'Forecast', icon: TrendingUp },
  { to: '/sponsorship/dashboard', label: 'Sport Business', icon: CreditCard },
]

const sportBusinessNav = [
  { to: '/sponsorship/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sponsorship/talents', label: 'Talents', icon: User },
  { to: '/sponsorship/vendor-uploads', label: 'Vendor', icon: Inbox },
  {
    to: '/sponsorship/payments',
    label: 'Payments',
    icon: CreditCard,
    children: [
      { to: '/sponsorship/payments', label: 'Payment summary', icon: BarChart3 },
      { to: '/sponsorship/payments/release-payment', label: 'Release payment', icon: CreditCard },
      { to: '/sponsorship/payments/ledger', label: 'Payment ledger', icon: BookOpen },
    ],
  },
  { to: '/sponsorship/journal-entry', label: 'Journal entry', icon: Calculator },
]

const talentPlayersNav = [
  { to: '/talent/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/talent/salary', label: 'Salary', icon: Receipt },
  { to: '/talent/signing-bonus', label: 'Performance Bonus', icon: Gift },
  { to: '/talent/royalties', label: 'Revenue share', icon: TrendingUp },
]

const vendorPortalNav = [
  { to: '/partner/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/partner/upload-sales', label: 'Upload Sales', icon: Upload },
  { to: '/partner/sales', label: 'Sales', icon: BarChart3 },
  { to: '/partner/contracts', label: 'Contracts', icon: FileText },
]

function isPaymentSectionActive(pathname) {
  return pathname.startsWith('/sponsorship/payments')
}

function SportBusinessNavItems({ location, sidebarOpen, paymentsSubOpen, setPaymentsSubOpen, onPortalNavigate }) {
  const navClick = (to) => (e) => {
    e.preventDefault()
    onPortalNavigate(to)
  }
  return sportBusinessNav.map((item) => {
    const Icon = item.icon
    const isPaymentParentActive = item.to === '/sponsorship/payments' && isPaymentSectionActive(location.pathname)
    const isTalentSectionActive =
      item.to === '/sponsorship/talents' &&
      (location.pathname === '/sponsorship/talents' || location.pathname.startsWith('/sponsorship/talents/'))
    const isVendorFromClubNav =
      item.to === '/sponsorship/vendor-uploads' && location.pathname.startsWith('/sponsorship/vendor')
    const isParentActive =
      location.pathname === item.to ||
      isPaymentParentActive ||
      (item.children && location.pathname.startsWith(`${item.to}/`)) ||
      isTalentSectionActive ||
      isVendorFromClubNav

    if (item.children) {
      if (!sidebarOpen) {
        return (
          <NavLink
            key={item.to}
            to={item.to}
            title={item.label}
            onClick={navClick(item.to)}
            className={({ isActive }) =>
              cn(
                'flex items-center justify-center rounded-lg px-2 py-2.5 text-xs font-medium',
                isActive || isParentActive ? 'bg-primary text-white shadow-sm' : 'text-gray-600 hover:bg-slate-100'
              )
            }
          >
            <Icon className="h-5 w-5 shrink-0" />
          </NavLink>
        )
      }
      return (
        <div key={item.to} className="min-w-0">
          <div className="flex items-stretch gap-0.5">
            <NavLink
              to={item.to}
              end={false}
              onClick={navClick(item.to)}
              className={({ isActive }) =>
                cn(
                  'flex min-w-0 flex-1 items-center gap-3 rounded-l-lg px-3 py-2 text-xs font-medium transition-colors',
                  isActive || isParentActive
                    ? 'bg-primary text-white shadow-sm'
                    : 'bg-slate-100/90 text-gray-800 hover:bg-slate-200/90'
                )
              }
            >
              <Icon className="h-5 w-5 shrink-0" />
              <span className="truncate">{item.label}</span>
            </NavLink>
            <button
              type="button"
              onClick={() => setPaymentsSubOpen((v) => !v)}
              className={cn(
                'flex w-9 shrink-0 items-center justify-center rounded-r-lg border border-l-0 border-primary/20 bg-white text-primary transition-colors hover:bg-slate-50',
                isPaymentParentActive && 'border-primary/30 bg-primary/10 text-primary'
              )}
              aria-expanded={paymentsSubOpen}
              aria-label={paymentsSubOpen ? 'Collapse payments submenu' : 'Expand payments submenu'}
            >
              <ChevronDown className={cn('h-4 w-4 transition-transform duration-200', paymentsSubOpen && 'rotate-180')} />
            </button>
          </div>
          {paymentsSubOpen && (
            <div className="ml-3 mt-1 space-y-0.5 border-l-2 border-accent/50 pl-3 py-0.5">
              {item.children.map((child) => {
                const ChildIcon = child.icon
                return (
                  <NavLink
                    key={child.to}
                    to={child.to}
                    end
                    onClick={navClick(child.to)}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium transition-colors',
                        isActive
                          ? 'bg-primary text-white shadow-sm ring-1 ring-primary/20'
                          : 'text-gray-600 hover:bg-slate-100 hover:text-gray-900'
                      )
                    }
                  >
                    <ChildIcon className="h-4 w-4 shrink-0" />
                    <span>{child.label}</span>
                  </NavLink>
                )
              })}
            </div>
          )}
        </div>
      )
    }

    return (
      <div key={item.to} className="min-w-0">
        <NavLink
          to={item.to}
          end
          onClick={navClick(item.to)}
          className={({ isActive }) =>
            cn(
              'flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium w-full transition-colors',
              isActive || isParentActive ? 'bg-primary text-white shadow-sm' : 'text-gray-700 hover:bg-slate-100'
            )
          }
        >
          <Icon className="h-5 w-5 shrink-0" />
          {sidebarOpen && <span>{item.label}</span>}
        </NavLink>
      </div>
    )
  })
}

function SimpleNavItems({ items, location, sidebarOpen, onPortalNavigate }) {
  return items.map((item) => {
    const Icon = item.icon
    return (
      <NavLink
        key={item.to}
        to={item.to}
        onClick={(e) => {
          e.preventDefault()
          onPortalNavigate(item.to)
        }}
        className={({ isActive }) =>
          cn(
            'flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition-colors',
            isActive ? 'bg-primary text-white shadow-sm' : 'text-gray-700 hover:bg-slate-100'
          )
        }
      >
        <Icon className="h-5 w-5 shrink-0" />
        {sidebarOpen && <span>{item.label}</span>}
      </NavLink>
    )
  })
}

function pageTitle(pathname) {
  const map = [
    ['/sponsorship/payments/release-payment', 'Release payment'],
    ['/sponsorship/payments/salary', 'Salary'],
    ['/sponsorship/payments/ledger', 'Payment ledger'],
    ['/sponsorship/signing-bonus', 'Performance Bonus'],
    ['/sponsorship/royalties', 'Revenue share'],
    ['/sponsorship/dashboard', 'Sport Business Dashboard'],
    ['/sponsorship/talents', 'Talents'],
    ['/sponsorship/payments', 'Payment summary'],
    ['/sponsorship/vendor-uploads', 'Vendor — Partner uploads'],
    ['/partner/upload-sales', 'Vendor — Upload sales'],
    ['/sponsorship/journal-entry', 'Journal entry'],
    ['/talent/dashboard', 'Talent Dashboard'],
    ['/partner/dashboard', 'Vendor Dashboard'],
  ]
  for (const [prefix, title] of map) {
    if (pathname === prefix) return title
  }
  if (pathname.startsWith('/sponsorship/talents/') && pathname !== '/sponsorship/talents') return 'Talent'
  if (pathname.startsWith('/admin')) return 'Admin'
  return 'Dashboard'
}

export function MainLayout() {
  const { user, loginAsFirstUserForRole } = useAuth()
  const navigate = useNavigate()
  const { sidebarOpen, toggleSidebar, bumpDataRevision } = useAppStore()
  const location = useLocation()
  const pathname = location.pathname
  const isAdminPath = pathname.startsWith('/admin')

  const [openAdminNav, setOpenAdminNav] = useState(true)
  const [openClubNav, setOpenClubNav] = useState(true)
  const [openTalentNav, setOpenTalentNav] = useState(true)
  const [openVendorNav, setOpenVendorNav] = useState(true)
  const [paymentsSubOpen, setPaymentsSubOpen] = useState(true)
  const pathnameRef = useRef(pathname)
  pathnameRef.current = pathname

  const onPortalNavigate = useCallback(
    (to) => {
      const pr = portalRoleForTargetPath(to)
      if (!pr) {
        navigate(to)
        return
      }
      if (userMatchesPortalRole(user, pr)) {
        navigate(to)
        return
      }
      const ok = loginAsFirstUserForRole(pr)
      if (ok.success) navigate(to)
      else toast.error('No seeded demo user for this portal.')
    },
    [user, loginAsFirstUserForRole, navigate]
  )

  useEffect(() => {
    if (isPaymentSectionActive(pathname)) setPaymentsSubOpen(true)
  }, [pathname])

  useEffect(() => {
    const onVendorImport = (e) => {
      const n = e.detail?.count
      bumpDataRevision()
      const onClub = pathnameRef.current.startsWith('/sponsorship')
      toast.success(
        onClub
          ? n != null
            ? `Partner uploaded sales (${n} rows). See Vendor → Partner uploads; revenue share updated.`
            : 'Partner sales upload completed. See Vendor → Partner uploads; revenue share updated.'
          : n != null
            ? `Vendor upload processed (${n} sales rows). Revenue share recalculated.`
            : 'Vendor upload processed. Revenue share recalculated.',
        { duration: 5200 }
      )
    }
    window.addEventListener('sports-pay-vendor-import', onVendorImport)
    return () => window.removeEventListener('sports-pay-vendor-import', onVendorImport)
  }, [bumpDataRevision])
  const portal = isAdminPath
    ? 'admin'
    : pathname.startsWith('/sponsorship')
      ? 'club'
      : pathname.startsWith('/talent')
        ? 'talent'
        : pathname.startsWith('/partner')
          ? 'vendor'
          : 'default'

  return (
    <div className="flex h-screen bg-white">
      <aside
        className={cn(
          'app-sidebar-surface flex flex-col border-r transition-all duration-200',
          portal === 'club' && 'app-sidebar-surface--club border-r-primary/15',
          portal === 'talent' && 'border-r-primary/15',
          portal === 'vendor' && 'border-r-accent/25',
          (portal === 'admin' || portal === 'default') && 'border-r-slate-200',
          sidebarOpen ? 'w-60' : 'w-16'
        )}
      >
        <div
          className={cn(
            'flex h-14 items-center justify-between border-b bg-white/80 px-3 backdrop-blur-sm',
            portal === 'club' && 'border-b-primary/15',
            portal === 'talent' && 'border-b-primary/12',
            portal === 'vendor' && 'border-b-accent/20',
            (portal === 'admin' || portal === 'default') && 'border-b-slate-200'
          )}
        >
          <Link
            to="/"
            className="flex items-center justify-center rounded-lg p-1 text-primary transition-opacity hover:opacity-90"
            aria-label="Sports Pay Pro — Welcome"
          >
            <CreditCard className="h-8 w-8 shrink-0" />
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="text-primary hover:bg-primary/10"
            onClick={toggleSidebar}
            aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          >
            {sidebarOpen ? <ChevronLeft className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
        <nav className="flex-1 space-y-3 overflow-y-auto p-2 scrollbar-thin [&_a]:outline-none [&_a]:select-none [&_a]:transition-[color,background-color,box-shadow] [&_a]:duration-150 [&_a]:ease-out [&_a]:[-webkit-tap-highlight-color:transparent]">
          {isAdminPath ? (
            <>
              {sidebarOpen && (
                <button
                  type="button"
                  className="nav-section-toggle"
                  onClick={() => setOpenAdminNav((v) => !v)}
                  aria-expanded={openAdminNav}
                >
                  <span className="text-3xs font-bold uppercase tracking-wider">Platform Admin</span>
                  <ChevronDown className={cn('nav-section-toggle__chevron', openAdminNav && 'rotate-180')} />
                </button>
              )}
              {(!sidebarOpen || openAdminNav) && (
                <div className="space-y-0.5">
                  <SimpleNavItems items={adminNav} location={location} sidebarOpen={sidebarOpen} onPortalNavigate={onPortalNavigate} />
                </div>
              )}
            </>
          ) : (
            <>
              {sidebarOpen && (
                <button
                  type="button"
                  className="nav-section-toggle"
                  onClick={() => setOpenClubNav((v) => !v)}
                  aria-expanded={openClubNav}
                >
                  <span className="text-3xs font-bold uppercase tracking-wider">Sport Business / Club</span>
                  <ChevronDown className={cn('nav-section-toggle__chevron', openClubNav && 'rotate-180')} />
                </button>
              )}
              {(!sidebarOpen || openClubNav) && (
                <div className="space-y-0.5">
                  <SportBusinessNavItems
                    location={location}
                    sidebarOpen={sidebarOpen}
                    paymentsSubOpen={paymentsSubOpen}
                    setPaymentsSubOpen={setPaymentsSubOpen}
                    onPortalNavigate={onPortalNavigate}
                  />
                </div>
              )}

              {sidebarOpen && (
                <>
                  <div className="mx-1 my-2 h-px bg-slate-200/90" aria-hidden />
                  <button
                    type="button"
                    className="nav-section-toggle"
                    onClick={() => setOpenTalentNav((v) => !v)}
                    aria-expanded={openTalentNav}
                  >
                    <span className="text-3xs font-bold uppercase tracking-wider">Talents / Players Portal</span>
                    <ChevronDown className={cn('nav-section-toggle__chevron', openTalentNav && 'rotate-180')} />
                  </button>
                </>
              )}
              {(!sidebarOpen || openTalentNav) && (
                <div className="space-y-0.5">
                  <SimpleNavItems items={talentPlayersNav} location={location} sidebarOpen={sidebarOpen} onPortalNavigate={onPortalNavigate} />
                </div>
              )}

              {sidebarOpen && (
                <>
                  <div className="mx-1 my-2 h-px bg-gradient-to-r from-transparent via-accent/25 to-transparent" aria-hidden />
                  <button
                    type="button"
                    className="nav-section-toggle nav-section-toggle--accent"
                    onClick={() => setOpenVendorNav((v) => !v)}
                    aria-expanded={openVendorNav}
                  >
                    <span className="text-3xs font-bold uppercase tracking-wider">Sponsorship / Vendor Portal</span>
                    <ChevronDown className={cn('nav-section-toggle__chevron', openVendorNav && 'rotate-180')} />
                  </button>
                </>
              )}
              {(!sidebarOpen || openVendorNav) && (
                <div className="space-y-0.5">
                  <SimpleNavItems items={vendorPortalNav} location={location} sidebarOpen={sidebarOpen} onPortalNavigate={onPortalNavigate} />
                </div>
              )}
            </>
          )}
        </nav>
        <div className="space-y-0.5 border-t border-slate-200/90 bg-white/60 p-2">
          <Link
            to="/home"
            className={cn(
              'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-2xs font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-primary',
              !sidebarOpen && 'justify-center px-0'
            )}
          >
            <Store className="h-4 w-4 shrink-0" />
            {sidebarOpen && <span>About / Home</span>}
          </Link>
          <ResetDemoDatabaseControl variant="sidebar" sidebarOpen={sidebarOpen} />
        </div>
      </aside>
      <div className="flex flex-1 flex-col overflow-hidden">
        <header
          className={cn(
            'portal-header-bar flex h-14 items-center justify-between px-6',
            portal === 'club' && 'portal-header-bar--club',
            portal === 'talent' && 'portal-header-bar--talent',
            portal === 'vendor' && 'portal-header-bar--vendor'
          )}
        >
          <h1
            className={cn(
              'text-xs font-semibold tracking-tight',
              portal === 'club' && 'font-bold text-primary-900',
              portal === 'talent' && 'text-primary',
              portal === 'vendor' && 'text-accent-700',
              (portal === 'admin' || portal === 'default') && 'text-slate-800'
            )}
          >
            {pageTitle(location.pathname)}
          </h1>
          <div className="max-w-[220px] truncate text-right text-2xs text-slate-500" title={user?.email}>
            <span className="font-medium text-slate-700">{user?.name || 'Session'}</span>
            <span className="block text-3xs uppercase tracking-wide text-primary">
              Demo session · no login
            </span>
          </div>
        </header>
        <main
          className={cn(
            'flex-1 overflow-auto p-6',
            portal === 'club' && 'portal-main-surface--club',
            portal === 'talent' && 'portal-main-surface--talent',
            portal === 'vendor' && 'portal-main-surface--vendor',
            portal === 'admin' && 'portal-main-surface--admin',
            portal === 'default' && 'portal-main-surface'
          )}
        >
          <Outlet />
        </main>
      </div>
    </div>
  )
}
