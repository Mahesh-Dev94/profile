import React, { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { getAll } from '../../database/dbService'
import { userMatchesPortalRole } from '../../utils/portalSession'
import { CreditCard, User, Building2, ArrowRight, ShieldCheck } from 'lucide-react'
import { Button } from '../../components/ui/button'
import { ResetDemoDatabaseControl } from '../../components/ResetDemoDatabaseControl'

const portals = [
  {
    id: 'sports_business',
    role: 'sponsorship_admin',
    title: 'Sport Business / Club',
    description: 'Payments, revenue share, contracts, and talent summaries — unified club operations.',
    icon: CreditCard,
    path: '/sponsorship/dashboard',
    demoPassword: 'admin123',
  },
  {
    id: 'talent',
    role: 'talent',
    title: 'Talents / Players Portal',
    description: 'Salary, performance bonus, and revenue share visibility for each player.',
    icon: User,
    path: '/talent/dashboard',
    demoPassword: 'talent123',
  },
  {
    id: 'partner',
    role: 'vendor_partner',
    title: 'Sponsorship / Vendor Portal',
    description: 'Upload sales files, review records, and push revenue that updates club calculations.',
    icon: Building2,
    path: '/partner/dashboard',
    demoPassword: 'admin123',
  },
]

function getSampleUserForRole(users, role) {
  if (!Array.isArray(users)) return null
  if (role === 'sponsorship_admin') {
    return (
      users.find((u) => ['sponsorship_admin', 'platform_admin', 'finance_manager', 'sponsor_manager'].includes(u.role)) ||
      null
    )
  }
  if (role === 'talent') return users.find((u) => u.role === 'talent') || null
  if (role === 'vendor_partner') {
    return users.find((u) => u.role === 'vendor_partner' || u.role === 'partner') || null
  }
  return null
}

export function LandingPage() {
  const navigate = useNavigate()
  const { user, loginAsFirstUserForRole } = useAuth()
  const users = useMemo(() => getAll('users'), [])

  const handleEnter = (portal) => {
    if (user && userMatchesPortalRole(user, portal.role)) {
      navigate(portal.path)
      return
    }
    const ok = loginAsFirstUserForRole(portal.role)
    if (ok.success) navigate(portal.path)
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#051a2e] text-white">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse 95% 55% at 50% -15%, rgba(61, 122, 173, 0.28) 0%, transparent 58%),
            radial-gradient(ellipse 70% 45% at 100% 0%, rgba(249, 115, 22, 0.14) 0%, transparent 50%),
            radial-gradient(ellipse 85% 55% at 0% 100%, rgba(7, 36, 56, 0.95) 0%, transparent 55%),
            linear-gradient(168deg, #0a2540 0%, #051a2e 38%, #061525 100%)
          `,
        }}
        aria-hidden
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
        aria-hidden
      />
      <div className="relative mx-auto max-w-6xl px-6 py-12 sm:py-16">
        <header className="mb-12 text-center">
          <div className="mb-5 inline-flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-white/20 bg-white/10 shadow-lg backdrop-blur-sm">
            <CreditCard className="h-8 w-8 text-accent" aria-hidden />
          </div>
          <h1 className="mb-2 text-sm font-bold uppercase tracking-[0.2em] text-accent">Sports Pay Pro</h1>
          <p className="mx-auto max-w-2xl text-lg font-semibold tracking-tight text-white sm:text-xl">
            Sports Business Payment &amp; Revenue Share
          </p>
          <p className="mx-auto mt-3 max-w-xl text-xs leading-relaxed text-white/75">
            Welcome — choose a portal below. Demo sessions use seeded credentials; revenue share updates flow from vendor uploads
            through the central ledger to dashboards and payment summary.
          </p>
          {user && (
            <p className="mt-4 text-2xs text-white/70">
              Active session: <span className="font-semibold text-white">{user.name}</span>
              <span className="mx-2 text-white/40">·</span>
              <button
                type="button"
                onClick={() =>
                  navigate(
                    user.role === 'talent'
                      ? '/talent/dashboard'
                      : user.role === 'vendor_partner' || user.role === 'partner'
                        ? '/partner/dashboard'
                        : '/sponsorship/dashboard'
                  )
                }
                className="font-semibold text-accent underline-offset-4 hover:underline"
              >
                Resume dashboard
              </button>
            </p>
          )}
        </header>

        <section
          className="mb-10 rounded-2xl border border-white/20 bg-white/[0.06] p-5 shadow-xl shadow-black/20 backdrop-blur-md sm:p-6"
          aria-labelledby="demo-credentials-heading"
        >
          <div className="flex flex-wrap items-center gap-2 text-left">
            <ShieldCheck className="h-5 w-5 shrink-0 text-accent" aria-hidden />
            <h2 id="demo-credentials-heading" className="text-xs font-bold uppercase tracking-wider text-white">
              Default demo credentials
            </h2>
          </div>
          <p className="mt-2 text-2xs leading-relaxed text-white/65">
            Shown for local / demo use only. The app auto-restores a club session if you navigate internally; use the cards below to
            switch portals explicitly.
          </p>
          <ul className="mt-4 grid gap-3 sm:grid-cols-3">
            {portals.map((p) => {
              const sample = getSampleUserForRole(users, p.role)
              return (
                <li
                  key={p.id}
                  className="rounded-xl border border-white/15 bg-[#0B3C5D]/55 px-3 py-3 text-2xs text-white/85"
                >
                  <p className="font-semibold text-white">{p.title}</p>
                  {sample ? (
                    <>
                      <p className="mt-2 font-mono text-[11px] text-white/90">{sample.email}</p>
                      <p className="mt-1 text-white/55">
                        Password: <span className="font-mono text-accent">{p.demoPassword}</span>
                      </p>
                    </>
                  ) : (
                    <p className="mt-2 text-white/50">No seeded user</p>
                  )}
                </li>
              )
            })}
          </ul>
        </section>

        <section className="grid gap-8 md:grid-cols-3">
          {portals.map((portal) => {
            const Icon = portal.icon
            return (
              <div
                key={portal.id}
                className="group relative flex flex-col rounded-2xl border border-white/18 bg-white/[0.07] p-6 shadow-lg shadow-black/15 backdrop-blur-md transition-all duration-300 hover:border-white/35 hover:bg-white/[0.11]"
              >
                <div className="mb-4 flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-accent/35 bg-accent/15 text-accent transition-opacity group-hover:opacity-95">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h2 className="text-sm font-semibold tracking-tight text-white">{portal.title}</h2>
                </div>
                <p className="mb-6 flex-1 text-2xs leading-relaxed text-white/70">{portal.description}</p>
                {/* <Button
                  onClick={() => handleEnter(portal)}
                  className="mt-auto w-full border-0 bg-accent font-semibold text-white transition-opacity hover:bg-accent/90 hover:opacity-100"
                >
                  Enter portal <ArrowRight className="ml-2 h-4 w-4" />
                </Button> */}
              </div>
            )
          })}
        </section>

        <footer className="mt-16 space-y-6 text-center">
        <Button
                  onClick={() => handleEnter({
                    id: 'sports_business',
                    role: 'sponsorship_admin',
                    title: 'Sport Business / Club',
                    description: 'Payments, revenue share, contracts, and talent summaries — unified club operations.',
                    icon: CreditCard,
                    path: '/sponsorship/dashboard',
                    demoPassword: 'admin123',
                  })}
                  className="mt-auto w-full border-0 bg-accent font-semibold text-white transition-opacity hover:bg-accent/90 hover:opacity-100"
                >
                  Enter portal <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
          <div className="flex justify-center">
            
            <ResetDemoDatabaseControl variant="landing" />
          </div>
          <p className="text-3xs text-white/45">
            Sports Pay Pro — modular Sport Business, Talent, and Vendor experiences
          </p>
        </footer>
      </div>
    </div>
  )
}
