import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { MainLayout } from './app/layouts/MainLayout'
import { ProtectedRoute } from './app/routes/ProtectedRoute'
import { ClubDashboardPage } from './modules/sport-business-club/ClubDashboardPage'
import { ClubSportsBusinessesPage } from './modules/sport-business-club/ClubSportsBusinessesPage'
import { ClubSportPartnersPage } from './modules/sport-business-club/ClubSportPartnersPage'
import { ContractsPage } from './modules/contracts/ContractsPage'
import { InvoicesPage } from './modules/invoices/InvoicesPage'
import { ClubPerformanceBonusPage } from './modules/sport-business-club/ClubPerformanceBonusPage'
import { ClubPaymentLedgerPage } from './modules/sport-business-club/ClubPaymentLedgerPage'
import { ClubRoyaltiesPage } from './modules/sport-business-club/ClubRoyaltiesPage'
import { ClubReleasePaymentPage } from './modules/sport-business-club/ClubReleasePaymentPage'
import { ClubAccountingPortalPage } from './modules/sport-business-club/ClubAccountingPortalPage'
import { ClubPaymentSummaryPage } from './modules/sport-business-club/ClubPaymentSummaryPage'
import { ClubVendorUploadsPage } from './modules/sport-business-club/ClubVendorUploadsPage'
import { ClubSalaryPage } from './modules/sport-business-club/ClubSalaryPage'
import { ClubTalentsListPage } from './modules/sport-business-club/ClubTalentsListPage'
import { ClubTalentDetailPage } from './modules/sport-business-club/ClubTalentDetailPage'
import { TalentDashboard } from './modules/talents-players-portal/TalentDashboard'
import { TalentSalaryPage } from './modules/talents-players-portal/TalentSalaryPage'
import { TalentRoyaltiesPage } from './modules/talents-players-portal/TalentRoyaltiesPage'
import { TalentSigningBonusPage } from './modules/talents-players-portal/TalentSigningBonusPage'
import { PartnerDashboard } from './modules/sponsorship-vendor-portal/PartnerDashboard'
import { PartnerUploadSalesPage } from './modules/sponsorship-vendor-portal/PartnerUploadSalesPage'
import { PartnerSalesPage } from './modules/sponsorship-vendor-portal/PartnerSalesPage'
import { PartnerContractsPage } from './modules/sponsorship-vendor-portal/PartnerContractsPage'
import { AdminDashboard } from './modules/admin/AdminDashboard'
import { OrganizationsPage } from './modules/admin/OrganizationsPage'
import { AdminContractsPage } from './modules/admin/AdminContractsPage'
import { ReconciliationPage } from './modules/admin/ReconciliationPage'
import { ForecastPage } from './modules/admin/ForecastPage'
import { LandingPage } from './app/pages/LandingPage'

/** Demo: club staff can browse Talent & Vendor portals from the unified menu. */
const TALENT_PORTAL_ROLES = ['talent', 'sponsorship_admin', 'sponsor_manager', 'platform_admin', 'finance_manager']
const VENDOR_PORTAL_ROLES = ['vendor_partner', 'partner', 'sponsorship_admin', 'sponsor_manager', 'platform_admin', 'finance_manager']

export default function App() {

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/sponsorship/dashboard" replace />} />

      <Route path="/admin" element={
        <ProtectedRoute allowedRoles={['platform_admin', 'finance_manager']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="organizations" element={<OrganizationsPage />} />
        <Route path="contracts" element={<AdminContractsPage />} />
        <Route path="reconciliation" element={<ReconciliationPage />} />
        <Route path="forecast" element={<ForecastPage />} />
      </Route>

      <Route path="/sponsorship" element={
        <ProtectedRoute allowedRoles={['sponsor_manager', 'platform_admin', 'finance_manager', 'sponsorship_admin']}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<ClubDashboardPage />} />
        <Route path="talents" element={<ClubTalentsListPage />} />
        <Route path="talents/contracts" element={<ContractsPage />} />
        <Route path="talents/:talentId" element={<ClubTalentDetailPage />} />
        <Route path="contracts" element={<Navigate to="/sponsorship/talents/contracts" replace />} />
        <Route path="payments" element={<ClubPaymentSummaryPage />} />
        <Route path="payments/overview" element={<Navigate to="/sponsorship/payments" replace />} />
        <Route path="payments/salary" element={<ClubSalaryPage />} />
        <Route path="payments/release-payment" element={<ClubReleasePaymentPage />} />
        <Route path="payments/ledger" element={<ClubPaymentLedgerPage />} />
        <Route path="salary" element={<Navigate to="/sponsorship/payments" replace />} />
        <Route path="release-payment" element={<Navigate to="/sponsorship/payments/release-payment" replace />} />
        <Route path="ledger" element={<Navigate to="/sponsorship/payments/ledger" replace />} />
        <Route path="signing-bonus" element={<ClubPerformanceBonusPage />} />
        <Route path="journal-entry" element={<ClubAccountingPortalPage />} />
        <Route path="businesses" element={<ClubSportsBusinessesPage />} />
        <Route path="companies" element={<ClubSportPartnersPage />} />
        <Route path="invoices" element={<InvoicesPage />} />
        <Route path="royalties" element={<ClubRoyaltiesPage />} />
        <Route path="vendor-uploads" element={<ClubVendorUploadsPage />} />
      </Route>

      <Route path="/talent" element={
        <ProtectedRoute allowedRoles={TALENT_PORTAL_ROLES}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<TalentDashboard />} />
        <Route path="salary" element={<TalentSalaryPage />} />
        <Route path="signing-bonus" element={<TalentSigningBonusPage />} />
        <Route path="royalties" element={<TalentRoyaltiesPage />} />
      </Route>

      <Route path="/partner" element={
        <ProtectedRoute allowedRoles={VENDOR_PORTAL_ROLES}>
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<PartnerDashboard />} />
        <Route path="upload-sales" element={<PartnerUploadSalesPage />} />
        <Route path="sales" element={<PartnerSalesPage />} />
        <Route path="contracts" element={<PartnerContractsPage />} />
      </Route>

      <Route path="/" element={<LandingPage />} />
      <Route path="/home" element={<LandingPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
